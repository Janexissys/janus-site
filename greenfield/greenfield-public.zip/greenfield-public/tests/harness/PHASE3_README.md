# Phase 3: Behavioral Comparison

This directory contains the Phase 3 comparison framework for validating greenfield v6.0 implementation against the plan requirements.

## Overview

Phase 3 focuses on **behavioral equivalence**, not code style. It validates:
- Same inputs → same or better outputs
- Sentinel behavior (PII, auth, ingest, handoff)
- MC scores and drift handling
- Dependency graph sanity
- MC separation (gate score vs confidence score)

## Files

- `phase3_comparison_harness.py` - Test harness for side-by-side comparison
- `phase3_mc_separation_validator.py` - MC score separation validation
- `phase3_sentinel_auditor.py` - Sentinel compliance auditing
- `phase3_dependency_validator.py` - Dependency graph validation
- `phase3_projects_validator.py` - Projects integration validation
- `phase3_comparison_runner.py` - Main comparison runner
- `phase3_report_generator.py` - Markdown report generator

## Running Phase 3 Comparison

### Quick Start

```bash
# Run comparison
cd greenfield/tests
python phase3_comparison_runner.py

# Generate markdown report from JSON
python phase3_report_generator.py phase3_comparison_report.json
```

### Output

The runner generates:
- `phase3_comparison_report.json` - Complete comparison results in JSON
- `phase3_comparison_report.md` - Human-readable markdown report

## Test Categories

### 1. Behavioral Equivalence Tests
Compares greenfield vs current system on:
- Input/output contracts
- Error handling
- Edge cases

### 2. Sentinel Compliance Audit
Validates:
- PII detection across all components
- Data validation
- Error handling
- Audit logging
- Access control (where applicable)

### 3. MC Separation Validation
Validates:
- Gate score (0.0-10.0) used for backend routing
- Confidence score (0.0-1.0) used for user-facing display
- No score misuse
- Gate decisions use gate score

### 4. Dependency Graph Validation
Validates:
- LEGO dependency ladder (foundation → second → third → top)
- No circular dependencies
- Proper isolation

### 5. Projects Integration Validation
Validates:
- Max 3 active projects (1 primary + 2 secondary)
- Alignment validation (≥0.7 threshold)
- Project context enrichment
- Project switching review
- Ingest policy (3-criteria check)

### 6. Integration Tests
End-to-end tests:
- Assembly Line pipeline
- Memory System (STM/LTM)
- Vault System
- API Layer

## Success Criteria

- [x] Behavioral equivalence tests completed
- [ ] Sentinel compliance validated (≥90%)
- [ ] MC separation validated
- [ ] Dependency graphs validated
- [ ] Projects integration validated

## Next Steps

After Phase 3 completes, proceed to Phase 4: Hardening, which will:
1. Rank blocks by MC gap and Sentinel severity
2. Fix Sentinel-critical blocks first
3. Apply North Star corrections
4. Address elegance or tech-debt polish

