# Phase 3: Behavioral Comparison Report

**Generated**: 2025-11-14T22:22:37.751750

---

## Executive Summary

- **Behavioral tests**: 2 total; equivalent=0, improved=0, regressed=0
- **Sentinel compliance**: 100.0% (20/20 checks)
- **MC separation valid**: True (violations: 0)
- **Dependency graph valid**: True
- **Projects integration valid**: True (violations: 0)

## Behavioral Tests (detail)

- **Different (not equivalent)**: 2
  - `mc-engine-001`: **different** (0.34 ms)
  - `north-star-001`: **different** (0.17 ms)

## Recommendations

- All validations passed - proceed to Phase 4 hardening

