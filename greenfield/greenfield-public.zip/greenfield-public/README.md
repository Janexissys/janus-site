# Greenfield Thesis Evidence Pack (Janus V6.0)

Reference-only archive consolidating Greenfield thesis artifacts from **JanusV5.5** (narrative cards) and **JanusV6.0** (implementation, validation, migration). Live runtime code remains in repo-root [`backend/`](../backend/).

## Thesis scope

**Mission:** Prove that 29 locked-scope cards + MC + Sentinels + Vault let AI build a clean reference implementation while humans guard North Star and structure.

**Phases:**

| Phase | Name | Primary proof in this pack |
|-------|------|----------------------------|
| 1 | Narrative documentation | [`cards/p1/`](cards/p1/) — 30 files (29 scope + INDEX) |
| 2 | Greenfield build | [`docs/status/PHASE2_COMPLETE.md`](docs/status/PHASE2_COMPLETE.md), [`backend/`](backend/) |
| 3 | Behavioral comparison | [`tests/results/phase3_comparison_report.json`](tests/results/phase3_comparison_report.json) |
| 4 | Hardening | [`tests/results/phase4_hardening_plan.json`](tests/results/phase4_hardening_plan.json) |
| 6 | Post-greenfield validation | [`docs/status/git-only/PHASE6_*.md`](docs/status/git-only/) |

**Principle:** Compare behaviour, not code style — same inputs → same or better outputs; Sentinel; MC separation.

---

## Phase 1 proof (narrative cards)

Phase 1 has **no separate completion report** — the cards *are* the deliverable.

| Artifact | Path | Count |
|----------|------|------:|
| Master index | [`cards/p1/CARD-V6B-P1-LEGO-INDEX.md`](cards/p1/CARD-V6B-P1-LEGO-INDEX.md) | 1 |
| P1 scope cards | [`cards/p1/CARD-V6B-P1-*.md`](cards/p1/) | 30 |
| Phase 1 summary | [`docs/status/PHASE1-COMPLETION-SUMMARY.md`](docs/status/PHASE1-COMPLETION-SUMMARY.md) | 1 |
| Original flight plan | [`docs/plans/greenfield-reference-implementation-plan.plan.md`](docs/plans/greenfield-reference-implementation-plan.plan.md) | 1 |
| Architecture breadcrumbs | [`docs/architecture/vault-refs/`](docs/architecture/vault-refs/) | 3 |

**Source:** Copied from JanusV5.5 (`vaults/stmvault/cards/`). These were never committed to V6.0 vault before consolidation.

---

## Phase 2 proof (build)

| Artifact | Path |
|----------|------|
| Completion report | [`docs/status/PHASE2_COMPLETE.md`](docs/status/PHASE2_COMPLETE.md) |
| Build log | [`docs/status/BUILD_PROGRESS.md`](docs/status/BUILD_PROGRESS.md) or [`docs/archive/BUILD_PROGRESS.md`](docs/archive/BUILD_PROGRESS.md) |
| Reference implementation | [`backend/blocks/`](backend/blocks/), [`backend/agents/`](backend/agents/), [`backend/systems/`](backend/systems/) |
| Canonical live code | See [`TRACEABILITY.md`](TRACEABILITY.md) → `backend/` at repo root |

---

## Phase 3 proof (behavioural comparison)

| Artifact | Path |
|----------|------|
| Machine report | [`tests/results/phase3_comparison_report.json`](tests/results/phase3_comparison_report.json) |
| Human report | [`tests/results/phase3_comparison_report.md`](tests/results/phase3_comparison_report.md) |
| Harness README | [`tests/harness/PHASE3_README.md`](tests/harness/PHASE3_README.md) |
| Final results (git-era) | [`docs/status/PHASE3_FINAL_RESULTS.md`](docs/status/PHASE3_FINAL_RESULTS.md) |

**Honest finding:** 2/2 behavioural tests marked `different` (not equivalent). Sentinel 20/20, MC separation valid, dependency graph valid, projects integration valid.

---

## Phase 4 proof (hardening)

| Artifact | Path |
|----------|------|
| JSON plan | [`tests/results/phase4_hardening_plan.json`](tests/results/phase4_hardening_plan.json) |
| Reports | [`docs/status/PHASE4_COMPLETE.md`](docs/status/PHASE4_COMPLETE.md), [`docs/archive/`](docs/archive/) |

---

## Extended evidence

| Category | Path |
|----------|------|
| P2 frontend cards (13) | [`cards/p2-fe/`](cards/p2-fe/) |
| Delta / migration cards | [`cards/delta/`](cards/delta/), [`vaults/stmvault/`](vaults/stmvault/) |
| V6 polish card | [`cards/v6-polish/`](cards/v6-polish/) |
| Proof packets | [`docs/proof_packets/`](docs/proof_packets/) |
| Phase 3a exports | [`exports/`](exports/) |
| Migration | [`migration/`](migration/) |
| Start scripts (archived) | [`start_scripts/`](start_scripts/) |
| Full status doc corpus | [`docs/status/`](docs/status/), [`docs/status/git-only/`](docs/status/git-only/) |
| V6 archive copies | [`docs/archive/`](docs/archive/) |

---

## Machine-readable indexes

| File | Purpose |
|------|---------|
| [`INVENTORY.json`](INVENTORY.json) | Every file: path, sha256, byte size, source, category |
| [`TRACEABILITY.md`](TRACEABILITY.md) | 29 cards → narrative → reference impl → canonical impl → tests |
| [`live_mapping/CARD_TO_CANONICAL_BACKEND.md`](live_mapping/CARD_TO_CANONICAL_BACKEND.md) | Card ID → live `backend/` path only |

Regenerate:

```bash
python3 greenfield/scripts/generate_inventory.py
python3 greenfield/scripts/generate_traceability.py
python3 greenfield/scripts/generate_phase3_report.py
```

---

## Known gaps and drift

1. **`greenfield/` was deleted** from V6.0 in commit `c809d26`; this tree restored from `c06c586` plus V5.5 cards and V6 satellites.
2. **Phase 1 cards** lived in JanusV5.5, not V6 vault, until this consolidation.
3. **Canonical runtime** is repo-root `backend/janus/app` + `backend/blocks` — not `greenfield/backend/`.
4. **Four COMP systems** archived at `backend/systems/_archive/` (API, telemetry, frontend, arbiter).
5. Root [`README.md`](../README.md) previously pointed to a missing `vaults/stmvault/cards/CARD-V6B-P1-LEGO-INDEX.md`; use [`cards/p1/CARD-V6B-P1-LEGO-INDEX.md`](cards/p1/CARD-V6B-P1-LEGO-INDEX.md) instead.

---

## How to compute metrics

1. Filter [`INVENTORY.json`](INVENTORY.json) by `category` or `source`.
2. Join card IDs via [`TRACEABILITY.md`](TRACEABILITY.md).
3. Validate Phase 3 claims against [`tests/results/phase3_comparison_report.json`](tests/results/phase3_comparison_report.json) only — not status-doc prose alone.
4. Cross-check live code with [`live_mapping/CARD_TO_CANONICAL_BACKEND.md`](live_mapping/CARD_TO_CANONICAL_BACKEND.md).
