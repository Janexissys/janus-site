#!/usr/bin/env python3

# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
⚠️  GREENFIELD EXPERIMENTAL APP - DO NOT USE AS DEFAULT ⚠️

This is the experimental greenfield implementation.
It hardcodes values and does not use the canonical Settings/config_loader.

For production use, use: backend.janus.app.main:app

This file is kept for testing/experimentation only.
"""

import logging
logging.warning("⚠️  RUNNING GREENFIELD EXPERIMENTAL APP - This is NOT the canonical Janus entrypoint!")
logging.warning("⚠️  For production, use: uvicorn backend.janus.app.main:app")

# ... existing greenfield code ...
