"""
LLM Response Cache for MC Repeatability

Purpose: Freeze the LLM boundary during tests to prove MC framework determinism.

This is NOT a production performance cache. This is a repeatability harness.

Usage:
    REPEATABILITY_MODE=true python -m pytest tests/repeatability/
    REPEATABILITY_STRICT=true  # fail on cache miss (default)
    LLM_CACHE_SQLITE_PATH=data/llm_cache.sqlite3  # default

Architecture:
    1. Fingerprint request → SHA256(canonical_json(request_payload))
    2. Check cache → return cached response if hit
    3. On miss: call LLM, store response, return
    4. Strict mode: raise on miss when REPEATABILITY_MODE=true

Key insight: You are not proving "LLMs are deterministic." You are proving
"Janus is a governed, testable pipeline" where stochastic steps are isolated
and deterministic steps (MC gates) are enforced.
"""

from __future__ import annotations

import hashlib
import json
import os
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional


def _canonical_json(obj: Any) -> str:
    """
    Stable canonicalization for fingerprinting.
    
    Requirements:
    - Sorted keys (deterministic ordering)
    - No whitespace (compact)
    - UTF-8 preserved (ensure_ascii=False)
    
    This ensures identical request payloads produce identical fingerprints
    regardless of dict ordering or minor formatting differences.
    """
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def fingerprint_llm_request(payload: dict) -> str:
    """
    Generate SHA256 fingerprint of LLM request payload.
    
    Args:
        payload: Dictionary containing all request parameters that affect
                the response (model, prompts, temperature, seed, tools, etc.)
    
    Returns:
        64-character hex string (SHA256 hash)
    
    Example:
        payload = {
            "endpoint": "responses.create",
            "model": "claude-3-5-sonnet-20241022",
            "prompt_pack_version": "v6.0",
            "temperature": 0,
            "messages": [...],
            "tools": [...]
        }
        key = fingerprint_llm_request(payload)
        # key = "a3f5b7c9..."
    """
    canonical = _canonical_json(payload)
    raw = canonical.encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


@dataclass
class LLMCacheConfig:
    """Configuration for LLM response cache."""
    
    enabled: bool  # REPEATABILITY_MODE=true
    strict: bool  # REPEATABILITY_STRICT=true (fail on cache miss)
    sqlite_path: str  # LLM_CACHE_SQLITE_PATH


class LLMResponseCache:
    """
    SQLite-backed cache for LLM responses.
    
    Schema:
        llm_cache (
            key TEXT PRIMARY KEY,       -- SHA256 fingerprint
            request_json TEXT NOT NULL, -- canonical JSON request
            response_json TEXT NOT NULL,-- canonical JSON response
            created_at TEXT NOT NULL,   -- ISO-8601 timestamp
            meta_json TEXT              -- optional metadata
        )
    
    Thread-safety: Single-threaded use assumed. For concurrent use,
    consider connection pooling or file locks.
    """
    
    def __init__(self, config: LLMCacheConfig):
        self.config = config
        
        # Ensure parent directory exists
        cache_path = Path(self.config.sqlite_path)
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        
        self._conn = sqlite3.connect(self.config.sqlite_path)
        self._init_schema()
    
    def _init_schema(self) -> None:
        """Create llm_cache table if not exists."""
        self._conn.execute(
            """
            CREATE TABLE IF NOT EXISTS llm_cache (
              key TEXT PRIMARY KEY,
              request_json TEXT NOT NULL,
              response_json TEXT NOT NULL,
              created_at TEXT NOT NULL,
              meta_json TEXT
            )
            """
        )
        self._conn.commit()
    
    def get(self, key: str) -> Optional[dict]:
        """
        Retrieve cached response by fingerprint key.
        
        Args:
            key: SHA256 fingerprint from fingerprint_llm_request()
        
        Returns:
            Response payload as dict, or None if cache miss
        """
        cur = self._conn.execute(
            "SELECT response_json FROM llm_cache WHERE key = ?",
            (key,),
        )
        row = cur.fetchone()
        if not row:
            return None
        return json.loads(row[0])
    
    def set(
        self,
        key: str,
        request_payload: dict,
        response_payload: dict,
        meta: Optional[dict] = None
    ) -> None:
        """
        Store LLM response in cache.
        
        Args:
            key: SHA256 fingerprint from fingerprint_llm_request()
            request_payload: Full request dict (for audit/inspection)
            response_payload: Full response dict to cache
            meta: Optional metadata (e.g., {"note": "golden_dataset"})
        """
        created_at = datetime.now(timezone.utc).isoformat()
        self._conn.execute(
            """
            INSERT OR REPLACE INTO llm_cache(key, request_json, response_json, created_at, meta_json)
            VALUES (?, ?, ?, ?, ?)
            """,
            (
                key,
                _canonical_json(request_payload),
                _canonical_json(response_payload),
                created_at,
                _canonical_json(meta) if meta else None,
            ),
        )
        self._conn.commit()
    
    def close(self) -> None:
        """Close database connection."""
        self._conn.close()


def load_llm_cache_config() -> LLMCacheConfig:
    """
    Load cache configuration from environment variables.
    
    Environment Variables:
        REPEATABILITY_MODE: "true" to enable caching (default: "false")
        REPEATABILITY_STRICT: "true" to fail on cache miss (default: "true")
        LLM_CACHE_SQLITE_PATH: Path to SQLite file (default: "data/llm_cache.sqlite3")
    
    Returns:
        LLMCacheConfig instance
    """
    enabled = os.getenv("REPEATABILITY_MODE", "false").lower() == "true"
    strict = os.getenv("REPEATABILITY_STRICT", "true").lower() == "true"
    sqlite_path = os.getenv("LLM_CACHE_SQLITE_PATH", "data/llm_cache.sqlite3")
    
    return LLMCacheConfig(
        enabled=enabled,
        strict=strict,
        sqlite_path=sqlite_path
    )


# Example integration (pseudo-code for your LLM adapter):
"""
def call_llm_with_cache(
    model: str,
    messages: list,
    temperature: float = 0,
    tools: Optional[list] = None,
    **kwargs
) -> dict:
    '''
    Call LLM with caching support for repeatability.
    
    When REPEATABILITY_MODE=true:
    - Generates fingerprint of request
    - Returns cached response if available
    - Fails if strict mode and no cache hit
    - Caches new responses for future runs
    '''
    cfg = load_llm_cache_config()
    cache = LLMResponseCache(cfg)
    
    # Build canonical request payload
    request_payload = {
        "endpoint": "responses.create",
        "model": model,
        "prompt_pack_version": PROMPT_PACK_VERSION,  # critical!
        "temperature": temperature,
        "top_p": kwargs.get("top_p"),
        "max_tokens": kwargs.get("max_tokens"),
        "seed": kwargs.get("seed"),  # include if supported
        "messages": messages,
        "tools": tools,  # include tool schemas
        "response_format": kwargs.get("response_format"),
    }
    
    # Generate fingerprint
    key = fingerprint_llm_request(request_payload)
    
    # Check cache if enabled
    if cfg.enabled:
        cached = cache.get(key)
        if cached is not None:
            logger.info(f"LLM cache HIT: {key[:8]}...")
            return cached
        
        if cfg.strict:
            raise RuntimeError(
                f"Repeatability strict mode: cache miss for key={key}. "
                f"Run without strict mode to populate cache, or add to golden dataset."
            )
        
        logger.info(f"LLM cache MISS: {key[:8]}...")
    
    # Call actual LLM
    response_payload = your_llm_client.create(
        model=model,
        messages=messages,
        temperature=temperature,
        tools=tools,
        **kwargs
    )
    
    # Store in cache (even if not in repeatability mode, for future use)
    cache.set(key, request_payload, response_payload, meta={"captured": True})
    
    cache.close()
    return response_payload
"""
