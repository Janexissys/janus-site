# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Chat Command Gateway

Unified gateway for parsing, validating, and routing chat commands to lifecycle APIs.

Card: CARD-V6B-DELTA-CHAT-GATEWAY
"""

import re
import shlex
from typing import Any, Dict, List, Optional, Set, Tuple

from .chat_command_registry import get_command_registry, CommandDef
from ..systems.task_card_system import TaskCardSystem
from ..systems.mc_engine import MCEngine


class ChatCommandError(Exception):
    """Chat command error."""
    
    def __init__(self, message: str, code: str = "invalid_command") -> None:
        self.message = message
        self.code = code
        super().__init__(message)


class ChatCommandGateway:
    """Chat command gateway service.
    
    Handles command detection, parsing, and routing to appropriate handlers.
    """
    
    def __init__(
        self,
        task_card_system: Optional[TaskCardSystem] = None,
        mc_engine: Optional[MCEngine] = None
    ) -> None:
        """Initialize gateway with command registry and optional services.
        
        Args:
            task_card_system: Optional TaskCardSystem instance for card operations
            mc_engine: Optional MCEngine instance for MC bin operations
        """
        self.registry = get_command_registry()
        self.task_card_system = task_card_system
        self.mc_engine = mc_engine
    
    def is_command(self, text: str) -> bool:
        """Check if text is a command.
        
        Args:
            text: Input text to check
            
        Returns:
            True if text starts with "/", False otherwise
        """
        return text.strip().startswith("/")
    
    def parse(self, text: str) -> Tuple[CommandDef, str]:
        """Parse command text into CommandDef and arguments.
        
        Args:
            text: Command text (e.g., "/edit card 123 title=New")
            
        Returns:
            Tuple of (CommandDef, remaining_args)
            
        Raises:
            ChatCommandError: If command is unknown
        """
        stripped = text.strip()
        
        # Extract first token (command)
        parts = stripped.split(maxsplit=1)
        first_token = parts[0]
        
        # Look up command in registry
        cmd = self.registry.get(first_token)
        if not cmd:
            raise ChatCommandError(
                f"Unknown command: {first_token}. Use /help to see available commands.",
                code="unknown_command",
            )
        
        # Extract remainder (arguments)
        remainder = parts[1] if len(parts) > 1 else ""
        
        return cmd, remainder.strip()
    
    def route(self, cmd: CommandDef, args: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Route command to appropriate handler.
        
        Args:
            cmd: Command definition
            args: Command arguments
            context: Request context (user_id, session_id, etc.)
            
        Returns:
            Handler result dictionary
            
        Raises:
            ChatCommandError: If handler is missing or fails
        """
        handler_name = cmd.handler_name
        handler = getattr(self, handler_name, None)
        
        if not handler:
            raise ChatCommandError(
                f"Handler not implemented for command: {cmd.full_trigger}",
                code="handler_missing",
            )
        
        try:
            return handler(args=args, context=context)
        except ChatCommandError:
            # Re-raise command errors
            raise
        except Exception as e:
            # Wrap unexpected errors
            raise ChatCommandError(
                f"Error executing command {cmd.full_trigger}: {str(e)}",
                code="handler_error",
            )
    
    def process(self, text: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Process command text through gateway.
        
        Args:
            text: Command text
            context: Request context
            
        Returns:
            Handler result dictionary
            
        Raises:
            ChatCommandError: If not a command or processing fails
        """
        if not self.is_command(text):
            raise ChatCommandError("Not a command", code="not_a_command")
        
        cmd, args = self.parse(text)
        return self.route(cmd, args, context)
    
    # P1 Lifecycle Command Handlers
    
    def handle_edit_card(self, args: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Handle /edit card command.
        
        Args:
            args: Command arguments (e.g., "card <id> title=New content=Updated")
            context: Request context
            
        Returns:
            Result dictionary
        """
        # Parse: "card <id> [field=value ...]"
        parts = shlex.split(args)
        if len(parts) < 2 or parts[0] != "card":
            raise ChatCommandError(
                "Usage: /edit card <id> [field=value ...]",
                code="invalid_args",
            )
        
        card_id = parts[1]
        if not card_id.startswith("CARD-"):
            raise ChatCommandError(
                f"Invalid card ID format: {card_id}. Must start with 'CARD-'",
                code="invalid_args",
            )
        
        updates = {}
        
        # Parse field=value pairs
        for part in parts[2:]:
            if "=" in part:
                field, value = part.split("=", 1)
                updates[field] = value
        
        # Validate service availability
        if not self.task_card_system:
            raise ChatCommandError(
                "Task Card System not available.",
                code="service_unavailable",
            )
        
        # Get card
        card = self.task_card_system.get_card(card_id)
        if not card:
            raise ChatCommandError(
                f"Card not found: {card_id}",
                code="card_not_found",
            )
        
        # Apply updates
        title = updates.get("title")
        content = updates.get("content")
        metadata_updates = {}
        
        # Separate direct fields from metadata
        for key, value in updates.items():
            if key not in ["title", "content"]:
                metadata_updates[key] = value
        
        # Update card (using direct attribute updates since update_card doesn't exist)
        if title is not None:
            card.title = title
        if content is not None:
            card.content = content
        if metadata_updates:
            card.metadata.update(metadata_updates)
        
        return {
            "type": "card_update_result",
            "message": f"Card {card_id} updated",
            "card_id": card_id,
            "updates": updates,
            "card_title": card.title,
        }
    
    def handle_move_card(self, args: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Handle /move card command.
        
        Args:
            args: Command arguments (e.g., "card <id> to <state>")
            context: Request context
            
        Returns:
            Result dictionary
        """
        # Parse: "card <id> to <state>"
        match = re.match(r"card\s+(\S+)\s+to\s+(\S+)", args)
        if not match:
            raise ChatCommandError(
                "Usage: /move card <id> to <state>",
                code="invalid_args",
            )
        
        card_id = match.group(1)
        if not card_id.startswith("CARD-"):
            raise ChatCommandError(
                f"Invalid card ID format: {card_id}. Must start with 'CARD-'",
                code="invalid_args",
            )
        
        target_state = match.group(2).lower()
        
        # Valid lifecycle states (v6.0 canonical)
        valid_states = {"new", "symbiosis", "running", "review", "completed", "cancelled"}
        if target_state not in valid_states:
            raise ChatCommandError(
                f"Invalid state: {target_state}. Valid states: {', '.join(sorted(valid_states))}",
                code="invalid_state",
            )
        
        # Validate service availability
        if not self.task_card_system:
            raise ChatCommandError(
                "Task Card System not available.",
                code="service_unavailable",
            )
        
        # Get card
        card = self.task_card_system.get_card(card_id)
        if not card:
            raise ChatCommandError(
                f"Card not found: {card_id}",
                code="card_not_found",
            )
        
        # Get current state from metadata (default to "new" if not set)
        old_state = card.metadata.get("lifecycle_state", "new")
        
        # Update lifecycle state in metadata
        card.metadata["lifecycle_state"] = target_state
        
        return {
            "type": "card_move_result",
            "message": f"Card {card_id} moved to {target_state}",
            "card_id": card_id,
            "old_state": old_state,
            "new_state": target_state,
            "card_title": card.title,
        }
    
    def handle_promote_card(self, args: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Handle /promote card command.
        
        Args:
            args: Command arguments (e.g., "card <id>")
            context: Request context
            
        Returns:
            Result dictionary
        """
        # Parse: "card <id>"
        parts = args.split()
        if len(parts) < 2 or parts[0] != "card":
            raise ChatCommandError(
                "Usage: /promote card <id>",
                code="invalid_args",
            )
        
        card_id = parts[1]
        if not card_id.startswith("CARD-"):
            raise ChatCommandError(
                f"Invalid card ID format: {card_id}. Must start with 'CARD-'",
                code="invalid_args",
            )
        
        # Validate service availability
        if not self.task_card_system:
            raise ChatCommandError(
                "Task Card System not available.",
                code="service_unavailable",
            )
        
        # Get card
        card = self.task_card_system.get_card(card_id)
        if not card:
            raise ChatCommandError(
                f"Card not found: {card_id}",
                code="card_not_found",
            )
        
        # Lifecycle state progression
        state_sequence = ["new", "symbiosis", "running", "review", "completed"]
        
        # Get current state from metadata (default to "new" if not set)
        current_state = card.metadata.get("lifecycle_state", "new")
        
        if current_state not in state_sequence:
            raise ChatCommandError(
                f"Cannot promote card {card_id}: invalid current state {current_state}",
                code="invalid_state",
            )
        
        current_index = state_sequence.index(current_state)
        if current_index >= len(state_sequence) - 1:
            raise ChatCommandError(
                f"Card {card_id} is already in terminal state: {current_state}",
                code="terminal_state",
            )
        
        next_state = state_sequence[current_index + 1]
        
        # Update lifecycle state in metadata
        card.metadata["lifecycle_state"] = next_state
        
        return {
            "type": "card_promote_result",
            "message": f"Card {card_id} promoted from {current_state} to {next_state}",
            "card_id": card_id,
            "old_state": current_state,
            "new_state": next_state,
            "card_title": card.title,
        }
    
    def handle_next_bin(self, args: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Handle /next bin command.
        
        Args:
            args: Command arguments (e.g., "bin <id>")
            context: Request context
            
        Returns:
            Result dictionary
        """
        # Parse: "bin <id>"
        parts = args.split()
        if len(parts) < 2 or parts[0] != "bin":
            raise ChatCommandError(
                "Usage: /next bin <id>",
                code="invalid_args",
            )
        
        card_id = parts[1]
        if not card_id.startswith("CARD-"):
            raise ChatCommandError(
                f"Invalid card ID format: {card_id}. Must start with 'CARD-'",
                code="invalid_args",
            )
        
        # Validate service availability
        if not self.task_card_system:
            raise ChatCommandError(
                "Task Card System not available.",
                code="service_unavailable",
            )
        
        # Get card
        card = self.task_card_system.get_card(card_id)
        if not card:
            raise ChatCommandError(
                f"Card not found: {card_id}",
                code="card_not_found",
            )
        
        # MC bin sequence (12 bins)
        bin_sequence = [
            "signal", "memory_short", "mental_state", "bias_good", "bias_bad",
            "memory_long", "knowledge", "education", "priority", "ethos",
            "drift", "execution_risk"
        ]
        
        # Get current bin from card metadata (default to "signal" if not set)
        current_bin = card.metadata.get("current_mc_bin", "signal")
        
        if current_bin not in bin_sequence:
            raise ChatCommandError(
                f"Cannot advance bin for card {card_id}: invalid current bin {current_bin}",
                code="invalid_bin",
            )
        
        current_index = bin_sequence.index(current_bin)
        if current_index >= len(bin_sequence) - 1:
            raise ChatCommandError(
                f"Card {card_id} is already in final bin: {current_bin}",
                code="final_bin",
            )
        
        next_bin = bin_sequence[current_index + 1]
        
        # Update MC bin in metadata
        card.metadata["current_mc_bin"] = next_bin
        
        return {
            "type": "mc_bin_result",
            "message": f"Card {card_id} moved from {current_bin} to {next_bin}",
            "card_id": card_id,
            "old_bin": current_bin,
            "new_bin": next_bin,
            "card_title": card.title,
        }
    
    def handle_validate_deps(self, args: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Handle /validate deps command.
        
        Args:
            args: Command arguments (e.g., "deps <id>")
            context: Request context
            
        Returns:
            Result dictionary with validation results
        """
        # Parse: "deps <id>"
        parts = args.split()
        if len(parts) < 2 or parts[0] != "deps":
            raise ChatCommandError(
                "Usage: /validate deps <id>",
                code="invalid_args",
            )
        
        card_id = parts[1]
        if not card_id.startswith("CARD-"):
            raise ChatCommandError(
                f"Invalid card ID format: {card_id}. Must start with 'CARD-'",
                code="invalid_args",
            )
        
        # Validate service availability
        if not self.task_card_system:
            raise ChatCommandError(
                "Task Card System not available.",
                code="service_unavailable",
            )
        
        # Get card
        card = self.task_card_system.get_card(card_id)
        if not card:
            raise ChatCommandError(
                f"Card not found: {card_id}",
                code="card_not_found",
            )
        
        # Get dependencies from metadata
        dependencies = card.metadata.get("dependencies", [])
        blocking_dependencies = card.metadata.get("blocking_dependencies", [])
        
        # Validate dependencies
        issues = []
        missing_deps = []
        all_deps = dependencies + blocking_dependencies
        
        # Check for missing dependencies
        for dep_id in all_deps:
            dep_card = self.task_card_system.get_card(dep_id)
            if not dep_card:
                missing_deps.append(dep_id)
                issues.append(f"Missing dependency: {dep_id}")
        
        # Check for circular dependencies (simple check - would need full graph traversal for complex cases)
        if card_id in all_deps:
            issues.append(f"Circular dependency detected: {card_id} depends on itself")
        
        # Determine status
        if issues:
            status = "issues_found"
        elif not all_deps:
            status = "no_dependencies"
        else:
            status = "ok"
        
        return {
            "type": "dependency_validation_result",
            "message": f"Dependency validation for {card_id}: {status}",
            "card_id": card_id,
            "status": status,
            "dependencies": dependencies,
            "blocking_dependencies": blocking_dependencies,
            "issues": issues,
            "missing_dependencies": missing_deps,
            "card_title": card.title,
        }
    
    def handle_analyze_mc(self, args: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Handle /analyze mc command.
        
        Analyzes MC bins for a card and identifies bins below 8.5 threshold.
        Provides rationale for why each bin is low and suggests improvements.
        
        Args:
            args: Command arguments (e.g., "mc <id>")
            context: Request context
            
        Returns:
            Result dictionary with low bins analysis
        """
        # Parse: "mc <id>"
        parts = args.split()
        if len(parts) < 2 or parts[0] != "mc":
            raise ChatCommandError(
                "Usage: /analyze mc <id>",
                code="invalid_args",
            )
        
        card_id = parts[1]
        if not card_id.startswith("CARD-"):
            raise ChatCommandError(
                f"Invalid card ID format: {card_id}. Must start with 'CARD-'",
                code="invalid_args",
            )
        
        # Validate service availability
        if not self.task_card_system:
            raise ChatCommandError(
                "Task Card System not available.",
                code="service_unavailable",
            )
        
        # Get card
        card = self.task_card_system.get_card(card_id)
        if not card:
            raise ChatCommandError(
                f"Card not found: {card_id}",
                code="card_not_found",
            )
        
        # Get MC bins from metadata
        mc_bins = card.metadata.get("mc_bins", {})
        if not mc_bins:
            raise ChatCommandError(
                f"Card {card_id} has no MC bins data. Run MC calculation first.",
                code="no_mc_data",
            )
        
        # Identify bins below 8.5
        low_bins = []
        for bin_name, score in mc_bins.items():
            num_score = float(score) if isinstance(score, (int, float, str)) else 0.0
            if num_score < 8.5:
                gap = 8.5 - num_score
                # Generate rationale based on bin type
                rationale = self._get_bin_rationale(bin_name, num_score, gap)
                low_bins.append({
                    "bin": bin_name,
                    "score": round(num_score, 2),
                    "gap": round(gap, 2),
                    "rationale": rationale
                })
        
        # Sort by lowest score first
        low_bins.sort(key=lambda x: x["score"])
        
        # Generate improvement suggestions
        suggestions = []
        for bin_info in low_bins:
            suggestions.append(f"- {bin_info['bin'].replace('_', ' ').title()}: {bin_info['rationale']}")
        
        message = f"MC Analysis for {card_id}:\n"
        if low_bins:
            message += f"Found {len(low_bins)} bin(s) below 8.5 threshold:\n\n"
            for bin_info in low_bins:
                message += f"  • {bin_info['bin'].replace('_', ' ').title()}: {bin_info['score']}/8.50 (gap: {bin_info['gap']})\n"
                message += f"    {bin_info['rationale']}\n\n"
            message += "Use /improve bin <id> <bin_name> to improve a specific bin."
        else:
            message += "All bins meet the 8.5 threshold. ✅"
        
        return {
            "type": "mc_analysis_result",
            "message": message,
            "card_id": card_id,
            "card_title": card.title,
            "mc_score": card.mc_score,
            "low_bins": low_bins,
            "total_bins": len(mc_bins),
            "bins_below_threshold": len(low_bins),
            "suggestions": suggestions,
        }
    
    def handle_improve_bin(self, args: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Handle /improve bin command.
        
        Initiates improvement workflow for a specific MC bin.
        Provides guidance on how to improve the bin and can trigger MC recalculation.
        
        Args:
            args: Command arguments (e.g., "bin <id> <bin_name>")
            context: Request context
            
        Returns:
            Result dictionary with improvement guidance
        """
        # Parse: "bin <id> <bin_name>"
        parts = args.split()
        if len(parts) < 3 or parts[0] != "bin":
            raise ChatCommandError(
                "Usage: /improve bin <id> <bin_name>",
                code="invalid_args",
            )
        
        card_id = parts[1]
        bin_name = parts[2]
        
        if not card_id.startswith("CARD-"):
            raise ChatCommandError(
                f"Invalid card ID format: {card_id}. Must start with 'CARD-'",
                code="invalid_args",
            )
        
        # Validate bin name
        valid_bins = [
            "signal", "memory_short", "mental_state", "bias_good", "bias_bad",
            "memory_long", "knowledge", "education", "priority", "ethos",
            "drift", "execution_risk"
        ]
        if bin_name not in valid_bins:
            raise ChatCommandError(
                f"Invalid bin name: {bin_name}. Valid bins: {', '.join(valid_bins)}",
                code="invalid_bin",
            )
        
        # Validate service availability
        if not self.task_card_system:
            raise ChatCommandError(
                "Task Card System not available.",
                code="service_unavailable",
            )
        
        # Get card
        card = self.task_card_system.get_card(card_id)
        if not card:
            raise ChatCommandError(
                f"Card not found: {card_id}",
                code="card_not_found",
            )
        
        # Get current bin score
        mc_bins = card.metadata.get("mc_bins", {})
        current_score = float(mc_bins.get(bin_name, 0.0)) if mc_bins else 0.0
        gap = 8.5 - current_score if current_score < 8.5 else 0.0
        
        # Get improvement guidance
        guidance = self._get_bin_improvement_guidance(bin_name, current_score, gap)
        
        message = f"Improving {bin_name.replace('_', ' ').title()} bin for {card_id}:\n\n"
        message += f"Current score: {current_score:.2f}/8.50\n"
        if gap > 0:
            message += f"Gap to threshold: {gap:.2f} points\n\n"
        message += f"Improvement guidance:\n{guidance}\n\n"
        message += "After making improvements, the MC score will be recalculated automatically."
        
        return {
            "type": "bin_improvement_result",
            "message": message,
            "card_id": card_id,
            "card_title": card.title,
            "bin_name": bin_name,
            "current_score": round(current_score, 2),
            "target_score": 8.5,
            "gap": round(gap, 2) if gap > 0 else 0,
            "guidance": guidance,
        }
    
    def _get_bin_rationale(self, bin_name: str, score: float, gap: float) -> str:
        """Generate rationale for why a bin is low.
        
        Args:
            bin_name: Name of the MC bin
            score: Current score
            gap: Gap below 8.5 threshold
            
        Returns:
            Rationale string
        """
        bin_descriptions = {
            "signal": "Technical clarity may be unclear or ambiguous",
            "memory_short": "Short-term memory integration may be weak",
            "mental_state": "Team familiarity may be low",
            "bias_good": "Positive assumptions may be unstated",
            "bias_bad": "Negative assumptions or risks may be overlooked",
            "memory_long": "Long-term memory integration may be insufficient",
            "knowledge": "Existing knowledge patterns may not be applied",
            "education": "Documentation or educational needs may be missing",
            "priority": "Strategic alignment may be unclear",
            "ethos": "V6.0 vision alignment may be weak",
            "drift": "Scope adherence may be at risk",
            "execution_risk": "Rollback complexity or implementation risk may be high",
        }
        
        base_reason = bin_descriptions.get(bin_name, "This cognitive bin requires improvement")
        
        if gap > 1.0:
            severity = "significantly"
        elif gap > 0.5:
            severity = "moderately"
        else:
            severity = "slightly"
        
        return f"{base_reason}. This bin is {severity} below threshold ({gap:.2f} points), indicating a gap that needs attention."
    
    def _get_bin_improvement_guidance(self, bin_name: str, current_score: float, gap: float) -> str:
        """Get improvement guidance for a specific bin.
        
        Args:
            bin_name: Name of the MC bin
            current_score: Current score
            gap: Gap below 8.5 threshold
            
        Returns:
            Improvement guidance string
        """
        guidance_map = {
            "signal": "• Add more specific technical details and examples\n• Clarify ambiguous terms or concepts\n• Include code snippets or diagrams if applicable",
            "memory_short": "• Reference recent conversations or context\n• Link to related cards or discussions\n• Add STM vault references",
            "mental_state": "• Add team context and shared understanding\n• Document collaboration notes\n• Include stakeholder perspectives",
            "bias_good": "• Document optimistic scenarios\n• State positive assumptions explicitly\n• Include success conditions",
            "bias_bad": "• Document failure modes and risks\n• Add mitigation strategies\n• Include contrarian analysis",
            "memory_long": "• Reference historical context and patterns\n• Link to similar past work\n• Add LTM vault references",
            "knowledge": "• Reference similar past work or patterns\n• Apply established best practices\n• Link to relevant documentation",
            "education": "• Add explanations and tutorials\n• Include learning resources\n• Document educational needs",
            "priority": "• Clarify alignment with project goals\n• Document strategic importance\n• Link to priority framework",
            "ethos": "• Ensure alignment with Janus doctrine\n• Reference V6.0 vision\n• Link to core principles",
            "drift": "• Review scope boundaries\n• Ensure adherence to defined limits\n• Document scope decisions",
            "execution_risk": "• Break into smaller steps\n• Add safeguards and rollback plans\n• Document implementation risks",
        }
        
        return guidance_map.get(bin_name, "Review the card content and context to identify improvement opportunities.")
    
    def handle_help(self, args: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Handle /help command.
        
        Args:
            args: Optional group name (e.g., "cards", "ingest")
            context: Request context
            
        Returns:
            Help text dictionary
        """
        # Group commands by group
        by_group: Dict[str, list] = {}
        for cmd in self.registry.values():
            # Avoid duplicates (aliases point to same CommandDef)
            if cmd not in by_group.get(cmd.group, []):
                by_group.setdefault(cmd.group, []).append(cmd)
        
        # If specific group requested
        if args:
            group = args.strip().lower()
            if group in by_group:
                commands = by_group[group]
                help_text = f"Commands in '{group}' group:\n\n"
                for cmd in sorted(commands, key=lambda c: c.full_trigger):
                    help_text += f"  {cmd.full_trigger:<15} {cmd.summary}\n"
                    help_text += f"  {'':<15} Usage: {cmd.usage}\n"
                    if cmd.aliases:
                        help_text += f"  {'':<15} Aliases: {', '.join(cmd.aliases)}\n"
                    help_text += "\n"
                help_text += f"See docs/CHAT_COMMANDS.md for full documentation."
                return {
                    "type": "help",
                    "group": group,
                    "text": help_text.strip(),
                }
            else:
                return {
                    "type": "help",
                    "error": f"Unknown group: {group}. Available groups: {', '.join(sorted(by_group.keys()))}",
                }
        
        # General help
        help_text = "Available commands:\n\n"
        for group, commands in sorted(by_group.items()):
            help_text += f"{group.upper()}:\n"
            for cmd in sorted(commands, key=lambda c: c.full_trigger):
                help_text += f"  {cmd.full_trigger:<15} {cmd.summary}\n"
            help_text += "\n"
        help_text += "Use /help <group> for detailed usage (e.g., /help cards)\n"
        help_text += "See docs/CHAT_COMMANDS.md for full documentation."
        
        return {
            "type": "help",
            "text": help_text.strip(),
        }

