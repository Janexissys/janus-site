# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Chat Pipeline Adapter

Thin adapter between chat router and 6-phase cognitive pipeline.

Card: CARD-V6B-DELTA-CHAT-PIPELINE-INTEGRATION
"""

import logging
from typing import Dict, Any, Optional

from ..blocks.cognitive_block import CognitiveBlock, LLMRequest, LLMProvider

logger = logging.getLogger(__name__)


class ChatPipelineAdapter:
    """Adapter for 6-phase chat pipeline.
    
    Provides a thin interface between the chat router and the cognitive pipeline,
    ensuring consistent response envelopes and proper error handling.
    """
    
    def __init__(self, cognitive_block: Optional[CognitiveBlock] = None):
        """Initialize adapter with cognitive block.
        
        Args:
            cognitive_block: Optional CognitiveBlock instance. If None, will create one.
        """
        self.cognitive_block = cognitive_block
        if self.cognitive_block is None:
            self.cognitive_block = CognitiveBlock()
            # Initialize with LOCAL LLM config (default for greenfield)
            # LOCAL doesn't require API keys, uses Ollama at localhost:11434
            try:
                import os
                local_llm_url = os.getenv("LOCAL_LLM_BASE_URL", "http://localhost:11434")
                config = {
                    "api_keys": {
                        "local": local_llm_url,  # LOCAL LLM (Ollama) - required
                    }
                }
                # Add cloud provider keys only if they exist (optional)
                openai_key = os.getenv("OPENAI_API_KEY", "")
                anthropic_key = os.getenv("ANTHROPIC_API_KEY", "")
                if openai_key:
                    config["api_keys"]["openai"] = openai_key
                if anthropic_key:
                    config["api_keys"]["anthropic"] = anthropic_key
                
                self.cognitive_block.initialize(config)
                logger.info(f"CognitiveBlock initialized with LOCAL LLM: {local_llm_url}")
            except Exception as e:
                logger.error(f"Failed to initialize CognitiveBlock: {e}", exc_info=True)
                # Mark as not initialized so fallback is used
                self.cognitive_block._initialized = False
    
    async def process_chat_message(
        self,
        message: str,
        context: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Process a chat message through the 6-phase pipeline.
        
        Args:
            message: User message text
            context: Request context (user_id, session_id, etc.)
            
        Returns:
            Dictionary with chat response:
            {
                "type": "chat_response",
                "message": str,
                "session_id": str,
                "provider": str,
                "metadata": dict
            }
        """
        session_id = context.get("session_id", "default")
        user_id = context.get("user_id", "anonymous")
        
        try:
            # Check if this is an improvement discussion request
            # Pattern: "improve", "discuss card", "how to improve", etc.
            is_improvement_request = any(keyword in message.lower() for keyword in [
                "improve", "discuss card", "how to", "what can we do", "mc score"
            ])
            
            # Extract card ID if present
            card_id = None
            if "CARD-" in message.upper():
                import re
                card_match = re.search(r'CARD-[A-Z0-9-]+', message.upper())
                if card_match:
                    card_id = card_match.group(0)
            
            # If improvement request and card ID found, get structured analysis
            improvement_data = None
            if is_improvement_request and card_id:
                try:
                    import requests
                    # Get card data
                    card_response = requests.get(f"http://localhost:8000/api/v1/cards/{card_id}", timeout=5)
                    if card_response.status_code == 200:
                        card = card_response.json()
                        # Get all cards for context
                        all_cards_response = requests.get("http://localhost:8000/api/v1/cards", timeout=5)
                        all_cards = all_cards_response.json().get("cards", []) if all_cards_response.status_code == 200 else []
                        
                        # Get improvement analysis
                        from .improvement_analyzer import get_improvement_analyzer
                        analyzer = get_improvement_analyzer()
                        improvement_data = analyzer.analyze_card(card, all_cards)
                except Exception as e:
                    logger.warning(f"Could not fetch improvement data: {e}")
            
            # Phase 1: Request Classification (implicit - handled by router)
            # Phase 2-6: Cognitive processing via CognitiveBlock
            
            # Create LLM request with accurate system prompt
            system_prompt = """You are an AI assistant for Janus DTM Core, a cognitive task management system.

Janus is NOT a generic project management tool. It is a cognitive task network with:

CORE FEATURES:
- Cards & Tasks: Task/card lifecycle with MC (Meta-Cognitive) scoring (0-10 scale)
- Agent Crew: 6 specialized agents (Caretaker, Gardener, Scribe, Mercury, Conductor, Sentinel)
- LEGO Blocks: 13 modular cognitive blocks (Vault, Cognitive, Memory, Telemetry, etc.)
- Vault System: STM (Short-Term Memory) and LTM (Long-Term Memory) vaults
- Assembly Line: Agent pipeline orchestration for task processing
- MC Scoring: 12-bin cognitive framework for task routing and memory promotion

AVAILABLE COMMANDS:
- /edit card <id> [field=value ...] - Edit card fields
- /move card <id> to <state> - Change lifecycle state (new, symbiosis, running, review, completed, cancelled)
- /promote card <id> - Advance card lifecycle
- /next bin <id> - Advance MC bin
- /validate deps <id> - Check card dependencies
- /help - List all commands

LIFECYCLE STATES: new → symbiosis → running → review → completed (or cancelled)

When users ask about Janus features, explain the ACTUAL system (cards, agents, MC scoring, vaults), not generic project management features.
If users ask about features that don't exist (like Gantt charts, resource allocation, etc.), politely explain that Janus focuses on cognitive task management with agent-based processing.

IMPORTANT: When analyzing card improvements, use BIN-ANCHORED, ARTIFACT-FIRST, DELTA-ONLY format:

BIN-ANCHORED CRITIQUE:
- Start with: "This card cannot advance from Bin N → N+1 because _______"
- Reference the stop_bin and gate_verdict.reason
- One sentence only - no lists

ARTIFACT-FIRST REMEDIATION:
- Identify exactly ONE required artifact (not a list)
- Artifact types: explicit_invariant, dependency_declaration, acceptance_test, negative_example, kill_condition
- Show the exact artifact description

DELTA-ONLY REWRITE:
- Format: "Add / Remove / Replace the following block:"
- Show exact section path and content
- Commit-shaped: 5 lines max, single commit

MCCE READOUT:
- If PASS: Show confidence envelope (structural, evidence_density, bias_resistance, dependency_clarity, overall)
- If HOLD: Show proximity (pass_distance) and risk_profile (top_risks, failure_modes)
- Never show 0.0 confidence on HOLD - show proximity+risk instead"""
            
            # Enhance prompt with improvement data if available
            enhanced_prompt = message
            if improvement_data:
                # Format improvement data for LLM
                improvement_context = self._format_improvement_context(improvement_data)
                enhanced_prompt = f"""{message}

CARD IMPROVEMENT ANALYSIS DATA:
{improvement_context}

Use this structured data to provide SPECIFIC, DATA-DRIVEN recommendations. Reference actual scores, gaps, and examples."""
            
            llm_request = LLMRequest(
                prompt=enhanced_prompt,
                system_prompt=system_prompt,
                max_tokens=1500,  # Increased for detailed analysis
                temperature=0.7,
                provider=LLMProvider.LOCAL  # Default to local, can be configured
            )
            
            # Process through cognitive block
            # CognitiveBlock.generate is async
            if not self.cognitive_block._initialized:
                logger.warning("CognitiveBlock not initialized, using fallback response")
                return {
                    "type": "chat_response",
                    "message": "Chat pipeline is being set up. Please try again in a moment.",
                    "session_id": session_id,
                    "provider": "fallback",
                    "metadata": {
                        "note": "CognitiveBlock not initialized",
                        "user_id": user_id
                    }
                }
            
            if hasattr(self.cognitive_block, 'generate'):
                response = await self.cognitive_block.generate(llm_request)
            else:
                # Fallback response if cognitive block not available
                logger.warning("CognitiveBlock.generate not available, using fallback response")
                return {
                    "type": "chat_response",
                    "message": "Chat pipeline is being set up. Please try again in a moment.",
                    "session_id": session_id,
                    "provider": "fallback",
                    "metadata": {
                        "note": "CognitiveBlock.generate method not available",
                        "user_id": user_id
                    }
                }
            
            # Extract response content
            reply_text = response.content if hasattr(response, 'content') else str(response)
            
            # Build response envelope
            response_metadata = {
                "user_id": user_id,
                "pii_detected": getattr(response, 'pii_detected', False),
                "latency_ms": getattr(response, 'latency_ms', None),
            }
            
            # Include improvement data if available
            if improvement_data:
                response_metadata["improvement_analysis"] = improvement_data
            
            return {
                "type": "chat_response",
                "message": reply_text,
                "session_id": session_id,
                "provider": getattr(response, 'provider', 'cognitive-block'),
                "metadata": response_metadata
            }
            
        except Exception as e:
            logger.error(f"Chat pipeline error: {e}", exc_info=True)
            # Return error response (not raise - let router handle HTTP status)
            return {
                "type": "chat_response",
                "message": f"Error processing chat message: {str(e)}",
                "session_id": session_id,
                "provider": "error",
                "metadata": {
                    "error": True,
                    "error_type": type(e).__name__,
                    "user_id": user_id
                }
            }
    
    def _format_improvement_context(self, improvement_data: Dict[str, Any]) -> str:
        """Format improvement analysis data for LLM context (commit-shaped format).
        
        Format: Gate Verdict → Required Artifact → MCCE → Delta Patch
        """
        lines = []
        
        # Card basics
        card_id = improvement_data.get('card_id', 'UNKNOWN')
        title = improvement_data.get('title', 'Untitled')
        lines.append(f"Card: {card_id} - {title}")
        lines.append("")
        
        # 1. Gate Verdict
        gate_verdict = improvement_data.get('gate_verdict', {})
        gate_result = gate_verdict.get('result', 'unknown')
        stop_bin = gate_verdict.get('stop_bin')
        gate_reason = gate_verdict.get('reason', '')
        
        lines.append(f"GATE VERDICT: {gate_result.upper()}")
        if stop_bin:
            lines.append(f"  Stop Bin: {stop_bin}")
        lines.append(f"  Reason: {gate_reason}")
        lines.append("")
        
        # Bin-anchored critique format
        if stop_bin:
            # Gate order for bin progression
            gate_order = [
                "signal", "execution_risk", "education", "knowledge", "bias_bad",
                "priority", "ethos", "drift", "memory_short", "memory_long",
                "mental_state", "bias_good"
            ]
            try:
                bin_index = gate_order.index(stop_bin)
                next_bin = gate_order[bin_index + 1] if bin_index + 1 < len(gate_order) else "next"
                lines.append(f"BIN-ANCHORED: This card cannot advance from Bin {stop_bin} → {next_bin} because {gate_reason}")
            except (ValueError, IndexError):
                lines.append(f"BIN-ANCHORED: This card cannot advance because {gate_reason}")
        else:
            lines.append(f"BIN-ANCHORED: Card passed all gates")
        lines.append("")
        
        # 2. One Required Artifact
        required_artifact = improvement_data.get('required_artifact', {})
        if required_artifact:
            artifact_type = required_artifact.get('type', 'unknown')
            artifact_desc = required_artifact.get('description', '')
            target_bin = required_artifact.get('target_bin', 'unknown')
            
            lines.append(f"REQUIRED ARTIFACT (exactly ONE):")
            lines.append(f"  Type: {artifact_type}")
            lines.append(f"  Target Bin: {target_bin}")
            lines.append(f"  Description: {artifact_desc}")
            lines.append("")
        
        # 3. MCCE Readout
        mcce = improvement_data.get('mcce', {})
        eligible = mcce.get('eligible', False)
        
        lines.append(f"MCCE READOUT:")
        if eligible:
            # PASS: Show confidence envelope
            confidence = mcce.get('confidence', {})
            lines.append(f"  Eligible: {eligible} (PASS)")
            lines.append(f"  Confidence:")
            lines.append(f"    Structural: {confidence.get('structural', 0.0):.2f}")
            lines.append(f"    Evidence Density: {confidence.get('evidence_density', 0.0):.2f}")
            lines.append(f"    Bias Resistance: {confidence.get('bias_resistance', 0.0):.2f}")
            lines.append(f"    Dependency Clarity: {confidence.get('dependency_clarity', 0.0):.2f}")
            lines.append(f"    Overall: {confidence.get('overall', 0.0):.2f}")
            
            fragility_points = mcce.get('fragility_points', [])
            if fragility_points:
                lines.append(f"  Fragility Points:")
                for fp in fragility_points[:2]:  # Top 2
                    lines.append(f"    - {fp.get('bin')}: {fp.get('reason', '')}")
        else:
            # HOLD: Show proximity + risk profile
            lines.append(f"  Eligible: {eligible} (HOLD)")
            reason = mcce.get('reason', 'Gate failed')
            lines.append(f"  Reason: {reason}")
            
            proximity = mcce.get('proximity', {})
            pass_distance = proximity.get('pass_distance', 0.0)
            lines.append(f"  Proximity: {pass_distance:.3f} (normalized distance to pass)")
            
            risk_profile = mcce.get('risk_profile', {})
            top_risks = risk_profile.get('top_risks', [])
            if top_risks:
                lines.append(f"  Top Risks: {', '.join(top_risks)}")
            
            failure_modes = risk_profile.get('failure_modes', [])
            if failure_modes:
                lines.append(f"  Failure Modes:")
                for fm in failure_modes[:2]:  # Top 2
                    lines.append(f"    - {fm}")
        lines.append("")
        
        # 4. Delta Patch
        delta_patch = improvement_data.get('delta_patch', {})
        if delta_patch:
            action = delta_patch.get('action', 'add')
            section = delta_patch.get('section', 'unknown')
            content = delta_patch.get('content', '')
            
            lines.append(f"DELTA PATCH (commit-shaped):")
            lines.append(f"  Action: {action.upper()}")
            lines.append(f"  Section: {section}")
            lines.append(f"  Content: {content}")
        
        return "\n".join(lines)

