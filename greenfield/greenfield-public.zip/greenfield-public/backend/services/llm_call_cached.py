# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""LLM Call Cached - Single choke-point wrapper for deterministic LLM boundary.

**Card**: CARD-OSS-P0-004 (Repeatability Harness)
**Purpose**: Provide unified cached LLM call interface for all adapters

This module provides a single entry point for all LLM calls with caching support,
ensuring deterministic repeatability when REPEATABILITY_MODE is enabled.

**Example Usage**:
    ```python
    from backend.services.llm_call_cached import call_llm_cached
    
    request_payload = {
        "model": "gpt-4o-mini",
        "prompt_pack_version": "v6.0",
        "agent_id": "cognitive_block",
        "messages": [...],
        "temperature": 0.7,
        "max_tokens": 1000,
    }
    
    def _real_call(payload: dict) -> dict:
        return llm_client.chat.completions.create(**payload)
    
    response = call_llm_cached(
        request_payload=request_payload,
        llm_call=_real_call,
        meta={"source": "cognitive_block"},
    )
    ```
"""

from __future__ import annotations

import os
from typing import Any, Callable, Dict, Optional

from .llm_cache import (
    LLMResponseCache,
    fingerprint_llm_request,
    load_llm_cache_config,
)


def _env_truthy(name: str, default: str = "false") -> bool:
    """Check if environment variable is truthy."""
    return os.getenv(name, default).strip().lower() in {"1", "true", "yes", "y", "on"}


async def call_llm_cached_async(
    *,
    request_payload: Dict[str, Any],
    llm_call: Callable[[Dict[str, Any]], Any],
    meta: Optional[Dict[str, Any]] = None,
) -> Any:
    """Async version of call_llm_cached for async LLM calls."""
    cfg = load_llm_cache_config()
    
    # If caching disabled, passthrough
    if not cfg.enabled:
        return await llm_call(request_payload)
    
    # Initialize cache
    cache = LLMResponseCache(cfg)
    
    try:
        # Compute fingerprint
        key = fingerprint_llm_request(request_payload)
        
        # Check cache
        cached = cache.get(key)
        if cached is not None:
            return cached
        
        # Cache miss in strict mode
        if cfg.strict:
            raise RuntimeError(
                f"Repeatability strict mode: cache miss for key={key[:16]}... "
                f"Enable cache population by running with REPEATABILITY_STRICT=false"
            )
        
        # Call LLM (await async call)
        response = await llm_call(request_payload)
        
        # Cache response
        cache.set(key, request_payload, response, meta=meta or {})
        
        return response
        
    finally:
        cache.close()


def call_llm_cached(
    *,
    request_payload: Dict[str, Any],
    llm_call: Callable[[Dict[str, Any]], Any],
    meta: Optional[Dict[str, Any]] = None,
) -> Any:
    """Deterministic boundary wrapper for LLM calls.
    
    Provides unified caching interface for all LLM calls with three modes:
    - Normal mode (REPEATABILITY_MODE=false): passthrough to LLM, cache responses
    - Repeatability mode (REPEATABILITY_MODE=true, STRICT=false): return cached or call+cache
    - Strict mode (REPEATABILITY_MODE=true, STRICT=true): return cached or raise on miss
    
    Args:
        request_payload: Canonical request dictionary containing all parameters
            that affect the LLM response. Must include:
            - model: Model identifier
            - prompt_pack_version: Version of prompts/system messages
            - agent_id: Identifier of calling agent
            - messages: List of message dictionaries
            - temperature, max_tokens, seed, etc.
        llm_call: Callable that accepts request_payload and returns response dict.
            The response should be JSON-serializable.
        meta: Optional metadata to store with cache entry (e.g., source, timestamp).
    
    Returns:
        Response dictionary from LLM (either cached or fresh).
    
    Raises:
        RuntimeError: If REPEATABILITY_STRICT=true and cache miss occurs.
    
    Environment Variables:
        REPEATABILITY_MODE: Enable caching (true/false)
        REPEATABILITY_STRICT: Require cache hits, fail on miss (true/false)
        LLM_CACHE_SQLITE_PATH: Path to SQLite cache database
    
    Example:
        ```python
        # Build canonical request
        request = {
            "model": "gpt-4o-mini",
            "prompt_pack_version": "v6.0",
            "agent_id": "cognitive_block",
            "messages": [{"role": "user", "content": "Hello"}],
            "temperature": 0.7,
            "max_tokens": 100,
            "seed": 42,
        }
        
        # Define actual LLM call
        def _call(payload):
            return client.chat.completions.create(**payload)
        
        # Call with caching
        response = call_llm_cached(
            request_payload=request,
            llm_call=_call,
            meta={"source": "cognitive_block"},
        )
        ```
    """
    cfg = load_llm_cache_config()
    
    # If caching disabled, passthrough
    if not cfg.enabled:
        return llm_call(request_payload)
    
    # Initialize cache
    cache = LLMResponseCache(cfg)
    
    try:
        # Compute fingerprint
        key = fingerprint_llm_request(request_payload)
        
        # Check cache
        cached = cache.get(key)
        if cached is not None:
            return cached
        
        # Cache miss in strict mode
        if cfg.strict:
            raise RuntimeError(
                f"Repeatability strict mode: cache miss for key={key[:16]}... "
                f"Enable cache population by running with REPEATABILITY_STRICT=false"
            )
        
        # Call LLM
        response = llm_call(request_payload)
        
        # Cache response
        cache.set(key, request_payload, response, meta=meta or {})
        
        return response
        
    finally:
        cache.close()
