# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Idle Orchestrator Service
=========================

Core orchestration engine for idle maintenance tasks.
Monitors system activity and executes background tasks during idle periods.

Design:
- Non-blocking: Runs in background asyncio task
- Activity tracking: Updates on every HTTP request via middleware
- Idle detection: Configurable threshold for idle state
- Sequential execution: Tasks run one at a time to avoid resource contention
- Observable: Comprehensive status interface and logging
- Safe defaults: Dry-run mode by default, runtime configuration
"""

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from .idle_tasks import (
    IdleContext,
    IdleTask,
    TaskResult,
    get_default_tasks,
)
from .metrics_bus import get_metrics_bus, IdleTaskMetric, MetricKind


logger = logging.getLogger(__name__)


@dataclass
class OrchestratorStatus:
    """Current status of the idle orchestrator."""

    enabled: bool
    running: bool
    dry_run: bool
    idle_threshold_seconds: int
    loop_interval_seconds: int
    last_activity: Optional[datetime]
    last_idle_check: Optional[datetime]
    is_idle: bool
    tasks_registered: int
    tasks_enabled: int
    total_cycles: int
    total_tasks_executed: int
    uptime_seconds: float
    last_results: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Convert status to dictionary for API responses."""
        return {
            "enabled": self.enabled,
            "running": self.running,
            "dry_run": self.dry_run,
            "idle_threshold_seconds": self.idle_threshold_seconds,
            "loop_interval_seconds": self.loop_interval_seconds,
            "last_activity": self.last_activity.isoformat() if self.last_activity else None,
            "last_idle_check": self.last_idle_check.isoformat() if self.last_idle_check else None,
            "is_idle": self.is_idle,
            "tasks_registered": self.tasks_registered,
            "tasks_enabled": self.tasks_enabled,
            "total_cycles": self.total_cycles,
            "total_tasks_executed": self.total_tasks_executed,
            "uptime_seconds": self.uptime_seconds,
            "last_results": self.last_results,
        }


class IdleOrchestrator:
    """
    Core orchestrator for idle maintenance tasks.

    The orchestrator:
    1. Monitors system activity via notify_activity() calls
    2. Detects idle state when no activity for threshold duration
    3. Executes registered tasks sequentially during idle periods
    4. Provides status interface for monitoring and control
    5. Supports runtime configuration changes

    Safe defaults:
    - enabled=True (orchestrator runs)
    - dry_run=True (tasks don't make changes)
    - threshold=300s (5 minutes idle required)
    - interval=60s (check every minute)
    """

    def __init__(
        self,
        enabled: bool = True,
        dry_run: bool = True,
        idle_threshold_seconds: int = 300,
        loop_interval_seconds: int = 60,
        ingest_path: Optional[Path] = None,
        stmvault_path: Optional[Path] = None,
        ltmvault_path: Optional[Path] = None,
        tasks: Optional[List[IdleTask]] = None,
        app_state: Optional[Any] = None,
    ):
        """
        Initialize idle orchestrator.

        Args:
            enabled: Whether orchestrator is enabled
            dry_run: Whether tasks run in dry-run mode (no changes)
            idle_threshold_seconds: Seconds of inactivity to trigger idle state
            loop_interval_seconds: Seconds between idle checks
            ingest_path: Path to ingest folder
            stmvault_path: Path to STMVault
            ltmvault_path: Path to LTMVault
            tasks: List of idle tasks (defaults to standard set)
            app_state: FastAPI app.state for service access
        """
        # Configuration
        self.enabled = enabled
        self.dry_run = dry_run
        self.idle_threshold_seconds = idle_threshold_seconds
        self.loop_interval_seconds = loop_interval_seconds

        # Paths
        self.ingest_path = ingest_path or Path("./Ingest/inbox/new")
        self.stmvault_path = stmvault_path or Path("./vaults/stmvault")
        self.ltmvault_path = ltmvault_path or Path("./vaults/ltmvault")

        # Application state
        self.app_state = app_state

        # Task registry
        self.tasks = tasks or get_default_tasks()

        # State tracking
        self._last_activity: datetime = datetime.now(timezone.utc)
        self._last_idle_check: Optional[datetime] = None
        self._is_idle: bool = False
        self._running: bool = False
        self._task_loop: Optional[asyncio.Task] = None
        self._started_at: Optional[datetime] = None

        # Metrics
        self._total_cycles: int = 0
        self._total_tasks_executed: int = 0
        self._last_results: List[TaskResult] = []

        # Logging
        self.logger = logging.getLogger(__name__)

    def notify_activity(self):
        """
        Notify orchestrator of system activity.

        Called by ActivityMiddleware on every HTTP request.
        Resets idle timer and marks system as active.
        """
        self._last_activity = datetime.now(timezone.utc)
        if self._is_idle:
            self._is_idle = False
            self.logger.debug("[idle] System is now active (activity detected)")

    def _check_idle_state(self) -> bool:
        """
        Check if system is currently idle.

        Returns:
            True if system has been inactive for threshold duration
        """
        now = datetime.now(timezone.utc)
        self._last_idle_check = now

        if not self._last_activity:
            # No activity tracked yet, not idle
            return False

        elapsed = (now - self._last_activity).total_seconds()
        is_idle = elapsed >= self.idle_threshold_seconds

        # Log idle state transitions
        if is_idle and not self._is_idle:
            self.logger.info(f"[idle] System is now IDLE (no activity for {elapsed:.0f}s >= {self.idle_threshold_seconds}s)")
        elif not is_idle and self._is_idle:
            self.logger.info(f"[idle] System is now ACTIVE (activity within {elapsed:.0f}s < {self.idle_threshold_seconds}s)")

        self._is_idle = is_idle
        return is_idle

    def _resolve_task_dependencies(self, tasks: List[IdleTask]) -> List[IdleTask]:
        """
        Resolve task dependencies and return tasks in execution order.

        Dependencies:
        - VaultPromotionTask depends on CardReviewTask
        - TaskCardStructureTask depends on GardenerTendingTask

        Args:
            tasks: List of tasks to order

        Returns:
            List of tasks in dependency-resolved order
        """
        # Build task name to task mapping
        task_map = {task.name: task for task in tasks}

        # Define dependencies (task_name -> list of dependency task names)
        dependencies = {
            "vault_promotion": ["card_review"],
            "task_card_structure": ["gardener_tending"],
        }

        # Track which tasks have been processed
        processed = set()
        ordered = []

        def process_task(task_name: str):
            """Recursively process task and its dependencies."""
            if task_name in processed:
                return

            # Process dependencies first
            if task_name in dependencies:
                for dep_name in dependencies[task_name]:
                    if dep_name in task_map:
                        process_task(dep_name)

            # Add task to ordered list
            if task_name in task_map:
                ordered.append(task_map[task_name])
                processed.add(task_name)

        # Process all tasks
        for task in tasks:
            if task.name not in processed:
                process_task(task.name)

        # Add any remaining tasks (those without dependencies)
        for task in tasks:
            if task.name not in processed:
                ordered.append(task)

        return ordered

    async def _run_idle_tasks(self, force: bool = False):
        """
        Execute idle tasks sequentially.

        Tasks are run one at a time to avoid resource contention.
        Each task checks its own cadence and availability.
        Task dependencies are resolved before execution.

        Args:
            force: If True, skip idle check (for manual triggers)
        """
        if not self.enabled:
            self.logger.debug("[idle] Orchestrator disabled, skipping tasks")
            return

        if not force and not self._check_idle_state():
            self.logger.debug("[idle] System not idle, skipping tasks")
            return

        self.logger.info("[idle] Starting idle task cycle")
        self._total_cycles += 1

        # Build execution context
        context = await self._build_context()

        # Resolve task dependencies
        ordered_tasks = self._resolve_task_dependencies(self.tasks)

        # Execute tasks sequentially in dependency order
        results: List[TaskResult] = []
        for task in ordered_tasks:
            try:
                result = await task.run(context)
                results.append(result)

                # Track execution
                if result.status.value in ["success", "failed"]:
                    self._total_tasks_executed += 1

                # Emit metrics for this task execution
                self._emit_task_metric(result)

                # Check if still idle after each task (unless forced)
                if not force and not self._check_idle_state():
                    self.logger.info("[idle] Activity detected, stopping task cycle")
                    break

            except Exception as e:
                self.logger.error(f"[idle] Unexpected error running task {task.name}: {e}", exc_info=True)

        # Store results
        self._last_results = results

        # Log cycle completion
        executed = sum(1 for r in results if r.status.value in ["success", "failed"])
        skipped = sum(1 for r in results if r.status.value == "skipped")
        failed = sum(1 for r in results if r.status.value == "failed")

        self.logger.info(f"[idle] Completed task cycle - executed={executed}, skipped={skipped}, failed={failed}")

    async def _build_context(self) -> IdleContext:
        """
        Build execution context for idle tasks.

        Gathers services from app_state and configuration.

        Returns:
            IdleContext with services and config
        """
        # Try to get services from app_state
        memory_service = None
        vector_service = None
        ingestion_service = None
        vault_service = None

        if self.app_state:
            memory_service = getattr(self.app_state, "memory_service", None)
            vector_service = getattr(self.app_state, "vector_service", None)
            ingestion_service = getattr(self.app_state, "ingestion_service", None)
            vault_service = getattr(self.app_state, "vault_service", None)

        return IdleContext(
            app_state=self.app_state,
            memory_service=memory_service,
            vector_service=vector_service,
            ingestion_service=ingestion_service,
            vault_service=vault_service,
            dry_run=self.dry_run,
            ingest_path=self.ingest_path,
            stmvault_path=self.stmvault_path,
            ltmvault_path=self.ltmvault_path,
            execution_time=datetime.now(timezone.utc),
            idle_duration_seconds=((datetime.now(timezone.utc) - self._last_activity).total_seconds() if self._last_activity else 0.0),
        )

    def _emit_task_metric(self, result: TaskResult):
        """
        Emit telemetry metric for task execution.

        Args:
            result: TaskResult from task execution
        """
        try:
            metrics_bus = get_metrics_bus()

            metric = IdleTaskMetric(
                metric_type=MetricKind.IDLE_TASK,
                source="idle_orchestrator",
                task_name=result.task_name,
                status=result.status.value,
                duration_seconds=result.duration_seconds,
                items_processed=result.items_processed,
                dry_run=result.dry_run,
                tags={
                    "cycle": str(self._total_cycles),
                    "error": result.error_message if result.error_message else "",
                },
            )

            metrics_bus.emit(metric)

        except Exception as e:
            # Don't let metrics failures break orchestrator
            self.logger.debug(f"[idle] Failed to emit task metric: {e}")

    async def _monitoring_loop(self):
        """
        Background monitoring loop.

        Runs continuously while orchestrator is running.
        Checks idle state and executes tasks at configured interval.
        """
        self.logger.info("[idle] Monitoring loop started")

        while self._running:
            try:
                # Run idle tasks if appropriate
                await self._run_idle_tasks()

                # Sleep until next check
                await asyncio.sleep(self.loop_interval_seconds)

            except asyncio.CancelledError:
                self.logger.info("[idle] Monitoring loop cancelled")
                break
            except Exception as e:
                self.logger.error(f"[idle] Error in monitoring loop: {e}", exc_info=True)
                # Continue running despite errors
                await asyncio.sleep(self.loop_interval_seconds)

        self.logger.info("[idle] Monitoring loop stopped")

    def start(self):
        """
        Start the idle orchestrator.

        Launches background monitoring loop as asyncio task.
        Safe to call multiple times (no-op if already running).
        """
        if self._running:
            self.logger.warning("[idle] Orchestrator already running")
            return

        if not self.enabled:
            self.logger.warning("[idle] Orchestrator disabled, not starting")
            return

        self._running = True
        self._started_at = datetime.now(timezone.utc)
        self._task_loop = asyncio.create_task(self._monitoring_loop())

        mode = "DRY-RUN" if self.dry_run else "LIVE"
        self.logger.info(f"[idle] Orchestrator started ({mode}) - threshold={self.idle_threshold_seconds}s, interval={self.loop_interval_seconds}s, tasks={len(self.tasks)}")

    async def stop(self):
        """
        Stop the idle orchestrator.

        Gracefully shuts down monitoring loop and waits for completion.
        Safe to call multiple times (no-op if not running).
        """
        if not self._running:
            self.logger.warning("[idle] Orchestrator not running")
            return

        self.logger.info("[idle] Stopping orchestrator...")
        self._running = False

        if self._task_loop and not self._task_loop.done():
            self._task_loop.cancel()
            try:
                await self._task_loop
            except asyncio.CancelledError:
                pass

        self.logger.info("[idle] Orchestrator stopped")

    def status(self) -> OrchestratorStatus:
        """
        Get current orchestrator status.

        Returns:
            OrchestratorStatus with current state and metrics
        """
        uptime = 0.0
        if self._started_at:
            uptime = (datetime.now(timezone.utc) - self._started_at).total_seconds()

        tasks_enabled = sum(1 for task in self.tasks if task.enabled)

        return OrchestratorStatus(
            enabled=self.enabled,
            running=self._running,
            dry_run=self.dry_run,
            idle_threshold_seconds=self.idle_threshold_seconds,
            loop_interval_seconds=self.loop_interval_seconds,
            last_activity=self._last_activity,
            last_idle_check=self._last_idle_check,
            is_idle=self._is_idle,
            tasks_registered=len(self.tasks),
            tasks_enabled=tasks_enabled,
            total_cycles=self._total_cycles,
            total_tasks_executed=self._total_tasks_executed,
            uptime_seconds=uptime,
            last_results=[r.to_dict() for r in self._last_results[-10:]],  # Last 10 results
        )

    async def run_once(self, force: bool = False) -> List[TaskResult]:
        """
        Manually trigger one idle task cycle.

        Useful for testing, manual maintenance, or cron jobs.

        Args:
            force: If True, run even if not idle

        Returns:
            List of task results from the cycle
        """
        if not self.enabled:
            self.logger.warning("[idle] Orchestrator disabled, cannot run")
            return []

        if not force and not self._check_idle_state():
            self.logger.warning("[idle] System not idle, cannot run (use force=True to override)")
            return []

        self.logger.info(f"[idle] Manual trigger: running task cycle (force={force})")

        await self._run_idle_tasks(force=force)
        return self._last_results

    def update_config(
        self,
        enabled: Optional[bool] = None,
        dry_run: Optional[bool] = None,
        idle_threshold_seconds: Optional[int] = None,
        loop_interval_seconds: Optional[int] = None,
    ):
        """
        Update orchestrator configuration at runtime.

        Changes take effect immediately without restart.

        Args:
            enabled: Enable/disable orchestrator
            dry_run: Enable/disable dry-run mode
            idle_threshold_seconds: Update idle threshold
            loop_interval_seconds: Update loop interval
        """
        changed = []

        if enabled is not None and enabled != self.enabled:
            old = self.enabled
            self.enabled = enabled
            changed.append(f"enabled: {old} → {enabled}")

            # Start/stop based on new state
            if enabled and not self._running:
                self.start()
            elif not enabled and self._running:
                asyncio.create_task(self.stop())

        if dry_run is not None and dry_run != self.dry_run:
            old = self.dry_run
            self.dry_run = dry_run
            changed.append(f"dry_run: {old} → {dry_run}")

        if idle_threshold_seconds is not None and idle_threshold_seconds != self.idle_threshold_seconds:
            old = self.idle_threshold_seconds
            self.idle_threshold_seconds = idle_threshold_seconds
            changed.append(f"idle_threshold_seconds: {old} → {idle_threshold_seconds}")

        if loop_interval_seconds is not None and loop_interval_seconds != self.loop_interval_seconds:
            old = self.loop_interval_seconds
            self.loop_interval_seconds = loop_interval_seconds
            changed.append(f"loop_interval_seconds: {old} → {loop_interval_seconds}")

        if changed:
            self.logger.info(f"[idle] Configuration updated: {', '.join(changed)}")
        else:
            self.logger.debug("[idle] No configuration changes")

    def register_task(self, task: IdleTask):
        """
        Register a new idle task.

        Tasks can be added dynamically at runtime.

        Args:
            task: IdleTask instance to register
        """
        if any(t.name == task.name for t in self.tasks):
            self.logger.warning(f"[idle] Task {task.name} already registered, skipping")
            return

        self.tasks.append(task)
        self.logger.info(f"[idle] Registered task: {task.name} (interval={task.interval_seconds}s)")

    def unregister_task(self, task_name: str) -> bool:
        """
        Unregister an idle task by name.

        Args:
            task_name: Name of task to remove

        Returns:
            True if task was found and removed
        """
        original_count = len(self.tasks)
        self.tasks = [t for t in self.tasks if t.name != task_name]

        if len(self.tasks) < original_count:
            self.logger.info(f"[idle] Unregistered task: {task_name}")
            return True
        else:
            self.logger.warning(f"[idle] Task not found: {task_name}")
            return False


__all__ = [
    "IdleOrchestrator",
    "OrchestratorStatus",
]
