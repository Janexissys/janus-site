# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Chat Command Documentation Generator

Generates CHAT_COMMANDS.md from command registry.

Card: CARD-V6B-DELTA-CHAT-HELP-DOCS
"""

from pathlib import Path
from typing import Dict

from .chat_command_registry import get_command_registry, CommandDef


def generate_chat_commands_doc(output_path: Path) -> str:
    """Generate CHAT_COMMANDS.md from command registry.
    
    Args:
        output_path: Path to write the documentation file
        
    Returns:
        Generated markdown content
    """
    registry = get_command_registry()
    
    # Group commands by group
    by_group: Dict[str, list] = {}
    for cmd in registry.values():
        # Avoid duplicates (aliases point to same CommandDef)
        if cmd not in by_group.get(cmd.group, []):
            by_group.setdefault(cmd.group, []).append(cmd)
    
    # Generate markdown
    md_lines = [
        "# Chat Commands Reference",
        "",
        "**Generated from**: `backend/services/chat_command_registry.py`",
        "**Last Updated**: Auto-generated from registry",
        "",
        "This document lists all available chat commands in the Janus system.",
        "",
        "---",
        "",
    ]
    
    # Get unique commands (avoid duplicates from aliases)
    unique_commands = []
    seen = set()
    for cmd in registry.values():
        if cmd.name not in seen:
            unique_commands.append(cmd)
            seen.add(cmd.name)
    
    # Overview
    md_lines.extend([
        "## Overview",
        "",
        f"Total commands: {len(unique_commands)}",
        "",
        "Commands are organized by group:",
        "",
    ])
    
    for group in sorted(by_group.keys()):
        count = len(by_group[group])
        md_lines.append(f"- **{group.title()}**: {count} command(s)")
    
    md_lines.extend(["", "---", ""])
    
    # Commands by group
    for group in sorted(by_group.keys()):
        commands = by_group[group]
        md_lines.extend([
            f"## {group.title()} Commands",
            "",
        ])
        
        for cmd in sorted(commands, key=lambda c: c.full_trigger):
            md_lines.extend([
                f"### `{cmd.full_trigger}`",
                "",
                f"**Summary**: {cmd.summary}",
                "",
                f"**Usage**: `{cmd.usage}`",
                "",
            ])
            
            if cmd.aliases:
                md_lines.extend([
                    f"**Aliases**: {', '.join(cmd.aliases)}",
                    "",
                ])
            
            md_lines.append("---")
            md_lines.append("")
    
    # Examples section
    md_lines.extend([
        "## Examples",
        "",
        "### Card Lifecycle",
        "",
        "```",
        "/edit card CARD-123 title=NewTitle content=Updated",
        "/move card CARD-123 to review",
        "/promote card CARD-123",
        "/next bin CARD-123",
        "/validate deps CARD-123",
        "```",
        "",
        "### Help",
        "",
        "```",
        "/help",
        "/help cards",
        "/help ingest",
        "```",
        "",
        "---",
        "",
        "## Notes",
        "",
        "- All commands start with `/`",
        "- Commands are case-insensitive",
        "- Use `/help` to see available commands",
        "- Use `/help <group>` for group-specific help",
        "",
    ])
    
    content = "\n".join(md_lines)
    
    # Write to file
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(content, encoding="utf-8")
    
    return content


def generate_docs(output_dir: Path = None) -> Path:
    """Generate chat commands documentation.
    
    Args:
        output_dir: Optional output directory (defaults to docs/)
        
    Returns:
        Path to generated file
    """
    if output_dir is None:
        # Default to greenfield/docs/
        output_dir = Path(__file__).parent.parent.parent / "docs"
    
    output_path = output_dir / "CHAT_COMMANDS.md"
    generate_chat_commands_doc(output_path)
    
    return output_path

