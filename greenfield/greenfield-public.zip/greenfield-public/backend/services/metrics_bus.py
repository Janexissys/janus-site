# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Minimal metrics bus stub for greenfield backend.

Provides basic metrics bus interface for idle orchestrator.
"""

import logging
from datetime import datetime
from enum import Enum
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


class MetricKind(str, Enum):
    """Enumeration of supported metric categories."""
    LATENCY = "latency"
    MC_VARIANCE = "mc_variance"
    THROUGHPUT = "throughput"
    ERROR_RATE = "error_rate"
    IDLE_TASK = "idle_task"


class IdleTaskMetric:
    """Idle orchestrator task execution metric."""
    
    def __init__(
        self,
        metric_type: MetricKind,
        source: str,
        task_name: str,
        status: str,
        duration_seconds: float,
        items_processed: int = 0,
        dry_run: bool = True,
        tags: Optional[Dict[str, str]] = None,
    ):
        self.metric_type = metric_type
        self.source = source
        self.task_name = task_name
        self.status = status
        self.duration_seconds = duration_seconds
        self.items_processed = items_processed
        self.dry_run = dry_run
        self.tags = tags or {}
        self.timestamp = datetime.utcnow()


class MetricsBus:
    """Minimal metrics bus stub."""
    
    def __init__(self, capacity: int = 1000):
        self._capacity = capacity
        self._metrics = []
    
    def emit(self, metric: Any) -> Any:
        """Emit a metric (stub - just logs for now)."""
        logger.debug(f"Metrics bus emit: {metric.task_name if hasattr(metric, 'task_name') else 'unknown'}")
        return metric


_GLOBAL_METRICS_BUS = MetricsBus()


def get_metrics_bus() -> MetricsBus:
    """Return the shared metrics bus instance."""
    return _GLOBAL_METRICS_BUS

