# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Chat Command Registry

Single source of truth for all chat commands. Used by:
- Gateway (routing)
- /help command
- Docs generator (CHAT_COMMANDS.md)

Card: CARD-V6B-DELTA-CHAT-GATEWAY
"""

from dataclasses import dataclass
from typing import Dict, List


@dataclass
class CommandDef:
    """Command definition."""
    name: str              # "edit"
    full_trigger: str      # "/edit"
    group: str            # "cards", "ingest", "system"
    summary: str          # one line for /help
    usage: str            # "/edit card <id> [fields]"
    handler_name: str      # "handle_edit_card"
    aliases: List[str]    # optional aliases


def get_command_registry() -> Dict[str, CommandDef]:
    """Get the command registry.
    
    Returns:
        Dictionary mapping command triggers to CommandDef objects.
    """
    commands = [
        # Card lifecycle commands (P1)
        CommandDef(
            name="edit",
            full_trigger="/edit",
            group="cards",
            summary="Edit an existing card",
            usage="/edit card <id> [field=value ...]",
            handler_name="handle_edit_card",
            aliases=[],
        ),
        CommandDef(
            name="move",
            full_trigger="/move",
            group="cards",
            summary="Move card to lifecycle state",
            usage="/move card <id> to <state>",
            handler_name="handle_move_card",
            aliases=[],
        ),
        CommandDef(
            name="promote",
            full_trigger="/promote",
            group="cards",
            summary="Promote card to next lifecycle state",
            usage="/promote card <id>",
            handler_name="handle_promote_card",
            aliases=[],
        ),
        CommandDef(
            name="next_bin",
            full_trigger="/next",
            group="cards",
            summary="Move card to next MC bin",
            usage="/next bin <id>",
            handler_name="handle_next_bin",
            aliases=["/nextbin"],
        ),
        CommandDef(
            name="validate",
            full_trigger="/validate",
            group="cards",
            summary="Validate card dependencies",
            usage="/validate deps <id>",
            handler_name="handle_validate_deps",
            aliases=["/validate_deps", "/check_deps"],
        ),
        CommandDef(
            name="analyze_mc",
            full_trigger="/analyze",
            group="cards",
            summary="Analyze MC bins and identify low bins",
            usage="/analyze mc <id>",
            handler_name="handle_analyze_mc",
            aliases=["/analyze_mc", "/mc_analyze"],
        ),
        CommandDef(
            name="improve_bin",
            full_trigger="/improve",
            group="cards",
            summary="Improve a specific MC bin for a card",
            usage="/improve bin <id> <bin_name>",
            handler_name="handle_improve_bin",
            aliases=["/improve_bin"],
        ),
        # Help command
        CommandDef(
            name="help",
            full_trigger="/help",
            group="system",
            summary="Show available commands",
            usage="/help [group]",
            handler_name="handle_help",
            aliases=["/h", "/?"],
        ),
    ]
    
    # Build registry with trigger as key
    registry = {
        cmd.full_trigger: cmd
        for cmd in commands
    }
    
    # Add aliases to registry
    for cmd in commands:
        for alias in cmd.aliases:
            registry[alias] = cmd
    
    return registry

