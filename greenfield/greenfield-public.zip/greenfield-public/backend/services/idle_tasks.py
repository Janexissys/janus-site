# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Idle Task System
================

Idle task primitives and concrete implementations for background maintenance.
Tasks execute during system idle periods to perform cleanup, consolidation,
and maintenance operations without impacting foreground requests.

Design Principles:
- Safe defaults: All tasks default to dry-run mode
- Graceful degradation: Skip if required services unavailable
- Independent cadences: Each task has its own execution interval
- Observable: Comprehensive logging for monitoring
"""

import asyncio
import logging
import shutil
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional


logger = logging.getLogger(__name__)


class TaskStatus(str, Enum):
    """Status of idle task execution."""

    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class IdleContext:
    """
    Context passed to idle tasks during execution.

    Provides access to application services and configuration
    needed for task execution.
    """

    # Application services (may be None if not available)
    app_state: Optional[Any] = None
    memory_service: Optional[Any] = None
    vector_service: Optional[Any] = None
    ingestion_service: Optional[Any] = None
    vault_service: Optional[Any] = None

    # Configuration
    dry_run: bool = True
    ingest_path: Path = field(default_factory=lambda: Path("./Ingest/inbox/new"))
    stmvault_path: Path = field(default_factory=lambda: Path("./vaults/stmvault"))
    ltmvault_path: Path = field(default_factory=lambda: Path("./vaults/ltmvault"))

    # Execution metadata
    execution_time: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    idle_duration_seconds: float = 0.0

    def get_service(self, service_name: str) -> Optional[Any]:
        """
        Safely get a service by name.

        Args:
            service_name: Name of service (memory, vector, ingestion, vault)

        Returns:
            Service instance or None if not available
        """
        service_map = {
            "memory": self.memory_service,
            "vector": self.vector_service,
            "ingestion": self.ingestion_service,
            "vault": self.vault_service,
        }
        return service_map.get(service_name)


@dataclass
class TaskResult:
    """Result of idle task execution."""

    task_name: str
    status: TaskStatus
    started_at: datetime
    completed_at: datetime
    duration_seconds: float
    items_processed: int = 0
    items_skipped: int = 0
    items_failed: int = 0
    dry_run: bool = True
    error_message: Optional[str] = None
    details: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert result to dictionary for serialization."""
        return {
            "task_name": self.task_name,
            "status": self.status.value,
            "started_at": self.started_at.isoformat(),
            "completed_at": self.completed_at.isoformat(),
            "duration_seconds": self.duration_seconds,
            "items_processed": self.items_processed,
            "items_skipped": self.items_skipped,
            "items_failed": self.items_failed,
            "dry_run": self.dry_run,
            "error_message": self.error_message,
            "details": self.details,
        }


class IdleTask(ABC):
    """
    Base class for idle maintenance tasks.

    All idle tasks must:
    - Have a unique name
    - Specify minimum interval between executions
    - Implement execute() method
    - Default to dry-run mode
    - Handle service unavailability gracefully
    """

    def __init__(
        self,
        name: str,
        interval_seconds: int,
        description: str = "",
        enabled: bool = True,
    ):
        """
        Initialize idle task.

        Args:
            name: Unique task name
            interval_seconds: Minimum seconds between executions
            description: Human-readable task description
            enabled: Whether task is enabled
        """
        self.name = name
        self.interval_seconds = interval_seconds
        self.description = description
        self.enabled = enabled
        self.last_run: Optional[datetime] = None
        self.last_result: Optional[TaskResult] = None
        self.logger = logging.getLogger(f"{__name__}.{name}")

    async def can_run(self, context: IdleContext) -> bool:
        """
        Check if task can run based on interval and availability.

        Args:
            context: Idle execution context

        Returns:
            True if task should run, False otherwise
        """
        if not self.enabled:
            self.logger.debug(f"[idle] Task {self.name} is disabled")
            return False

        # Check interval
        if self.last_run:
            elapsed = (context.execution_time - self.last_run).total_seconds()
            if elapsed < self.interval_seconds:
                self.logger.debug(f"[idle] Task {self.name} interval not met: {elapsed:.0f}s < {self.interval_seconds}s")
                return False

        # Check service availability (subclass override)
        if not await self.check_availability(context):
            self.logger.warning(f"[idle] Task {self.name} required services unavailable")
            return False

        return True

    @abstractmethod
    async def check_availability(self, context: IdleContext) -> bool:
        """
        Check if required services are available.

        Subclasses must implement this to verify their dependencies.

        Args:
            context: Idle execution context

        Returns:
            True if all required services available
        """
        pass

    @abstractmethod
    async def execute(self, context: IdleContext) -> TaskResult:
        """
        Execute the idle task.

        Subclasses must implement the actual task logic here.

        Args:
            context: Idle execution context with services and config

        Returns:
            TaskResult with execution details
        """
        pass

    async def run(self, context: IdleContext) -> TaskResult:
        """
        Run the task with error handling and timing.

        This is the public interface - it wraps execute() with
        error handling, timing, and result tracking.

        Args:
            context: Idle execution context

        Returns:
            TaskResult with execution details
        """
        started_at = datetime.now(timezone.utc)

        try:
            # Check if we can run
            if not await self.can_run(context):
                result = TaskResult(
                    task_name=self.name,
                    status=TaskStatus.SKIPPED,
                    started_at=started_at,
                    completed_at=datetime.now(timezone.utc),
                    duration_seconds=0.0,
                    dry_run=context.dry_run,
                    details={"reason": "interval not met or disabled"},
                )
                self.last_result = result
                return result

            # Log start with full context
            mode = "DRY-RUN" if context.dry_run else "LIVE"
            self.logger.info(
                f"[idle] Starting task: {self.name} ({mode})",
                extra={
                    "task_operation": "start",
                    "task_name": self.name,
                    "task_mode": mode,
                    "interval_seconds": self.interval_seconds,
                    "idle_duration_seconds": context.idle_duration_seconds,
                    "dry_run": context.dry_run,
                    "services_available": {
                        "memory": context.memory_service is not None,
                        "vector": context.vector_service is not None,
                        "ingestion": context.ingestion_service is not None,
                        "vault": context.vault_service is not None,
                    },
                },
            )

            # Execute task
            result = await self.execute(context)

            # Update tracking
            self.last_run = datetime.now(timezone.utc)
            self.last_result = result

            # Log completion with metrics
            self.logger.info(
                f"[idle] Completed task: {self.name} - status={result.status.value}, processed={result.items_processed}, duration={result.duration_seconds:.2f}s",
                extra={
                    "task_operation": "complete",
                    "task_name": self.name,
                    "task_status": result.status.value,
                    "items_processed": result.items_processed,
                    "items_skipped": result.items_skipped,
                    "items_failed": result.items_failed,
                    "duration_seconds": result.duration_seconds,
                    "duration_ms": result.duration_seconds * 1000,
                    "dry_run": result.dry_run,
                    "error_message": result.error_message,
                    "details": result.details,
                },
            )

            return result

        except Exception as e:
            # Handle errors gracefully
            completed_at = datetime.now(timezone.utc)
            duration = (completed_at - started_at).total_seconds()

            result = TaskResult(
                task_name=self.name,
                status=TaskStatus.FAILED,
                started_at=started_at,
                completed_at=completed_at,
                duration_seconds=duration,
                dry_run=context.dry_run,
                error_message=str(e),
                details={"exception_type": type(e).__name__},
            )

            self.last_result = result
            self.logger.error(
                f"[idle] Task {self.name} failed: {e}",
                exc_info=True,
                extra={
                    "task_operation": "error",
                    "task_name": self.name,
                    "task_status": "failed",
                    "duration_seconds": duration,
                    "duration_ms": duration * 1000,
                    "error_type": type(e).__name__,
                    "error_message": str(e),
                    "dry_run": context.dry_run,
                },
            )

            return result


# ============================================================================
# CONCRETE TASK IMPLEMENTATIONS
# ============================================================================


class IngestProcessingTask(IdleTask):
    """
    Process files from the ingest folder.

    Monitors the ingest folder for new files and processes them
    during idle periods. Files are parsed, validated, and ingested
    into the memory system.

    Interval: 10 minutes (600 seconds)
    Services: ingestion_service
    """

    def __init__(self):
        super().__init__(
            name="ingest_processing",
            interval_seconds=600,  # 10 minutes
            description="Process files from ingest folder",
        )

    async def check_availability(self, context: IdleContext) -> bool:
        """Check if ingestion service is available."""
        return context.ingestion_service is not None or context.get_service("ingestion") is not None

    async def execute(self, context: IdleContext) -> TaskResult:
        """Process files from ingest folder."""
        started_at = datetime.now(timezone.utc)
        processed = 0
        skipped = 0
        failed = 0

        try:
            # Resolve ingest path (handle both absolute and relative paths)
            ingest_path = context.ingest_path
            if not ingest_path.is_absolute():
                # Resolve relative path from project root
                from pathlib import Path
                project_root = Path.cwd()
                ingest_path = (project_root / ingest_path).resolve()
            
            # Ensure the ingest path directory exists, create if needed
            if not ingest_path.exists():
                self.logger.info(f"[idle] Creating ingest path: {ingest_path}")
                ingest_path.mkdir(parents=True, exist_ok=True)
            
            # Determine ingest root based on path structure
            # Path could be: ./Ingest/inbox/new or Ingest/inbox/new or full absolute path
            if ingest_path.name == "new" and ingest_path.parent.name == "inbox":
                # Standard structure: .../Ingest/inbox/new
                ingest_root = ingest_path.parent.parent
            elif ingest_path.name == "inbox":
                # Path points to inbox directory
                ingest_root = ingest_path.parent
                ingest_path = ingest_path / "new"
                ingest_path.mkdir(parents=True, exist_ok=True)
            else:
                # Fallback: assume ingest_path is the root, create inbox/new structure
                ingest_root = ingest_path
                ingest_path = ingest_root / "inbox" / "new"
                ingest_path.mkdir(parents=True, exist_ok=True)
            
            # Ensure processing, archive, dlq, error, and unsupported directories exist
            processing_dir = ingest_root / "inbox" / "processing"
            archive_dir = ingest_root / "inbox" / "archive"
            dlq_dir = ingest_root / "inbox" / "dlq"
            error_dir = ingest_root / "inbox" / "error"
            unsupported_dir = ingest_root / "inbox" / "unsupported"
            
            for dir_path in [processing_dir, archive_dir, dlq_dir, error_dir, unsupported_dir, ingest_path]:
                dir_path.mkdir(parents=True, exist_ok=True)
            
            # Find files to process
            # Filter out system output files (e.g., 00_INDEX_results-*.md) - these are JSON results, not content
            # Supported file types: .md, .rmd, .txt
            all_files = list(ingest_path.glob("*.md")) + list(ingest_path.glob("*.rmd")) + list(ingest_path.glob("*.txt"))
            
            # Handle unsupported file types (move to unsupported folder)
            unsupported_files = [f for f in ingest_path.glob("*") if f.is_file() and f.suffix.lower() not in [".md", ".rmd", ".txt"]]
            unsupported_count = 0
            for unsupported_file in unsupported_files:
                try:
                    unsupported_path = unsupported_dir / unsupported_file.name
                    if not context.dry_run:
                        shutil.move(str(unsupported_file), str(unsupported_path))
                        self.logger.info(f"[idle] Moved unsupported file type to unsupported/: {unsupported_file.name}")
                        unsupported_count += 1
                    else:
                        self.logger.info(f"[idle] DRY-RUN: Would move unsupported file {unsupported_file.name} to unsupported/")
                except Exception as e:
                    self.logger.warning(f"[idle] Failed to move unsupported file {unsupported_file.name}: {e}")
            
            def is_system_output_file(file_path: Path) -> bool:
                """Check if file is a system output file (should be filtered out)."""
                # Check filename pattern
                if "_results" in file_path.stem:
                    return True
                
                # Backup check: Try to read and validate as JSON
                try:
                    content = file_path.read_text(encoding="utf-8")
                    import json
                    json.loads(content)
                    # If valid JSON, it's likely system output
                    return True
                except (json.JSONDecodeError, ValueError, UnicodeDecodeError, IOError):
                    # Not JSON or can't read - treat as regular content
                    return False
            
            files = []
            filtered_count = 0
            for f in all_files:
                if is_system_output_file(f):
                    filtered_count += 1
                    self.logger.debug(f"[idle] Skipping system output file: {f.name}")
                else:
                    files.append(f)
            
            if filtered_count > 0:
                self.logger.info(f"[idle] Filtered out {filtered_count} system output file(s)")

            # Fallback: If no files in inbox, find other work for assembly line
            fallback_work_items = []
            if not files:
                self.logger.debug(f"[idle] No files to process in {ingest_path}, checking for fallback work")

                # Helper function to check if file has been processed (using memory database like Option C)
                async def _is_file_already_processed(file_path: Path) -> bool:
                    """Check if file has already been processed by checking memory database (Option C tracking)."""
                    try:
                        import hashlib
                        from sqlalchemy import select
                        from ..models.memory import MemoryRecord
                        from ..core.database import get_db_session
                        
                        # Read file and compute hash (same as Option C - MD5 of full content)
                        try:
                            content = file_path.read_text(encoding="utf-8")
                            file_hash = hashlib.md5(content.encode("utf-8")).hexdigest()
                        except Exception:
                            return False  # Can't read file, assume not processed
                        
                        # Check if memory record exists with matching file_path and hash (Option C tracking)
                        async with get_db_session() as session:
                            result = await session.execute(
                                select(MemoryRecord).where(
                                    MemoryRecord.source_file_path == str(file_path),
                                    MemoryRecord.source_file_hash == file_hash
                                )
                            )
                            existing = result.scalar_one_or_none()
                            if existing:
                                self.logger.debug(f"[idle] File already processed (Option C): {file_path.name}")
                                return True
                            return False
                    except Exception as e:
                        self.logger.debug(f"[idle] Could not check processing status for {file_path.name}: {e}")
                        return False  # On error, assume not processed to allow retry
                
                # 1. Check for vault files needing promotion (MC >= 8.0)
                try:
                    stm_files = list(context.stmvault_path.rglob("*.md")) + list(context.stmvault_path.rglob("*.rmd"))
                    # Sort by modification time (oldest first) for consistent processing order
                    stm_files.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0)
                    
                    promotion_candidates = []
                    for vault_file in stm_files:
                        # Check if already processed
                        if await _is_file_already_processed(vault_file):
                            continue
                        
                        try:
                            content = vault_file.read_text(encoding="utf-8")
                            if "---" in content and "mc_score" in content:
                                frontmatter = content.split("---")[1].split("---")[0]
                                for line in frontmatter.split("\n"):
                                    if "mc_score" in line:
                                        try:
                                            mc_value = float(line.split(":")[1].strip())
                                            if mc_value >= 8.0:
                                                promotion_candidates.append((vault_file, mc_value))
                                                break
                                        except (ValueError, IndexError):
                                            pass
                        except Exception:
                            continue
                        
                        # Limit to 5 promotion candidates
                        if len(promotion_candidates) >= 5:
                            break
                    
                    # Add promotion candidates to work items
                    for vault_file, mc_value in promotion_candidates:
                        fallback_work_items.append(("vault_promotion", vault_file, mc_value))
                        
                except Exception as e:
                    self.logger.debug(f"[idle] Could not scan vault for promotion candidates: {e}")

                # 2. Check for vault files needing tending (any files in STM vault, not already processed)
                try:
                    stm_files = list(context.stmvault_path.rglob("*.md")) + list(context.stmvault_path.rglob("*.rmd"))
                    # Sort by modification time (oldest first) for consistent processing order
                    stm_files.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0)
                    
                    tending_candidates = []
                    for vault_file in stm_files:
                        # Skip if already in promotion list
                        if any(item[1] == vault_file for item in fallback_work_items):
                            continue
                        
                        # Check if already processed
                        if await _is_file_already_processed(vault_file):
                            continue
                        
                        tending_candidates.append(vault_file)
                        
                        # Limit to 5 tending candidates (or fill up to 5 total including promotions)
                        if len(tending_candidates) + len(fallback_work_items) >= 5:
                            break
                    
                    # Add tending candidates to work items
                    for vault_file in tending_candidates:
                        fallback_work_items.append(("vault_tending", vault_file, None))
                        
                except Exception as e:
                    self.logger.debug(f"[idle] Could not scan vault for tending candidates: {e}")

                # 3. Check for task cards needing review (would require CardManager access)
                # This is deferred to AssemblyLineMaintenanceTask for now

                if not fallback_work_items:
                    self.logger.debug(f"[idle] No fallback work found")
                    return TaskResult(
                        task_name=self.name,
                        status=TaskStatus.SUCCESS,
                        started_at=started_at,
                        completed_at=datetime.now(timezone.utc),
                        duration_seconds=0.0,
                        dry_run=context.dry_run,
                        details={"reason": "no_files_found", "fallback_checked": True},
                    )
                else:
                    self.logger.info(f"[idle] Found {len(fallback_work_items)} fallback work items")
            else:
                self.logger.info(f"[idle] Found {len(files)} files to process")

            # Get or create IngestJobManager instance
            ingest_manager = None
            if context.ingestion_service:
                ingest_manager = context.ingestion_service
            else:
                try:
                    from ..services.ingest_jobs import IngestJobManager

                    ingest_manager = IngestJobManager()
                except Exception as e:
                    self.logger.error(f"[idle] Failed to create IngestJobManager: {e}")
                    return TaskResult(
                        task_name=self.name,
                        status=TaskStatus.FAILED,
                        started_at=started_at,
                        completed_at=datetime.now(timezone.utc),
                        duration_seconds=(datetime.now(timezone.utc) - started_at).total_seconds(),
                        items_processed=processed,
                        items_skipped=skipped,
                        items_failed=failed,
                        dry_run=context.dry_run,
                        error_message=f"Failed to initialize IngestJobManager: {e}",
                    )

            # Directories already created above (in unsupported file handling)

            # Process files or fallback work items
            job_ids = []
            work_items = [(None, file_path, None) for file_path in files] if files else fallback_work_items

            for work_type, file_path, mc_score in work_items:
                processing_path = None
                try:
                    # Handle fallback work items differently
                    if work_type:
                        # Fallback work: process through assembly line directly
                        if context.dry_run:
                            self.logger.info(f"[idle] DRY-RUN: Would process {work_type} work for {file_path.name}")
                            processed += 1
                        else:
                            try:
                                from ..services.assembly_line_processor import get_assembly_line_processor

                                assembly_processor = get_assembly_line_processor()

                                content = file_path.read_text(encoding="utf-8")
                                metadata = {"source": "idle_fallback", "work_type": work_type}
                                if mc_score is not None:
                                    metadata["mc_score"] = mc_score

                                result = await assembly_processor.process_vault_content_with_crew(
                                    content=content,
                                    vault_path=file_path,
                                    metadata=metadata,
                                )

                                if result.get("final_decision") == "completed":
                                    processed += 1
                                    self.logger.info(f"[idle] Processed {work_type} work for {file_path.name}")
                                else:
                                    skipped += 1
                                    self.logger.debug(f"[idle] Skipped {work_type} work for {file_path.name} (not approved)")
                            except Exception as assembly_error:
                                failed += 1
                                self.logger.error(f"[idle] Assembly line processing failed for {file_path.name}: {assembly_error}")
                        continue

                    # Regular inbox file processing - Route through Assembly Line for full agent crew processing
                    if context.dry_run:
                        self.logger.info(f"[idle] DRY-RUN: Would process {file_path.name} through assembly line")
                        # Read content for dry-run simulation
                        content = file_path.read_text(encoding="utf-8")
                        if len(content) > 0:
                            processed += 1
                        else:
                            skipped += 1
                    else:
                        self.logger.info(f"[idle] Processing {file_path.name} through assembly line crew")

                        # Read file content
                        content = file_path.read_text(encoding="utf-8")
                        if len(content) == 0:
                            skipped += 1
                            self.logger.warning(f"[idle] Skipped empty file {file_path.name}")
                            continue

                        # CRITICAL: Check North Star ingest policy before processing
                        # This is the canonical NS gate - blocking violations
                        try:
                            from ..core.nano_agents import CaretakerAgent
                            caretaker = CaretakerAgent()
                            passes_policy, defer_reason_code = await caretaker._evaluate_ingest_policy(
                                content=content,
                                context=f"File: {file_path.name}"
                            )
                            
                            if not passes_policy:
                                # North Star policy violation - move to error folder
                                skipped += 1
                                self.logger.warning(f"[idle] North Star policy violation ({defer_reason_code}) for {file_path.name}")
                                
                                if not context.dry_run:
                                    error_path = error_dir / file_path.name
                                    shutil.move(str(file_path), str(error_path))
                                    self.logger.info(f"[idle] Moved {file_path.name} to error folder due to NS policy violation: {defer_reason_code}")
                                continue
                        except Exception as e:
                            self.logger.warning(f"[idle] North Star policy evaluation failed (non-critical): {e}, continuing with processing")

                        # Move file to processing directory
                        processing_path = processing_dir / file_path.name
                        shutil.move(str(file_path), str(processing_path))
                        self.logger.debug(f"[idle] Moved {file_path.name} to processing")

                        # Process through Assembly Line for MC scoring, tagging, and crew processing
                        try:
                            from ..services.assembly_line_processor import get_assembly_line_processor

                            assembly_processor = get_assembly_line_processor()

                            # Build card data for assembly line
                            card_data = {
                                "id": f"ingest_{file_path.stem}_{int(time.time())}",
                                "title": file_path.stem.replace("-", " ").replace("_", " ").title(),
                                "content": content,
                                "metadata": {
                                    "file_type": file_path.suffix.lower(),
                                    "path": str(processing_path),
                                    "source": "idle_ingest",
                                    "original_filename": file_path.name,
                                },
                            }

                            # Process through 6-agent crew (Caretaker, Gardener, Mercury, Sentinel, Conductor, Scribe)
                            result = await assembly_processor.process_card_with_crew(card_data)

                            # Check if approved and processed successfully
                            if result.get("final_decision") in ["approve", "completed", None]:
                                processed += 1
                                self.logger.info(f"[idle] Assembly line processed {file_path.name} - agents: {len(result.get('agents_executed', []))}")

                                # Move to archive after successful processing
                                archive_path = archive_dir / processing_path.name
                                shutil.move(str(processing_path), str(archive_path))
                                self.logger.debug(f"[idle] Archived {file_path.name}")
                            else:
                                # Check decision type to route appropriately
                                decision = result.get("final_decision", "unknown")
                                skipped += 1
                                
                                if decision == "error":
                                    # Error decisions go to error folder
                                    error_path = error_dir / processing_path.name
                                    shutil.move(str(processing_path), str(error_path))
                                    self.logger.warning(f"[idle] File {file_path.name} had error decision - moved to error folder")
                                else:
                                    # Other non-approved decisions (reject, defer, etc.) go to archive
                                    self.logger.info(f"[idle] File {file_path.name} not approved (decision: {decision})")
                                    archive_path = archive_dir / processing_path.name
                                    shutil.move(str(processing_path), str(archive_path))

                        except Exception as assembly_error:
                            # Assembly line processing failed - move to DLQ
                            failed += 1
                            self.logger.error(f"[idle] Assembly line processing failed for {file_path.name}: {assembly_error}")
                            if processing_path and processing_path.exists():
                                dlq_path = dlq_dir / processing_path.name
                                shutil.move(str(processing_path), str(dlq_path))
                                self.logger.warning(f"[idle] Moved {file_path.name} to DLQ")

                except Exception as e:
                    failed += 1
                    self.logger.error(f"[idle] Failed to process {file_path.name}: {e}", exc_info=True)
                    # Try to move to DLQ if file is stuck in processing
                    if processing_path and processing_path.exists():
                        try:
                            dlq_path = dlq_dir / processing_path.name
                            shutil.move(str(processing_path), str(dlq_path))
                            self.logger.warning(f"[idle] Moved failed file {file_path.name} to DLQ")
                        except Exception as move_error:
                            self.logger.error(f"[idle] Failed to move {file_path.name} to DLQ: {move_error}")

            # Return result
            completed_at = datetime.now(timezone.utc)
            duration = (completed_at - started_at).total_seconds()

            return TaskResult(
                task_name=self.name,
                status=TaskStatus.SUCCESS if failed == 0 else TaskStatus.FAILED,
                started_at=started_at,
                completed_at=completed_at,
                duration_seconds=duration,
                items_processed=processed,
                items_skipped=skipped,
                items_failed=failed,
                dry_run=context.dry_run,
                details={
                    "files_found": len(files) if files else 0,
                    "fallback_work_items": len(fallback_work_items) if not files else 0,
                    "ingest_path": str(ingest_path),
                    "job_ids": job_ids[:10],  # Limit to first 10 job IDs for logging
                    "job_count": len(job_ids),
                    "filtered_system_output_count": filtered_count,
                },
            )

        except Exception as e:
            completed_at = datetime.now(timezone.utc)
            duration = (completed_at - started_at).total_seconds()

            return TaskResult(
                task_name=self.name,
                status=TaskStatus.FAILED,
                started_at=started_at,
                completed_at=completed_at,
                duration_seconds=duration,
                items_processed=processed,
                items_skipped=skipped,
                items_failed=failed,
                dry_run=context.dry_run,
                error_message=str(e),
            )


class AssemblyLineMaintenanceTask(IdleTask):
    """
    Continuous card processing for assembly line when no new work is available.

    Queries CardManager for cards needing processing (pending, needs_review, etc.)
    and processes them through the assembly line to keep the system active.

    Interval: 5 minutes (300 seconds) - configured for soak/stress testing
    Dependencies: CardManager
    """

    def __init__(self):
        super().__init__(
            name="assembly_line_maintenance",
            interval_seconds=300,  # 5 minutes (soak/stress test configuration)
            description="Process existing cards through assembly line when no new work",
        )

    async def check_availability(self, context: IdleContext) -> bool:
        """Check if CardManager is available."""
        # CardManager would be accessed through app_state if available
        return context.app_state is not None

    async def execute(self, context: IdleContext) -> TaskResult:
        """Process cards through assembly line."""
        started_at = datetime.now(timezone.utc)
        processed = 0
        skipped = 0
        failed = 0

        try:
            # Import assembly line processor
            try:
                from ..services.assembly_line_processor import get_assembly_line_processor

                assembly_processor = get_assembly_line_processor()
            except Exception as e:
                self.logger.error(f"[idle] Failed to import AssemblyLineProcessor: {e}")
                return TaskResult(
                    task_name=self.name,
                    status=TaskStatus.FAILED,
                    started_at=started_at,
                    completed_at=datetime.now(timezone.utc),
                    duration_seconds=0.0,
                    dry_run=context.dry_run,
                    error_message=f"Failed to import AssemblyLineProcessor: {e}",
                )

            # Get CardManager - try app_state first, then create with database session
            card_manager = None
            db_session = None
            
            if context.app_state and hasattr(context.app_state, "card_manager"):
                card_manager = context.app_state.card_manager
                self.logger.debug("[idle] Using CardManager from app_state")
            else:
                # Create CardManager with database session
                try:
                    from ..services.card_manager import CardManager
                    from ..core.database import get_db_session
                    
                    # Get database session for CardManager
                    db_session = get_db_session()
                    card_manager = CardManager(db_session)
                    self.logger.debug("[idle] Created CardManager with database session")
                except Exception as e:
                    self.logger.warning(f"[idle] Failed to create CardManager: {e}")
                    return TaskResult(
                        task_name=self.name,
                        status=TaskStatus.SKIPPED,
                        started_at=started_at,
                        completed_at=datetime.now(timezone.utc),
                        duration_seconds=0.0,
                        dry_run=context.dry_run,
                        details={"reason": f"card_manager_creation_failed: {e}"},
                    )

            # Query for cards needing processing
            # Look for cards in "general" work mode that haven't been processed yet
            try:
                # Use async context manager for database session if we created one
                if db_session:
                    async with db_session as session:
                        card_manager.db = session
                        cards_to_process = await card_manager.get_cards_by_work_mode("general", limit=10, offset=0)
                else:
                    # CardManager from app_state should handle its own session
                    cards_to_process = await card_manager.get_cards_by_work_mode("general", limit=10, offset=0)
                
                if not cards_to_process:
                    self.logger.debug("[idle] No cards found for processing")
                    return TaskResult(
                        task_name=self.name,
                        status=TaskStatus.SUCCESS,
                        started_at=started_at,
                        completed_at=datetime.now(timezone.utc),
                        duration_seconds=(datetime.now(timezone.utc) - started_at).total_seconds(),
                        items_processed=processed,
                        items_skipped=skipped,
                        items_failed=failed,
                        dry_run=context.dry_run,
                        details={"reason": "no_cards_found"},
                    )
                
                self.logger.info(f"[idle] Found {len(cards_to_process)} cards to process through assembly line")
                
                # Process cards through assembly line
                for card in cards_to_process[:10]:  # Limit to 10 cards per cycle
                    try:
                        # Convert card to card_data format for assembly line
                        card_data = {
                            "id": str(card.id),
                            "title": card.title,
                            "content": card.content.get("description", "") if isinstance(card.content, dict) else str(card.content),
                            "metadata": {
                                "card_type": card.card_type.value if hasattr(card.card_type, 'value') else str(card.card_type),
                                "work_mode": card.work_mode.value if hasattr(card.work_mode, 'value') else str(card.work_mode),
                                "priority": card.priority.value if hasattr(card.priority, 'value') else str(card.priority),
                                "source": "assembly_line_maintenance",
                            },
                        }
                        
                        # Process through assembly line
                        if not context.dry_run:
                            result = await assembly_processor.process_card_with_crew(card_data)
                            if result.get("final_decision") == "approve":
                                processed += 1
                                self.logger.info(f"[idle] Processed card {card.id} through assembly line")
                            else:
                                skipped += 1
                                self.logger.debug(f"[idle] Card {card.id} not approved: {result.get('final_decision')}")
                        else:
                            self.logger.info(f"[idle] DRY-RUN: Would process card {card.id}")
                            processed += 1
                            
                    except Exception as e:
                        failed += 1
                        self.logger.error(f"[idle] Failed to process card {card.id}: {e}", exc_info=True)
                
                return TaskResult(
                    task_name=self.name,
                    status=TaskStatus.SUCCESS,
                    started_at=started_at,
                    completed_at=datetime.now(timezone.utc),
                    duration_seconds=(datetime.now(timezone.utc) - started_at).total_seconds(),
                    items_processed=processed,
                    items_skipped=skipped,
                    items_failed=failed,
                    dry_run=context.dry_run,
                    details={"cards_found": len(cards_to_process), "processed": processed, "skipped": skipped, "failed": failed},
                )
                
            except Exception as e:
                self.logger.error(f"[idle] Failed to query cards: {e}", exc_info=True)
                return TaskResult(
                    task_name=self.name,
                    status=TaskStatus.FAILED,
                    started_at=started_at,
                    completed_at=datetime.now(timezone.utc),
                    duration_seconds=(datetime.now(timezone.utc) - started_at).total_seconds(),
                    dry_run=context.dry_run,
                    error_message=f"Failed to query cards: {e}",
                )

        except Exception as e:
            completed_at = datetime.now(timezone.utc)
            duration = (completed_at - started_at).total_seconds()

            return TaskResult(
                task_name=self.name,
                status=TaskStatus.FAILED,
                started_at=started_at,
                completed_at=completed_at,
                duration_seconds=duration,
                items_processed=processed,
                items_skipped=skipped,
                items_failed=failed,
                dry_run=context.dry_run,
                error_message=str(e),
            )


class WorkItemProcessingTask(IdleTask):
    """
    Processes pending work items through the assembly line.
    
    Queries for work items with status="pending", picks them up,
    processes them through the assembly line, and updates status.
    
    Interval: 1 minute (60 seconds) - frequent for responsive processing
    Dependencies: AgentCrewService, AssemblyLineProcessor, CardManager
    """

    def __init__(self):
        super().__init__(
            name="work_item_processing",
            interval_seconds=60,  # 1 minute
            description="Process pending work items through assembly line",
        )

    async def check_availability(self, context: IdleContext) -> bool:
        """Check if required services are available."""
        try:
            from ..services.agent_crew_service import AgentCrewService
            from ..services.assembly_line_processor import get_assembly_line_processor
            from ..services.card_manager import CardManager
            from ..core.database import get_db_session
            return True
        except Exception as e:
            self.logger.warning(f"[idle] WorkItemProcessingTask services unavailable: {e}")
            return False

    async def execute(self, context: IdleContext) -> TaskResult:
        """Process pending work items."""
        started_at = datetime.now(timezone.utc)
        processed = 0
        skipped = 0
        failed = 0

        try:
            from ..services.agent_crew_service import AgentCrewService
            from ..services.assembly_line_processor import get_assembly_line_processor
            from ..services.card_manager import CardManager
            from ..core.database import get_db_session
            from ..models.work_item import WorkItem
            from sqlalchemy import select

            crew_service = AgentCrewService()
            assembly_processor = get_assembly_line_processor()

            # Query for pending work items (limit to 10 per cycle)
            async with get_db_session() as db:
                work_items_query = (
                    select(WorkItem)
                    .where(WorkItem.status == "pending")
                    .order_by(WorkItem.created_at.asc())  # Process oldest first
                    .limit(10)
                )

                result = await db.execute(work_items_query)
                pending_items = result.scalars().all()

                if not pending_items:
                    return TaskResult(
                        task_name=self.name,
                        status=TaskStatus.SUCCESS,
                        started_at=started_at,
                        completed_at=datetime.now(timezone.utc),
                        duration_seconds=0.0,
                        items_processed=0,
                        items_skipped=0,
                        items_failed=0,
                        dry_run=context.dry_run,
                        details={"reason": "no_pending_work_items"},
                    )

                self.logger.info(f"[idle] Found {len(pending_items)} pending work items to process")

                # Process each work item
                for work_item in pending_items:
                    try:
                        # Update status to "processing"
                        if not context.dry_run:
                            work_item.status = "processing"
                            work_item.started_at = datetime.now(timezone.utc)
                            work_item.assigned_agent = work_item.agent
                            await db.flush()

                        # Get card data from work item
                        # Need to fetch card from database using card_id
                        card_manager = CardManager(db)
                        card = await card_manager.get_card(str(work_item.card_id))

                        if not card:
                            self.logger.warning(f"[idle] Card {work_item.card_id} not found for work item {work_item.work_item_id}")
                            if not context.dry_run:
                                work_item.status = "failed"
                                work_item.completed_at = datetime.now(timezone.utc)
                                await db.flush()
                            failed += 1
                            continue

                        # Convert card to card_data format for assembly line
                        card_data = {
                            "id": str(card.id),
                            "title": card.title,
                            "content": card.content.get("description", "") if isinstance(card.content, dict) else str(card.content),
                            "metadata": {
                                "card_type": card.card_type.value if hasattr(card.card_type, 'value') else str(card.card_type),
                                "work_mode": card.work_mode.value if hasattr(card.work_mode, 'value') else str(card.work_mode),
                                "priority": card.priority.value if hasattr(card.priority, 'value') else str(card.priority),
                                "source": "work_item_processing",
                                "work_item_id": work_item.work_item_id,
                                "context_refs": work_item.context_refs,
                                "evidence_refs": work_item.evidence_refs,
                            },
                        }

                        # Process through assembly line
                        if not context.dry_run:
                            result = await assembly_processor.process_card_with_crew(card_data)

                            # Update work item status based on result
                            if result.get("final_decision") == "approve":
                                work_item.status = "completed"
                                work_item.completed_at = datetime.now(timezone.utc)
                                processed += 1
                                self.logger.info(f"[idle] Completed work item {work_item.work_item_id}")
                            else:
                                work_item.status = "failed"
                                work_item.completed_at = datetime.now(timezone.utc)
                                failed += 1
                                self.logger.warning(f"[idle] Work item {work_item.work_item_id} failed: {result.get('final_decision')}")

                            await db.flush()
                        else:
                            self.logger.info(f"[idle] DRY-RUN: Would process work item {work_item.work_item_id}")
                            processed += 1

                    except Exception as e:
                        failed += 1
                        self.logger.error(f"[idle] Failed to process work item {work_item.work_item_id}: {e}", exc_info=True)
                        if not context.dry_run:
                            try:
                                work_item.status = "failed"
                                work_item.completed_at = datetime.now(timezone.utc)
                                await db.flush()
                            except Exception as flush_error:
                                self.logger.error(f"[idle] Failed to update work item status: {flush_error}")

                # Context manager auto-commits on exit

                return TaskResult(
                    task_name=self.name,
                    status=TaskStatus.SUCCESS,
                    started_at=started_at,
                    completed_at=datetime.now(timezone.utc),
                    duration_seconds=(datetime.now(timezone.utc) - started_at).total_seconds(),
                    items_processed=processed,
                    items_skipped=skipped,
                    items_failed=failed,
                    dry_run=context.dry_run,
                    details={
                        "pending_found": len(pending_items),
                        "processed": processed,
                        "skipped": skipped,
                        "failed": failed,
                    },
                )

        except Exception as e:
            self.logger.error(f"[idle] WorkItemProcessingTask failed: {e}", exc_info=True)
            return TaskResult(
                task_name=self.name,
                status=TaskStatus.FAILED,
                started_at=started_at,
                completed_at=datetime.now(timezone.utc),
                duration_seconds=(datetime.now(timezone.utc) - started_at).total_seconds(),
                dry_run=context.dry_run,
                error_message=str(e),
            )


class MemoryConsolidationTask(IdleTask):
    """
    Consolidate short-term memories to long-term storage.

    Reviews memories in STMVault and promotes high-quality items
    to LTMVault based on MC scoring and access patterns.

    Interval: 15 minutes (900 seconds)
    Services: memory_service
    """

    def __init__(self):
        super().__init__(
            name="memory_consolidation",
            interval_seconds=900,  # 15 minutes
            description="Consolidate STM to LTM based on MC scores",
        )

    async def check_availability(self, context: IdleContext) -> bool:
        """Check if memory service is available."""
        return context.memory_service is not None or context.get_service("memory") is not None

    async def execute(self, context: IdleContext) -> TaskResult:
        """Consolidate memories from STM to LTM."""
        started_at = datetime.now(timezone.utc)
        promoted = 0
        skipped = 0
        failed = 0

        try:
            # Get memory service
            memory_service = context.memory_service or context.get_service("memory")

            if context.dry_run:
                self.logger.info("[idle] DRY-RUN: Would query memories for consolidation")
                # Simulate finding candidates
                promoted = 5  # Simulated count

                return TaskResult(
                    task_name=self.name,
                    status=TaskStatus.SUCCESS,
                    started_at=started_at,
                    completed_at=datetime.now(timezone.utc),
                    duration_seconds=0.5,
                    items_processed=promoted,
                    dry_run=True,
                    details={"threshold": 0.8, "candidates_found": promoted},
                )

            # TODO: Implement actual memory consolidation logic
            # For now, placeholder for live mode
            self.logger.info("[idle] Memory consolidation not yet implemented")

            completed_at = datetime.now(timezone.utc)
            duration = (completed_at - started_at).total_seconds()

            return TaskResult(
                task_name=self.name,
                status=TaskStatus.SUCCESS,
                started_at=started_at,
                completed_at=completed_at,
                duration_seconds=duration,
                items_processed=promoted,
                items_skipped=skipped,
                items_failed=failed,
                dry_run=context.dry_run,
                details={"implementation": "placeholder"},
            )

        except Exception as e:
            completed_at = datetime.now(timezone.utc)
            duration = (completed_at - started_at).total_seconds()

            return TaskResult(
                task_name=self.name,
                status=TaskStatus.FAILED,
                started_at=started_at,
                completed_at=completed_at,
                duration_seconds=duration,
                items_processed=promoted,
                items_skipped=skipped,
                items_failed=failed,
                dry_run=context.dry_run,
                error_message=str(e),
            )


class CaretakerScanTask(IdleTask):
    """
    Run caretaker agent to scan and organize vault content.

    Executes caretaker agent to analyze vault files, detect orphans,
    suggest improvements, and maintain vault health.

    Interval: 30 minutes (1800 seconds)
    Services: vault_service
    """

    def __init__(self):
        super().__init__(
            name="caretaker_scan",
            interval_seconds=1800,  # 30 minutes
            description="Run caretaker agent for vault maintenance",
        )

    async def check_availability(self, context: IdleContext) -> bool:
        """Check if vault paths exist."""
        return context.stmvault_path.exists() or context.ltmvault_path.exists()

    async def execute(self, context: IdleContext) -> TaskResult:
        """Run caretaker scan on vaults with health checks and rescoring detection."""
        started_at = datetime.now(timezone.utc)
        scanned = 0
        issues_found = 0
        orphans_detected = 0
        low_mc_candidates = 0

        try:
            # Check vault paths
            vaults_to_scan = []
            if context.stmvault_path.exists():
                vaults_to_scan.append(("STMVault", context.stmvault_path))
            if context.ltmvault_path.exists():
                vaults_to_scan.append(("LTMVault", context.ltmvault_path))

            if not vaults_to_scan:
                self.logger.warning("[idle] No vault paths exist for caretaker scan")
                return TaskResult(
                    task_name=self.name,
                    status=TaskStatus.SKIPPED,
                    started_at=started_at,
                    completed_at=datetime.now(timezone.utc),
                    duration_seconds=0.0,
                    dry_run=context.dry_run,
                    details={"reason": "no_vaults_found"},
                )

            # Import parsing utilities
            import frontmatter

            # Scan vaults with health analysis
            for vault_name, vault_path in vaults_to_scan:
                files = list(vault_path.rglob("*.md"))
                # Sort files by modification time (oldest first) for consistent processing order
                files.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0)
                scanned += len(files)

                if context.dry_run:
                    self.logger.info(f"[idle] DRY-RUN: Would scan {vault_name} ({len(files)} files at {vault_path})")
                else:
                    self.logger.info(f"[idle] Scanning {vault_name} ({len(files)} files at {vault_path})")

                    # Analyze each file for health issues (oldest first)
                    for file_path in files:
                        try:
                            # Parse frontmatter
                            with open(file_path, "r", encoding="utf-8") as f:
                                post = frontmatter.load(f)

                            # Check for orphaned files (no links, no tags, low MC)
                            tags = post.metadata.get("tags", [])
                            links = post.metadata.get("links", [])
                            mc_score = post.metadata.get("mc_score", 0.0)

                            # Orphan detection: no tags, no links, low content
                            content_length = len(post.content.strip())
                            if not tags and not links and content_length < 500:
                                orphans_detected += 1
                                self.logger.debug(f"[idle] Orphan candidate: {file_path.name} (no tags, no links, {content_length} chars)")

                            # Low MC detection: flag for potential rescoring
                            if mc_score in [0.0, 0.7]:  # Fallback scores
                                low_mc_candidates += 1
                                self.logger.debug(f"[idle] Low MC candidate: {file_path.name} (MC={mc_score:.2f}, may need rescoring)")

                            # Missing critical metadata
                            if "title" not in post.metadata:
                                issues_found += 1
                                self.logger.debug(f"[idle] Missing title: {file_path.name}")

                            if "updated_at" not in post.metadata:
                                issues_found += 1
                                self.logger.debug(f"[idle] Missing updated_at: {file_path.name}")

                        except Exception as file_err:
                            self.logger.debug(f"[idle] Error analyzing {file_path.name}: {file_err}")
                            issues_found += 1
                            continue

            # Log summary
            if orphans_detected > 0:
                self.logger.info(f"[idle] Detected {orphans_detected} potential orphans (no tags/links, minimal content)")

            if low_mc_candidates > 0:
                self.logger.info(f"[idle] Detected {low_mc_candidates} files with fallback MC scores (consider running memory_rescoring task)")

            completed_at = datetime.now(timezone.utc)
            duration = (completed_at - started_at).total_seconds()

            return TaskResult(
                task_name=self.name,
                status=TaskStatus.SUCCESS,
                started_at=started_at,
                completed_at=completed_at,
                duration_seconds=duration,
                items_processed=scanned,
                dry_run=context.dry_run,
                details={
                    "vaults_scanned": len(vaults_to_scan),
                    "files_scanned": scanned,
                    "issues_found": issues_found,
                    "orphans_detected": orphans_detected,
                    "low_mc_candidates": low_mc_candidates,
                },
            )

        except Exception as e:
            completed_at = datetime.now(timezone.utc)
            duration = (completed_at - started_at).total_seconds()

            return TaskResult(
                task_name=self.name,
                status=TaskStatus.FAILED,
                started_at=started_at,
                completed_at=completed_at,
                duration_seconds=duration,
                items_processed=scanned,
                dry_run=context.dry_run,
                error_message=str(e),
            )


class VectorMaintenanceTask(IdleTask):
    """
    Maintain vector database indices and embeddings.

    Performs maintenance on ChromaDB collections:
    - Removes orphaned embeddings
    - Updates stale embeddings
    - Optimizes index structure

    Interval: 60 minutes (3600 seconds)
    Services: vector_service
    """

    def __init__(self):
        super().__init__(
            name="vector_maintenance",
            interval_seconds=3600,  # 60 minutes
            description="Maintain vector database indices",
        )

    async def check_availability(self, context: IdleContext) -> bool:
        """Check if vector service is available."""
        return context.vector_service is not None or context.get_service("vector") is not None

    async def execute(self, context: IdleContext) -> TaskResult:
        """Perform vector database maintenance."""
        started_at = datetime.now(timezone.utc)
        optimized = 0
        removed = 0

        try:
            # Get vector service
            vector_service = context.vector_service or context.get_service("vector")

            if context.dry_run:
                self.logger.info("[idle] DRY-RUN: Would perform vector maintenance")
                # Simulate maintenance stats
                optimized = 10
                removed = 3

                return TaskResult(
                    task_name=self.name,
                    status=TaskStatus.SUCCESS,
                    started_at=started_at,
                    completed_at=datetime.now(timezone.utc),
                    duration_seconds=1.0,
                    items_processed=optimized,
                    items_skipped=removed,
                    dry_run=True,
                    details={"collections_checked": 2},
                )

            # TODO: Implement actual vector maintenance logic
            # For now, placeholder for live mode
            self.logger.info("[idle] Vector maintenance not yet implemented")

            completed_at = datetime.now(timezone.utc)
            duration = (completed_at - started_at).total_seconds()

            return TaskResult(
                task_name=self.name,
                status=TaskStatus.SUCCESS,
                started_at=started_at,
                completed_at=completed_at,
                duration_seconds=duration,
                items_processed=optimized,
                items_skipped=removed,
                dry_run=context.dry_run,
                details={"implementation": "placeholder"},
            )

        except Exception as e:
            completed_at = datetime.now(timezone.utc)
            duration = (completed_at - started_at).total_seconds()

            return TaskResult(
                task_name=self.name,
                status=TaskStatus.FAILED,
                started_at=started_at,
                completed_at=completed_at,
                duration_seconds=duration,
                items_processed=optimized,
                items_skipped=removed,
                dry_run=context.dry_run,
                error_message=str(e),
            )


class IngestCleanupTask(IdleTask):
    """
    Clean up stuck files in processing folder and enforce ingest directory structure contract.
    
    Moves files that have been in processing for more than 1 day to DLQ,
    as they likely failed processing but weren't properly handled.
    
    Also enforces the ingest directory contract (.ingest_contract.yaml) by:
    - Moving processable files from prohibited directories to inbox/new/
    - Deleting prohibited directories (to prevent clutter)
    - Moving files at root level to inbox/new/
    
    Interval: 1 hour (3600 seconds)
    Services: None required (operates on file system)
    """
    
    def __init__(self):
        super().__init__(
            name="ingest_cleanup",
            interval_seconds=3600,  # 1 hour
            description="Clean up stuck files and enforce ingest directory structure",
        )
    
    async def check_availability(self, context: IdleContext) -> bool:
        """Check if ingest paths exist."""
        ingest_root = context.ingest_path.parent.parent if context.ingest_path.name == "new" else context.ingest_path.parent
        processing_dir = ingest_root / "inbox" / "processing"
        return processing_dir.exists()
    
    async def execute(self, context: IdleContext) -> TaskResult:
        """Clean up stuck files and enforce directory structure contract."""
        started_at = datetime.now(timezone.utc)
        cleaned = 0
        failed = 0
        files_moved = 0
        folders_deleted = 0
        
        try:
            ingest_root = context.ingest_path.parent.parent if context.ingest_path.name == "new" else context.ingest_path.parent
            processing_dir = ingest_root / "inbox" / "processing"
            dlq_dir = ingest_root / "inbox" / "dlq"
            new_dir = ingest_root / "inbox" / "new"
            
            dlq_dir.mkdir(parents=True, exist_ok=True)
            new_dir.mkdir(parents=True, exist_ok=True)
            
            # 1. Clean up stuck files in processing folder
            stuck_files = []
            for file_path in processing_dir.glob("*"):
                if file_path.is_file():
                    stat = file_path.stat()
                    age_seconds = (datetime.now(timezone.utc).timestamp() - stat.st_mtime)
                    age_days = age_seconds / 86400
                    if age_days > 1.0:  # Stuck for more than 1 day
                        stuck_files.append((file_path, age_days))
            
            if not context.dry_run:
                # Move stuck files to DLQ
                for file_path, age_days in stuck_files:
                    try:
                        dlq_path = dlq_dir / file_path.name
                        shutil.move(str(file_path), str(dlq_path))
                        self.logger.warning(f"[idle] Moved stuck file to DLQ: {file_path.name} ({age_days:.1f} days old)")
                        cleaned += 1
                    except Exception as e:
                        self.logger.error(f"[idle] Failed to move stuck file {file_path.name}: {e}")
                        failed += 1
            
            # 2. Enforce directory structure contract
            # Prohibited directories (from .ingest_contract.yaml)
            prohibited_dirs = ["data", "scripts", "outputs", "canary_test", "batch", "docs", "api", "vot", "sql", "config", "assembly_line_deployment"]
            
            for dir_name in prohibited_dirs:
                dir_path = ingest_root / dir_name
                if dir_path.exists():
                    # Find processable files
                    md_files = list(dir_path.rglob("*.md"))
                    rmd_files = list(dir_path.rglob("*.rmd"))
                    txt_files = list(dir_path.rglob("*.txt"))
                    processable_files = md_files + rmd_files + txt_files
                    
                    if processable_files:
                        if context.dry_run:
                            self.logger.info(f"[idle] DRY-RUN: Would move {len(processable_files)} files from {dir_name}/ to inbox/new/")
                        else:
                            # Move processable files to inbox/new
                            for file_path in processable_files:
                                try:
                                    dest_path = new_dir / file_path.name
                                    # Handle duplicates
                                    counter = 1
                                    while dest_path.exists():
                                        stem = file_path.stem
                                        suffix = file_path.suffix
                                        dest_path = new_dir / f"{stem}_{counter}{suffix}"
                                        counter += 1
                                    
                                    shutil.move(str(file_path), str(dest_path))
                                    self.logger.info(f"[idle] Moved file from prohibited directory: {file_path.name} → inbox/new/")
                                    files_moved += 1
                                except Exception as e:
                                    self.logger.error(f"[idle] Failed to move {file_path.name}: {e}")
                                    failed += 1
                    
                    # Delete the prohibited directory (even if it has non-processable files)
                    # Non-processable files shouldn't be in Ingest root anyway
                    if context.dry_run:
                        self.logger.info(f"[idle] DRY-RUN: Would delete prohibited directory: {dir_name}/")
                    else:
                        try:
                            shutil.rmtree(str(dir_path))
                            self.logger.info(f"[idle] Deleted prohibited directory: {dir_name}/")
                            folders_deleted += 1
                        except Exception as e:
                            self.logger.error(f"[idle] Failed to delete {dir_name}/: {e}")
                            failed += 1
            
            # 3. Check for files at root level (excluding contract file)
            root_files = [f for f in ingest_root.iterdir() if f.is_file() and f.name != ".ingest_contract.yaml"]
            if root_files:
                if context.dry_run:
                    self.logger.info(f"[idle] DRY-RUN: Would move {len(root_files)} files from root to inbox/new/")
                else:
                    for file_path in root_files:
                        try:
                            dest_path = new_dir / file_path.name
                            shutil.move(str(file_path), str(dest_path))
                            self.logger.info(f"[idle] Moved file from root: {file_path.name} → inbox/new/")
                            files_moved += 1
                        except Exception as e:
                            self.logger.error(f"[idle] Failed to move {file_path.name}: {e}")
                            failed += 1
            
            total_processed = cleaned + files_moved
            
            if context.dry_run and (stuck_files or prohibited_dirs or root_files):
                return TaskResult(
                    task_name=self.name,
                    status=TaskStatus.SUCCESS,
                    started_at=started_at,
                    completed_at=datetime.now(timezone.utc),
                    duration_seconds=0.5,
                    items_processed=len(stuck_files) + len(prohibited_dirs) + len(root_files),
                    dry_run=True,
                    details={
                        "stuck_files": [f.name for f, _ in stuck_files],
                        "prohibited_dirs": prohibited_dirs,
                        "root_files": [f.name for f in root_files],
                    },
                )
            
            return TaskResult(
                task_name=self.name,
                status=TaskStatus.SUCCESS if failed == 0 else TaskStatus.FAILED,
                started_at=started_at,
                completed_at=datetime.now(timezone.utc),
                duration_seconds=(datetime.now(timezone.utc) - started_at).total_seconds(),
                items_processed=total_processed,
                items_failed=failed,
                dry_run=context.dry_run,
                details={
                    "stuck_files_cleaned": cleaned,
                    "files_moved_from_prohibited": files_moved,
                    "folders_deleted": folders_deleted,
                    "failed_count": failed,
                },
            )
            
        except Exception as e:
            self.logger.error(f"[idle] Ingest cleanup task failed: {e}", exc_info=True)
            return TaskResult(
                task_name=self.name,
                status=TaskStatus.FAILED,
                started_at=started_at,
                completed_at=datetime.now(timezone.utc),
                duration_seconds=(datetime.now(timezone.utc) - started_at).total_seconds(),
                items_processed=cleaned + files_moved,
                items_failed=failed,
                dry_run=context.dry_run,
                error_message=str(e),
            )


class VaultCleanupTask(IdleTask):
    """
    Run vault cleanup operations (safe stages 1-2 only).

    Executes stages 1-2 of pvault_cleanup_agent.py:
    - Stage 1: Memory conversation analysis
    - Stage 2: Content quality assessment

    These stages are read-only and generate reports without mutations.

    Interval: 1 hour (3600 seconds)
    Services: None required (operates on file system)
    """

    def __init__(self):
        super().__init__(
            name="vault_cleanup",
            interval_seconds=3600,  # 1 hour
            description="Analyze vault quality and generate cleanup reports (stages 1-2 only)",
        )

    async def check_availability(self, context: IdleContext) -> bool:
        """Check if vault paths exist."""
        import os

        # Check for vault paths - use ltmvault (renamed from pvault)
        ltmvault_path = os.getenv("LTMVAULT_PATH", "./vaults/ltmvault")
        return os.path.exists(ltmvault_path)

    async def execute(self, context: IdleContext) -> TaskResult:
        """Execute vault cleanup stages 1-2."""
        import sys
        from pathlib import Path

        started_at = datetime.now(timezone.utc)
        files_analyzed = 0
        reports_generated = 0

        try:
            # Import cleanup agent
            project_root = Path(__file__).parent.parent.parent.parent.parent
            sys.path.insert(0, str(project_root))

            from scripts.pvault_cleanup_agent import LTMVaultCleanupAgent

            # Get vault path
            import os

            ltmvault_path = os.getenv("LTMVAULT_PATH", "./vaults/ltmvault")

            if context.dry_run:
                self.logger.info(f"[idle] DRY-RUN: Would run vault cleanup on {ltmvault_path}")
                self.logger.info(f"[idle] DRY-RUN: Would execute stage 1 (memory conversation analysis)")
                self.logger.info(f"[idle] DRY-RUN: Would execute stage 2 (content quality assessment)")

                return TaskResult(
                    task_name=self.name,
                    status=TaskStatus.SUCCESS,
                    started_at=started_at,
                    completed_at=datetime.now(timezone.utc),
                    duration_seconds=0.5,
                    items_processed=0,
                    dry_run=True,
                    details={
                        "vault_path": ltmvault_path,
                        "stages": [1, 2],
                        "mode": "analysis_only",
                    },
                )

            # Initialize cleanup agent (always in dry-run for stages 1-2)
            self.logger.info(f"[idle] Starting vault cleanup analysis on {ltmvault_path}")
            agent = LTMVaultCleanupAgent(ltm_vault_path=ltmvault_path, dry_run=True)

            # Analyze all files first
            for file_path in Path(ltmvault_path).rglob("*.md"):
                try:
                    analysis = agent.analyze_file(file_path)
                    agent.file_analysis.append(analysis)
                    files_analyzed += 1
                except Exception as e:
                    self.logger.warning(f"[idle] Failed to analyze {file_path}: {e}")

            # Run stage 1: Memory conversation analysis
            self.logger.info(f"[idle] Running stage 1: Memory conversation analysis ({files_analyzed} files)")
            stage1_result = agent.stage1_memory_conversation_analysis()
            reports_generated += 1

            # Run stage 2: Content quality assessment
            self.logger.info(f"[idle] Running stage 2: Content quality assessment")
            stage2_result = agent.stage2_content_quality_assessment()
            reports_generated += 1

            completed_at = datetime.now(timezone.utc)
            duration = (completed_at - started_at).total_seconds()

            self.logger.info(f"[idle] Vault cleanup complete: analyzed {files_analyzed} files, generated {reports_generated} reports in {duration:.1f}s")

            return TaskResult(
                task_name=self.name,
                status=TaskStatus.SUCCESS,
                started_at=started_at,
                completed_at=completed_at,
                duration_seconds=duration,
                items_processed=files_analyzed,
                items_skipped=0,
                dry_run=context.dry_run,
                details={
                    "vault_path": ltmvault_path,
                    "files_analyzed": files_analyzed,
                    "reports_generated": reports_generated,
                    "stage1_summary": stage1_result,
                    "stage2_summary": stage2_result,
                },
            )

        except ImportError as e:
            self.logger.error(f"[idle] Failed to import LTMVaultCleanupAgent: {e}")
            completed_at = datetime.now(timezone.utc)
            duration = (completed_at - started_at).total_seconds()

            return TaskResult(
                task_name=self.name,
                status=TaskStatus.FAILED,
                started_at=started_at,
                completed_at=completed_at,
                duration_seconds=duration,
                items_processed=files_analyzed,
                dry_run=context.dry_run,
                error_message=f"Import error: {str(e)}",
            )

        except Exception as e:
            completed_at = datetime.now(timezone.utc)
            duration = (completed_at - started_at).total_seconds()

            return TaskResult(
                task_name=self.name,
                status=TaskStatus.FAILED,
                started_at=started_at,
                completed_at=completed_at,
                duration_seconds=duration,
                items_processed=files_analyzed,
                dry_run=context.dry_run,
                error_message=str(e),
            )


class BacklinkRecoveryTask(IdleTask):
    """
    Suggest backlinks between vault cards using semantic similarity and MC scoring.

    Analyzes vault cards to identify potential backlink opportunities between
    related notes. Uses content similarity, shared concepts, and MC scoring to
    rank suggestions. Creates yellow-flag suggestions (review queue) rather than
    auto-adding links.

    Interval: 2 hours (7200 seconds)
    Services: vault_service, mc_engine
    """

    def __init__(self):
        super().__init__(
            name="backlink_recovery",
            interval_seconds=7200,  # 2 hours
            description="Suggest backlinks between related vault cards",
        )

    async def check_availability(self, context: IdleContext) -> bool:
        """Check if qvault exists and has content."""
        # Use qvault (short-term staging) which has 482+ files
        # TODO: Update to stmvault/ltmvault naming convention (see vault naming standardization card)
        qvault_path = Path("./vaults/stmvault")
        return qvault_path.exists() and any(qvault_path.rglob("*.md"))

    async def execute(self, context: IdleContext) -> TaskResult:
        """Run backlink recovery script via subprocess."""
        started_at = datetime.now(timezone.utc)

        try:
            import subprocess
            import re
            from pathlib import Path

            # Get project root and script path
            project_root = Path(__file__).parent.parent.parent.parent.parent
            script_path = project_root / "scripts" / "backlink_recovery.py"

            if not script_path.exists():
                self.logger.warning(f"[idle] Backlink recovery script not found: {script_path}")
                return TaskResult(
                    task_name=self.name,
                    status=TaskStatus.SKIPPED,
                    started_at=started_at,
                    completed_at=datetime.now(timezone.utc),
                    duration_seconds=0.0,
                    dry_run=context.dry_run,
                    details={"reason": "script_not_found", "path": str(script_path)},
                )

            # Run backlink recovery script with vault path
            # Prefer configured STMVault path when available
            vault_root = None
            try:
                if context.stmvault_path and isinstance(context.stmvault_path, Path):
                    vault_root = context.stmvault_path
            except Exception:
                vault_root = None
            if not vault_root:
                vault_root = Path("./vaults/stmvault")
            vault_path = str(vault_root)

            if context.dry_run:
                self.logger.info(f"[idle] [DRY RUN] Would run: python {script_path} {vault_path}")
                return TaskResult(
                    task_name=self.name,
                    status=TaskStatus.SUCCESS,
                    started_at=started_at,
                    completed_at=datetime.now(timezone.utc),
                    duration_seconds=0.0,
                    dry_run=True,
                    details={"dry_run": True},
                )

            # Execute script
            self.logger.info(f"[idle] Running backlink recovery on {vault_path}")
            result = subprocess.run(
                ["python", str(script_path), vault_path],
                cwd=str(project_root),
                capture_output=True,
                text=True,
                timeout=300,  # 5 minute timeout
            )

            if result.returncode != 0:
                self.logger.error(f"[idle] Backlink recovery failed: {result.stderr}")
                return TaskResult(
                    task_name=self.name,
                    status=TaskStatus.FAILED,
                    started_at=started_at,
                    completed_at=datetime.now(timezone.utc),
                    duration_seconds=(datetime.now(timezone.utc) - started_at).total_seconds(),
                    dry_run=False,
                    error=result.stderr,
                )

            # Parse output for stats (robust to missing/blank values)
            output_lines = result.stdout.strip().split("\n")
            stats = {}
            def _safe_int_extract(line: str) -> int:
                # Extract the last integer found in the line; default to 0 if none
                try:
                    m = re.findall(r"(\d+)", line)
                    return int(m[-1]) if m else 0
                except Exception:
                    return 0
            for line in output_lines:
                if "Files scanned:" in line:
                    stats["files_scanned"] = _safe_int_extract(line)
                elif "Existing links:" in line:
                    stats["existing_links"] = _safe_int_extract(line)
                elif "Suggestions:" in line:
                    stats["suggestions"] = _safe_int_extract(line)
                elif "High confidence" in line:
                    stats["high_confidence"] = _safe_int_extract(line)

            self.logger.info(f"[idle] Backlink recovery complete: {stats}")

            return TaskResult(
                task_name=self.name,
                status=TaskStatus.SUCCESS,
                started_at=started_at,
                completed_at=datetime.now(timezone.utc),
                duration_seconds=(datetime.now(timezone.utc) - started_at).total_seconds(),
                dry_run=False,
                details=stats,
            )
        except subprocess.TimeoutExpired:
            self.logger.error("[idle] Backlink recovery timed out after 5 minutes")
            return TaskResult(
                task_name=self.name,
                status=TaskStatus.FAILED,
                started_at=started_at,
                completed_at=datetime.now(timezone.utc),
                duration_seconds=300.0,
                dry_run=False,
                error="timeout",
            )
        except Exception as e:
            self.logger.error(f"[idle] Backlink recovery error: {e}", exc_info=True)
            return TaskResult(
                task_name=self.name,
                status=TaskStatus.FAILED,
                started_at=started_at,
                completed_at=datetime.now(timezone.utc),
                duration_seconds=(datetime.now(timezone.utc) - started_at).total_seconds(),
                dry_run=False,
                error_message=str(e),
            )


class MemoryRescoringTask(IdleTask):
    """
    Rescore memories with fallback or incorrectly low scores using real MC calculation.

    Targets memories where:
    - mc_score == 0.7 (fallback indicator from when MC was disabled)
    - mc_score == 0.0 (never scored)
    - mc_score < 0.5 (potentially affected by scale bug - scores were 10x too low)
    - mc_score between 0.3-0.4 (common range for scale bug victims)

    This task gradually upgrades historical data to use real MC scores.
    After fixing the MC formula scale bug (2025-11-05), all scores < 0.5 need rescoring.

    Interval: 1 hour (3600 seconds)
    Services: memory_service, ingestion_service
    """

    def __init__(self):
        super().__init__(
            name="memory_rescoring",
            interval_seconds=3600,  # 1 hour
            description="Rescore memories with fallback MC scores",
        )

    async def check_availability(self, context: IdleContext) -> bool:
        """Check if memory service is available."""
        return context.memory_service is not None or context.get_service("memory") is not None

    async def execute(self, context: IdleContext) -> TaskResult:
        """Rescore memories with fallback scores."""
        started_at = datetime.now(timezone.utc)
        rescored = 0
        skipped = 0
        failed = 0

        try:
            # Get memory service
            memory_service = context.memory_service or context.get_service("memory")

            if not memory_service:
                self.logger.warning("[idle] Memory service not available for rescoring")
                return TaskResult(
                    task_name=self.name,
                    status=TaskStatus.SKIPPED,
                    started_at=started_at,
                    completed_at=datetime.now(timezone.utc),
                    duration_seconds=0.0,
                    dry_run=context.dry_run,
                    details={"reason": "memory_service_unavailable"},
                )

            # Import at execution time to avoid circular dependencies
            from sqlalchemy import select, or_
            from ..models.memory_database import MemoryRecord
            from ..services.ingest_jobs import IngestJobManager
            from ..core.database import get_session

            # Query memories with fallback scores or low scores (potentially affected by scale bug)
            # After MC formula scale fix (2025-11-05), scores < 0.5 likely need rescoring
            # Increased batch size to process more memories per hour
            batch_size = 50  # Rescore 50 memories per hour (increased from 10)

            async with get_session() as session:
                result = await session.execute(
                    select(MemoryRecord)
                    .where(
                        or_(
                            MemoryRecord.mc_score == 0.0,  # Never scored
                            MemoryRecord.mc_score == 0.7,  # Fallback score
                            MemoryRecord.mc_score < 0.5,  # Low scores (potentially affected by scale bug)
                        )
                    )
                    .order_by(MemoryRecord.created_at.desc())  # Newest first
                    .limit(batch_size)
                )
                memories_to_rescore = result.scalars().all()

                if not memories_to_rescore:
                    self.logger.info("[idle] No memories found needing rescoring")
                    return TaskResult(
                        task_name=self.name,
                        status=TaskStatus.SUCCESS,
                        started_at=started_at,
                        completed_at=datetime.now(timezone.utc),
                        duration_seconds=0.1,
                        items_processed=0,
                        dry_run=context.dry_run,
                        details={"reason": "no_candidates_found"},
                    )

                self.logger.info(f"[idle] Found {len(memories_to_rescore)} memories to rescore (batch_size={batch_size})")

                # Get ingest job manager for MC calculation
                ingest_manager = context.ingestion_service or IngestJobManager()

                for memory in memories_to_rescore:
                    try:
                        if context.dry_run:
                            self.logger.info(f"[idle] DRY-RUN: Would rescore memory {memory.id} (current MC: {memory.mc_score:.2f})")
                            rescored += 1
                            continue

                        # Build memory dict for MC calculation
                        # Use note_id or title to construct path (MemoryRecord doesn't have 'source' attribute)
                        path_value = "rescoring"
                        if hasattr(memory, "note_id") and memory.note_id:
                            path_value = memory.note_id
                        elif hasattr(memory, "title") and memory.title:
                            path_value = memory.title

                        mem_dict = {
                            "content": memory.content or "",
                            "title": memory.title or "",
                            "tags": memory.tags or [],
                            "priority": memory.priority or "MEDIUM",
                            "metadata": memory.memory_metadata or {},
                            "path": path_value,
                        }

                        # Calculate real MC score using ingest manager
                        from ..services.metrics import JobPolicy
                        from ..core.config_loader import get_settings

                        # Create policy with rescore_override enabled (JobPolicy is frozen, use overrides)
                        policy = JobPolicy.from_settings(get_settings(), overrides={"rescore_override": True})
                        new_score, mc_metadata = await ingest_manager._calculate_real_mc_score(mem_dict, job_id=f"rescore_{memory.id}", policy=policy)

                        if new_score is not None:
                            # Get old score safely
                            old_score = getattr(memory, "mc_score", 0.0)
                            if old_score is None:
                                old_score = 0.0

                            # Update using setattr to avoid type checking issues
                            setattr(memory, "mc_score", new_score)

                            # Update metadata to track rescoring
                            metadata = dict(getattr(memory, "memory_metadata", None) or {})
                            metadata["rescored_at"] = datetime.now(timezone.utc).isoformat()
                            metadata["old_mc_score"] = old_score
                            metadata["mc_metadata"] = mc_metadata
                            setattr(memory, "memory_metadata", metadata)

                            await session.commit()

                            score_delta = new_score - old_score
                            self.logger.info(
                                f"[idle] Rescored memory {memory.id}: {old_score:.2f} → {new_score:.2f} (Δ={score_delta:+.2f})",
                                extra={
                                    "memory_operation": "rescoring",
                                    "memory_id": str(memory.id),
                                    "old_mc_score": old_score,
                                    "new_mc_score": new_score,
                                    "score_delta": score_delta,
                                    "note_id": getattr(memory, "note_id", None),
                                    "title": getattr(memory, "title", None)[:100] if getattr(memory, "title", None) else None,
                                },
                            )
                            rescored += 1
                        else:
                            # Defensive: mc_metadata should be a dict, but handle edge cases
                            error_msg = 'unknown'
                            if isinstance(mc_metadata, dict):
                                error_msg = mc_metadata.get('error', 'unknown')
                            else:
                                error_msg = f"metadata_type_error: {type(mc_metadata).__name__}"
                            self.logger.warning(f"[idle] Failed to calculate MC for memory {memory.id}: {error_msg}")
                            skipped += 1

                    except Exception as e:
                        self.logger.error(f"[idle] Error rescoring memory {memory.id}: {e}", exc_info=True)
                        failed += 1
                        continue

            completed_at = datetime.now(timezone.utc)
            duration = (completed_at - started_at).total_seconds()

            return TaskResult(
                task_name=self.name,
                status=TaskStatus.SUCCESS,
                started_at=started_at,
                completed_at=completed_at,
                duration_seconds=duration,
                items_processed=rescored,
                items_skipped=skipped,
                items_failed=failed,
                dry_run=context.dry_run,
                details={
                    "batch_size": batch_size,
                    "candidates_found": len(memories_to_rescore) if not context.dry_run else batch_size,
                    "rescored": rescored,
                    "skipped": skipped,
                    "failed": failed,
                },
            )

        except Exception as e:
            self.logger.error(f"[idle] Error in memory_rescoring task: {e}", exc_info=True)
            completed_at = datetime.now(timezone.utc)
            duration = (completed_at - started_at).total_seconds()
            return TaskResult(
                task_name=self.name,
                status=TaskStatus.FAILED,
                started_at=started_at,
                completed_at=completed_at,
                duration_seconds=duration,
                items_processed=rescored,
                items_skipped=skipped,
                items_failed=failed,
                error_message=str(e),
                dry_run=context.dry_run,
            )


# ============================================================================
# TASK REGISTRY
# ============================================================================


def get_default_tasks() -> List[IdleTask]:
    """
    Get the default set of idle tasks.

    Returns:
        List of idle task instances ready for registration
        
    Note: For greenfield backend, returns only basic tasks that don't require
    agent dependencies. Agent-based tasks can be added later when those
    dependencies are available.
    """
    # Basic tasks that don't require agent dependencies
    tasks = [
        IngestProcessingTask(),
        IngestCleanupTask(),  # Clean up stuck files in processing
        AssemblyLineMaintenanceTask(),
        MemoryConsolidationTask(),
        CaretakerScanTask(),
        VectorMaintenanceTask(),
        VaultCleanupTask(),
        BacklinkRecoveryTask(),
        MemoryRescoringTask(),
        WorkItemProcessingTask(),
    ]

    # Agent-based tasks are skipped in greenfield backend
    # They require idle_tasks_agents.py which has dependencies on
    # nano_agents and contracts that aren't available in greenfield.
    # These can be added later when those dependencies are integrated.

    return tasks


__all__ = [
    "IdleContext",
    "TaskResult",
    "TaskStatus",
    "IdleTask",
    "IngestProcessingTask",
    "IngestCleanupTask",
    "MemoryConsolidationTask",
    "CaretakerScanTask",
    "VectorMaintenanceTask",
    "VaultCleanupTask",
    "BacklinkRecoveryTask",
    "MemoryRescoringTask",
    "AssemblyLineMaintenanceTask",
    "WorkItemProcessingTask",
    "CardReviewTask",
    "DependencyValidationTask",
    "VaultPromotionTask",
    "TaskCardStructureTask",
    "GardenerTendingTask",
    "ConductorCoordinationTask",
    "get_default_tasks",
]
