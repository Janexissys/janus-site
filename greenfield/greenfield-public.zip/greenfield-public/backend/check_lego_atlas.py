#!/usr/bin/env python3
"""
LEGO Atlas Verification Script

Checks all LEGO blocks registration and initialization status.
Verifies Greenfield is 100% initialized.

Card Reference: CARD-V6B-P1-COMP-LEGO_REGISTRY
"""

import sys
import os
from pathlib import Path

# Add backend to path
backend_path = Path(__file__).parent
sys.path.insert(0, str(backend_path.parent))
sys.path.insert(0, str(backend_path))

from systems.lego_registry import LEGORegistry
from blocks.vault_block import VaultBlock
from blocks.cognitive_block import CognitiveBlock
from blocks.agent_block import AgentBlock
from blocks.ingest_block import IngestBlock
from blocks.vector_database_block import VectorDatabaseBlock
from blocks.telemetry_block import TelemetryBlock
from blocks.batch_block import BatchBlock
from blocks.actions_block import ActionsBlock
from blocks.action_webhook_block import ActionWebhookBlock
from blocks.rmd_block import RmdBlock
from blocks.memory_block import MemoryBlock
from blocks.learning_block import LearningBlock
from blocks.assembly_line_block import AssemblyLineBlock

def get_all_blocks():
    """Get all LEGO block classes."""
    blocks = [
        VaultBlock,
        CognitiveBlock,
        AgentBlock,
        IngestBlock,
        VectorDatabaseBlock,
        TelemetryBlock,
        BatchBlock,
        ActionsBlock,
        ActionWebhookBlock,
        RmdBlock,
        MemoryBlock,
        LearningBlock,
        AssemblyLineBlock,
    ]
    
    # Verify all blocks have block_name
    for block in blocks:
        block_name = getattr(block, 'block_name', None)
        if not block_name:
            print(f"⚠️  Warning: {block.__name__} missing block_name attribute")
    
    return blocks

def check_block_registration():
    """Check all blocks are registered."""
    print("=" * 60)
    print("LEGO ATLAS VERIFICATION")
    print("=" * 60)
    print()
    
    registry = LEGORegistry()
    all_blocks = get_all_blocks()
    
    print("📦 Registering LEGO Blocks...")
    print()
    
    registered = []
    failed = []
    
    for block_class in all_blocks:
        try:
            block_name = getattr(block_class, 'block_name', None)
            version = getattr(block_class, 'version', '1.0.0')
            requires = getattr(block_class, 'requires', ())
            
            if not block_name:
                print(f"⚠️  {block_class.__name__}: Missing block_name")
                failed.append(block_class.__name__)
                continue
            
            # Try to register
            try:
                registry.register_block(block_class)
                registered.append(block_name)
                deps_str = ", ".join(requires) if requires else "none"
                print(f"✅ {block_name:25} v{version:8} (requires: {deps_str})")
            except ValueError as e:
                if "already registered" in str(e):
                    print(f"ℹ️  {block_name:25} v{version:8} (already registered)")
                    registered.append(block_name)
                else:
                    print(f"❌ {block_name:25} - Registration failed: {e}")
                    failed.append(block_name)
        except Exception as e:
            print(f"❌ {block_class.__name__} - Error: {e}")
            failed.append(block_class.__name__)
    
    print()
    print("=" * 60)
    print("REGISTRATION SUMMARY")
    print("=" * 60)
    print(f"✅ Registered: {len(registered)}/{len(all_blocks)}")
    print(f"❌ Failed: {len(failed)}/{len(all_blocks)}")
    print()
    
    if failed:
        print("Failed blocks:")
        for name in failed:
            print(f"  - {name}")
        print()
    
    # Get registry statistics
    stats = registry.get_statistics()
    print("Registry Statistics:")
    print(f"  Total Registered: {stats['total_registered']}")
    print(f"  Total Instances: {stats['total_instances']}")
    print(f"  Registration Count: {stats['registration_count']}")
    print()
    
    # List all registered blocks
    print("Registered Blocks:")
    for block_info in stats['blocks']:
        deps_str = ", ".join(block_info['requires']) if block_info['requires'] else "none"
        print(f"  - {block_info['name']:25} v{block_info['version']:8} (deps: {deps_str}, instances: {block_info['instance_count']})")
    print()
    
    # Get registration order
    order = registry.get_registration_order()
    print("Recommended Registration Order (by dependencies):")
    for i, block_name in enumerate(order, 1):
        print(f"  {i:2}. {block_name}")
    print()
    
    # Health check
    health = registry.get_health()
    print("Registry Health:")
    print(f"  Status: {health['status']}")
    print(f"  Message: {health['message']}")
    print()
    
    # Dependency graph
    deps = registry.get_dependencies()
    print("Dependency Graph:")
    for block_name, block_deps in deps.items():
        if block_deps:
            print(f"  {block_name} -> {', '.join(block_deps)}")
        else:
            print(f"  {block_name} -> (no dependencies)")
    print()
    
    # Check if all 13 blocks are registered
    expected_blocks = [
        "vault", "cognitive", "agent", "ingest", "vector_database",
        "telemetry", "batch", "actions", "action_webhook", "rmd",
        "memory", "learning", "assembly_line"
    ]
    
    registered_names = [b['name'] for b in stats['blocks']]
    missing = [b for b in expected_blocks if b not in registered_names]
    extra = [b for b in registered_names if b not in expected_blocks]
    
    print("=" * 60)
    print("COMPLETENESS CHECK")
    print("=" * 60)
    print(f"Expected blocks: {len(expected_blocks)}")
    print(f"Registered blocks: {len(registered_names)}")
    print()
    
    if missing:
        print(f"⚠️  Missing blocks ({len(missing)}):")
        for block in missing:
            print(f"    - {block}")
        print()
    
    if extra:
        print(f"ℹ️  Extra blocks ({len(extra)}):")
        for block in extra:
            print(f"    - {block}")
        print()
    
    if len(registered) == len(all_blocks) and len(missing) == 0:
        print("✅ ALL 13 LEGO BLOCKS REGISTERED")
        print("✅ Greenfield LEGO Atlas: 100% INITIALIZED")
        print()
        print("🎉 Greenfield is fully initialized and ready!")
    else:
        print(f"⚠️  {len(registered)}/{len(all_blocks)} blocks registered")
        if missing:
            print(f"⚠️  Missing blocks: {', '.join(missing)}")
        print()
        print("❌ Greenfield LEGO Atlas: NOT 100% INITIALIZED")
    
    print()
    return len(registered) == len(all_blocks) and len(missing) == 0

if __name__ == "__main__":
    try:
        success = check_block_registration()
        sys.exit(0 if success else 1)
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

