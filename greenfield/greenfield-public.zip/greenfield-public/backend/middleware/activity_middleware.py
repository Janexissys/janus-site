# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Activity Middleware for Idle Detection
=======================================

Lightweight middleware that tracks HTTP activity to enable idle detection.
Pings the idle orchestrator on every request to update last activity timestamp.
"""

import logging
from typing import Optional
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware


logger = logging.getLogger(__name__)


class ActivityMiddleware(BaseHTTPMiddleware):
    """
    Tracks HTTP activity for idle detection.

    This middleware pings the idle orchestrator on every HTTP request,
    enabling the orchestrator to accurately detect when the system is idle.

    Design:
    - Minimal overhead: single method call per request
    - Graceful degradation: no-op if orchestrator not available
    - No request blocking: activity notification is fire-and-forget
    """

    def __init__(self, app, orchestrator=None):
        """
        Initialize activity middleware.

        Args:
            app: FastAPI application instance
            orchestrator: Optional IdleOrchestrator instance to notify
        """
        super().__init__(app)
        self.orchestrator = orchestrator
        self.logger = logging.getLogger(__name__)

        # CARD-V6B-P0-PRE-24H-CRITICAL-FIXES P1-8: Log initialization status
        if self.orchestrator:
            self.logger.info("[activity] ActivityMiddleware initialized with orchestrator")
        else:
            # This is expected - orchestrator will be available via app.state after startup
            self.logger.info("[activity] ActivityMiddleware initialized (orchestrator will be available via app.state)")

    async def dispatch(self, request: Request, call_next):
        """
        Process request and notify orchestrator of activity.

        Args:
            request: Incoming HTTP request
            call_next: Next middleware/handler in chain

        Returns:
            Response from downstream handler
        """
        # Notify orchestrator of activity BEFORE processing request
        # This ensures activity is tracked even if request fails
        await self._notify_activity(request)

        # Process request normally
        response = await call_next(request)

        return response

    async def _notify_activity(self, request: Request):
        """
        Notify idle orchestrator of HTTP activity.

        This method is fire-and-forget to avoid blocking the request.
        Handles all errors gracefully to prevent middleware from breaking requests.

        Args:
            request: Incoming HTTP request
        """
        try:
            # IMPORTANT: Exclude health check endpoints from activity tracking
            # Health checks run every 30s and would prevent the system from ever being idle
            path = request.url.path
            if path in ["/health", "/health/simple", "/health/components", "/health/status"]:
                # Don't track health checks as activity
                return

            # Try to get orchestrator from init or app.state
            orchestrator = self.orchestrator
            if not orchestrator and hasattr(request.app.state, "idle_orchestrator"):
                orchestrator = request.app.state.idle_orchestrator

            # Notify if available
            if orchestrator and hasattr(orchestrator, "notify_activity"):
                orchestrator.notify_activity()
                # Optional: log at debug level for visibility
                # self.logger.debug(f"[activity] Notified orchestrator: {request.method} {request.url.path}")

        except Exception as e:
            # Never let activity tracking break a request
            # Log at debug level to avoid log spam
            self.logger.debug(f"[activity] Failed to notify orchestrator: {e}")

    def set_orchestrator(self, orchestrator):
        """
        Set or update the orchestrator reference.

        Allows orchestrator to be wired after middleware initialization.
        Useful for startup sequences where orchestrator is created after middleware.

        Args:
            orchestrator: IdleOrchestrator instance
        """
        self.orchestrator = orchestrator
        self.logger.info("[activity] Orchestrator reference updated")


def setup_activity_middleware(app, orchestrator=None):
    """
    Setup activity middleware for idle detection.

    This is a convenience function for wiring the middleware into the app.
    Can be called with or without an orchestrator - orchestrator can be
    set later via app.state.idle_orchestrator.

    Args:
        app: FastAPI application instance
        orchestrator: Optional IdleOrchestrator instance

    Returns:
        ActivityMiddleware instance (for reference updates)
    """
    middleware = ActivityMiddleware(app, orchestrator=orchestrator)
    app.add_middleware(ActivityMiddleware, orchestrator=orchestrator)
    logger.info("[activity] Activity middleware enabled for idle detection")
    return middleware
