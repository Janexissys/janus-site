# V7 Issues & Configuration Comparison: V5.5 vs V6.0 Greenfield

**Date:** 2025-12-02  
**Purpose:** Document V7 surfaced issues and compare all configurations between V5.5 and V6.0 Greenfield

---

## 🔴 V7 CRITICAL ISSUES SUMMARY

### Issue #037: Work Items Not Being Processed (CRITICAL)
- **Status:** 🔴 CRITICAL - Work items created but never processed
- **Problem:** Work items stuck in "pending" status since October 31, 2025
- **Root Cause:** `WorkItemProcessingTask` exists but may be failing silently
- **Fix Applied:** Added logging to `check_availability()` to surface import errors
- **Action Required:** Monitor logs, verify task registration, test with existing work items

### Issue #028: Insights Tab Hardcoded Data (P0)
- **Status:** ✅ Delta Card Created
- **Problem:** 80% hardcoded/mock data violates core ethos
- **Delta Card:** `CARD-V7-DELTA-INSIGHTS-REAL-DATA-SOURCES` (P0 - Critical)

### Issue #012: Assembly Line Job Architecture (P0)
- **Status:** ✅ Delta Card Created
- **Problem:** User confusion about Cards vs Jobs vs WorkItems
- **Delta Card:** `CARD-V7-DELTA-ASSEMBLY-JOB-ARCHITECTURE` (P0 - Critical)

### All 10 Delta Cards Created:
1. ✅ `CARD-V7-DELTA-ASSEMBLY-JOB-ARCHITECTURE` (P0)
2. ✅ `CARD-V7-DELTA-INSIGHTS-REAL-DATA-SOURCES` (P0)
3. ✅ `CARD-V7-DELTA-ATLAS-HEALTH-HARDENING` (P1)
4. ✅ `CARD-V7-DELTA-KNOWLEDGE-BACKLINKS-CITATIONS` (P1)
5. ✅ `CARD-V7-DELTA-CARDS-LIFECYCLE-MAPPING` (P1)
6. ✅ `CARD-V7-DELTA-SEARCH-SYNTHESIS` (P2)
7. ✅ `CARD-V7-DELTA-ASSEMBLY-MEMORY-INTEGRATION` (P2)
8. ✅ `CARD-V7-DELTA-UNIFIED-LOGS-VIEW` (P2)
9. ✅ `CARD-V7-DELTA-ZERO-VALUE-CONTEXT` (P2)
10. ✅ `CARD-V7-DELTA-IDLE-LOGGING-NOISE` (P2)

**Full Details:** See `V7_ISSUES_SURFACING.md` and `V7_CRITICAL_ISSUES_REVIEW.md`

---

## 📋 V5.5 CONFIGURATIONS

### 1. Server Configuration
```yaml
HOST: "0.0.0.0"
PORT: 10000
API_HOST: "0.0.0.0"
API_PORT: 10000
ENVIRONMENT: "production" | "development"
DEBUG: false | true
LOG_LEVEL: "INFO" | "DEBUG" | "WARNING" | "ERROR"
```

### 2. CORS Configuration
```yaml
CORS_ORIGINS: "http://localhost:8000,http://127.0.0.1:8000,http://localhost:8001,http://127.0.0.1:8001,http://localhost:3000,http://127.0.0.1:3000,http://localhost:5173,http://127.0.0.1:5173,https://*.ngrok-free.app,https://*.ngrok.io,https://*.figma.site,https://*.figmaiframepreview.figma.site"
```

### 3. Database Configuration
```yaml
DATABASE_URL: "sqlite+aiosqlite:///./data/janus_v5.5.db"
SQL_ECHO: false
```

### 4. Vault Configuration
```yaml
VAULT_PATH: "./vaults/stmvault"
PVAULT_PATH: "./ltm-vault"
JANUS_DATA_PATH: "./data"
VAULT_INCLUDE: ["**/*.md", "**/*.rmd"]
VAULT_EXCLUDE: [".git/**", "**/node_modules/**", "**/.DS_Store", "Private/**"]
STM_VAULT_PATH: "./vaults/stmvault"
LTM_VAULT_PATH: "./vaults/ltmvault"
```

### 5. Memory System Configuration
```yaml
MC_THRESHOLD: 0.8
MC_MEDIUM_THRESHOLD: 0.6
MC_LOW_THRESHOLD: 0.3
MC_PROMOTION_THRESHOLD: 0.85
MC_STM_THRESHOLD: 0.5
ENABLE_AUTO_TRANSFER: true
CRITICAL_TAGS: "critical,breakthrough,key"
STM_MAX_SIZE: 1000
TRANSFER_THRESHOLD: 100
LTM_BATCH_SIZE: 100
DECAY_RATE: 0.1
DECAY_INTERVAL_HOURS: 24
```

### 6. AI/LLM Configuration
```yaml
OPENAI_API_KEY: "sk-proj-..."
ANTHROPIC_API_KEY: "sk-ant-..."
OPENAI_MODEL: "gpt-4o-mini"
MAX_TOKENS: 4096
LOCAL_LLM_BASE_URL: "http://localhost:11434"
LOCAL_LLM_MODEL: "llama3.1:8b"
LOCAL_LLM_PROVIDER: "ollama"
USE_LOCAL_LLM: true
LOCAL_LLM_TIMEOUT: 3600
LOCAL_LLM_MAX_TOKENS: 32768
LOCAL_LLM_TEMPERATURE: 0.7
```

### 7. Vector Database Configuration (ChromaDB)
```yaml
ENABLE_VECTOR_SEARCH: true
CHROMA_MODE: "embedded" | "http"
CHROMADB_PATH: "./data/chromadb"
CHROMADB_HOST: "localhost"
CHROMADB_PORT: 8001
```

### 8. Feature Flags
```yaml
CHAT_PERSIST_ENABLED: true
CHAT_COMMANDS_ENABLED: false
INGEST_TRIGGER_ENABLED: true
ENABLE_WORKFLOW_ROUTER: true
ENABLE_CARDS_ROUTER: true
ENABLE_PROJECT_CARDS_ROUTER: false
ENABLE_HEALTH_ROUTER: true
ENABLE_TASKS_ROUTER: true
ENABLE_MEMORY_ROUTER: true
ENABLE_RETRIEVAL_TIERS: true
ENABLE_BIAS_DEFENSE: true
ENABLE_ASSEMBLY_LINE: true
ENABLE_VOT_GATES: true
ENABLE_UNIFIED_QUALITY_HOOK: true
ENABLE_MC_EVOLUTION: true
FAIL_OPEN_ON_ORCHESTRATOR_ERROR: true
VOT_NORTH_STAR_ENABLED: true
VOT_NORTH_STAR_ALPHA: 0.0
VOT_NORTH_STAR_ALPHA_MAP: null
```

### 9. Assembly Line Configuration
```yaml
ASSEMBLY_LINE_MEMORY_THRESHOLD: "medium"  # low|medium|high
ENABLE_MC_CALCULATION_ON_INGEST: true
MC_TIMEOUT_SECONDS: 300.0
ASSEMBLY_LINE_TOKEN_BUDGET: 800
```

### 10. Idle Orchestrator Configuration
```yaml
IDLE_ORCHESTRATOR_ENABLED: true
IDLE_DRY_RUN: false
IDLE_THRESHOLD_SECONDS: 120
IDLE_CHECK_INTERVAL_SECONDS: 60
INGEST_PATH: "./Ingest/inbox/new"
ENABLE_CARD_REVIEW_TASK: true
ENABLE_DEPENDENCY_VALIDATION_TASK: true
ENABLE_VAULT_PROMOTION_TASK: true
ENABLE_TASK_STRUCTURE_TASK: false
ENABLE_GARDENER_TENDING_TASK: true
ENABLE_CONDUCTOR_COORDINATION_TASK: true
GARDENER_TENDING_INTERVAL: 900  # 15 minutes
CONDUCTOR_COORDINATION_INTERVAL: 1200  # 20 minutes
ENABLE_SCRIBE_LEDGER_PERSISTENCE: true
VAULT_PROMOTION_THRESHOLD: 8.0
```

### 11. Security Configuration
```yaml
SECRET_KEY: "janus-codespace-secret-key-change-in-production"
JWT_SECRET_KEY: "janus-jwt-secret-change-in-production"
ACCESS_TOKEN_EXPIRE_MINUTES: 30
REFRESH_TOKEN_EXPIRE_DAYS: 7
```

### 12. Agent Quality Monitoring
```yaml
AGENT_QUALITY_MODE: "shadow"  # off|shadow|enforce
AGENT_QUALITY_THRESHOLD: 0.80
AGENT_MAX_RETRIES: 3
AGENT_BREAKER_TRIP_THRESHOLD: 5
AGENT_BREAKER_COOLDOWN_SECONDS: 60
AGENT_DLQ_ENABLED: true
SANITIZER_ALLOWED_DOMAINS: "github.com,stackoverflow.com,python.org,fastapi.tiangolo.com,docs.sqlalchemy.org"
SANITIZER_BLOCK_TOOL_INVOKE: true
SANITIZER_REDACT_PII: true
QUALITY_EVENTS_RETENTION_DAYS: 30
QUALITY_EVENTS_CLEANUP_ENABLED: true
QUALITY_VALIDATION_TIMEOUT_MS: 500
QUALITY_BASELINE_P95_MS: 0.0
```

### 13. LLM Validation Configuration
```yaml
VALIDATION_ENABLED: false
VALIDATION_MODE: "shadow"  # shadow|disabled
VALIDATION_SCHEMA_VERSION: "v1"
VALIDATION_RULES_VERSION: "1.0.0"
```

### 14. Onboarding System Configuration
```yaml
ONBOARDING_EVENTS_ENABLED: false
ONBOARDING_OBSERVE_ONLY: true
ONBOARDING_PROMOTE_ENABLED: false
```

### 15. WebSocket Configuration
```yaml
WEBSOCKET_ENABLED: true
WEBSOCKET_PORT: 10001
```

### 16. Observability Configuration
```yaml
OBSERVABILITY_ENABLED: true
METRICS_ENABLED: true
TRACING_ENABLED: true
LOG_FORMAT: "json"
LOG_TO_CONSOLE: true
LOG_TO_FILE: true
```

### 17. Performance Configuration
```yaml
WORKERS: 1
MAX_CONNECTIONS: 100
TIMEOUT: 30
```

### 18. LEGO Configuration
```yaml
LEGO_LEGACY_ENABLE: false
LEGO_COGNITIVE_PROVIDER: "openai" | "none"
LEGO_COGNITIVE_MODEL: "gpt-4o-mini"
LEGO_COGNITIVE_TIMEOUT_S: 60
LEGO_MEMORY_STM_MAX_MB: 256
LEGO_VAULT_LTM_VAULT_PATH: "./vaults/ltmvault"  # Note: PVAULT_PATH deprecated
LEGO_VAULT_STM_VAULT_PATH: "./vaults/stmvault"  # Note: QVAULT_PATH deprecated
LEGO_TELEMETRY_FLUSH_INTERVAL_S: 5
LEGO_ACTIONS_RATE_LIMIT_RPM: 60
```

### 19. Agent Model Configuration (YAML)
**File:** `config/agent_model_config.yaml`
```yaml
agent_models:
  caretaker:
    primary_model: "mistral:7b"
    fallback_model: "gpt-4o-mini"
    context_window: 200000
    max_tokens: 4000
    temperature: 0.3
  gardener:
    primary_model: "mistral:instruct"
    fallback_model: "gpt-4o-mini"
    context_window: 200000
    max_tokens: 8000
    temperature: 0.2
  mercury:
    primary_model: "mistral:7b"
    fallback_model: "gpt-4o-mini"
    context_window: 200000
    max_tokens: 2000
    temperature: 0.1
  sentinel:
    primary_model: "mistral:7b"
    fallback_model: "gpt-4o-mini"
    context_window: 200000
    max_tokens: 3000
    temperature: 0.1
  conductor:
    primary_model: "mistral:7b"
    fallback_model: "gpt-4o-mini"
    context_window: 200000
    max_tokens: 4000
    temperature: 0.2
  scribe:
    primary_model: "mistral:7b"
    fallback_model: "gpt-4o-mini"
    context_window: 200000
    max_tokens: 6000
    temperature: 0.3
```

### 20. Batch Processing Configuration (YAML)
**File:** `config/batch_config.yaml`
```yaml
agent_coordinator:
  batch_threshold: 5
  max_queue_size: 100
  auto_batch_enabled: true
  always_batch: false
  processing_mode: "conversation_batch"
  max_wait_seconds: 30
ingest:
  batch_threshold: 10
  batch_mode: false
batch:
  auto_batch_threshold: 5
  max_batch_size: 100
cost_optimization:
  enable_local_processing: true
  token_budget_per_hour: 50000
  priority_based_processing: true
  mc_threshold_for_processing: 0.7
```

### 21. MC Schema Configuration (YAML)
**File:** `schemas/memory/mc_schema.yaml`
- Defines MC stages: input_classification, education_check, source_canon, priority_alignment, drift_detection
- Weight configurations for each stage
- Matching logic and triggers

---

## 📋 V6.0 GREENFIELD CONFIGURATIONS

### 1. Server Configuration
```python
# Hardcoded in main.py
HOST: "0.0.0.0"
PORT: 8000  # From os.getenv("PORT", "8000")
```

### 2. CORS Configuration
```python
# Hardcoded in main.py
allow_origins: ["http://localhost:3000"]
allow_credentials: true
allow_methods: ["*"]
allow_headers: ["*"]
```

### 3. Database Configuration
```python
# ❌ NO DATABASE SYSTEM - No configuration
```

### 4. Vault Configuration
```python
# Hardcoded in main.py
# NOTE: This is a comparison reference to V5.5 structure, not a dependency
# Greenfield should use: greenfield/vaults/stmvault and greenfield/vaults/ltmvault
base_vault_path = Path.home() / "Janus Project" / "Janus" / "JanusV5.5" / "vaults"  # V5.5 reference
stmvault_path: str(base_vault_path / "stmvault")
ltmvault_path: str(base_vault_path / "ltmvault")
```

### 5. Memory System Configuration
```python
# ❌ NO CONFIGURATION SYSTEM - Hardcoded values
# MC thresholds, memory settings not configurable
```

### 6. AI/LLM Configuration
```python
# Hardcoded in main.py
api_keys = {
    "openai": "sk-mock-key-for-development-only",
    "anthropic": "sk-ant-mock-key-for-development-only",
    "local": os.getenv("LOCAL_LLM_BASE_URL", "http://localhost:11434")
}
# Environment variables supported:
# - LOCAL_LLM_BASE_URL (default: http://localhost:11434)
# - LOCAL_LLM_MODEL (default: mistral:7b) - used in cognitive_block.py
# - LOCAL_LLM_TIMEOUT (default: 600) - used in cognitive_block.py
```

### 7. Vector Database Configuration
```python
# Hardcoded in main.py - no configuration
vector_db_block.initialize({})
```

### 8. Feature Flags
```python
# ❌ NO FEATURE FLAG SYSTEM - All features always enabled
```

### 9. Assembly Line Configuration
```python
# ❌ NO CONFIGURATION - Hardcoded in assembly_line_block.py
```

### 10. Idle Orchestrator Configuration
```python
# Hardcoded in main.py
idle_orchestrator = IdleOrchestrator(
    enabled=True,
    dry_run=True,
    idle_threshold_seconds=300,
    loop_interval_seconds=60,
    ingest_path=Path.home() / "Janus Project" / "Janus" / "JanusV5.5" / "Ingest" / "inbox" / "new",  # V5.5 reference (comparison only)
    stmvault_path=base_vault_path / "stmvault",
    ltmvault_path=base_vault_path / "ltmvault",
    app_state=None
)
```

### 11. Security Configuration
```python
# ❌ NO SECURITY CONFIGURATION - No JWT, no auth middleware
```

### 12. Agent Quality Monitoring
```python
# ❌ NO AGENT QUALITY MONITORING
```

### 13. LLM Validation Configuration
```python
# ❌ NO LLM VALIDATION SYSTEM
```

### 14. Onboarding System Configuration
```python
# ❌ NO ONBOARDING SYSTEM
```

### 15. WebSocket Configuration
```python
# ❌ NO WEBSOCKET SUPPORT
```

### 16. Observability Configuration
```python
# Basic logging only
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
```

### 17. Performance Configuration
```python
# ❌ NO PERFORMANCE CONFIGURATION
```

### 18. LEGO Configuration
```python
# ❌ NO LEGO CONFIGURATION - Blocks initialized with empty dicts
```

### 19. Agent Model Configuration
```python
# ❌ NO AGENT MODEL CONFIGURATION - Uses default cognitive block settings
```

### 20. Batch Processing Configuration
```python
# ❌ NO BATCH PROCESSING CONFIGURATION
```

### 21. MC Schema Configuration
```python
# ❌ NO MC SCHEMA CONFIGURATION - Uses hardcoded MC engine
```

---

## 🔍 CONFIGURATION GAP ANALYSIS

### ✅ V6.0 Has (Minimal):
1. ✅ Basic server configuration (port from env)
2. ✅ Basic CORS (hardcoded localhost:3000)
3. ✅ Vault paths (hardcoded to V5.5 vaults)
4. ✅ Local LLM support (env vars: LOCAL_LLM_BASE_URL, LOCAL_LLM_MODEL, LOCAL_LLM_TIMEOUT)
5. ✅ Basic idle orchestrator (hardcoded settings)
6. ✅ Basic logging (hardcoded format)

### ❌ V6.0 Missing (Critical):
1. ❌ **Configuration System** - No `config_loader.py`, no Settings class, no YAML configs
2. ❌ **Database Configuration** - No database system at all
3. ❌ **Feature Flags** - No feature flag system
4. ❌ **Memory System Configuration** - MC thresholds, memory settings not configurable
5. ❌ **Vector Database Configuration** - No ChromaDB configuration
6. ❌ **Security Configuration** - No JWT, no auth, no secrets management
7. ❌ **Agent Model Configuration** - No agent-specific model settings
8. ❌ **Batch Processing Configuration** - No batch processing settings
9. ❌ **MC Schema Configuration** - No MC schema customization
10. ❌ **Assembly Line Configuration** - No assembly line settings
11. ❌ **Agent Quality Monitoring** - No quality monitoring configuration
12. ❌ **LLM Validation Configuration** - No validation settings
13. ❌ **Onboarding System Configuration** - No onboarding settings
14. ❌ **WebSocket Configuration** - No WebSocket support
15. ❌ **Observability Configuration** - Basic logging only, no metrics/tracing
16. ❌ **Performance Configuration** - No performance tuning settings
17. ❌ **LEGO Configuration** - No LEGO block configuration
18. ❌ **Environment Variable Management** - Only 3 env vars supported (PORT, LOCAL_LLM_*)

---

## 📊 SUMMARY STATISTICS

| Configuration Category | V5.5 | V6.0 Greenfield | Missing |
|------------------------|------|-----------------|---------|
| **Server Config** | ✅ Full | ✅ Basic | Port only |
| **CORS Config** | ✅ Full | ✅ Basic | Limited origins |
| **Database Config** | ✅ Full | ❌ None | Entire system |
| **Vault Config** | ✅ Full | ✅ Basic | Hardcoded paths |
| **Memory Config** | ✅ Full | ❌ None | All settings |
| **AI/LLM Config** | ✅ Full | ✅ Basic | Limited env vars |
| **Vector DB Config** | ✅ Full | ❌ None | ChromaDB settings |
| **Feature Flags** | ✅ Full (20+) | ❌ None | Entire system |
| **Assembly Line** | ✅ Full | ❌ None | All settings |
| **Idle Orchestrator** | ✅ Full | ✅ Basic | Hardcoded values |
| **Security Config** | ✅ Full | ❌ None | JWT, auth, secrets |
| **Agent Quality** | ✅ Full | ❌ None | Entire system |
| **LLM Validation** | ✅ Full | ❌ None | Entire system |
| **Onboarding** | ✅ Full | ❌ None | Entire system |
| **WebSocket** | ✅ Full | ❌ None | Entire system |
| **Observability** | ✅ Full | ✅ Basic | Metrics, tracing |
| **Performance** | ✅ Full | ❌ None | All settings |
| **LEGO Config** | ✅ Full | ❌ None | Block settings |
| **Agent Models** | ✅ Full (YAML) | ❌ None | Agent-specific |
| **Batch Processing** | ✅ Full (YAML) | ❌ None | Batch settings |
| **MC Schema** | ✅ Full (YAML) | ❌ None | MC stages |
| **Total Config Items** | **100+** | **~10** | **90+** |

---

## 🎯 PRIORITY RECOMMENDATIONS

### Phase 1: Critical Infrastructure (Must Have)
1. **Configuration System** - Port `config_loader.py` and Settings class from V5.5
2. **Database Configuration** - Add database system with configuration
3. **Environment Variable Management** - Support all V5.5 env vars
4. **Feature Flags** - Add feature flag system for gradual rollout

### Phase 2: Core Functionality (Should Have)
1. **Memory System Configuration** - MC thresholds, memory settings
2. **Vault Configuration** - Make vault paths configurable
3. **AI/LLM Configuration** - Full LLM provider configuration
4. **Security Configuration** - JWT, auth, secrets management

### Phase 3: Advanced Features (Nice to Have)
1. **Agent Model Configuration** - Agent-specific model settings
2. **Batch Processing Configuration** - Batch processing settings
3. **MC Schema Configuration** - MC stage customization
4. **Observability Configuration** - Metrics, tracing, advanced logging

---

## 📝 NOTES

- **V6.0 Greenfield** has ~10% of V5.5's configuration capabilities
- **V5.5** has comprehensive configuration system with 100+ configurable items
- **V6.0** relies on hardcoded values and minimal environment variable support
- **Critical Gap:** No configuration system means no way to customize behavior without code changes
- **Migration Path:** Port `config_loader.py` and Settings class as first priority

---

**Files Referenced:**
- V5.5: `backend/janus/app/core/config_loader.py` (606 lines)
- V5.5: `backend/janus/app/config/agent_model_config.yaml`
- V5.5: `backend/janus/app/config/batch_config.yaml`
- V5.5: `backend/janus/app/schemas/memory/mc_schema.yaml`
- V6.0: `greenfield/backend/main.py` (573 lines)
- V7 Issues: `greenfield/V7_ISSUES_SURFACING.md` (1345 lines)
- V7 Critical: `greenfield/V7_CRITICAL_ISSUES_REVIEW.md` (162 lines)

