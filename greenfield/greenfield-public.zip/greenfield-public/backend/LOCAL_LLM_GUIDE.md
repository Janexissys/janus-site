# Local LLM Integration Guide

## ✅ Status: Working

Local LLM (Ollama) integration is **fully functional** in the greenfield backend.

## Test Results

```
✅ Test 1: Simple prompt - SUCCESS (16.2s latency)
✅ Test 2: System prompt - SUCCESS (18.8s latency)  
✅ Test 3: Quick test - SUCCESS (1.3s latency)
✅ Health check - HEALTHY
```

## Prerequisites

1. **Ollama installed and running**
   ```bash
   # Check if Ollama is running
   curl http://localhost:11434/api/tags
   ```

2. **Model downloaded**
   ```bash
   ollama pull mistral:7b
   ```

3. **Python dependencies**
   ```bash
   pip install aiohttp
   ```

## Configuration

### Environment Variables

```bash
export LOCAL_LLM_BASE_URL="http://localhost:11434"  # Default
export LOCAL_LLM_MODEL="mistral:7b"                  # Default
export LOCAL_LLM_TIMEOUT="600"                       # 10 minutes default
```

### Code Configuration

The CognitiveBlock is automatically configured in `main.py`:

```python
cognitive_block.initialize({
    "api_keys": {
        "local": "http://localhost:11434"  # Ollama endpoint
    }
})
```

## Usage

### Basic Usage

```python
from blocks.cognitive_block import CognitiveBlock, LLMRequest, LLMProvider

# Initialize
block = CognitiveBlock()
block.initialize({
    "api_keys": {
        "local": "http://localhost:11434"
    }
})

# Make request
request = LLMRequest(
    prompt="What is 2+2?",
    provider=LLMProvider.LOCAL,
    max_tokens=100,
    temperature=0.7
)

response = await block.generate(request)
print(response.content)
```

### With System Prompt

```python
request = LLMRequest(
    prompt="Explain quantum computing",
    system_prompt="You are a helpful assistant.",
    provider=LLMProvider.LOCAL,
    max_tokens=200,
    temperature=0.5
)

response = await block.generate(request)
```

## Testing

Run the test script:

```bash
cd greenfield/backend
python3 test_local_llm.py
```

## Performance

- **Latency**: 1-20 seconds (depending on prompt complexity)
- **Model**: mistral:7b (default)
- **Timeout**: 600 seconds (10 minutes)

## Supported Models

Any Ollama-compatible model. Common options:
- `mistral:7b` (default, ~4.4GB)
- `llama2:7b`
- `codellama:7b`
- `phi:2.7b` (smaller, faster)

Change model via environment variable:
```bash
export LOCAL_LLM_MODEL="llama2:7b"
```

## Troubleshooting

### Ollama not running
```bash
# Start Ollama
ollama serve
```

### Model not found
```bash
# List available models
ollama list

# Pull a model
ollama pull mistral:7b
```

### Connection timeout
- Increase `LOCAL_LLM_TIMEOUT` environment variable
- Check Ollama is accessible: `curl http://localhost:11434/api/tags`

### aiohttp not installed
```bash
pip install aiohttp
```

## Next Steps

1. ✅ Local LLM integration complete
2. ✅ Tested and working
3. Ready for production use

The system will automatically use the local LLM when `LLMProvider.LOCAL` is specified in requests.

