# V5.5 → V6.0 Greenfield Migration Gap Analysis

## Summary
This document lists all items, systems, and settings from V5.5 that have not yet been migrated to the greenfield V6.0 backend.

---

## 🔴 CRITICAL MISSING COMPONENTS

### 1. Configuration System
**V5.5**: Full `config_loader.py` with YAML-based configuration, environment variable overlay, Settings class
**Greenfield**: ❌ No configuration system - hardcoded values
- Missing: `config_loader.py` with unified config system
- Missing: Settings class with feature flags
- Missing: Environment variable management
- Missing: YAML config file support (`agent_model_config.yaml`, `batch_config.yaml`)
- Missing: Feature flags system (`CHAT_COMMANDS_ENABLED`, `INGEST_TRIGGER_ENABLED`, etc.)

### 2. Database System
**V5.5**: Full SQLAlchemy database with models, migrations, async engine
**Greenfield**: ❌ No database system
- Missing: `core/database.py` with async engine
- Missing: All database models (`models/card.py`, `models/task_ledger.py`, etc.)
- Missing: Database migrations system
- Missing: Database connection pooling

### 3. Core Infrastructure
**V5.5**: Comprehensive core modules
**Greenfield**: ❌ Missing most core infrastructure
- Missing: `core/app_state.py` - Application state management
- Missing: `core/app_bootstrap.py` - Bootstrap system
- Missing: `core/error_handler.py` - Error handling
- Missing: `core/error_codes.py` - Error code system
- Missing: `core/security.py` - Security headers and validation
- Missing: `core/observability.py` - Observability system
- Missing: `core/quality_gates.py` - Quality gate system
- Missing: `core/policy_defaults.py` - Policy defaults

---

## 🟡 ROUTERS (API Endpoints)

### Currently in Greenfield (1):
- ✅ `routers/idle.py` - Idle orchestrator status

### Missing from V5.5 (75+ routers):
1. ❌ `routers/workflow.py` - Workflow management
2. ❌ `routers/cards.py` - Card operations
3. ❌ `routers/health.py` - Health checks
4. ❌ `routers/notifications.py` - Notifications
5. ❌ `routers/coordination.py` - Agent coordination
6. ❌ `routers/websocket.py` - WebSocket support
7. ❌ `routers/chat.py` - Chat interface
8. ❌ `routers/chat_memory.py` - Chat memory
9. ❌ `routers/auth.py` - Authentication
10. ❌ `routers/vault.py` - Vault operations
11. ❌ `routers/vault_sync.py` - Vault synchronization
12. ❌ `routers/rmd.py` - RMD format operations
13. ❌ `routers/learning.py` - Learning system
14. ❌ `routers/actions.py` - Action system
15. ❌ `routers/logs.py` - Log management
16. ❌ `routers/workspace.py` - Workspace management
17. ❌ `routers/agents.py` - Agent operations
18. ❌ `routers/assembly.py` - Assembly operations
19. ❌ `routers/sidebar.py` - Sidebar data
20. ❌ `routers/tasks_yaml.py` - Tasks YAML operations
21. ❌ `routers/metrics_v2.py` - Metrics v2
22. ❌ `routers/parallel_workflow.py` - Parallel workflows
23. ❌ `routers/agent_operations.py` - Agent operations
24. ❌ `routers/assembly_line.py` - Assembly line operations
25. ❌ `routers/assembly_replay.py` - Assembly replay
26. ❌ `routers/priority_decisions.py` - Priority decisions
27. ❌ `routers/unified_cards.py` - Unified cards system
28. ❌ `routers/vector_search.py` - Vector search
29. ❌ `routers/lens_vot.py` - Vector of Truth
30. ❌ `routers/lego_atlas.py` - LEGO Atlas visualization
31. ❌ `routers/task_archival.py` - Task archival
32. ❌ `routers/dashboard.py` - Dashboard telemetry
33. ❌ `routers/insights.py` - Insights
34. ❌ `routers/knowledge.py` - Knowledge base
35. ❌ `routers/audit.py` - Audit trail
36. ❌ `routers/batch.py` - Batch processing
37. ❌ `routers/cognitive_sql.py` - Cognitive SQL
38. ❌ `routers/llm_validation.py` - LLM validation
39. ❌ `routers/observability.py` - Observability
40. ❌ `routers/telemetry.py` - Telemetry
41. ❌ `routers/alias_routes.py` - Alias routes
42. ❌ `routers/dev_probe.py` - Developer probe
43. ❌ `routers/onboarding.py` - Onboarding
44. ❌ `routers/github_webhooks.py` - GitHub webhooks
45. ❌ `routers/hlm_dashboard.py` - HLM dashboard
46. ❌ `routers/docs.py` - Documentation
47. ❌ `routers/issues.py` - Issues
48. ❌ `routers/vault_cleanup.py` - Vault cleanup
49. ❌ `routers/chat_commands.py` - Chat commands (feature flag)
50. ❌ `routers/ingest_trigger.py` - Ingest trigger (feature flag)

---

## 🟡 SERVICES

### Currently in Greenfield (3):
- ✅ `services/idle_orchestrator.py` - Idle orchestrator
- ✅ `services/idle_tasks.py` - Idle tasks
- ✅ `services/metrics_bus.py` - Metrics bus (stub)

### Missing from V5.5 (190+ services):
**Core Services:**
1. ❌ `services/card_manager.py` - Card management
2. ❌ `services/card_generator.py` - Card generation
3. ❌ `services/card_curation_service.py` - Card curation
4. ❌ `services/task_lifecycle_manager.py` - Task lifecycle
5. ❌ `services/task_archival.py` - Task archival
6. ❌ `services/memory_system.py` - Memory system
7. ❌ `services/memory_database_service.py` - Memory database
8. ❌ `services/memory_decay.py` - Memory decay
9. ❌ `services/memory_redaction.py` - Memory redaction
10. ❌ `services/memory_telemetry.py` - Memory telemetry
11. ❌ `services/vault_service.py` - Vault service
12. ❌ `services/vault_sync_service.py` - Vault sync
13. ❌ `services/vault_adapter.py` - Vault adapter
14. ❌ `services/bidirectional_vault_sync.py` - Bidirectional vault sync
15. ❌ `services/vault_card_integration.py` - Vault-card integration
16. ❌ `services/vault_project_integration.py` - Vault-project integration

**MC & Cognitive Services:**
17. ❌ `services/mc_engine.py` - MC engine (V5.5 has full 12-bin system)
18. ❌ `services/mc_system/` - Full MC system directory
19. ❌ `services/mc_aggregator.py` - MC aggregation
20. ❌ `services/mc_circuit_breaker.py` - MC circuit breaker
21. ❌ `services/mc_improvement_system.py` - MC improvement
22. ❌ `services/mc_lite.py` - MC lite
23. ❌ `services/mc_plan_hardening.py` - MC plan hardening
24. ❌ `services/mc_task_router.py` - MC task router
25. ❌ `services/mc_threshold_validator.py` - MC threshold validator
26. ❌ `services/cognitive_sql_extended.py` - Cognitive SQL extended
27. ❌ `services/llm_provider.py` - LLM provider
28. ❌ `services/llm.py` - LLM service
29. ❌ `services/llm_output_validator.py` - LLM output validation
30. ❌ `services/llm_validation_service.py` - LLM validation service
31. ❌ `services/llm_resource_manager.py` - LLM resource manager

**Agent & Assembly Services:**
32. ❌ `services/agent_crew_service.py` - Agent crew service
33. ❌ `services/agent_model_selector.py` - Agent model selector
34. ❌ `services/agent_quality_monitor.py` - Agent quality monitor
35. ❌ `services/agent_sanitizer.py` - Agent sanitizer
36. ❌ `services/assembly_line_processor.py` - Assembly line processor
37. ❌ `services/assembly_line_curation.py` - Assembly line curation
38. ❌ `services/assembly_replay_service.py` - Assembly replay
39. ❌ `services/multi_agent_coordination.py` - Multi-agent coordination
40. ❌ `services/xy_agent_coordination.py` - XY agent coordination
41. ❌ `services/mind_crew_agents.py` - Mind crew agents

**Ingestion & Processing:**
42. ❌ `services/ingestion_system.py` - Ingestion system
43. ❌ `services/ingestion_integration.py` - Ingestion integration
44. ❌ `services/ingestion_monitoring.py` - Ingestion monitoring
45. ❌ `services/ingestion_dashboard.py` - Ingestion dashboard
46. ❌ `services/ingest_jobs.py` - Ingest jobs
47. ❌ `services/batch_system.py` - Batch system
48. ❌ `services/batch_queue_manager.py` - Batch queue manager
49. ❌ `services/batch.py` - Batch processing

**Vector & Search:**
50. ❌ `services/vector_db.py` - Vector database
51. ❌ `services/vector_indexing.py` - Vector indexing
52. ❌ `services/vector_indexing/` - Vector indexing directory
53. ❌ `services/vector_metrics.py` - Vector metrics
54. ❌ `services/vector_retry_service.py` - Vector retry
55. ❌ `services/retrieval_orchestrator.py` - Retrieval orchestrator
56. ❌ `services/retrieval_tier_selector.py` - Retrieval tier selector
57. ❌ `services/rmd_indexer.py` - RMD indexer

**Quality & Monitoring:**
58. ❌ `services/quality_hook.py` - Quality hook
59. ❌ `services/quality_tracing.py` - Quality tracing
60. ❌ `services/monitoring_service.py` - Monitoring service
61. ❌ `services/system_monitor.py` - System monitor
62. ❌ `services/observability.py` - Observability
63. ❌ `services/crew_telemetry_service.py` - Crew telemetry
64. ❌ `services/log_storage_service.py` - Log storage
65. ❌ `services/audit_trail_service.py` - Audit trail
66. ❌ `services/audit_integration.py` - Audit integration

**Project & Planning:**
67. ❌ `services/project_card_service.py` - Project card service
68. ❌ `services/project_graph.py` - Project graph
69. ❌ `services/project_status_mapper.py` - Project status mapper
70. ❌ `services/project_sunset_manager.py` - Project sunset manager
71. ❌ `services/project_wip_manager.py` - Project WIP manager
72. ❌ `services/project_focus_tracker.py` - Project focus tracker
73. ❌ `services/project_acceptance_validator.py` - Project acceptance validator
74. ❌ `services/plan_generator.py` - Plan generator
75. ❌ `services/planner_service.py` - Planner service
76. ❌ `services/ideation_service.py` - Ideation service

**Bias & Defense:**
77. ❌ `services/bias_defense_orchestrator.py` - Bias defense orchestrator
78. ❌ `services/confidence_estimator.py` - Confidence estimator
79. ❌ `services/drift_monitor.py` - Drift monitor

**Resilience & Error Handling:**
80. ❌ `services/resilience.py` - Resilience system
81. ❌ `services/retry_manager.py` - Retry manager
82. ❌ `services/dead_letter_queue.py` - Dead letter queue
83. ❌ `services/dl_policy.py` - Dead letter policy
84. ❌ `services/runtime_supervisor.py` - Runtime supervisor
85. ❌ `services/data_integrity.py` - Data integrity

**Other Services:**
86. ❌ `services/cache_service.py` - Cache service
87. ❌ `services/event_emitter.py` - Event emitter
88. ❌ `services/feature_flag_manager.py` - Feature flag manager
89. ❌ `services/idempotency_checker.py` - Idempotency checker
90. ❌ `services/request_classifier.py` - Request classifier
91. ❌ `services/state_transition_service.py` - State transition
92. ❌ `services/tag_resolution_service.py` - Tag resolution
93. ❌ `services/task_to_card_bridge.py` - Task to card bridge
94. ❌ `services/unified_space_manager.py` - Unified space manager
95. ❌ `services/ux_ui_agent.py` - UX/UI agent
96. ❌ `services/conversation_parser.py` - Conversation parser
97. ❌ `services/conversation_recorder.py` - Conversation recorder
98. ❌ `services/daily_check_in_service.py` - Daily check-in
99. ❌ `services/onboarding_service.py` - Onboarding service
100. ❌ `services/onboarding_rollout.py` - Onboarding rollout
101. ❌ `services/hitl_task_generator.py` - HITL task generator
102. ❌ `services/hlm_calculator.py` - HLM calculator
103. ❌ `services/lifecycle_router.py` - Lifecycle router
104. ❌ `services/live_workspace.py` - Live workspace
105. ❌ `services/parallel_workflow_tracker.py` - Parallel workflow tracker
106. ❌ `services/realtime_aggregator.py` - Realtime aggregator
107. ❌ `services/synopsis_generator.py` - Synopsis generator
108. ❌ `services/ai_curation_service.py` - AI curation
109. ❌ `services/applier_service.py` - Applier service
110. ❌ `services/archive_access_integration.py` - Archive access
111. ❌ `services/archive_access_tracker.py` - Archive tracker
112. ❌ `services/archive_degradation_engine.py` - Archive degradation
113. ❌ `services/archive_synopsis_indexing.py` - Archive synopsis
114. ❌ `services/background_services.py` - Background services
115. ❌ `services/billing.py` - Billing
116. ❌ `services/google_api.py` - Google API
117. ❌ `services/janus_memory_integration.py` - Janus memory integration
118. ❌ `services/learning_metrics.py` - Learning metrics
119. ❌ `services/ltm_schema_validator.py` - LTM schema validator
120. ❌ `services/modular_activation.py` - Modular activation
121. ❌ `services/normalize_header.py` - Normalize header
122. ❌ `services/normalize_schema.py` - Normalize schema
123. ❌ `services/stm_cleanup_policy.py` - STM cleanup policy
124. ❌ `services/toth_service.py` - Toth service
125. ❌ `services/vault_indexer.py` - Vault indexer
126. ❌ `services/activation_integration.py` - Activation integration
127. ❌ `services/idle_tasks_agents.py` - Idle tasks for agents
128. ❌ `services/idle_tasks_archive.py` - Idle tasks for archive

**GitHub Integration Services:**
129. ❌ `services/github_assembly_line.py` - GitHub assembly line
130. ❌ `services/github_card_generator.py` - GitHub card generator
131. ❌ `services/github_compliance.py` - GitHub compliance
132. ❌ `services/github_mc_integration.py` - GitHub MC integration
133. ❌ `services/github_memory_integration.py` - GitHub memory integration
134. ❌ `services/github_observability.py` - GitHub observability
135. ❌ `services/github_resilience.py` - GitHub resilience
136. ❌ `services/github_security.py` - GitHub security

**Maintenance Services:**
137. ❌ `services/maintenance_assembly_line.py` - Maintenance assembly line
138. ❌ `services/maintenance_card_generator.py` - Maintenance card generator
139. ❌ `services/maintenance_mc_integration.py` - Maintenance MC integration
140. ❌ `services/maintenance_memory_integration.py` - Maintenance memory integration
141. ❌ `services/maintenance_observability.py` - Maintenance observability
142. ❌ `services/maintenance_resilience.py` - Maintenance resilience

**Docs Cleanup Services:**
143. ❌ `services/docs_cleanup_assembly_line.py` - Docs cleanup assembly line
144. ❌ `services/docs_cleanup_card_generator.py` - Docs cleanup card generator
145. ❌ `services/docs_cleanup_mc_integration.py` - Docs cleanup MC integration
146. ❌ `services/docs_cleanup_memory_integration.py` - Docs cleanup memory integration
147. ❌ `services/docs_cleanup_observability.py` - Docs cleanup observability
148. ❌ `services/docs_cleanup_resilience.py` - Docs cleanup resilience

---

## 🟡 MIDDLEWARE

### Currently in Greenfield (1):
- ✅ `middleware/activity_middleware.py` - Activity tracking for idle detection

### Missing from V5.5 (8):
1. ❌ `middleware/api_validation.py` - API validation middleware
2. ❌ `middleware/auth_middleware.py` - Authentication middleware
3. ❌ `middleware/authz_middleware.py` - Authorization middleware
4. ❌ `middleware/global_error_handler.py` - Global error handler
5. ❌ `middleware/idempotency.py` - Idempotency middleware
6. ❌ `middleware/logging_middleware.py` - Logging middleware
7. ❌ `middleware/rate_limiter.py` - Rate limiter
8. ❌ `middleware/removed_routes.py` - Removed routes handler

---

## 🟡 CORE MODULES

### Missing Core Infrastructure (40+ files):
1. ❌ `core/app_state.py` - Application state
2. ❌ `core/app_bootstrap.py` - Bootstrap system
3. ❌ `core/config_loader.py` - Configuration loader
4. ❌ `core/config.py` - Configuration (shim)
5. ❌ `core/database.py` - Database engine
6. ❌ `core/error_handler.py` - Error handler
7. ❌ `core/error_codes.py` - Error codes
8. ❌ `core/error_responses.py` - Error responses
9. ❌ `core/security.py` - Security
10. ❌ `core/observability.py` - Observability
11. ❌ `core/quality_gates.py` - Quality gates
12. ❌ `core/policy_defaults.py` - Policy defaults
13. ❌ `core/agent_capabilities.py` - Agent capabilities
14. ❌ `core/agent_manager.py` - Agent manager
15. ❌ `core/bias_defense.py` - Bias defense
16. ❌ `core/caretaker_integration.py` - Caretaker integration
17. ❌ `core/caretaker.py` - Caretaker
18. ❌ `core/cognitive_resonance.py` - Cognitive resonance
19. ❌ `core/crew_boot.py` - Crew boot
20. ❌ `core/crew_config.py` - Crew config
21. ❌ `core/file_processing_tracker.py` - File processing tracker
22. ❌ `core/file_watcher.py` - File watcher
23. ❌ `core/insight_extraction.py` - Insight extraction
24. ❌ `core/lens_vot.py` - Lens VoT
25. ❌ `core/llm_resource_manager.py` - LLM resource manager
26. ❌ `core/logging.py` - Logging system
27. ❌ `core/memory.py` - Memory core
28. ❌ `core/models.py` - Core models
29. ❌ `core/north_star_alignment.py` - North star alignment
30. ❌ `core/north_star_insight_validator.py` - North star insight validator
31. ❌ `core/north_star_meta.py` - North star meta
32. ❌ `core/north_star_projects_service.py` - North star projects
33. ❌ `core/north_star_store.py` - North star store
34. ❌ `core/projects_contract.py` - Projects contract
35. ❌ `core/query_engine.py` - Query engine
36. ❌ `core/redaction.py` - Redaction
37. ❌ `core/registry_bind.py` - Registry bind
38. ❌ `core/rmd_format_converter.py` - RMD format converter
39. ❌ `core/route_audit.py` - Route audit
40. ❌ `core/standardized_responses.py` - Standardized responses
41. ❌ `core/strategic_decision_engine.py` - Strategic decision engine
42. ❌ `core/sync_database.py` - Sync database
43. ❌ `core/user_intelligence.py` - User intelligence
44. ❌ `core/vault_indexer.py` - Vault indexer
45. ❌ `core/vot_config.py` - VoT config
46. ❌ `core/vot_matrix_store.py` - VoT matrix store
47. ❌ `core/vot_mc_integration.py` - VoT MC integration
48. ❌ `core/vot_models.py` - VoT models
49. ❌ `core/resilience/circuit_breaker.py` - Circuit breaker

---

## 🟡 MODELS

### Missing Database Models (20+ files):
1. ❌ `models/card.py` - Card model
2. ❌ `models/card_support.py` - Card support
3. ❌ `models/task_ledger.py` - Task ledger
4. ❌ `models/work_item.py` - Work item
5. ❌ `models/memory.py` - Memory model
6. ❌ `models/memory_database.py` - Memory database
7. ❌ `models/audit_models.py` - Audit models
8. ❌ `models/base.py` - Base model
9. ❌ `models/archive_models.py` - Archive models
10. ❌ `models/crew_telemetry.py` - Crew telemetry
11. ❌ `models/error_queue.py` - Error queue
12. ❌ `models/feature_flags.py` - Feature flags
13. ❌ `models/github_assignment.py` - GitHub assignment
14. ❌ `models/ideation.py` - Ideation
15. ❌ `models/log_storage.py` - Log storage
16. ❌ `models/memory.py` - Memory
17. ❌ `models/pr_metrics.py` - PR metrics
18. ❌ `models/research.py` - Research
19. ❌ `models/rmd_artifacts.py` - RMD artifacts
20. ❌ `models/session.py` - Session
21. ❌ `models/xy_scheduler.py` - XY scheduler

---

## 🟡 SCHEMAS

### Missing Schemas (30+ files):
- V5.5 has 30+ schema files in `schemas/` directory
- Greenfield has minimal schema support
- Missing: Pydantic models for all API requests/responses
- Missing: Validation schemas
- Missing: Configuration schemas

---

## 🟡 WEB SOCKETS

### Missing:
1. ❌ `websockets/workspace_ws.py` - Workspace WebSocket
2. ❌ WebSocket support in main.py
3. ❌ WebSocket broadcaster service

---

## 🟡 EVENTS

### Missing:
1. ❌ `events/memory_events.py` - Memory events
2. ❌ Event emitter system
3. ❌ Event-driven architecture

---

## 🟡 LEGO REGISTRY

### V5.5 Has:
- Full LEGO registry system with blocks, contracts, mixins
- Block adapters for integration
- Registry bindings

### Greenfield Has:
- ✅ Basic `systems/lego_registry.py`
- ❌ Missing full block adapter system
- ❌ Missing contract mixins
- ❌ Missing registry bindings

---

## 🟡 CONFIGURATION FILES

### Missing:
1. ❌ `config/agent_model_config.yaml` - Agent model configuration
2. ❌ `config/batch_config.yaml` - Batch configuration
3. ❌ `config/janus.yaml` - Main configuration
4. ❌ `config/environments/` - Environment-specific configs
5. ❌ `.env` file with all environment variables
6. ❌ Feature flags configuration

---

## 🟡 MIGRATIONS

### Missing:
1. ❌ `migrations/` directory with all migration scripts
2. ❌ Database migration system
3. ❌ Schema migration tools

---

## 🟡 SCRIPTS

### Missing:
1. ❌ `scripts/adversarial_eval_harness.py` - Adversarial evaluation
2. ❌ `scripts/yaml_to_card_flow.py` - YAML to card flow
3. ❌ `scripts/config_validator.py` - Config validator
4. ❌ Other utility scripts

---

## 🟡 TESTS

### Missing:
1. ❌ `tests/` directory with test suites
2. ❌ Test infrastructure
3. ❌ Integration tests

---

## 🟡 DOCUMENTATION

### Missing:
1. ❌ `docs/calibration_policy.md` - Calibration policy
2. ❌ `docs/gemini_integration.md` - Gemini integration
3. ❌ `docs/honeypots.md` - Honeypots
4. ❌ `docs/sentinel_dashboard_spec.md` - Sentinel dashboard spec

---

## 🟡 API MODULES

### Missing:
1. ❌ `api/modular_activation_api.py` - Modular activation API

---

## 📊 SUMMARY STATISTICS

| Category | V5.5 Count | Greenfield Count | Missing |
|----------|-----------|------------------|---------|
| **Routers** | 75+ | 1 | 74+ |
| **Services** | 190+ | 3 | 187+ |
| **Middleware** | 8 | 1 | 7 |
| **Core Modules** | 40+ | 0 | 40+ |
| **Models** | 20+ | 0 | 20+ |
| **Schemas** | 30+ | 0 | 30+ |
| **Blocks** | 13 | 13 | 0 ✅ |
| **Systems** | 12 | 12 | 0 ✅ |
| **Agents** | 6 | 6 | 0 ✅ |

**Total Missing Components: ~400+ files/modules**

---

## 🎯 PRIORITY RECOMMENDATIONS

### Phase 1: Critical Infrastructure (Must Have)
1. Configuration system (`config_loader.py`, Settings)
2. Database system (models, migrations, engine)
3. Core infrastructure (app_state, error_handler, security)
4. Essential routers (health, cards, unified_cards, vault)

### Phase 2: Core Functionality (Should Have)
1. Memory system services
2. MC engine full implementation
3. Vault services
4. Assembly line services
5. Authentication/authorization middleware

### Phase 3: Advanced Features (Nice to Have)
1. WebSocket support
2. Event system
3. Advanced monitoring
4. GitHub integration
5. Batch processing

---

## 📝 NOTES

- Greenfield has a clean LEGO architecture foundation ✅
- All blocks and systems are implemented ✅
- Missing: All the services, routers, and infrastructure that make V5.5 production-ready
- Greenfield is ~5% of V5.5's functionality in terms of API endpoints and services
- Greenfield has the core architecture but lacks the operational layer

