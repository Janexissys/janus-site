#!/usr/bin/env python3

# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Test script for local LLM (Ollama) integration.

Tests the CognitiveBlock with local LLM provider.
"""

import asyncio
import sys
from pathlib import Path

# Add current directory to path
sys.path.insert(0, str(Path(__file__).parent))

from blocks.cognitive_block import CognitiveBlock, LLMRequest, LLMProvider

async def test_local_llm():
    """Test local LLM provider."""
    print("🧪 Testing Local LLM Integration\n")
    
    # Initialize cognitive block
    block = CognitiveBlock()
    block.initialize({
        "api_keys": {
            "local": "http://localhost:11434"  # Ollama default
        }
    })
    
    print("✓ CognitiveBlock initialized\n")
    
    # Test 1: Simple prompt
    print("Test 1: Simple prompt")
    print("-" * 50)
    request = LLMRequest(
        prompt="What is 2+2?",
        provider=LLMProvider.LOCAL,
        max_tokens=100,
        temperature=0.7
    )
    
    try:
        response = await block.generate(request)
        print(f"✅ Success!")
        print(f"Response: {response.content[:200]}...")
        print(f"Provider: {response.provider.value}")
        print(f"Latency: {response.latency_ms:.2f}ms")
        print(f"PII Detected: {response.pii_detected}")
        print()
    except Exception as e:
        print(f"❌ Error: {e}")
        print()
    
    # Test 2: With system prompt
    print("Test 2: With system prompt")
    print("-" * 50)
    request = LLMRequest(
        prompt="Explain quantum computing in one sentence.",
        system_prompt="You are a helpful assistant that explains complex topics simply.",
        provider=LLMProvider.LOCAL,
        max_tokens=200,
        temperature=0.5
    )
    
    try:
        response = await block.generate(request)
        print(f"✅ Success!")
        print(f"Response: {response.content[:200]}...")
        print(f"Latency: {response.latency_ms:.2f}ms")
        print()
    except Exception as e:
        print(f"❌ Error: {e}")
        print()
    
    # Test 3: Health check
    print("Test 3: Health check")
    print("-" * 50)
    health = block.get_health()
    print(f"Status: {health.status.value}")
    print(f"Message: {health.message}")
    print(f"Details: {health.details}")
    print()

if __name__ == "__main__":
    print("=" * 50)
    print("Local LLM Test (Ollama)")
    print("=" * 50)
    print()
    print("Prerequisites:")
    print("  1. Ollama installed and running")
    print("  2. Model downloaded (e.g., 'ollama pull mistral:7b')")
    print("  3. Ollama running on http://localhost:11434")
    print()
    
    # Check if Ollama is running
    import aiohttp
    async def check_ollama():
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get("http://localhost:11434/api/tags", timeout=aiohttp.ClientTimeout(total=5)) as resp:
                    if resp.status == 200:
                        print("✓ Ollama is running")
                        data = await resp.json()
                        models = [m.get("name", "") for m in data.get("models", [])]
                        if models:
                            print(f"✓ Available models: {', '.join(models[:5])}")
                        else:
                            print("⚠ No models found. Run: ollama pull mistral:7b")
                        print()
                        return True
        except Exception as e:
            print(f"❌ Ollama not accessible: {e}")
            print("   Make sure Ollama is running: ollama serve")
            print()
            return False
    
    # Run checks and tests
    asyncio.run(check_ollama())
    asyncio.run(test_local_llm())

