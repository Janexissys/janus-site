"""
Vector Repeatability Validation

**Card**: CARD-V6B-P1-DELTA-VECTOR-REPEATABILITY

Purpose: Validate that system outputs follow consistent "vectors" (directions/outcomes)
rather than requiring impossible 1:1 exact matches with AI systems.

Key Principle: AI systems cannot guarantee byte-for-byte identical outputs, but we CAN
guarantee consistent gate decisions, workflow directions, and MC score ranges.

Usage:
    from utils.vector_repeatability import validate_vector_repeatability, VectorTolerance
    
    result1 = mc_engine.calculate_mc(content, card_id)
    result2 = mc_engine.calculate_mc(content, card_id)  # Second run
    
    is_valid = validate_vector_repeatability(result1, result2)
    assert is_valid, "Vector repeatability failed"
"""

from dataclasses import dataclass
from typing import Any, Dict, Optional
import os


@dataclass
class VectorTolerance:
    """Tolerance configuration for vector repeatability validation.
    
    Defines acceptable variance for different metrics when validating
    that two runs produce the same "vector" (direction/outcome).
    
    Key Insight: MC is heuristic (scores vary), but gate decisions are
    deterministic. Guard bands around thresholds ensure gate decisions
    remain stable even with score variance.
    
    Attributes:
        mc_score: Maximum allowed difference in MC gate score (default: 0.1)
        bin_score: Maximum allowed difference in bin scores (default: 0.2)
        gate_decision: Must be exact (0.0) - gate decisions are deterministic
        workflow_direction: Must be exact (0.0) - workflow routing is deterministic
        guard_band: Safety margin around thresholds to prevent gate flips (default: 0.15)
    """
    mc_score: float = 0.1
    bin_score: float = 0.2
    gate_decision: float = 0.0  # Must be exact
    workflow_direction: float = 0.0  # Must be exact
    guard_band: float = 0.15  # Safety margin around thresholds
    
    @classmethod
    def from_env(cls) -> "VectorTolerance":
        """Load tolerance from environment variables."""
        return cls(
            mc_score=float(os.getenv("VECTOR_TOLERANCE_MC_SCORE", "0.1")),
            bin_score=float(os.getenv("VECTOR_TOLERANCE_BIN_SCORE", "0.2")),
            gate_decision=float(os.getenv("VECTOR_TOLERANCE_GATE_DECISION", "0.0")),
            workflow_direction=float(os.getenv("VECTOR_TOLERANCE_WORKFLOW", "0.0")),
            guard_band=float(os.getenv("VECTOR_GUARD_BAND", "0.15"))
        )


def validate_gate_decision_consistency(
    result1: Dict[str, Any],
    result2: Dict[str, Any],
    tolerance: VectorTolerance
) -> tuple[bool, Optional[str]]:
    """Validate that gate decisions are consistent.
    
    Gate decisions (pass/hold, promote_ltm, route_caretaker) must be
    identical across runs - these are deterministic based on MC scores.
    
    Args:
        result1: First MC result dictionary
        result2: Second MC result dictionary
        tolerance: Tolerance configuration
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    # Extract gate decisions
    gate1 = result1.get("gate_verdict", {}).get("result")
    gate2 = result2.get("gate_verdict", {}).get("result")
    
    if gate1 != gate2:
        return False, f"Gate decision mismatch: {gate1} != {gate2}"
    
    # Check promote_ltm decision
    promote1 = result1.get("gate_verdict", {}).get("promote_ltm", False)
    promote2 = result2.get("gate_verdict", {}).get("promote_ltm", False)
    
    if promote1 != promote2:
        return False, f"Promote LTM mismatch: {promote1} != {promote2}"
    
    return True, None


def validate_mc_score_range(
    result1: Dict[str, Any],
    result2: Dict[str, Any],
    tolerance: VectorTolerance
) -> tuple[bool, Optional[str]]:
    """Validate that MC scores are within tolerance.
    
    MC gate scores can vary slightly (within tolerance) but should be
    close enough that gate decisions remain consistent.
    
    Uses guard bands around thresholds to ensure gate decisions remain
    stable even with score variance. Scores near boundaries (within guard
    band) may require human review, but gate decisions must still match.
    
    Args:
        result1: First MC result dictionary
        result2: Second MC result dictionary
        tolerance: Tolerance configuration
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    score1 = result1.get("gate_score", {}).get("score", 0.0)
    score2 = result2.get("gate_score", {}).get("score", 0.0)
    
    diff = abs(score1 - score2)
    
    if diff > tolerance.mc_score:
        return False, f"MC score difference {diff:.3f} exceeds tolerance {tolerance.mc_score}"
    
    # Verify gate decision is still consistent despite variance
    # This is the critical check - gate decisions must match even if scores vary
    gate1 = result1.get("gate_verdict", {}).get("result")
    gate2 = result2.get("gate_verdict", {}).get("result")
    
    if gate1 != gate2:
        # Check if both scores are near a threshold (within guard band)
        # If so, this might be acceptable if human oversight is involved
        thresholds = [8.5, 7.0, 7.5, 5.0]  # Standard MC thresholds
        near_threshold = any(
            abs(score1 - t) < tolerance.guard_band and abs(score2 - t) < tolerance.guard_band
            for t in thresholds
        )
        
        if near_threshold:
            # Near threshold - gate decision change might be acceptable with human review
            return False, (
                f"MC score variance {diff:.3f} near threshold caused gate decision change: "
                f"{gate1} != {gate2} (requires human review)"
            )
        else:
            # Not near threshold - gate decision change is unacceptable
            return False, (
                f"MC score variance {diff:.3f} caused gate decision change: "
                f"{gate1} != {gate2} (scores not near threshold - vector drift detected)"
            )
    
    return True, None


def validate_bin_scores(
    result1: Dict[str, Any],
    result2: Dict[str, Any],
    tolerance: VectorTolerance
) -> tuple[bool, Optional[str]]:
    """Validate that bin scores are within tolerance.
    
    Individual bin scores can vary more than the overall MC score,
    but should still be within reasonable bounds.
    
    Args:
        result1: First MC result dictionary
        result2: Second MC result dictionary
        tolerance: Tolerance configuration
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    bins1 = result1.get("gate_score", {}).get("bins", {})
    bins2 = result2.get("gate_score", {}).get("bins", {})
    
    if set(bins1.keys()) != set(bins2.keys()):
        return False, f"Bin keys mismatch: {set(bins1.keys())} != {set(bins2.keys())}"
    
    for bin_name in bins1.keys():
        score1 = bins1[bin_name].get("score", 0.0) if isinstance(bins1[bin_name], dict) else bins1[bin_name]
        score2 = bins2[bin_name].get("score", 0.0) if isinstance(bins2[bin_name], dict) else bins2[bin_name]
        
        diff = abs(score1 - score2)
        
        if diff > tolerance.bin_score:
            return False, f"Bin '{bin_name}' difference {diff:.3f} exceeds tolerance {tolerance.bin_score}"
    
    return True, None


def validate_workflow_direction(
    result1: Dict[str, Any],
    result2: Dict[str, Any],
    tolerance: VectorTolerance
) -> tuple[bool, Optional[str]]:
    """Validate that workflow direction is consistent.
    
    Workflow routing decisions (which agent, which path) must be
    identical - these are deterministic based on gate scores.
    
    Args:
        result1: First MC result dictionary
        result2: Second MC result dictionary
        tolerance: Tolerance configuration
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    # Check eligible_for_action (determines if workflow proceeds)
    eligible1 = result1.get("eligible_for_action", False)
    eligible2 = result2.get("eligible_for_action", False)
    
    if eligible1 != eligible2:
        return False, f"Eligible for action mismatch: {eligible1} != {eligible2}"
    
    # Check stop_gate (determines workflow path)
    stop1 = result1.get("gate_verdict", {}).get("stop_gate")
    stop2 = result2.get("gate_verdict", {}).get("stop_gate")
    
    if stop1 != stop2:
        return False, f"Stop gate mismatch: {stop1} != {stop2}"
    
    return True, None


def validate_vector_repeatability(
    result1: Dict[str, Any],
    result2: Dict[str, Any],
    tolerance: Optional[VectorTolerance] = None
) -> tuple[bool, Optional[str]]:
    """Validate vector repeatability between two MC results.
    
    Vector repeatability means same input produces same **direction/outcome**,
    not necessarily exact same output. This is achievable with AI systems.
    
    Validates:
    1. Gate decisions are identical (deterministic)
    2. MC scores are within tolerance
    3. Bin scores are within tolerance
    4. Workflow direction is consistent (deterministic)
    
    Args:
        result1: First MC result dictionary
        result2: Second MC result dictionary
        tolerance: Optional tolerance configuration (defaults to from_env)
    
    Returns:
        Tuple of (is_valid, error_message)
    
    Example:
        ```python
        result1 = mc_engine.calculate_mc(content, card_id)
        result2 = mc_engine.calculate_mc(content, card_id)
        
        is_valid, error = validate_vector_repeatability(result1, result2)
        if not is_valid:
            print(f"Vector repeatability failed: {error}")
        ```
    """
    if tolerance is None:
        tolerance = VectorTolerance.from_env()
    
    # Validate gate decisions (must be exact)
    valid, error = validate_gate_decision_consistency(result1, result2, tolerance)
    if not valid:
        return False, f"Gate decision: {error}"
    
    # Validate MC score range (within tolerance)
    valid, error = validate_mc_score_range(result1, result2, tolerance)
    if not valid:
        return False, f"MC score: {error}"
    
    # Validate bin scores (within tolerance)
    valid, error = validate_bin_scores(result1, result2, tolerance)
    if not valid:
        return False, f"Bin scores: {error}"
    
    # Validate workflow direction (must be exact)
    valid, error = validate_workflow_direction(result1, result2, tolerance)
    if not valid:
        return False, f"Workflow direction: {error}"
    
    return True, None

