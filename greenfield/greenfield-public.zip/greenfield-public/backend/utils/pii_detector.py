# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Shared PII Detection Utility

Optimized PII detection with compiled regex patterns for better performance.
Used across all greenfield components for consistent PII detection.
"""

import re
from typing import List, Tuple, Pattern

logger = None  # Will be set if logging needed


class PIIDetector:
    """Shared PII detector with compiled regex patterns."""
    
    # PII patterns (compiled once for performance)
    _COMPILED_PATTERNS: List[Tuple[str, Pattern]] = []
    
    @classmethod
    def _compile_patterns(cls) -> None:
        """Compile PII patterns once (lazy initialization)."""
        if cls._COMPILED_PATTERNS:
            return  # Already compiled
        
        patterns = [
            ("email", r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'),
            ("phone", r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b'),
            ("ssn", r'\b\d{3}-\d{2}-\d{4}\b'),
            ("credit_card", r'\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b'),
            ("ip_address", r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b'),
        ]
        
        cls._COMPILED_PATTERNS = [
            (pii_type, re.compile(pattern, re.IGNORECASE))
            for pii_type, pattern in patterns
        ]
    
    @classmethod
    def detect(cls, content: str) -> bool:
        """Detect PII in content (SENTINEL: PII Detection).
        
        Args:
            content: Content to check
            
        Returns:
            True if PII detected, False otherwise
        """
        cls._compile_patterns()
        
        for pii_type, compiled_pattern in cls._COMPILED_PATTERNS:
            if compiled_pattern.search(content):
                return True
        
        return False
    
    @classmethod
    def detect_with_types(cls, content: str) -> Tuple[bool, List[str]]:
        """Detect PII and return detected types.
        
        Args:
            content: Content to check
            
        Returns:
            Tuple of (detected: bool, types: List[str])
        """
        cls._compile_patterns()
        
        detected_types = []
        for pii_type, compiled_pattern in cls._COMPILED_PATTERNS:
            if compiled_pattern.search(content):
                detected_types.append(pii_type)
        
        return len(detected_types) > 0, detected_types
    
    @classmethod
    def get_patterns(cls) -> List[Tuple[str, Pattern]]:
        """Get compiled patterns (for advanced usage).
        
        Returns:
            List of (pii_type, compiled_pattern) tuples
        """
        cls._compile_patterns()
        return cls._COMPILED_PATTERNS

