# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Standardized exception hierarchy for Janus v6.0.

Card: CARD-PHASE4-P2-ERROR-HANDLING
Phase: Phase 4 - Hardening & Refinement
"""


class JanusError(Exception):
    """Base exception for all Janus errors.
    
    All Janus exceptions inherit from this base class, providing:
    - Component name tracking
    - Context dictionary for error details
    - Consistent error message format
    """
    
    def __init__(self, message: str, component: str = None, context: dict = None):
        """Initialize Janus error.
        
        Args:
            message: Error message (should follow format: "Component: Action - Reason")
            component: Name of the component raising the error
            context: Dictionary of additional context (IDs, values, etc.)
        """
        self.component = component
        self.context = context or {}
        super().__init__(message)
    
    def __str__(self) -> str:
        """Return formatted error string."""
        if self.component:
            return f"[{self.component}] {super().__str__()}"
        return super().__str__()
    
    def to_dict(self) -> dict:
        """Convert error to dictionary for logging/serialization.
        
        Returns:
            Dictionary with error details
        """
        return {
            "error_type": self.__class__.__name__,
            "message": str(self),
            "component": self.component,
            "context": self.context
        }


class ValidationError(JanusError):
    """Raised when input validation fails.
    
    Use for:
    - Invalid input parameters
    - Missing required fields
    - Type mismatches
    - Value out of range
    """
    pass


class ConfigurationError(JanusError):
    """Raised when configuration is invalid.
    
    Use for:
    - Missing configuration values
    - Invalid configuration format
    - Configuration conflicts
    """
    pass


class SystemError(JanusError):
    """Raised for system-level errors.
    
    Use for:
    - Internal system failures
    - Resource exhaustion
    - System state inconsistencies
    """
    pass


class IntegrationError(JanusError):
    """Raised when external service integration fails.
    
    Use for:
    - External API failures
    - Network errors
    - Service unavailable
    - Integration timeouts
    """
    pass

