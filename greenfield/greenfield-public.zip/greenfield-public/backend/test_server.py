#!/usr/bin/env python3

# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Greenfield Backend Test Server

Simple FastAPI server that wraps greenfield backend systems
to provide API endpoints for frontend testing.

Card Reference: CARD-V6B-P2-FE-APP-WIRING (testing support)
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Dict, Any, Optional
import sys
import os
import json
import logging
from pathlib import Path
from datetime import datetime, timedelta

# Add greenfield backend to path
backend_path = os.path.join(os.path.dirname(__file__), '..')
sys.path.insert(0, backend_path)
sys.path.insert(0, os.path.join(backend_path, 'backend'))

# Configure logging
script_dir = Path(__file__).parent
logs_dir = script_dir.parent / "logs"
logs_dir.mkdir(parents=True, exist_ok=True)

# Set up logging to both file and console
log_file = logs_dir / "server.log"
log_level = os.getenv("LOG_LEVEL", "INFO").upper()

logging.basicConfig(
    level=getattr(logging, log_level, logging.INFO),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_file, encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger(__name__)
logger.info(f"🚀 Greenfield v6.0 Backend Server starting...")
logger.info(f"📝 Logging to: {log_file}")
logger.info(f"📊 Telemetry logs: {logs_dir / 'telemetry.ndjson'}")

app = FastAPI(title="Janus Greenfield v6.0 API", version="6.0.0")

# Request logging middleware
@app.middleware("http")
async def log_requests(request, call_next):
    start_time = datetime.now()
    response = await call_next(request)
    duration = (datetime.now() - start_time).total_seconds() * 1000
    logger.info(
        f"{request.method} {request.url.path} - "
        f"Status: {response.status_code} - "
        f"Duration: {duration:.2f}ms"
    )
    return response

# CORS middleware for frontend (LAN access support)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins for LAN access
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["*"],
    expose_headers=["*"],
)

# Mock data for testing (until real backend integration)
# Using actual Greenfield card IDs from seed_all_29_cards.py
MOCK_CARDS = []

def extract_phase(card_id: str) -> str:
    """Extract phase (P0, P1, P2, P3) from card_id."""
    if "-P0-" in card_id:
        return "P0"
    elif "-P1-" in card_id:
        return "P1"
    elif "-P2-" in card_id:
        return "P2"
    elif "-P3-" in card_id:
        return "P3"
    return "P1"  # Default

def get_lifecycle_state(mc_score: float, index: int) -> str:
    """Assign lifecycle state based on MC score and index for variety."""
    if mc_score >= 8.5:
        # High MC - mostly completed, some in review
        states = ["completed", "completed", "review", "completed", "running"]
        return states[index % len(states)]
    elif mc_score >= 8.0:
        # Medium-high MC - running or review
        states = ["running", "review", "running", "symbiosis", "running"]
        return states[index % len(states)]
    else:
        # Lower MC - new or symbiosis
        states = ["new", "symbiosis", "new", "symbiosis", "new"]
        return states[index % len(states)]

def generate_mc_bins(base_score: float) -> dict:
    """Generate 12-bin MC breakdown with realistic variation."""
    # Base bins around the score with some variation
    bins = {
        "signal": max(0, min(10, base_score + (0.1 if base_score >= 8.5 else -0.2))),
        "memory_short": max(0, min(10, base_score - 0.1)),
        "mental_state": max(0, min(10, base_score + 0.05)),
        "bias_good": max(0, min(10, base_score + 0.15)),
        "bias_bad": max(0, min(10, base_score - 0.2)),
        "memory_long": max(0, min(10, base_score + 0.1)),
        "knowledge": max(0, min(10, base_score + 0.2)),
        "education": max(0, min(10, base_score - 0.1)),
        "priority": max(0, min(10, base_score + 0.05)),
        "ethos": max(0, min(10, base_score + 0.1)),
        "drift": max(0, min(10, base_score - 0.15)),
        "execution_risk": max(0, min(10, base_score - 0.1))
    }
    return {k: round(v, 2) for k, v in bins.items()}

def generate_breadcrumb_pointer(card_id: str, title: str, card_type: str) -> dict:
    """Generate breadcrumb pointer to vault file."""
    # Map card types to pointer types
    pointer_type_map = {
        "lego_block": "task_spec",
        "agent": "vault_insight",
        "core_system": "task_spec",
        "doctrine": "vault_insight"
    }
    
    # Generate vault path
    vault_path = f"stmvault/cards/{card_id.lower().replace('-', '_')}.md"
    
    return {
        "type": pointer_type_map.get(card_type, "task_spec"),
        "path": vault_path,
        "title": f"{title} - Full Context"
    }

def generate_dependencies(card_id: str, all_card_ids: list, card_type: str) -> tuple:
    """Generate realistic dependencies and blocking dependencies."""
    deps = []
    blocking = []
    
    # LEGO blocks depend on foundational blocks
    if card_type == "lego_block":
        if "MEMORY" in card_id:
            deps = ["CARD-V6B-P1-LEGO-VAULT", "CARD-V6B-P1-LEGO-VECTOR_DB"]
        elif "VECTOR_DB" in card_id:
            deps = ["CARD-V6B-P1-LEGO-VAULT"]
        elif "ASSEMBLY_LINE" in card_id:
            deps = ["CARD-V6B-P1-LEGO-AGENT", "CARD-V6B-P1-LEGO-MEMORY"]
    
    # Agents depend on Agent Soul Pack
    elif card_type == "agent":
        deps = ["CARD-V6B-P0-AGENT-SOUL"]
        # Some agents block others
        if "CARETAKER" in card_id:
            blocking = ["CARD-V6B-P1-AGENT-GARDENER"]
    
    # Core systems depend on LEGO blocks
    elif card_type == "core_system":
        if "MC_ENGINE" in card_id:
            deps = ["CARD-V6B-P1-LEGO-COGNITIVE"]
        elif "MEMORY_SYSTEM" in card_id:
            deps = ["CARD-V6B-P1-LEGO-MEMORY", "CARD-V6B-P1-LEGO-VECTOR_DB"]
        elif "ASSEMBLY_LINE" in card_id:
            deps = ["CARD-V6B-P1-LEGO-ASSEMBLY_LINE"]
    
    # Filter to only include IDs that exist
    deps = [d for d in deps if d in all_card_ids]
    blocking = [b for b in blocking if b in all_card_ids]
    
    return deps, blocking

# 13 LEGO Blocks
lego_blocks = [
    ("CARD-V6B-P1-LEGO-VAULT", "VaultBlock", 8.60),
    ("CARD-V6B-P1-LEGO-COGNITIVE", "CognitiveBlock", 8.55),
    ("CARD-V6B-P1-LEGO-AGENT", "AgentBlock", 8.55),
    ("CARD-V6B-P1-LEGO-INGEST", "IngestBlock", 8.70),
    ("CARD-V6B-P1-LEGO-VECTOR_DB", "VectorDatabaseBlock", 8.60),
    ("CARD-V6B-P1-LEGO-TELEMETRY", "TelemetryBlock", 8.50),
    ("CARD-V6B-P1-LEGO-BATCH", "BatchBlock", 8.55),
    ("CARD-V6B-P1-LEGO-ACTIONS", "ActionsBlock", 8.50),
    ("CARD-V6B-P1-LEGO-ACTION_WEBHOOK", "ActionWebhookBlock", 8.50),
    ("CARD-V6B-P1-LEGO-RMD", "RmdBlock", 8.50),
    ("CARD-V6B-P1-LEGO-MEMORY", "MemoryBlock", 8.65),
    ("CARD-V6B-P1-LEGO-LEARNING", "LearningBlock", 8.60),
    ("CARD-V6B-P1-LEGO-ASSEMBLY_LINE", "AssemblyLineBlock", 8.60),
]

# Collect all card IDs first for dependency generation
all_card_ids = []

for card_id, title, mc_score in lego_blocks:
    # Generate MC bins with some variation (some below 8.5 for testing)
    mc_bins = generate_mc_bins(mc_score)
    # Ensure at least one bin is below 8.5 for validation testing
    if all(v >= 8.5 for v in mc_bins.values()):
        # Lower a few bins to test validation
        mc_bins["drift"] = max(7.0, mc_bins["drift"] - 0.5)
        mc_bins["execution_risk"] = max(7.5, mc_bins["execution_risk"] - 0.3)
    
    MOCK_CARDS.append({
        "card_id": card_id,
        "id": card_id,
        "title": title,
        "type": "lego_block",
        "card_type": "lego_block",
        "mc_score": mc_score,
        "mc": {"score": mc_score, "gate": 8.50},
        "mc_gate": 8.50,
        "status": "done",
        "lifecycle_state": "done",
        "dependencies": [],
        "blocking_dependencies": [],
        "metadata": {
            "mc_bins": mc_bins,
            "acceptance": [
                f"All acceptance criteria for {title} are met",
                f"MC score meets or exceeds gate threshold (8.50)",
                f"All dependencies are resolved",
                f"Code review completed and approved"
            ],
            "mc_validation_note": f"Card {title} has been validated. Some bins below 8.5 require discussion.",
            "last_mc_validation": "2025-01-27T12:00:00Z",
            "bin_focus": "drift (primary), execution_risk (secondary)",
            "pointer": generate_breadcrumb_pointer(card_id, title, "lego_block")
        },
        "created_at": "2025-01-27T00:00:00Z",
        "updated_at": "2025-01-27T00:00:00Z",
        "last_activity": "2025-01-27T00:00:00Z"
    })

# 6 Agent Crew
agents = [
    ("CARD-V6B-P1-AGENT-SENTINEL", "Sentinel Agent", 8.70, "Protector of Truth", "Policy violations and security breaches"),
    ("CARD-V6B-P1-AGENT-CARETAKER", "Caretaker Agent", 8.65, "Guardian of Stewardship", "Tactical implementation details"),
    ("CARD-V6B-P1-AGENT-GARDENER", "Gardener Agent", 8.60, "Revealer of Order", "Strategic planning and decision-making"),
    ("CARD-V6B-P1-AGENT-MERCURY", "Mercury Agent", 8.55, "Revealer of Hidden Gems", "Card creation and structuring"),
    ("CARD-V6B-P1-AGENT-SCRIBE", "Scribe Agent", 8.55, "Witness and Translator", "Memory routing and retrieval"),
    ("CARD-V6B-P1-AGENT-CONDUCTOR", "Conductor Agent", 8.50, "Keeper of Rhythm", "Individual agent implementation"),
]

for card_id, title, mc_score, obsession, stays_out_of in agents:
    # Generate MC bins with some variation
    mc_bins = generate_mc_bins(mc_score)
    # Ensure at least one bin is below 8.5 for validation testing
    if all(v >= 8.5 for v in mc_bins.values()):
        mc_bins["mental_state"] = max(7.8, mc_bins["mental_state"] - 0.4)
        mc_bins["education"] = max(7.5, mc_bins["education"] - 0.5)
    
    MOCK_CARDS.append({
        "card_id": card_id,
        "id": card_id,
        "title": title,
        "type": "agent",
        "card_type": "agent",
        "mc_score": mc_score,
        "mc": {"score": mc_score, "gate": 8.50},
        "mc_gate": 8.50,
        "status": "done",
        "lifecycle_state": "done",
        "dependencies": [],
        "blocking_dependencies": [],
        "soul_ref": "CARD-V6B-P0-AGENT-SOUL",
        "soulRef": "CARD-V6B-P0-AGENT-SOUL",
        "obsession": obsession,
        "stays_out_of": stays_out_of,
        "staysOutOf": stays_out_of,
        "metadata": {
            "mc_bins": mc_bins,
            "acceptance": [
                f"Agent {title} identity is clearly defined",
                f"Obsession and boundaries are documented",
                f"MC score meets or exceeds gate threshold (8.50)",
                f"Agent soul pack reference is valid"
            ],
            "mc_validation_note": f"Agent {title} validated. Some cognitive bins require team discussion.",
            "last_mc_validation": "2025-01-27T12:00:00Z",
            "bin_focus": "mental_state (primary), education (secondary)",
            "pointer": generate_breadcrumb_pointer(card_id, title, "agent")
        },
        "created_at": "2025-01-27T00:00:00Z",
        "updated_at": "2025-01-27T00:00:00Z",
        "last_activity": "2025-01-27T00:00:00Z"
    })

# 10 Core Systems
core_systems = [
    ("CARD-V6B-P1-COMP-MC_ENGINE", "MC Engine & 12-Bin System", 8.70),
    ("CARD-V6B-P1-COMP-NORTH_STAR", "North Star Integration", 8.80),
    ("CARD-V6B-P1-COMP-LEGO_REGISTRY", "LEGO Registry", 8.70),
    ("CARD-V6B-P1-COMP-ASSEMBLY_LINE", "Assembly Line Processor", 8.60),
    ("CARD-V6B-P1-COMP-MEMORY_SYSTEM", "Memory System (STM/LTM)", 8.65),
    ("CARD-V6B-P1-COMP-VAULT_SYSTEM", "Vault System", 8.60),
    ("CARD-V6B-P1-COMP-TELEMETRY", "Telemetry & Metrics", 8.50),
    ("CARD-V6B-P1-COMP-TASK_CARD_SYSTEM", "Task & Card System", 8.55),
    ("CARD-V6B-P1-COMP-API", "API Layer", 8.55),
    ("CARD-V6B-P1-COMP-FRONTEND", "Frontend Components", 8.50),
]

for card_id, title, mc_score in core_systems:
    # Generate MC bins with some variation
    mc_bins = generate_mc_bins(mc_score)
    # Ensure at least one bin is below 8.5 for validation testing
    if all(v >= 8.5 for v in mc_bins.values()):
        mc_bins["priority"] = max(7.9, mc_bins["priority"] - 0.3)
        mc_bins["knowledge"] = max(8.2, mc_bins["knowledge"] - 0.2)
    
    MOCK_CARDS.append({
        "card_id": card_id,
        "id": card_id,
        "title": title,
        "type": "core_system",
        "card_type": "core_system",
        "mc_score": mc_score,
        "mc": {"score": mc_score, "gate": 8.50},
        "mc_gate": 8.50,
        "status": "done",
        "lifecycle_state": "done",
        "dependencies": [],
        "blocking_dependencies": [],
        "metadata": {
            "mc_bins": mc_bins,
            "acceptance": [
                f"Core system {title} is fully implemented",
                f"All integration tests pass",
                f"MC score meets or exceeds gate threshold (8.50)",
                f"Documentation is complete and accurate"
            ],
            "mc_validation_note": f"Core system {title} validated. Review bins below 8.5 for improvement opportunities.",
            "last_mc_validation": "2025-01-27T12:00:00Z",
            "bin_focus": "priority (primary), knowledge (secondary)",
            "pointer": generate_breadcrumb_pointer(card_id, title, "core_system")
        },
        "created_at": "2025-01-27T00:00:00Z",
        "updated_at": "2025-01-27T00:00:00Z",
        "last_activity": "2025-01-27T00:00:00Z"
    })

# Agent Soul Pack (Doctrine Card)
soul_mc_bins = generate_mc_bins(8.70)
# Ensure some bins below 8.5 for testing
soul_mc_bins["ethos"] = 8.3
soul_mc_bins["drift"] = 7.8

MOCK_CARDS.append({
    "card_id": "CARD-V6B-P0-AGENT-SOUL",
    "id": "CARD-V6B-P0-AGENT-SOUL",
    "title": "Agent Soul Pack",
    "type": "doctrine",
    "card_type": "doctrine",
    "mc_score": 8.70,
    "mc": {"score": 8.70, "gate": 8.50},
    "mc_gate": 8.50,
    "status": "done",
    "lifecycle_state": "done",
    "dependencies": [],
    "blocking_dependencies": [],
    "soul_ref": "CARD-V6B-P0-AGENT-SOUL",
    "soulRef": "CARD-V6B-P0-AGENT-SOUL",
    "obsession": "Agent identity and boundaries",
    "stays_out_of": "Implementation details",
    "staysOutOf": "Implementation details",
    "metadata": {
        "mc_bins": soul_mc_bins,
        "acceptance": [
            "Agent identity framework is clearly defined",
            "All agent obsessions and boundaries are documented",
            "MC score meets or exceeds gate threshold (8.50)",
            "Doctrine is aligned with V6.0 vision"
        ],
        "mc_validation_note": "Agent Soul Pack validated. Ethos and drift bins need team discussion.",
        "last_mc_validation": "2025-01-27T12:00:00Z",
        "bin_focus": "ethos (primary), drift (secondary)",
        "pointer": generate_breadcrumb_pointer("CARD-V6B-P0-AGENT-SOUL", "Agent Soul Pack", "doctrine")
    },
    "created_at": "2025-01-27T00:00:00Z",
    "updated_at": "2025-01-27T00:00:00Z",
    "last_activity": "2025-01-27T00:00:00Z"
})


@app.get("/api/v1/health")
async def health():
    """Health check endpoint."""
    return {
        "status": "healthy", 
        "version": "6.0.0",
        "cors_enabled": True,
        "timestamp": datetime.now().isoformat()
    }

@app.options("/{full_path:path}")
async def options_handler(full_path: str):
    """Handle CORS preflight requests."""
    return {"status": "ok"}


# Store for dynamically created cards (in addition to MOCK_CARDS)
CREATED_CARDS: List[Dict[str, Any]] = []


@app.post("/api/v1/cards")
async def create_card(card_data: Dict[str, Any]):
    """Create a new card endpoint.
    
    Args:
        card_data: Card data including title, content, mc_score, metadata
    
    Returns:
        Created card object
    
    Raises:
        HTTPException: 400/422 if required fields are missing or invalid
    """
    import uuid
    from datetime import datetime
    
    # Validate required fields
    if not card_data:
        raise HTTPException(status_code=400, detail="Request body is required")
    
    # Title is required (can be in root or metadata)
    title = card_data.get("title") or card_data.get("metadata", {}).get("title")
    if not title or not isinstance(title, str) or not title.strip():
        raise HTTPException(
            status_code=422, 
            detail="'title' field is required and must be a non-empty string"
        )
    
    # Validate mc_score if provided
    if "mc_score" in card_data:
        mc_score = card_data["mc_score"]
        if not isinstance(mc_score, (int, float)) or mc_score < 0 or mc_score > 10:
            raise HTTPException(
                status_code=422,
                detail="'mc_score' must be a number between 0 and 10"
            )
    
    # Generate a proper Greenfield card ID if not provided in metadata
    canonical_id = card_data.get("metadata", {}).get("card_id")
    if not canonical_id:
        # Generate a Greenfield-style ID based on type
        card_type = card_data.get("metadata", {}).get("type", "lego_block")
        # Support new card types: workflow, delta, new
        if card_type == "lego_block":
            prefix = "CARD-V6B-P1-LEGO"
        elif card_type == "workflow":
            prefix = "CARD-V6B-P1-WORKFLOW"
        elif card_type == "delta":
            prefix = "CARD-V6B-P1-DELTA"
        elif card_type == "new":
            prefix = "CARD-V6B-P1-NEW"
        elif card_type == "agent":
            prefix = "CARD-V6B-P1-AGENT"
        elif card_type == "core_system":
            prefix = "CARD-V6B-P1-COMP"
        elif card_type == "doctrine":
            prefix = "CARD-V6B-P0"
        else:
            prefix = "CARD-V6B-P1-LEGO"
        
        # Use a short hash of the title for uniqueness
        title_hash = str(abs(hash(card_data.get("title", ""))))[:6].upper()
        canonical_id = f"{prefix}-{title_hash}"
    
    # Default status based on type
    # New cards (workflow, delta, new) go to review_queue
    card_type = card_data.get("metadata", {}).get("type", "lego_block")
    default_status = "not_started"
    if card_type in ["workflow", "delta", "new"]:
        default_status = "review_queue"
    elif card_type == "doctrine":
        default_status = "done"
    
    # Create card object
    now = datetime.now().isoformat() + "Z"
    new_card = {
        "card_id": canonical_id,
        "id": canonical_id,
        "title": card_data.get("title", "Untitled Card"),
        "type": card_data.get("metadata", {}).get("type", "lego_block"),
        "card_type": card_data.get("metadata", {}).get("type", "lego_block"),
        "mc_score": card_data.get("mc_score", 8.0),
        "mc": {"score": card_data.get("mc_score", 8.0), "gate": 8.50},
        "mc_gate": 8.50,
        "status": default_status,
        "lifecycle_state": default_status,
        "dependencies": card_data.get("dependencies", []),
        "blocking_dependencies": card_data.get("blocking_dependencies", []),
        "metadata": {
            **card_data.get("metadata", {}),
            "card_id": canonical_id,
            "content": card_data.get("content", "")
        },
        "content": card_data.get("content", ""),
        "created_at": now,
        "updated_at": now,
        "last_activity": now
    }
    
    # Add agent-specific fields if present
    if card_data.get("metadata", {}).get("soul_ref"):
        new_card["soul_ref"] = card_data["metadata"]["soul_ref"]
        new_card["soulRef"] = card_data["metadata"]["soul_ref"]
    if card_data.get("metadata", {}).get("obsession"):
        new_card["obsession"] = card_data["metadata"]["obsession"]
    if card_data.get("metadata", {}).get("stays_out_of"):
        new_card["stays_out_of"] = card_data["metadata"]["stays_out_of"]
        new_card["staysOutOf"] = card_data["metadata"]["stays_out_of"]
    
    # Store the card
    CREATED_CARDS.append(new_card)
    
    return new_card


@app.get("/api/v1/cards")
async def get_cards(project: Optional[str] = None):
    """Get cards endpoint.
    
    Args:
        project: Optional project filter (e.g., 'v6_greenfield')
    
    Returns:
        List of cards (MOCK_CARDS + CREATED_CARDS)
    """
    # Combine mock cards and created cards
    all_cards = MOCK_CARDS + CREATED_CARDS
    
    if project == "v6_greenfield":
        return {"cards": all_cards}
    return {"cards": all_cards}


@app.get("/api/v1/cards/{card_id}")
async def get_card(card_id: str):
    """Get a specific card by ID.
    
    Args:
        card_id: Card ID to look up
    
    Returns:
        Card object if found, 404 if not found
    """
    # Search in both MOCK_CARDS and CREATED_CARDS
    all_cards = MOCK_CARDS + CREATED_CARDS
    
    # Try to find by card_id or id
    for card in all_cards:
        if card.get("card_id") == card_id or card.get("id") == card_id:
            return card
    
    # If not found, return 404
    raise HTTPException(status_code=404, detail=f"Card not found: {card_id}")


@app.get("/api/v1/cards/{card_id}/mc-status")
async def get_card_mc_status(card_id: str):
    """Get MC status for a specific card.
    
    Args:
        card_id: Card ID to look up
    
    Returns:
        MC status object with mc_score, mc_gate, mc_bins, etc.
    """
    # Search for the card
    all_cards = MOCK_CARDS + CREATED_CARDS
    card = None
    
    for c in all_cards:
        if c.get("card_id") == card_id or c.get("id") == card_id:
            card = c
            break
    
    if not card:
        raise HTTPException(status_code=404, detail=f"Card not found: {card_id}")
    
    # Extract MC data from card
    mc_score = card.get("mc_score", 8.0)
    mc_gate = card.get("mc_gate", 8.5)
    metadata = card.get("metadata", {})
    mc_bins = metadata.get("mc_bins", generate_mc_bins(mc_score))
    
    # Determine gate result
    gate_result = "pass" if mc_score >= mc_gate else "hold"
    
    # Determine confidence label
    if mc_score >= 8.5:
        confidence_label = "high_confidence"
    elif mc_score >= 7.0:
        confidence_label = "needs_review"
    else:
        confidence_label = "low_confidence"
    
    return {
        "card_id": card_id,
        "mc_score": mc_score,
        "mc_gate": mc_gate,
        "mc_bins": mc_bins,
        "gate_result": gate_result,
        "confidence_label": confidence_label,
        "sentinel_status": "clear",
        "status": "ok",
        "message": f"MC status for {card_id}"
    }


@app.get("/api/v1/agents")
async def get_agents():
    """Get agents endpoint.
    
    Returns:
        List of agent identities
    """
    agents = [
        {
            "agent_id": "caretaker",
            "id": "caretaker",
            "name": "Caretaker",
            "title": "Guardian of Stewardship",
            "obsession": "Strategic decision-making",
            "stays_out_of": "Implementation details",
            "staysOutOf": "Implementation details",
            "soul_ref": "CARD-V6B-P0-AGENT-SOUL",
            "soulRef": "CARD-V6B-P0-AGENT-SOUL",
            "implementation_card_id": "CARD-V6B-P1-AGENT-CARETAKER",
            "card_id": "CARD-V6B-P1-AGENT-CARETAKER",
            "metadata": {}
        },
        {
            "agent_id": "gardener",
            "id": "gardener",
            "name": "Gardener",
            "title": "Card Structuring Agent",
            "obsession": "Card organization",
            "stays_out_of": "Business logic",
            "staysOutOf": "Business logic",
            "soul_ref": "CARD-V6B-P0-AGENT-SOUL",
            "soulRef": "CARD-V6B-P0-AGENT-SOUL",
            "implementation_card_id": "CARD-V6B-P1-AGENT-GARDENER",
            "card_id": "CARD-V6B-P1-AGENT-GARDENER",
            "metadata": {}
        },
        {
            "agent_id": "mercury",
            "id": "mercury",
            "name": "Mercury",
            "title": "Memory Routing Agent",
            "obsession": "Memory coordination",
            "stays_out_of": "Content creation",
            "staysOutOf": "Content creation",
            "soul_ref": "CARD-V6B-P0-AGENT-SOUL",
            "soulRef": "CARD-V6B-P0-AGENT-SOUL",
            "implementation_card_id": "CARD-V6B-P1-AGENT-MERCURY",
            "card_id": "CARD-V6B-P1-AGENT-MERCURY",
            "metadata": {}
        },
        {
            "agent_id": "sentinel",
            "id": "sentinel",
            "name": "Sentinel",
            "title": "Policy Violation Auditor",
            "obsession": "Security and compliance",
            "stays_out_of": "Feature implementation",
            "staysOutOf": "Feature implementation",
            "soul_ref": "CARD-V6B-P0-AGENT-SOUL",
            "soulRef": "CARD-V6B-P0-AGENT-SOUL",
            "implementation_card_id": "CARD-V6B-P1-AGENT-SENTINEL",
            "card_id": "CARD-V6B-P1-AGENT-SENTINEL",
            "metadata": {}
        },
        {
            "agent_id": "conductor",
            "id": "conductor",
            "name": "Conductor",
            "title": "Workflow Orchestration Agent",
            "obsession": "Workflow coordination",
            "stays_out_of": "Individual task execution",
            "staysOutOf": "Individual task execution",
            "soul_ref": "CARD-V6B-P0-AGENT-SOUL",
            "soulRef": "CARD-V6B-P0-AGENT-SOUL",
            "implementation_card_id": "CARD-V6B-P1-AGENT-CONDUCTOR",
            "card_id": "CARD-V6B-P1-AGENT-CONDUCTOR",
            "metadata": {}
        },
        {
            "agent_id": "scribe",
            "id": "scribe",
            "name": "Scribe",
            "title": "Ledger Persistence Agent",
            "obsession": "Audit trails",
            "stays_out_of": "Decision making",
            "staysOutOf": "Decision making",
            "soul_ref": "CARD-V6B-P0-AGENT-SOUL",
            "soulRef": "CARD-V6B-P0-AGENT-SOUL",
            "implementation_card_id": "CARD-V6B-P1-AGENT-SCRIBE",
            "card_id": "CARD-V6B-P1-AGENT-SCRIBE",
            "metadata": {}
        }
    ]
    return {"agents": agents}


@app.get("/api/v1/assembly-line/ledger")
async def get_assembly_line_ledger():
    """Get assembly line processing history.
    
    Returns:
        Processing history for cards
    """
    return {
        "history": [],
        "ledger": []
    }


@app.post("/api/v1/telemetry")
async def post_telemetry(event: Dict[str, Any]):
    """Post telemetry event endpoint.
    
    Args:
        event: Telemetry event data (JSON body)
    
    Returns:
        Success response
    """
    # Get log file path (use same logs_dir as configured at startup)
    log_file = logs_dir / "telemetry.ndjson"
    
    # Ensure logs directory exists
    log_file.parent.mkdir(parents=True, exist_ok=True)
    
    try:
        # Add timestamp if not present
        if "timestamp" not in event:
            event["timestamp"] = datetime.now().isoformat()
        
        # Add event_id if not present
        if "event_id" not in event:
            event["event_id"] = f"event_{int(datetime.now().timestamp() * 1000)}"
        
        # Write NDJSON line (one JSON object per line)
        with open(log_file, "a", encoding="utf-8") as f:
            json_line = json.dumps(event, ensure_ascii=False)
            f.write(json_line + "\n")
        
        logger.info(f"Telemetry event recorded: {event.get('event_id')} - {event.get('event_type', 'unknown')}")
        return {"status": "success", "event_id": event.get("event_id")}
    except Exception as e:
        logger.error(f"Error writing telemetry event: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to write telemetry event: {str(e)}")


# Chat router - try to import and use real router, fallback to stub if import fails
try:
    # Import as backend.routers.chat (relative to greenfield directory)
    import backend.routers.chat as chat_module
    chat_router = chat_module.router
    app.include_router(chat_router)
    logger.info("✅ Chat router wired up successfully")
except Exception as e:
    logger.warning(f"⚠️  Chat router import failed: {e}")
    logger.info("   Using stub chat endpoint")
    import traceback
    traceback.print_exc()
    
    @app.post("/api/v1/chat")
    async def chat_endpoint_stub(request: Dict[str, Any]):
        """Stub chat endpoint (real router not available)."""
        message = request.get("message", "")
        return {
            "type": "chat_response",
            "result": {
                "message": f"Chat router not available. Message received: '{message}'",
                "note": f"Import error: {str(e)}. Check that backend dependencies are installed."
            }
        }


@app.get("/api/v1/cards/review-queue")
async def get_review_queue():
    """Get cards in review queue.
    
    Returns cards that need categorization and placement.
    """
    all_cards = MOCK_CARDS + CREATED_CARDS
    review_queue = [card for card in all_cards if card.get("status") == "review_queue"]
    return {"cards": review_queue, "count": len(review_queue)}


@app.post("/api/v1/cards/{card_id}/categorize")
async def categorize_card(card_id: str, category_data: Dict[str, Any]):
    """Categorize a card in review queue.
    
    Moves card from review_queue to categorized status and assigns category.
    
    Args:
        card_id: Card ID to categorize
        category_data: { "category": "workflow" | "delta" | "lego_block" | ... }
    
    Returns:
        Updated card object
    """
    # Find card in CREATED_CARDS or MOCK_CARDS
    card = None
    card_list = None
    
    for c in CREATED_CARDS:
        if c.get("card_id") == card_id or c.get("id") == card_id:
            card = c
            card_list = CREATED_CARDS
            break
    
    if not card:
        for c in MOCK_CARDS:
            if c.get("card_id") == card_id or c.get("id") == card_id:
                card = c
                card_list = MOCK_CARDS
                break
    
    if not card:
        raise HTTPException(status_code=404, detail=f"Card {card_id} not found")
    
    if card.get("status") != "review_queue":
        raise HTTPException(
            status_code=400, 
            detail=f"Card {card_id} is not in review queue (current status: {card.get('status')})"
        )
    
    category = category_data.get("category")
    if not category:
        raise HTTPException(status_code=400, detail="'category' field is required")
    
    # Update card
    card["type"] = category
    card["card_type"] = category
    card["status"] = "categorized"
    card["lifecycle_state"] = "categorized"
    
    return card


@app.post("/api/v1/cards/{card_id}/improve")
async def improve_card(card_id: str, improvement_data: Dict[str, Any]):
    """Start improvement discussion for a card.
    
    Tracks understanding improvements separate from MC score.
    
    Args:
        card_id: Card ID to improve
        improvement_data: { "discussion": str, "understanding_improvements": [...] }
    
    Returns:
        Improvement record
    """
    # Find card
    card = None
    for c in CREATED_CARDS + MOCK_CARDS:
        if c.get("card_id") == card_id or c.get("id") == card_id:
            card = c
            break
    
    if not card:
        raise HTTPException(status_code=404, detail=f"Card {card_id} not found")
    
    # Initialize improvement tracking if not exists
    if "improvement_discussions" not in card.get("metadata", {}):
        if "metadata" not in card:
            card["metadata"] = {}
        card["metadata"]["improvement_discussions"] = []
    
    if "understanding_score" not in card.get("metadata", {}):
        card["metadata"]["understanding_score"] = card.get("mc_score", 0) / 10.0
    
    # Add improvement discussion
    improvement = {
        "timestamp": datetime.now().isoformat(),
        "discussion": improvement_data.get("discussion", ""),
        "understanding_improvements": improvement_data.get("understanding_improvements", []),
        "user_id": improvement_data.get("user_id", "anonymous")
    }
    
    card["metadata"]["improvement_discussions"].append(improvement)
    
    # Update understanding score (can improve over time)
    understanding_score = card["metadata"].get("understanding_score", 0.75)
    # Simple improvement: add 0.05 per discussion (capped at 1.0)
    card["metadata"]["understanding_score"] = min(1.0, understanding_score + 0.05)
    
    return {
        "card_id": card_id,
        "improvement": improvement,
        "understanding_score": card["metadata"]["understanding_score"]
    }


@app.get("/api/v1/cards/{card_id}/improvements")
async def get_card_improvements(card_id: str):
    """Get improvement history for a card.
    
    Returns understanding score and improvement discussions.
    """
    # Find card
    card = None
    for c in CREATED_CARDS + MOCK_CARDS:
        if c.get("card_id") == card_id or c.get("id") == card_id:
            card = c
            break
    
    if not card:
        raise HTTPException(status_code=404, detail=f"Card {card_id} not found")
    
    metadata = card.get("metadata", {})
    return {
        "card_id": card_id,
        "understanding_score": metadata.get("understanding_score", card.get("mc_score", 0) / 10.0),
        "improvement_discussions": metadata.get("improvement_discussions", []),
        "mc_score": card.get("mc_score", 0),
        "mc_gate": card.get("mc_gate", 8.5)
    }


@app.get("/api/v1/cards/{card_id}/improvement-analysis")
async def get_improvement_analysis(card_id: str):
    """Get structured improvement analysis for a card.
    
    Returns detailed analysis with MC bin breakdown, unclear items, agent recommendations, etc.
    """
    # Find card
    all_cards = CREATED_CARDS + MOCK_CARDS
    card = None
    for c in all_cards:
        if c.get("card_id") == card_id or c.get("id") == card_id:
            card = c
            break
    
    if not card:
        raise HTTPException(status_code=404, detail=f"Card {card_id} not found")
    
    # Get improvement analyzer
    try:
        from services.improvement_analyzer import get_improvement_analyzer
        analyzer = get_improvement_analyzer()
        analysis = analyzer.analyze_card(card, all_cards)
        return analysis
    except ImportError:
        # Fallback if analyzer not available
        raise HTTPException(
            status_code=503,
            detail="Improvement analyzer service not available"
        )


@app.get("/api/v1/logs/greenfield")
async def get_logs(project: Optional[str] = None, type: Optional[str] = None, range: Optional[str] = None):
    """Get run log events.
    
    Args:
        project: Project filter (defaults to 'v6_greenfield')
        type: Event type filter
        range: Time range filter (e.g., '24h', '7d', '30d')
    
    Returns:
        List of log events from telemetry.ndjson file
    """
    events_list = []
    
    # Default project to v6_greenfield (normalize to lowercase)
    project_filter = (project or "v6_greenfield").lower()
    
    # Get log file path (use same logs_dir as configured at startup)
    log_file = logs_dir / "telemetry.ndjson"
    
    if not log_file.exists():
        return {"events": [], "logs": []}
    
    try:
        # Calculate time range filter
        cutoff_time = None
        if range:
            now = datetime.now()
            range_lower = range.lower()
            if range_lower == "24h" or range_lower == "1d":
                cutoff_time = now - timedelta(hours=24)
            elif range_lower == "7d":
                cutoff_time = now - timedelta(days=7)
            elif range_lower == "30d":
                cutoff_time = now - timedelta(days=30)
        
        # Read events from NDJSON file
        with open(log_file, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                
                try:
                    event = json.loads(line)
                    
                    # Filter by project (case-insensitive)
                    event_project = event.get("project_id", "").lower()
                    if project_filter and event_project != project_filter:
                        continue
                    
                    # Filter by event type (case-insensitive)
                    if type:
                        event_type = event.get("event_type", "").lower()
                        if event_type != type.lower():
                            continue
                    
                    # Filter by time range
                    if cutoff_time:
                        event_timestamp_str = event.get("timestamp")
                        if event_timestamp_str:
                            try:
                                event_time = datetime.fromisoformat(event_timestamp_str.replace("Z", "+00:00"))
                                if event_time < cutoff_time:
                                    continue
                            except (ValueError, AttributeError):
                                pass  # Skip if timestamp parsing fails
                    
                    # Transform to RunLogEvent format
                    run_log_event = {
                        "id": event.get("event_id", f"event_{hash(line)}"),
                        "type": event.get("event_type", "unknown"),
                        "timestamp": event.get("timestamp", ""),
                        "card_id": event.get("cardId") or event.get("card_id"),
                        "agent_id": event.get("agent_id"),
                        "description": f"{event.get('event_type', 'event')} - {event.get('cardId', 'N/A')}",
                        "metadata": {k: v for k, v in event.items() if k not in ["event_id", "event_type", "timestamp", "cardId", "card_id", "agent_id"]}
                    }
                    
                    events_list.append(run_log_event)
                    
                except json.JSONDecodeError:
                    continue  # Skip invalid JSON lines
        
        # Sort by timestamp (newest first)
        events_list.sort(key=lambda x: x.get("timestamp", ""), reverse=True)
        
        # Limit to 1000 events
        events_list = events_list[:1000]
        
    except Exception as e:
        logger.error(f"Error reading log file: {e}")
        return {"events": [], "logs": []}
    
    return {
        "events": events_list,
        "logs": events_list  # Alias for compatibility
    }


if __name__ == "__main__":
    import uvicorn
    print("🚀 Starting Greenfield Backend Test Server on http://localhost:8000")
    print("📚 API docs available at http://localhost:8000/docs")
    uvicorn.run("test_server:app", host="0.0.0.0", port=8000, reload=True)

