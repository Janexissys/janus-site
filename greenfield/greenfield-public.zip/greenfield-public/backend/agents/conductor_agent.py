# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Conductor Agent - Workflow orchestration.

The Conductor Agent is responsible for orchestrating workflows and coordinating
agent activities at a sustainable, human-compatible pace. It manages timing and
flow without controlling, protecting human focus and decision points from runaway
automation.

**Card**: CARD-V6B-P1-AGENT-CONDUCTOR  
**Soul Reference**: CARD-V6B-P0-AGENT-SOUL (Keeper of Rhythm)  
**MC Target**: 8.50  
**Dependencies**: None (foundational agent)

**Identity**: Keeper of Rhythm - Coordinates workflow without controlling. Keeps
agents moving together at a sustainable, human-compatible pace and manages
timing and flow. Protects human focus and decision points from runaway automation.

**Key Responsibilities**:
- Create and manage workflows with multiple steps
- Execute workflows sequentially at a controlled pace
- Detect PII in workflow state and metadata
- Maintain audit logs of all workflow operations
- Track workflow success and failure rates

**Sentinel Compliance**:
- PII Detection: Scans workflow state and metadata for PII patterns
- Data Validation: Validates workflow creation and execution inputs
- Audit Logging: Logs all workflow operations with context

**Example Usage**:
    ```python
    from agents.conductor_agent import ConductorAgent
    
    agent = ConductorAgent()
    workflow = agent.create_workflow(
        name="Process document",
        steps=["validate", "process", "store"],
        metadata={"priority": "high"}
    )
    result = agent.execute_workflow(workflow.workflow_id)
    print(f"Workflow status: {result.status.value}")
    ```
"""

import logging
import re
import time
import uuid
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional

from utils.exceptions import ValidationError

logger = logging.getLogger(__name__)


class WorkflowStatus(Enum):
    """Workflow status.
    
    Attributes:
        PENDING: Workflow created but not yet started.
        RUNNING: Workflow is currently executing.
        COMPLETED: Workflow completed successfully.
        FAILED: Workflow execution failed.
        CANCELLED: Workflow was cancelled before completion.
    """
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class WorkflowStep:
    """Workflow step.
    
    Attributes:
        step_id: Unique identifier for the step.
        step_name: Human-readable name of the step.
        status: Current status of the step (PENDING, RUNNING, COMPLETED, FAILED).
        started_at: Timestamp when step execution started (None if not started).
        completed_at: Timestamp when step execution completed (None if not completed).
        error: Error message if step failed (None if successful).
    """
    step_id: str
    step_name: str
    status: WorkflowStatus
    started_at: Optional[float] = None
    completed_at: Optional[float] = None
    error: Optional[str] = None


@dataclass
class Workflow:
    """Workflow definition.
    
    Attributes:
        workflow_id: Unique identifier for the workflow.
        name: Human-readable name of the workflow.
        steps: List of WorkflowStep objects in execution order.
        status: Current status of the workflow (PENDING, RUNNING, COMPLETED, FAILED).
        created_at: Timestamp when the workflow was created.
        metadata: Dictionary of workflow metadata (priority, tags, etc.).
    """
    workflow_id: str
    name: str
    steps: List[WorkflowStep]
    status: WorkflowStatus
    created_at: float
    metadata: Dict[str, Any]


class ConductorAgent:
    """Conductor Agent provides workflow orchestration.
    
    The Conductor Agent orchestrates workflows by creating, managing, and executing
    multi-step processes. It coordinates agent activities at a sustainable pace,
    protecting human focus and decision points from runaway automation. Workflows
    are executed sequentially with proper error handling and audit logging.
    
    Attributes:
        PII_PATTERNS: Dictionary of regex patterns for PII detection.
            Keys are PII types (email, phone, ssn), values are regex patterns.
    """
    
    # PII patterns (SENTINEL: PII Detection)
    PII_PATTERNS: Dict[str, str] = {
        "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        "phone": r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
        "ssn": r'\b\d{3}-\d{2}-\d{4}\b',
    }
    
    def __init__(self) -> None:
        """Initialize Conductor Agent.
        
        Sets up internal counters, audit log, and workflow storage for tracking
        workflow operations.
        """
        self._workflow_count: int = 0
        self._completed_workflows: int = 0
        self._failed_workflows: int = 0
        self._pii_detections: int = 0
        self._audit_log: List[Dict[str, Any]] = []
        self._workflows: Dict[str, Workflow] = {}
    
    def create_workflow(
        self,
        name: str,
        steps: List[str],
        metadata: Optional[Dict[str, Any]] = None
    ) -> Workflow:
        """Create a new workflow.
        
        Creates a new workflow with the specified name, steps, and optional metadata.
        Performs PII detection on workflow data and audit logging. All steps are
        initialized with PENDING status.
        
        Args:
            name: Workflow name (must be non-empty string).
            steps: List of step names in execution order (must be non-empty list).
            metadata: Optional dictionary of workflow metadata (priority, tags, etc.).
        
        Returns:
            Workflow object with:
            - workflow_id: Unique identifier for the workflow
            - name: Workflow name
            - steps: List of WorkflowStep objects (all PENDING)
            - status: WorkflowStatus.PENDING
            - created_at: Timestamp of creation
            - metadata: Provided metadata dictionary
        
        Raises:
            ValidationError: If name is not a non-empty string, or steps is not
                a non-empty list.
        
        Example:
            ```python
            agent = ConductorAgent()
            workflow = agent.create_workflow(
                name="Process document",
                steps=["validate", "process", "store"],
                metadata={"priority": "high"}
            )
            assert workflow.status == WorkflowStatus.PENDING
            assert len(workflow.steps) == 3
            ```
        """
        # SENTINEL: Data Validation
        if not isinstance(name, str) or not name.strip():
            raise ValidationError(
                "Conductor: Validate workflow creation - name must be a non-empty string",
                component="ConductorAgent",
                context={"operation": "create_workflow", "name_type": type(name).__name__}
            )
        
        if not isinstance(steps, list) or len(steps) == 0:
            raise ValidationError(
                "Conductor: Validate workflow creation - steps must be a non-empty list",
                component="ConductorAgent",
                context={"operation": "create_workflow", "name": name, "steps_type": type(steps).__name__, "steps_count": len(steps) if isinstance(steps, list) else 0}
            )
        
        # SENTINEL: PII Detection - Workflow state session data leakage
        workflow_str = f"{name} {str(steps)} {str(metadata or {})}"
        pii_detected = self._detect_pii(workflow_str)
        if pii_detected:
            self._pii_detections += 1
            logger.warning("PII detected in workflow - proceeding with caution")
        
        workflow_id = str(uuid.uuid4())
        workflow_steps = [
            WorkflowStep(
                step_id=str(uuid.uuid4()),
                step_name=step,
                status=WorkflowStatus.PENDING
            )
            for step in steps
        ]
        
        workflow = Workflow(
            workflow_id=workflow_id,
            name=name,
            steps=workflow_steps,
            status=WorkflowStatus.PENDING,
            created_at=time.time(),
            metadata=metadata or {}
        )
        
        self._workflows[workflow_id] = workflow
        self._workflow_count += 1
        
        # SENTINEL: Audit Logging
        self._log_audit("create_workflow", workflow_id, workflow, pii_detected)
        
        return workflow
    
    def execute_workflow(self, workflow_id: str) -> Workflow:
        """Execute a workflow.
        
        Executes a workflow by running all steps sequentially. Updates workflow
        and step statuses as execution progresses. If any step fails, the workflow
        is marked as FAILED and execution stops. Performs audit logging on completion.
        
        Args:
            workflow_id: Unique identifier of the workflow to execute.
        
        Returns:
            Updated Workflow object with:
            - status: WorkflowStatus.COMPLETED or WorkflowStatus.FAILED
            - steps: Updated with execution timestamps and statuses
        
        Raises:
            ValidationError: If workflow_id is not found.
            Exception: If workflow execution fails (workflow marked as FAILED).
        
        Example:
            ```python
            agent = ConductorAgent()
            workflow = agent.create_workflow(
                name="Process document",
                steps=["validate", "process"]
            )
            result = agent.execute_workflow(workflow.workflow_id)
            assert result.status == WorkflowStatus.COMPLETED
            ```
        """
        # SENTINEL: Data Validation
        if workflow_id not in self._workflows:
            raise ValidationError(
                f"Conductor: Execute workflow - workflow not found: {workflow_id}",
                component="ConductorAgent",
                context={"operation": "execute_workflow", "workflow_id": workflow_id}
            )
        
        workflow = self._workflows[workflow_id]
        workflow.status = WorkflowStatus.RUNNING
        
        try:
            # Execute steps sequentially
            for step in workflow.steps:
                step.status = WorkflowStatus.RUNNING
                step.started_at = time.time()
                
                # Simulate step execution (in production, this would call actual step handlers)
                # For greenfield, just mark as completed
                step.status = WorkflowStatus.COMPLETED
                step.completed_at = time.time()
            
            workflow.status = WorkflowStatus.COMPLETED
            self._completed_workflows += 1
            
            # SENTINEL: Audit Logging
            self._log_audit("execute_workflow", workflow_id, workflow, False)
            
        except ValidationError:
            # Re-raise validation errors as-is
            raise
        except Exception as e:
            workflow.status = WorkflowStatus.FAILED
            self._failed_workflows += 1
            
            # Mark current step as failed
            for step in workflow.steps:
                if step.status == WorkflowStatus.RUNNING:
                    step.status = WorkflowStatus.FAILED
                    step.error = str(e)
                    break
            
            logger.error(f"Workflow execution failed: {workflow_id} - {e}")
            raise
        
        return workflow
    
    def get_workflow(self, workflow_id: str) -> Workflow:
        """Get workflow by ID.
        
        Retrieves a workflow by its unique identifier.
        
        Args:
            workflow_id: Unique identifier of the workflow to retrieve.
        
        Returns:
            Workflow object with current status and step information.
        
        Raises:
            ValidationError: If workflow_id is not found.
        """
        if workflow_id not in self._workflows:
            raise ValidationError(
                f"Conductor: Get workflow - workflow not found: {workflow_id}",
                component="ConductorAgent",
                context={"operation": "get_workflow", "workflow_id": workflow_id}
            )
        
        return self._workflows[workflow_id]
    
    def _detect_pii(self, text: str) -> bool:
        """Detect PII in text.
        
        Scans text for PII patterns including email addresses, phone numbers,
        and SSNs. This is a Sentinel compliance check for PII detection.
        
        Args:
            text: Text string to scan for PII.
        
        Returns:
            True if any PII pattern is detected, False otherwise.
        """
        text_lower = text.lower()
        
        for pii_type, pattern in self.PII_PATTERNS.items():
            if re.search(pattern, text_lower, re.IGNORECASE):
                logger.warning(f"PII detected in workflow: {pii_type}")
                return True
        
        return False
    
    def _log_audit(
        self,
        operation: str,
        workflow_id: str,
        workflow: Workflow,
        pii_detected: bool
    ) -> None:
        """Log audit operation.
        
        Creates an audit log entry for the workflow operation. This is a Sentinel
        compliance check for audit logging.
        
        Args:
            operation: Name of the operation (e.g., "create_workflow", "execute_workflow").
            workflow_id: Unique identifier of the workflow.
            workflow: Workflow object containing workflow details.
            pii_detected: Boolean indicating if PII was detected in workflow data.
        """
        audit_entry = {
            "operation": operation,
            "workflow_id": workflow_id,
            "timestamp": time.time(),
            "workflow_name": workflow.name,
            "status": workflow.status.value,
            "step_count": len(workflow.steps),
            "pii_detected": pii_detected
        }
        
        self._audit_log.append(audit_entry)
        logger.info(f"Conductor {operation}: {workflow_id} - {workflow.name} ({workflow.status.value})")
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get agent statistics.
        
        Returns comprehensive statistics about workflow operations performed
        by the agent.
        
        Returns:
            Dictionary containing:
            - total_workflows: Total number of workflows created
            - completed_workflows: Number of successfully completed workflows
            - failed_workflows: Number of failed workflows
            - pii_detections: Number of times PII was detected
            - success_rate: Ratio of completed workflows to total workflows
        """
        return {
            "total_workflows": self._workflow_count,
            "completed_workflows": self._completed_workflows,
            "failed_workflows": self._failed_workflows,
            "pii_detections": self._pii_detections,
            "success_rate": (
                self._completed_workflows / self._workflow_count 
                if self._workflow_count > 0 else 0.0
            )
        }
    
    def get_health(self) -> Dict[str, Any]:
        """Get agent health status.
        
        Returns health status based on workflow failure rate and operational metrics.
        Health is considered degraded if failure rate exceeds 20%.
        
        Returns:
            Dictionary containing:
            - status: Health status ("healthy" or "degraded")
            - message: Human-readable status message
            - statistics: Full statistics dictionary from get_statistics()
        """
        stats = self.get_statistics()
        
        # Health is degraded if failure rate is high
        failure_rate = (
            self._failed_workflows / self._workflow_count 
            if self._workflow_count > 0 else 0.0
        )
        
        if failure_rate > 0.2:  # >20% failure rate
            status = "degraded"
            message = f"High workflow failure rate: {failure_rate:.1%}"
        else:
            status = "healthy"
            message = "Conductor agent operational"
        
        return {
            "status": status,
            "message": message,
            "statistics": stats
        }

