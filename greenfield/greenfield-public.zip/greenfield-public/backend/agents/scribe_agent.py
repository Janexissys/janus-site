# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Scribe Agent - Ledger entry persistence.

The Scribe Agent is responsible for persisting ledger entries that record system
activity. It acts as a witness and translator, recording what happened, aggregating
insights, and surfacing digestible summaries to the dashboard. It translates system
activity into human-readable narratives, ensuring no black box.

**Card**: CARD-V6B-P1-AGENT-SCRIBE  
**Soul Reference**: CARD-V6B-P0-AGENT-SOUL (Witness and Translator)  
**MC Target**: 8.55  
**Dependencies**: None (foundational agent)

**Identity**: Witness and Translator - Records what happened, aggregates insights,
and surfaces digestible summaries to the dashboard, translating system activity
into human-readable narratives. Ensures no black box.

**Key Responsibilities**:
- Persist ledger entries with entry types and data
- Retrieve ledger entries by ID or type
- Detect PII in ledger entry data
- Maintain audit logs of all persistence operations
- Track persistence success and failure rates

**Sentinel Compliance**:
- PII Detection: Scans ledger entry data for PII patterns
- Data Validation: Validates entry type and data format
- Audit Logging: Logs all persistence operations with context

**Example Usage**:
    ```python
    from agents.scribe_agent import ScribeAgent
    
    agent = ScribeAgent()
    entry = agent.persist_entry(
        entry_type="agent_decision",
        data={"agent": "caretaker", "decision": "approve", "reason": "aligned"}
    )
    print(f"Entry persisted: {entry.entry_id}")
    
    # Retrieve entry
    retrieved = agent.get_entry(entry.entry_id)
    print(f"Entry type: {retrieved.entry_type}")
    ```
"""

import logging
import re
import time
import uuid
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from utils.exceptions import ValidationError

logger = logging.getLogger(__name__)


@dataclass
class LedgerEntry:
    """Ledger entry.
    
    Attributes:
        entry_id: Unique identifier for the ledger entry.
        entry_type: Type of entry (e.g., "agent_decision", "workflow_complete").
        data: Dictionary containing entry data.
        created_at: Timestamp when the entry was created.
        persisted: Boolean indicating if entry was successfully persisted.
        persistence_error: Error message if persistence failed (None if successful).
    """
    entry_id: str
    entry_type: str
    data: Dict[str, Any]
    created_at: float
    persisted: bool = False
    persistence_error: Optional[str] = None


class ScribeAgent:
    """Scribe Agent provides ledger entry persistence.
    
    The Scribe Agent persists ledger entries that record system activity for
    observability and audit purposes. It detects PII in entry data and maintains
    comprehensive audit logs. Entries can be retrieved by ID or filtered by type.
    
    Attributes:
        PII_PATTERNS: Dictionary of regex patterns for PII detection.
            Keys are PII types (email, phone, ssn), values are regex patterns.
    """
    
    # PII patterns (SENTINEL: PII Detection)
    PII_PATTERNS: Dict[str, str] = {
        "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        "phone": r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
        "ssn": r'\b\d{3}-\d{2}-\d{4}\b',
    }
    
    def __init__(self) -> None:
        """Initialize Scribe Agent.
        
        Sets up internal counters, audit log, and ledger storage for tracking
        persistence operations.
        """
        self._entry_count: int = 0
        self._persisted_count: int = 0
        self._failed_count: int = 0
        self._pii_detections: int = 0
        self._audit_log: List[Dict[str, Any]] = []
        self._ledger: Dict[str, LedgerEntry] = {}
    
    def persist_entry(
        self,
        entry_type: str,
        data: Dict[str, Any]
    ) -> LedgerEntry:
        """Persist a ledger entry.
        
        Creates and persists a ledger entry with the specified type and data.
        Performs PII detection on entry data and audit logging. In production,
        this would persist to a database or storage system; for greenfield, it
        stores entries in memory.
        
        Args:
            entry_type: Type of entry (e.g., "agent_decision", "workflow_complete")
                (must be non-empty string).
            data: Dictionary containing entry data (must be a dictionary).
        
        Returns:
            LedgerEntry object with:
            - entry_id: Unique identifier for the entry
            - entry_type: Provided entry type
            - data: Provided data dictionary
            - created_at: Timestamp of creation
            - persisted: Boolean indicating if persistence succeeded
            - persistence_error: Error message if persistence failed (None if successful)
        
        Raises:
            ValidationError: If entry_type is not a non-empty string, or data is
                not a dictionary.
            Exception: If persistence fails (entry marked with error).
        
        Example:
            ```python
            agent = ScribeAgent()
            entry = agent.persist_entry(
                entry_type="agent_decision",
                data={"agent": "caretaker", "decision": "approve"}
            )
            assert entry.persisted == True
            assert entry.entry_id is not None
            ```
        """
        # SENTINEL: Data Validation
        if not isinstance(entry_type, str) or not entry_type.strip():
            raise ValidationError(
                "Scribe: Validate ledger entry - entry_type must be a non-empty string",
                component="ScribeAgent",
                context={"operation": "persist_entry", "entry_type_type": type(entry_type).__name__}
            )
        
        if not isinstance(data, dict):
            raise ValidationError(
                "Scribe: Validate ledger entry - data must be a dictionary",
                component="ScribeAgent",
                context={"operation": "persist_entry", "entry_type": entry_type, "data_type": type(data).__name__}
            )
        
        # SENTINEL: PII Detection - Ledger entries PII
        data_str = str(data)
        pii_detected = self._detect_pii(data_str)
        if pii_detected:
            self._pii_detections += 1
            logger.warning("PII detected in ledger entry - proceeding with caution")
        
        entry_id = str(uuid.uuid4())
        entry = LedgerEntry(
            entry_id=entry_id,
            entry_type=entry_type,
            data=data,
            created_at=time.time()
        )
        
        # Attempt persistence (simplified for greenfield)
        try:
            # In production, this would persist to database/storage
            # For greenfield, just store in memory
            self._ledger[entry_id] = entry
            entry.persisted = True
            self._persisted_count += 1
            
            # SENTINEL: Audit Logging
            self._log_audit("persist_entry", entry_id, entry, pii_detected)
            
        except ValidationError:
            # Re-raise validation errors as-is
            raise
        except Exception as e:
            entry.persisted = False
            entry.persistence_error = str(e)
            self._failed_count += 1
            
            logger.error(f"Failed to persist ledger entry: {entry_id} - {e}")
            raise
        
        self._entry_count += 1
        
        return entry
    
    def get_entry(self, entry_id: str) -> LedgerEntry:
        """Get ledger entry by ID.
        
        Retrieves a ledger entry by its unique identifier.
        
        Args:
            entry_id: Unique identifier of the entry to retrieve.
        
        Returns:
            LedgerEntry object with entry data and persistence status.
        
        Raises:
            ValidationError: If entry_id is not found.
        """
        if entry_id not in self._ledger:
            raise ValidationError(
                f"Scribe: Get ledger entry - ledger entry not found: {entry_id}",
                component="ScribeAgent",
                context={"operation": "get_entry", "entry_id": entry_id}
            )
        
        return self._ledger[entry_id]
    
    def get_entries_by_type(self, entry_type: str) -> List[LedgerEntry]:
        """Get all entries of a specific type.
        
        Retrieves all ledger entries that match the specified entry type.
        
        Args:
            entry_type: Entry type to filter by (e.g., "agent_decision").
        
        Returns:
            List of LedgerEntry objects matching the entry type (empty list if none found).
        """
        return [
            entry for entry in self._ledger.values()
            if entry.entry_type == entry_type
        ]
    
    def _detect_pii(self, text: str) -> bool:
        """Detect PII in text.
        
        Scans text for PII patterns including email addresses, phone numbers,
        and SSNs. This is a Sentinel compliance check for PII detection.
        
        Args:
            text: Text string to scan for PII.
        
        Returns:
            True if any PII pattern is detected, False otherwise.
        """
        text_lower = text.lower()
        
        for pii_type, pattern in self.PII_PATTERNS.items():
            if re.search(pattern, text_lower, re.IGNORECASE):
                logger.warning(f"PII detected in ledger entry: {pii_type}")
                return True
        
        return False
    
    def _log_audit(
        self,
        operation: str,
        entry_id: str,
        entry: LedgerEntry,
        pii_detected: bool
    ) -> None:
        """Log audit operation.
        
        Creates an audit log entry for the persistence operation. This is a
        Sentinel compliance check for audit logging.
        
        Args:
            operation: Name of the operation (e.g., "persist_entry").
            entry_id: Unique identifier of the ledger entry.
            entry: LedgerEntry object containing entry details.
            pii_detected: Boolean indicating if PII was detected in entry data.
        """
        audit_entry = {
            "operation": operation,
            "entry_id": entry_id,
            "timestamp": entry.created_at,
            "entry_type": entry.entry_type,
            "persisted": entry.persisted,
            "pii_detected": pii_detected
        }
        
        self._audit_log.append(audit_entry)
        logger.info(f"Scribe {operation}: {entry_id} - {entry.entry_type} (persisted: {entry.persisted})")
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get agent statistics.
        
        Returns comprehensive statistics about persistence operations performed
        by the agent.
        
        Returns:
            Dictionary containing:
            - total_entries: Total number of entries created
            - persisted_entries: Number of successfully persisted entries
            - failed_entries: Number of failed persistence attempts
            - pii_detections: Number of times PII was detected
            - persistence_rate: Ratio of persisted entries to total entries
        """
        return {
            "total_entries": self._entry_count,
            "persisted_entries": self._persisted_count,
            "failed_entries": self._failed_count,
            "pii_detections": self._pii_detections,
            "persistence_rate": (
                self._persisted_count / self._entry_count 
                if self._entry_count > 0 else 0.0
            )
        }
    
    def get_health(self) -> Dict[str, Any]:
        """Get agent health status.
        
        Returns health status based on persistence failure rate and operational metrics.
        Health is considered degraded if failure rate exceeds 10%.
        
        Returns:
            Dictionary containing:
            - status: Health status ("healthy" or "degraded")
            - message: Human-readable status message
            - statistics: Full statistics dictionary from get_statistics()
        """
        stats = self.get_statistics()
        
        # Health is degraded if failure rate is high
        failure_rate = (
            self._failed_count / self._entry_count 
            if self._entry_count > 0 else 0.0
        )
        
        if failure_rate > 0.1:  # >10% failure rate
            status = "degraded"
            message = f"High persistence failure rate: {failure_rate:.1%}"
        else:
            status = "healthy"
            message = "Scribe agent operational"
        
        return {
            "status": status,
            "message": message,
            "statistics": stats
        }

