# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Sentinel Agent - Policy violation auditing.

The Sentinel Agent is responsible for auditing content for policy violations,
security threats, and compliance issues. It acts as the system's immune system,
guarding North Star alignment, privacy, and boundaries. It can block operations
even when everything else says "go."

**Card**: CARD-V6B-P1-AGENT-SENTINEL  
**Soul Reference**: CARD-V6B-P0-AGENT-SOUL (Protector of Truth)  
**MC Target**: 8.70  
**Dependencies**: None (foundational agent)

**Identity**: Protector of Truth - Guards North Star alignment, privacy, and
boundaries. Detects corruption and policy violations, acting as the system's
immune system. Can block even when everything else says "go."

**Key Responsibilities**:
- Audit content for PII, credentials, and sensitive data
- Detect security policy violations (SQL injection, XSS, path traversal)
- Generate audit reports with violation severity levels
- Maintain audit logs of all security checks
- Block operations when critical violations are detected

**Sentinel Compliance**:
- PII Detection: Scans content for PII patterns (email, phone, SSN, credit card, IP)
- Security: Detects credentials, sensitive data, and policy violations
- Data Validation: Validates input content
- Audit Logging: Logs all audit operations with context

**Example Usage**:
    ```python
    from agents.sentinel_agent import SentinelAgent
    
    agent = SentinelAgent()
    result = agent.audit_content(
        content="User email: john@example.com, password: secret123",
        context={"operation": "user_registration"}
    )
    print(f"Audit passed: {result.passed}")
    print(f"Violations: {len(result.violations)}")
    for violation in result.violations:
        print(f"  - {violation.rule_name.value}: {violation.notes}")
    ```
"""

import logging
import re
import time
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional

from utils.exceptions import ValidationError

logger = logging.getLogger(__name__)


class ViolationSeverity(Enum):
    """Policy violation severity levels.
    
    Attributes:
        OK: No violation detected.
        WARNING: Minor violation that should be reviewed.
        CRITICAL: Severe violation that blocks the operation.
    """
    OK = "ok"
    WARNING = "warning"
    CRITICAL = "critical"


class PolicyRule(Enum):
    """Policy rule identifiers.
    
    Attributes:
        PII_DETECTED: PII pattern detected in content (PII-001).
        CREDENTIALS_DETECTED: Credentials or sensitive keywords detected (SEC-001).
        SENSITIVE_DATA: Sensitive data patterns detected (SEC-002).
        POLICY_VIOLATION: Security policy violation pattern detected (POL-001).
        UNAUTHORIZED_ACCESS: Unauthorized access attempt (AUTH-001).
        DATA_LEAK: Potential data leak detected (SEC-003).
    """
    PII_DETECTED = "PII-001"
    CREDENTIALS_DETECTED = "SEC-001"
    SENSITIVE_DATA = "SEC-002"
    POLICY_VIOLATION = "POL-001"
    UNAUTHORIZED_ACCESS = "AUTH-001"
    DATA_LEAK = "SEC-003"


@dataclass
class PolicyViolation:
    """Policy violation audit result.
    
    Attributes:
        severity: Severity level of the violation (OK, WARNING, CRITICAL).
        rule_id: Rule identifier string (e.g., "PII-001").
        rule_name: PolicyRule enum value identifying the rule.
        notes: Human-readable description of the violation.
        detected_at: Timestamp when the violation was detected.
        context: Optional dictionary with additional context (position, type, etc.).
    """
    severity: ViolationSeverity
    rule_id: str
    rule_name: PolicyRule
    notes: str
    detected_at: float
    context: Optional[Dict[str, Any]] = None


@dataclass
class AuditResult:
    """Complete audit result.
    
    Attributes:
        violations: List of PolicyViolation objects detected during audit.
        passed: Boolean indicating if audit passed (no critical violations).
        audit_id: Unique identifier for this audit.
        audited_at: Timestamp when the audit was performed.
        summary: Human-readable summary of the audit results.
    """
    violations: List[PolicyViolation]
    passed: bool
    audit_id: str
    audited_at: float
    summary: str


class SentinelAgent:
    """Sentinel Agent provides policy violation auditing.
    
    The Sentinel Agent audits content for policy violations, security threats,
    and compliance issues. It performs multiple security checks including PII
    detection, credential detection, sensitive data detection, and policy violation
    pattern matching. It can block operations when critical violations are detected.
    
    Attributes:
        PII_PATTERNS: Dictionary of regex patterns for PII detection.
            Keys are PII types (email, phone, ssn, credit_card, ip_address),
            values are regex patterns.
        SENSITIVE_KEYWORDS: List of keywords that indicate potential credentials.
        POLICY_PATTERNS: Dictionary of security violation patterns.
            Keys are violation types (sql_injection, xss_pattern, path_traversal),
            values are regex patterns.
    """
    
    # PII patterns (SENTINEL: PII Detection)
    PII_PATTERNS: Dict[str, str] = {
        "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        "phone": r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
        "ssn": r'\b\d{3}-\d{2}-\d{4}\b',
        "credit_card": r'\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b',
        "ip_address": r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b',
    }
    
    # Sensitive keywords (SENTINEL: Security)
    SENSITIVE_KEYWORDS: List[str] = [
        "password", "secret", "key", "token", "credential", "api_key",
        "private_key", "access_token", "bearer_token", "auth_token"
    ]
    
    # Policy violation patterns
    POLICY_PATTERNS: Dict[str, str] = {
        "sql_injection": r"(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER)\b)",
        "xss_pattern": r"<script[^>]*>.*?</script>",
        "path_traversal": r"\.\./|\.\.\\",
    }
    
    def __init__(self) -> None:
        """Initialize Sentinel Agent.
        
        Sets up internal counters and audit log for tracking audit operations.
        """
        self._audit_count: int = 0
        self._violation_count: int = 0
        self._critical_violations: int = 0
        self._audit_log: List[Dict[str, Any]] = []
    
    def audit_content(
        self,
        content: str,
        context: Optional[Dict[str, Any]] = None
    ) -> AuditResult:
        """Audit content for policy violations.
        
        Performs comprehensive security audit of content, checking for:
        - PII patterns (email, phone, SSN, credit card, IP address)
        - Credentials and sensitive keywords
        - Sensitive data patterns (base64 encoded data)
        - Security policy violations (SQL injection, XSS, path traversal)
        
        Returns an AuditResult with all detected violations. Audit passes only
        if no critical violations are detected.
        
        Args:
            content: Content string to audit (must be a string).
            context: Optional dictionary with additional context (operation name, etc.).
        
        Returns:
            AuditResult containing:
            - violations: List of all detected PolicyViolation objects
            - passed: Boolean indicating if audit passed (no critical violations)
            - audit_id: Unique identifier for this audit
            - audited_at: Timestamp when audit was performed
            - summary: Human-readable summary of audit results
        
        Raises:
            ValidationError: If content is not a string.
        
        Example:
            ```python
            agent = SentinelAgent()
            result = agent.audit_content(
                content="User data: email@example.com",
                context={"operation": "user_registration"}
            )
            if not result.passed:
                print(f"Audit failed: {result.summary}")
                for violation in result.violations:
                    print(f"  - {violation.rule_name.value}: {violation.notes}")
            ```
        """
        # SENTINEL: Data Validation
        if not isinstance(content, str):
            raise ValidationError(
                "Sentinel: Validate audit content - content must be a string",
                component="SentinelAgent",
                context={"operation": "audit_content", "content_type": type(content).__name__}
            )
        
        audit_id = f"audit_{int(time.time() * 1000)}"
        violations: List[PolicyViolation] = []
        
        # SENTINEL: PII Detection
        pii_violations = self._detect_pii(content)
        violations.extend(pii_violations)
        
        # SENTINEL: Security - Credentials detection
        credential_violations = self._detect_credentials(content)
        violations.extend(credential_violations)
        
        # SENTINEL: Security - Sensitive data detection
        sensitive_violations = self._detect_sensitive_data(content)
        violations.extend(sensitive_violations)
        
        # SENTINEL: Security - Policy violation patterns
        policy_violations = self._detect_policy_violations(content)
        violations.extend(policy_violations)
        
        # Determine if audit passed
        critical_violations = [v for v in violations if v.severity == ViolationSeverity.CRITICAL]
        passed = len(critical_violations) == 0
        
        # Update statistics
        self._audit_count += 1
        if violations:
            self._violation_count += 1
        if critical_violations:
            self._critical_violations += 1
        
        # Generate summary
        summary = self._generate_summary(violations, passed)
        
        # Create audit result
        result = AuditResult(
            violations=violations,
            passed=passed,
            audit_id=audit_id,
            audited_at=time.time(),
            summary=summary
        )
        
        # SENTINEL: Audit Logging
        self._log_audit(audit_id, result, context)
        
        return result
    
    def _detect_pii(self, content: str) -> List[PolicyViolation]:
        """Detect PII in content.
        
        Scans content for PII patterns including email addresses, phone numbers,
        SSNs, credit card numbers, and IP addresses. This is a Sentinel compliance
        check for PII detection. Each detected PII pattern creates a CRITICAL
        severity violation.
        
        Args:
            content: Content string to scan for PII.
        
        Returns:
            List of PolicyViolation objects, one for each detected PII pattern.
        """
        violations = []
        content_lower = content.lower()
        
        for pii_type, pattern in self.PII_PATTERNS.items():
            matches = re.finditer(pattern, content, re.IGNORECASE)
            for match in matches:
                # Extract matched text (truncated for logging)
                matched_text = match.group(0)
                if len(matched_text) > 20:
                    matched_text = matched_text[:20] + "..."
                
                violation = PolicyViolation(
                    severity=ViolationSeverity.CRITICAL,
                    rule_id=PolicyRule.PII_DETECTED.value,
                    rule_name=PolicyRule.PII_DETECTED,
                    notes=f"PII detected: {pii_type} - {matched_text}",
                    detected_at=time.time(),
                    context={"pii_type": pii_type, "position": match.start()}
                )
                violations.append(violation)
        
        return violations
    
    def _detect_credentials(self, content: str) -> List[PolicyViolation]:
        """Detect credentials in content.
        
        Scans content for sensitive keywords (password, secret, key, token, etc.)
        followed by potential credential values. This is a Sentinel compliance
        check for credential detection. Each detected credential creates a CRITICAL
        severity violation.
        
        Args:
            content: Content string to scan for credentials.
        
        Returns:
            List of PolicyViolation objects, one for each detected credential pattern.
        """
        violations = []
        content_lower = content.lower()
        
        for keyword in self.SENSITIVE_KEYWORDS:
            # Look for keyword followed by potential credential pattern
            pattern = rf"{keyword}\s*[:=]\s*([^\s]+)"
            matches = re.finditer(pattern, content_lower, re.IGNORECASE)
            
            for match in matches:
                # Extract potential credential (truncated)
                potential_credential = match.group(1)
                if len(potential_credential) > 20:
                    potential_credential = potential_credential[:20] + "..."
                
                violation = PolicyViolation(
                    severity=ViolationSeverity.CRITICAL,
                    rule_id=PolicyRule.CREDENTIALS_DETECTED.value,
                    rule_name=PolicyRule.CREDENTIALS_DETECTED,
                    notes=f"Potential credentials detected: {keyword}",
                    detected_at=time.time(),
                    context={"keyword": keyword, "position": match.start()}
                )
                violations.append(violation)
        
        return violations
    
    def _detect_sensitive_data(self, content: str) -> List[PolicyViolation]:
        """Detect sensitive data patterns.
        
        Scans content for patterns that indicate sensitive data, such as base64
        encoded data. This is a Sentinel compliance check for sensitive data
        detection. Detected patterns create WARNING severity violations.
        
        Args:
            content: Content string to scan for sensitive data patterns.
        
        Returns:
            List of PolicyViolation objects for detected sensitive data patterns.
        """
        violations = []
        
        # Check for base64 encoded data (potential sensitive data)
        base64_pattern = r'[A-Za-z0-9+/]{40,}={0,2}'
        if re.search(base64_pattern, content):
            violation = PolicyViolation(
                severity=ViolationSeverity.WARNING,
                rule_id=PolicyRule.SENSITIVE_DATA.value,
                rule_name=PolicyRule.SENSITIVE_DATA,
                notes="Potential base64 encoded sensitive data detected",
                detected_at=time.time()
            )
            violations.append(violation)
        
        return violations
    
    def _detect_policy_violations(self, content: str) -> List[PolicyViolation]:
        """Detect policy violation patterns.
        
        Scans content for security policy violation patterns including SQL injection,
        XSS (cross-site scripting), and path traversal attempts. This is a Sentinel
        compliance check for security policy violations. Each detected pattern creates
        a CRITICAL severity violation.
        
        Args:
            content: Content string to scan for policy violation patterns.
        
        Returns:
            List of PolicyViolation objects for detected policy violations.
        """
        violations = []
        
        for violation_type, pattern in self.POLICY_PATTERNS.items():
            if re.search(pattern, content, re.IGNORECASE):
                violation = PolicyViolation(
                    severity=ViolationSeverity.CRITICAL,
                    rule_id=PolicyRule.POLICY_VIOLATION.value,
                    rule_name=PolicyRule.POLICY_VIOLATION,
                    notes=f"Policy violation pattern detected: {violation_type}",
                    detected_at=time.time(),
                    context={"violation_type": violation_type}
                )
                violations.append(violation)
        
        return violations
    
    def _generate_summary(self, violations: List[PolicyViolation], passed: bool) -> str:
        """Generate audit summary.
        
        Creates a human-readable summary of the audit results, including counts
        of critical and warning violations.
        
        Args:
            violations: List of PolicyViolation objects detected during audit.
            passed: Boolean indicating if audit passed (no critical violations).
        
        Returns:
            Human-readable summary string describing audit results.
        """
        if passed:
            return "Audit passed: No critical violations detected"
        
        critical_count = sum(1 for v in violations if v.severity == ViolationSeverity.CRITICAL)
        warning_count = sum(1 for v in violations if v.severity == ViolationSeverity.WARNING)
        
        return (
            f"Audit failed: {critical_count} critical violation(s), "
            f"{warning_count} warning(s) detected"
        )
    
    def _log_audit(
        self,
        audit_id: str,
        result: AuditResult,
        context: Optional[Dict[str, Any]]
    ) -> None:
        """Log audit operation.
        
        Creates an audit log entry for the audit operation. This is a Sentinel
        compliance check for audit logging.
        
        Args:
            audit_id: Unique identifier for the audit.
            result: AuditResult containing audit details.
            context: Optional dictionary with additional context.
        """
        audit_entry = {
            "audit_id": audit_id,
            "timestamp": result.audited_at,
            "passed": result.passed,
            "violation_count": len(result.violations),
            "critical_count": sum(
                1 for v in result.violations 
                if v.severity == ViolationSeverity.CRITICAL
            ),
            "summary": result.summary,
            "context": context or {}
        }
        
        self._audit_log.append(audit_entry)
        logger.info(f"Sentinel audit: {audit_id} - {result.summary}")
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get agent statistics.
        
        Returns comprehensive statistics about audit operations performed
        by the agent.
        
        Returns:
            Dictionary containing:
            - total_audits: Total number of audits performed
            - total_violations: Number of audits with violations
            - critical_violations: Number of audits with critical violations
            - violation_rate: Ratio of audits with violations to total audits
            - critical_rate: Ratio of audits with critical violations to total audits
        """
        return {
            "total_audits": self._audit_count,
            "total_violations": self._violation_count,
            "critical_violations": self._critical_violations,
            "violation_rate": (
                self._violation_count / self._audit_count 
                if self._audit_count > 0 else 0.0
            ),
            "critical_rate": (
                self._critical_violations / self._audit_count 
                if self._audit_count > 0 else 0.0
            )
        }
    
    def get_health(self) -> Dict[str, Any]:
        """Get agent health status.
        
        Returns health status based on critical violation rate and operational metrics.
        Health is considered degraded if critical violation rate exceeds 10%.
        
        Returns:
            Dictionary containing:
            - status: Health status ("healthy" or "degraded")
            - message: Human-readable status message
            - statistics: Full statistics dictionary from get_statistics()
        """
        stats = self.get_statistics()
        
        # Health is degraded if critical violation rate is high
        if stats["critical_rate"] > 0.1:  # >10% critical violations
            status = "degraded"
            message = f"High critical violation rate: {stats['critical_rate']:.1%}"
        else:
            status = "healthy"
            message = "Sentinel agent operational"
        
        return {
            "status": status,
            "message": message,
            "statistics": stats
        }

