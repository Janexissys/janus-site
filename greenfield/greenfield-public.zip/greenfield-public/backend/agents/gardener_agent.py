# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Gardener Agent - Card structuring and organization.

The Gardener Agent is responsible for structuring and organizing cards to make
thinking visible. It surfaces patterns, contradictions, gaps, and connections
without altering content, organizing and mapping ideas for better understanding.

**Card**: CARD-V6B-P1-AGENT-GARDENER  
**Soul Reference**: CARD-V6B-P0-AGENT-SOUL (Revealer of Order)  
**MC Target**: 8.60  
**Dependencies**: None (foundational agent)

**Identity**: Revealer of Order - Makes thinking visible by surfacing patterns,
contradictions, gaps, and connections. Organizes and maps ideas without
altering their content.

**Key Responsibilities**:
- Structure and organize card content
- Calculate organization scores
- Identify improvement opportunities
- Detect PII in card content
- Maintain audit logs of all structuring operations

**Sentinel Compliance**:
- PII Detection: Scans card content for PII patterns
- Data Validation: Validates input card data
- Audit Logging: Logs all structuring operations with context

**Example Usage**:
    ```python
    from agents.gardener_agent import GardenerAgent
    
    agent = GardenerAgent()
    result = agent.structure_card(
        card_id="card-001",
        title="Implement authentication system",
        content="Add OAuth2 support for user authentication...",
        metadata={"status": "pending", "priority": "high"}
    )
    print(f"Organization score: {result.structured_card.organization_score:.2f}")
    print(f"Improvements: {result.organization_improvements}")
    ```
"""

import logging
import re
import time
import uuid
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from utils.exceptions import ValidationError

logger = logging.getLogger(__name__)


@dataclass
class CardStructure:
    """Structured card data.
    
    Attributes:
        card_id: Unique identifier for the card.
        title: Card title (cleaned and normalized).
        content: Card content (cleaned and normalized).
        metadata: Dictionary of card metadata (status, priority, etc.).
        structured_at: Timestamp when the card was structured.
        organization_score: Organization quality score (0.0-1.0).
    """
    card_id: str
    title: str
    content: str
    metadata: Dict[str, Any]
    structured_at: float
    organization_score: float


@dataclass
class StructuringResult:
    """Card structuring result.
    
    Attributes:
        card_id: Unique identifier for the card.
        structured_card: The structured CardStructure object.
        organization_improvements: List of suggested improvements.
        sensitive_data_detected: Whether PII was detected in the card.
    """
    card_id: str
    structured_card: CardStructure
    organization_improvements: List[str]
    sensitive_data_detected: bool


class GardenerAgent:
    """Gardener Agent provides card structuring and organization.
    
    The Gardener Agent structures and organizes cards to improve their clarity
    and organization. It calculates organization scores based on title quality,
    content structure, and metadata completeness, and provides improvement
    suggestions.
    
    Attributes:
        PII_PATTERNS: Dictionary of regex patterns for PII detection.
            Keys are PII types (email, phone, ssn), values are regex patterns.
    """
    
    # PII patterns (SENTINEL: PII Detection)
    PII_PATTERNS: Dict[str, str] = {
        "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        "phone": r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
        "ssn": r'\b\d{3}-\d{2}-\d{4}\b',
    }
    
    def __init__(self) -> None:
        """Initialize Gardener Agent.
        
        Sets up internal counters and audit log for tracking structuring operations.
        """
        self._structured_count: int = 0
        self._pii_detections: int = 0
        self._audit_log: List[Dict[str, Any]] = []
    
    def structure_card(
        self,
        card_id: str,
        title: str,
        content: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> StructuringResult:
        """Structure and organize a card.
        
        Takes a card with title, content, and optional metadata, and structures
        it by calculating organization scores and identifying improvements.
        Performs PII detection and audit logging as part of the structuring process.
        
        Args:
            card_id: Unique identifier for the card (must be non-empty string).
            title: Card title (must be non-empty string).
            content: Card content (must be a string, can be empty).
            metadata: Optional dictionary of card metadata (status, priority, etc.).
        
        Returns:
            StructuringResult containing:
            - structured_card: CardStructure with organization score
            - organization_improvements: List of improvement suggestions
            - sensitive_data_detected: Boolean indicating if PII was found
        
        Raises:
            ValidationError: If card_id or title is not a non-empty string, or
                if content is not a string.
        
        Example:
            ```python
            agent = GardenerAgent()
            result = agent.structure_card(
                card_id="card-001",
                title="Implement feature",
                content="# Feature\n\nDescription...",
                metadata={"status": "pending"}
            )
            print(f"Score: {result.structured_card.organization_score}")
            ```
        """
        # SENTINEL: Data Validation
        if not isinstance(card_id, str) or not card_id.strip():
            raise ValidationError(
                "Gardener: Validate card structure - card_id must be a non-empty string",
                component="GardenerAgent",
                context={"operation": "structure_card", "card_id_type": type(card_id).__name__}
            )
        
        if not isinstance(title, str) or not title.strip():
            raise ValidationError(
                "Gardener: Validate card structure - title must be a non-empty string",
                component="GardenerAgent",
                context={"operation": "structure_card", "card_id": card_id, "title_type": type(title).__name__}
            )
        
        if not isinstance(content, str):
            raise ValidationError(
                "Gardener: Validate card structure - content must be a string",
                component="GardenerAgent",
                context={"operation": "structure_card", "card_id": card_id, "content_type": type(content).__name__}
            )
        
        # SENTINEL: PII Detection - Sensitive data in card structuring
        sensitive_data_detected = self._detect_pii(content) or self._detect_pii(title)
        if sensitive_data_detected:
            self._pii_detections += 1
            logger.warning("Sensitive data detected in card - proceeding with caution")
        
        # Structure the card
        structured_card = self._organize_card(card_id, title, content, metadata or {})
        
        # Identify improvements
        improvements = self._identify_improvements(structured_card)
        
        result = StructuringResult(
            card_id=card_id,
            structured_card=structured_card,
            organization_improvements=improvements,
            sensitive_data_detected=sensitive_data_detected
        )
        
        self._structured_count += 1
        
        # SENTINEL: Audit Logging
        self._log_audit(card_id, result)
        
        return result
    
    def _organize_card(
        self,
        card_id: str,
        title: str,
        content: str,
        metadata: Dict[str, Any]
    ) -> CardStructure:
        """Organize card structure.
        
        Internal method that creates a structured card by cleaning and normalizing
        the input data and calculating an organization score.
        
        Args:
            card_id: Unique identifier for the card.
            title: Card title to clean and normalize.
            content: Card content to clean and normalize.
            metadata: Dictionary of card metadata.
        
        Returns:
            CardStructure object with cleaned data and organization score.
        """
        # Calculate organization score (simplified for greenfield)
        organization_score = self._calculate_organization_score(title, content, metadata)
        
        return CardStructure(
            card_id=card_id,
            title=title.strip(),
            content=content.strip(),
            metadata=metadata,
            structured_at=time.time(),
            organization_score=organization_score
        )
    
    def _calculate_organization_score(
        self,
        title: str,
        content: str,
        metadata: Dict[str, Any]
    ) -> float:
        """Calculate organization score.
        
        Calculates a quality score (0.0-1.0) based on:
        - Title quality (30%): Length and clarity
        - Content structure (40%): Presence of headings, lists, code blocks
        - Metadata completeness (30%): Required fields present
        
        Args:
            title: Card title to evaluate.
            content: Card content to evaluate.
            metadata: Dictionary of metadata to check for completeness.
        
        Returns:
            Organization score between 0.0 and 1.0, where 1.0 is perfectly organized.
        """
        score = 0.0
        
        # Title quality (0.3)
        if title and len(title) > 5:
            score += 0.3
        
        # Content structure (0.4)
        if content:
            # Check for headings
            if re.search(r'^#+\s+', content, re.MULTILINE):
                score += 0.2
            # Check for lists
            if re.search(r'^[-*]\s+', content, re.MULTILINE):
                score += 0.1
            # Check for code blocks
            if re.search(r'```', content):
                score += 0.1
        
        # Metadata completeness (0.3)
        if metadata:
            required_fields = ["status", "priority", "created"]
            present_fields = sum(1 for field in required_fields if field in metadata)
            score += 0.3 * (present_fields / len(required_fields))
        
        return min(score, 1.0)
    
    def _identify_improvements(self, card: CardStructure) -> List[str]:
        """Identify organization improvements.
        
        Analyzes a structured card and suggests improvements based on organization
        score, missing metadata fields, and content length.
        
        Args:
            card: CardStructure object to analyze.
        
        Returns:
            List of human-readable improvement suggestions (e.g., "Missing status field").
        """
        improvements = []
        
        if card.organization_score < 0.5:
            improvements.append("Low organization score - consider restructuring")
        
        if not card.metadata.get("status"):
            improvements.append("Missing status field")
        
        if not card.metadata.get("priority"):
            improvements.append("Missing priority field")
        
        if len(card.content) < 50:
            improvements.append("Content too short - consider adding details")
        
        return improvements
    
    def _detect_pii(self, text: str) -> bool:
        """Detect PII in text.
        
        Scans text for PII patterns including email addresses, phone numbers,
        and SSNs. This is a Sentinel compliance check for PII detection.
        
        Args:
            text: Text string to scan for PII.
        
        Returns:
            True if any PII pattern is detected, False otherwise.
        """
        text_lower = text.lower()
        
        for pii_type, pattern in self.PII_PATTERNS.items():
            if re.search(pattern, text_lower, re.IGNORECASE):
                logger.warning(f"PII detected in card: {pii_type}")
                return True
        
        return False
    
    def _log_audit(self, card_id: str, result: StructuringResult) -> None:
        """Log audit operation.
        
        Creates an audit log entry for the structuring operation. This is a
        Sentinel compliance check for audit logging.
        
        Args:
            card_id: Unique identifier for the card.
            result: StructuringResult containing operation details.
        """
        audit_entry = {
            "card_id": card_id,
            "timestamp": result.structured_card.structured_at,
            "organization_score": result.structured_card.organization_score,
            "sensitive_data_detected": result.sensitive_data_detected,
            "improvements": result.organization_improvements
        }
        
        self._audit_log.append(audit_entry)
        logger.info(f"Gardener structured card: {card_id} - score: {result.structured_card.organization_score:.2f}")
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get agent statistics.
        
        Returns comprehensive statistics about structuring operations performed
        by the agent.
        
        Returns:
            Dictionary containing:
            - total_structured: Total number of cards structured
            - pii_detections: Number of times PII was detected
            - pii_rate: Ratio of PII detections to total cards structured
        """
        return {
            "total_structured": self._structured_count,
            "pii_detections": self._pii_detections,
            "pii_rate": (
                self._pii_detections / self._structured_count 
                if self._structured_count > 0 else 0.0
            )
        }
    
    def get_health(self) -> Dict[str, Any]:
        """Get agent health status.
        
        Returns health status based on PII detection rate and operational metrics.
        Health is considered degraded if PII detection rate exceeds 20%.
        
        Returns:
            Dictionary containing:
            - status: Health status ("healthy" or "degraded")
            - message: Human-readable status message
            - statistics: Full statistics dictionary from get_statistics()
        """
        stats = self.get_statistics()
        
        # Health is degraded if PII detection rate is high
        if stats["pii_rate"] > 0.2:  # >20% PII detection rate
            status = "degraded"
            message = f"High PII detection rate: {stats['pii_rate']:.1%}"
        else:
            status = "healthy"
            message = "Gardener agent operational"
        
        return {
            "status": status,
            "message": message,
            "statistics": stats
        }

