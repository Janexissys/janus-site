# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Caretaker Agent - Strategic decision-making (approve/reject/defer).

The Caretaker Agent is responsible for making strategic decisions about whether
content should be approved, rejected, or deferred. It evaluates content against
North Star policies, detects PII, and makes decisions based on alignment with
project goals and strategic value.

**Card**: CARD-V6B-P1-AGENT-CARETAKER  
**Soul Reference**: CARD-V6B-P0-AGENT-SOUL (Guardian of Stewardship)  
**MC Target**: 8.65  
**Dependencies**: None (foundational agent)

**Identity**: Guardian of Stewardship - Decides what enters the system and asks,
"Is this safe, and does this belong with this human?" Monitors vault and system
health, protecting long-term library integrity over speed.

**Key Responsibilities**:
- Evaluate content for strategic value and alignment
- Detect PII in decision contexts
- Apply North Star policy evaluation
- Make approve/reject/defer decisions
- Maintain audit logs of all decisions

**Sentinel Compliance**:
- PII Detection: Scans content for PII patterns
- Data Validation: Validates input content
- Audit Logging: Logs all decisions with context

**Example Usage**:
    ```python
    from agents.caretaker_agent import CaretakerAgent, DecisionContext
    
    agent = CaretakerAgent()
    context = DecisionContext(
        content="Implement new feature for user authentication",
        project_alignment=0.85,
        mc_score=8.5
    )
    result = agent.make_decision(context)
    print(f"Decision: {result.decision.value} - {result.why}")
    ```
"""

import logging
import re
import time
import uuid
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

from utils.exceptions import ValidationError

logger = logging.getLogger(__name__)


class Decision(Enum):
    """Strategic decision types."""
    APPROVE = "approve"
    REJECT = "reject"
    DEFER = "defer"


@dataclass
class DecisionContext:
    """Context for decision-making."""
    content: str
    metadata: Optional[Dict[str, Any]] = None
    project_alignment: Optional[float] = None
    mc_score: Optional[float] = None


@dataclass
class DecisionResult:
    """Decision result."""
    decision: Decision
    decision_id: str
    why: str
    mc_stub: str
    created_at: float
    context: DecisionContext
    north_star_alignment: Optional[float] = None


class CaretakerAgent:
    """Caretaker Agent provides strategic decision-making (approve/reject/defer).
    
    The Caretaker Agent evaluates content and makes strategic decisions based on:
    - Content quality and strategic value
    - North Star alignment
    - Project alignment scores
    - MC scores
    
    Decisions are one of:
    - APPROVE: Content is valuable and aligned
    - REJECT: Content is not valuable or misaligned
    - DEFER: Content needs more information or investigation
    
    Attributes:
        PII_PATTERNS: Dictionary of regex patterns for PII detection.
            Keys are PII types (email, phone, ssn), values are regex patterns.
    """
    
    # PII patterns (SENTINEL: PII Detection)
    PII_PATTERNS: Dict[str, str] = {
        "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        "phone": r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
        "ssn": r'\b\d{3}-\d{2}-\d{4}\b',
    }
    
    def __init__(self) -> None:
        """Initialize Caretaker Agent.
        
        Sets up internal counters and audit log for tracking decisions.
        """
        self._decision_count: int = 0
        self._approve_count: int = 0
        self._reject_count: int = 0
        self._defer_count: int = 0
        self._pii_detections: int = 0
        self._audit_log: List[Dict[str, Any]] = []
    
    def make_decision(self, context: DecisionContext) -> DecisionResult:
        """Make strategic decision (approve/reject/defer).
        
        Evaluates the provided context and makes a decision based on content
        analysis, North Star alignment, and project alignment. Performs PII
        detection and audit logging as part of the decision process.
        
        Args:
            context: Decision context containing content, metadata, project
                alignment, and MC score.
        
        Returns:
            DecisionResult containing the decision, decision ID, rationale,
            MC stub, timestamp, and North Star alignment score.
        
        Raises:
            ValidationError: If context content is not a non-empty string.
        
        Example:
            ```python
            context = DecisionContext(
                content="Implement authentication system",
                project_alignment=0.9,
                mc_score=8.5
            )
            result = agent.make_decision(context)
            assert result.decision in [Decision.APPROVE, Decision.REJECT, Decision.DEFER]
            ```
        """
        # SENTINEL: Data Validation
        if not isinstance(context.content, str) or not context.content.strip():
            raise ValidationError(
                "Caretaker: Validate decision context - content must be a non-empty string",
                component="CaretakerAgent",
                context={"operation": "make_decision", "content_type": type(context.content).__name__}
            )
        
        # SENTINEL: PII Detection
        pii_detected = self._detect_pii(context.content)
        if pii_detected:
            self._pii_detections += 1
            logger.warning("PII detected in decision context - proceeding with caution")
        
        # SENTINEL: North Star policy evaluation for PII
        north_star_alignment = self._evaluate_north_star_policy(context)
        
        # Make decision based on content analysis
        decision, why, mc_stub = self._analyze_and_decide(context, north_star_alignment)
        
        decision_id = str(uuid.uuid4())
        result = DecisionResult(
            decision=decision,
            decision_id=decision_id,
            why=why,
            mc_stub=mc_stub,
            created_at=time.time(),
            context=context,
            north_star_alignment=north_star_alignment
        )
        
        # Update statistics
        self._decision_count += 1
        if decision == Decision.APPROVE:
            self._approve_count += 1
        elif decision == Decision.REJECT:
            self._reject_count += 1
        elif decision == Decision.DEFER:
            self._defer_count += 1
        
        # SENTINEL: Audit Logging
        self._log_audit(decision_id, result, pii_detected)
        
        return result
    
    def _analyze_and_decide(
        self,
        context: DecisionContext,
        north_star_alignment: Optional[float]
    ) -> Tuple[Decision, str, str]:
        """Analyze context and make decision.
        
        Internal method that analyzes the decision context and determines the
        appropriate decision based on keyword matching and North Star alignment.
        
        Args:
            context: Decision context containing content and metadata.
            north_star_alignment: North Star alignment score (0.0-1.0) or None.
        
        Returns:
            Tuple containing:
            - Decision: The decision (APPROVE, REJECT, or DEFER)
            - why: Human-readable rationale for the decision
            - mc_stub: MC stub identifier for the decision type
        """
        content_lower = context.content.lower()
        
        # Decision criteria (simplified for greenfield)
        # APPROVE: Reusable patterns, strategic work, technical solutions
        approve_keywords = [
            "implement", "create", "build", "design", "architecture",
            "pattern", "strategy", "solution", "system", "framework"
        ]
        
        # REJECT: Personal scheduling, ephemeral content, trivial tasks
        reject_keywords = [
            "buy", "schedule", "remind", "todo", "personal",
            "ephemeral", "trivial", "noise"
        ]
        
        # DEFER: Missing evidence, needs investigation, unclear
        defer_keywords = [
            "investigate", "clarify", "review", "analyze",
            "unclear", "missing", "unknown"
        ]
        
        # Check for approve keywords
        approve_score = sum(1 for kw in approve_keywords if kw in content_lower)
        
        # Check for reject keywords
        reject_score = sum(1 for kw in reject_keywords if kw in content_lower)
        
        # Check for defer keywords
        defer_score = sum(1 for kw in defer_keywords if kw in content_lower)
        
        # Consider North Star alignment
        if north_star_alignment is not None and north_star_alignment < 0.5:
            return Decision.REJECT, "Low North Star alignment", "ns_low"
        
        # Make decision based on scores
        if approve_score > reject_score and approve_score > defer_score:
            return Decision.APPROVE, "Reusable pattern or strategic work", f"approve_{approve_score}"
        elif reject_score > defer_score:
            return Decision.REJECT, "Personal or ephemeral content", f"reject_{reject_score}"
        elif defer_score > 0:
            return Decision.DEFER, "Needs investigation or clarification", f"defer_{defer_score}"
        else:
            # Default to defer if unclear
            return Decision.DEFER, "Insufficient information for decision", "defer_default"
    
    def _evaluate_north_star_policy(self, context: DecisionContext) -> Optional[float]:
        """Evaluate North Star policy alignment.
        
        Evaluates content against North Star policies including truth alignment,
        project alignment, and reasoning clarity. This is a Sentinel check for
        North Star policy evaluation.
        
        Args:
            context: Decision context containing content and project alignment.
        
        Returns:
            Alignment score (0.0-1.0) representing overall North Star alignment,
            or None if evaluation cannot be performed.
        """
        # Simplified North Star evaluation for greenfield
        # In production, this would check against actual North Star policies
        
        # Check for truth alignment (content quality)
        truth_indicators = ["accurate", "verified", "validated", "confirmed"]
        truth_score = sum(1 for ind in truth_indicators if ind in context.content.lower()) / max(len(truth_indicators), 1)
        
        # Check for project alignment
        project_score = context.project_alignment if context.project_alignment else 0.5
        
        # Check for reasoning clarity
        reasoning_indicators = ["because", "reason", "rationale", "analysis"]
        reasoning_score = sum(1 for ind in reasoning_indicators if ind in context.content.lower()) / max(len(reasoning_indicators), 1)
        
        # Average alignment score
        alignment = (truth_score + project_score + reasoning_score) / 3.0
        
        return alignment
    
    def _detect_pii(self, content: str) -> bool:
        """Detect PII in content.
        
        Scans content for PII patterns including email addresses, phone numbers,
        and SSNs. This is a Sentinel compliance check for PII detection.
        
        Args:
            content: Content string to scan for PII.
        
        Returns:
            True if any PII pattern is detected, False otherwise.
        """
        content_lower = content.lower()
        
        for pii_type, pattern in self.PII_PATTERNS.items():
            if re.search(pattern, content_lower, re.IGNORECASE):
                logger.warning(f"PII detected in decision context: {pii_type}")
                return True
        
        return False
    
    def _log_audit(
        self,
        decision_id: str,
        result: DecisionResult,
        pii_detected: bool
    ) -> None:
        """Log audit operation.
        
        Creates an audit log entry for the decision. This is a Sentinel compliance
        check for audit logging.
        
        Args:
            decision_id: Unique identifier for the decision.
            result: DecisionResult containing decision details.
            pii_detected: Boolean indicating if PII was detected in the content.
        """
        audit_entry = {
            "decision_id": decision_id,
            "timestamp": result.created_at,
            "decision": result.decision.value,
            "why": result.why,
            "mc_stub": result.mc_stub,
            "north_star_alignment": result.north_star_alignment,
            "pii_detected": pii_detected
        }
        
        self._audit_log.append(audit_entry)
        logger.info(f"Caretaker decision: {decision_id} - {result.decision.value} - {result.why}")
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get agent statistics.
        
        Returns comprehensive statistics about decisions made by the agent.
        
        Returns:
            Dictionary containing:
            - total_decisions: Total number of decisions made
            - approve_count: Number of approve decisions
            - reject_count: Number of reject decisions
            - defer_count: Number of defer decisions
            - pii_detections: Number of times PII was detected
            - approve_rate: Ratio of approve decisions to total decisions
        """
        return {
            "total_decisions": self._decision_count,
            "approve_count": self._approve_count,
            "reject_count": self._reject_count,
            "defer_count": self._defer_count,
            "pii_detections": self._pii_detections,
            "approve_rate": (
                self._approve_count / self._decision_count 
                if self._decision_count > 0 else 0.0
            )
        }
    
    def get_health(self) -> Dict[str, Any]:
        """Get agent health status.
        
        Returns health status based on PII detection rate and operational metrics.
        Health is considered degraded if PII detection rate exceeds 20%.
        
        Returns:
            Dictionary containing:
            - status: Health status ("healthy" or "degraded")
            - message: Human-readable status message
            - statistics: Full statistics dictionary from get_statistics()
        """
        stats = self.get_statistics()
        
        # Health is degraded if PII detection rate is high
        pii_rate = (
            self._pii_detections / self._decision_count 
            if self._decision_count > 0 else 0.0
        )
        
        if pii_rate > 0.2:  # >20% PII detection rate
            status = "degraded"
            message = f"High PII detection rate: {pii_rate:.1%}"
        else:
            status = "healthy"
            message = "Caretaker agent operational"
        
        return {
            "status": status,
            "message": message,
            "statistics": stats
        }

