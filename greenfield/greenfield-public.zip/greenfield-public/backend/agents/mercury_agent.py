# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Mercury Agent - Memory routing and promotion.

The Mercury Agent is responsible for routing memory content to appropriate
storage destinations (STM, LTM, or Quarantine) based on MC scores, confidence
levels, and PII detection. It surfaces forgotten or archived thoughts and
connects past insights to current decisions.

**Card**: CARD-V6B-P1-AGENT-MERCURY  
**Soul Reference**: CARD-V6B-P0-AGENT-SOUL (Revealer of Hidden Gems)  
**MC Target**: 8.55  
**Dependencies**: None (foundational agent)

**Identity**: Revealer of Hidden Gems - Surfaces forgotten or archived thoughts
and connects past insights to current decisions so important knowledge is not lost.

**Key Responsibilities**:
- Route memory content to STM, LTM, or Quarantine based on MC scores
- Detect PII in memory content (routes to quarantine if detected)
- Calculate routing decisions based on MC score and confidence
- Maintain audit logs of all routing operations

**Sentinel Compliance**:
- PII Detection: Scans memory content for PII patterns (routes to quarantine)
- Data Validation: Validates input content, MC scores, and confidence
- Audit Logging: Logs all routing decisions with context

**Example Usage**:
    ```python
    from agents.mercury_agent import MercuryAgent
    
    agent = MercuryAgent()
    decision = agent.route_memory(
        content_id="content-001",
        content="Important project insight...",
        mc_score=8.7,
        confidence=0.85
    )
    print(f"Route: {decision.route.value} - {decision.rationale}")
    ```
"""

import logging
import re
import time
import uuid
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

from utils.exceptions import ValidationError

logger = logging.getLogger(__name__)


class MemoryRoute(Enum):
    """Memory routing destinations.
    
    Attributes:
        STM: Short-term memory (STMVault) - for content with medium MC scores.
        LTM: Long-term memory (LTMVault) - for high-quality content (MC >= 8.5).
        QUARANTINE: Quarantine - for low-quality content or content with PII.
    """
    STM = "stm"  # Short-term memory
    LTM = "ltm"  # Long-term memory
    QUARANTINE = "quarantine"


@dataclass
class RoutingDecision:
    """Memory routing decision.
    
    Attributes:
        route: Destination route (STM, LTM, or QUARANTINE).
        decision_id: Unique identifier for this routing decision.
        mc_score: MC score (0.0-10.0) used for routing decision.
        confidence: Confidence score (0.0-1.0) used for routing decision.
        rationale: Human-readable explanation for the routing decision.
        created_at: Timestamp when the routing decision was made.
        content_id: Identifier of the content being routed.
    """
    route: MemoryRoute
    decision_id: str
    mc_score: float
    confidence: float
    rationale: str
    created_at: float
    content_id: str


class MercuryAgent:
    """Mercury Agent provides memory routing and promotion.
    
    The Mercury Agent routes memory content to appropriate storage destinations
    based on MC scores, confidence levels, and PII detection. It implements
    the memory lifecycle by promoting high-quality content to LTM and routing
    low-quality or sensitive content appropriately.
    
    Attributes:
        PII_PATTERNS: Dictionary of regex patterns for PII detection.
            Keys are PII types (email, phone, ssn), values are regex patterns.
        LTM_THRESHOLD: MC score threshold (8.5) for promoting to LTM.
        STM_THRESHOLD: MC score threshold (7.0) for routing to STM.
        QUARANTINE_THRESHOLD: MC score threshold (5.0) for quarantining content.
    """
    
    # PII patterns (SENTINEL: PII Detection)
    PII_PATTERNS: Dict[str, str] = {
        "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        "phone": r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
        "ssn": r'\b\d{3}-\d{2}-\d{4}\b',
    }
    
    # MC thresholds for routing
    LTM_THRESHOLD: float = 8.5  # Promote to LTM if MC >= 8.5
    STM_THRESHOLD: float = 7.0  # Route to STM if MC >= 7.0
    QUARANTINE_THRESHOLD: float = 5.0  # Quarantine if MC < 5.0
    
    def __init__(self) -> None:
        """Initialize Mercury Agent.
        
        Sets up internal counters and audit log for tracking routing operations.
        """
        self._routing_count: int = 0
        self._stm_routes: int = 0
        self._ltm_routes: int = 0
        self._quarantine_routes: int = 0
        self._pii_detections: int = 0
        self._audit_log: List[Dict[str, Any]] = []
    
    def route_memory(
        self,
        content_id: str,
        content: str,
        mc_score: float,
        confidence: float = 0.5
    ) -> RoutingDecision:
        """Route memory to STM/LTM/Quarantine.
        
        Routes memory content to the appropriate storage destination based on
        MC score, confidence level, and PII detection. Performs PII detection
        first - if PII is detected, content is automatically routed to quarantine.
        Otherwise, routing is based on MC score and confidence thresholds.
        
        Args:
            content_id: Unique identifier for the content (must be non-empty string).
            content: Content string to route (must be a string).
            mc_score: MC score between 0.0 and 10.0 (used for routing decision).
            confidence: Confidence score between 0.0 and 1.0 (default: 0.5).
        
        Returns:
            RoutingDecision containing:
            - route: Destination (STM, LTM, or QUARANTINE)
            - decision_id: Unique identifier for this decision
            - mc_score: MC score used for routing
            - confidence: Confidence score used for routing
            - rationale: Human-readable explanation
            - created_at: Timestamp of decision
            - content_id: Identifier of routed content
        
        Raises:
            ValidationError: If content_id is not a non-empty string, content is
                not a string, mc_score is not between 0.0-10.0, or confidence is
                not between 0.0-1.0.
        
        Example:
            ```python
            agent = MercuryAgent()
            decision = agent.route_memory(
                content_id="content-001",
                content="Project insight...",
                mc_score=8.7,
                confidence=0.85
            )
            assert decision.route == MemoryRoute.LTM
            ```
        """
        # SENTINEL: Data Validation
        if not isinstance(content_id, str) or not content_id.strip():
            raise ValidationError(
                "Mercury: Validate memory routing - content_id must be a non-empty string",
                component="MercuryAgent",
                context={"operation": "route_memory", "content_id_type": type(content_id).__name__}
            )
        
        if not isinstance(content, str):
            raise ValidationError(
                "Mercury: Validate memory routing - content must be a string",
                component="MercuryAgent",
                context={"operation": "route_memory", "content_id": content_id, "content_type": type(content).__name__}
            )
        
        if not isinstance(mc_score, (int, float)) or mc_score < 0 or mc_score > 10:
            raise ValidationError(
                "Mercury: Validate memory routing - mc_score must be between 0.0 and 10.0",
                component="MercuryAgent",
                context={"operation": "route_memory", "content_id": content_id, "mc_score": mc_score}
            )
        
        if not isinstance(confidence, (int, float)) or confidence < 0 or confidence > 1:
            raise ValidationError(
                "Mercury: Validate memory routing - confidence must be between 0.0 and 1.0",
                component="MercuryAgent",
                context={"operation": "route_memory", "content_id": content_id, "confidence": confidence}
            )
        
        # SENTINEL: PII Detection - Memory routing credential exposure
        pii_detected = self._detect_pii(content)
        if pii_detected:
            self._pii_detections += 1
            logger.warning("PII detected in memory content - routing to quarantine")
            # Route to quarantine if PII detected
            route = MemoryRoute.QUARANTINE
            rationale = "PII detected - quarantined for security"
        else:
            # Route based on MC score and confidence
            route, rationale = self._determine_route(mc_score, confidence)
        
        decision_id = str(uuid.uuid4())
        decision = RoutingDecision(
            route=route,
            decision_id=decision_id,
            mc_score=mc_score,
            confidence=confidence,
            rationale=rationale,
            created_at=time.time(),
            content_id=content_id
        )
        
        # Update statistics
        self._routing_count += 1
        if route == MemoryRoute.STM:
            self._stm_routes += 1
        elif route == MemoryRoute.LTM:
            self._ltm_routes += 1
        elif route == MemoryRoute.QUARANTINE:
            self._quarantine_routes += 1
        
        # SENTINEL: Audit Logging
        self._log_audit(decision_id, decision, pii_detected)
        
        return decision
    
    def _determine_route(
        self,
        mc_score: float,
        confidence: float
    ) -> Tuple[MemoryRoute, str]:
        """Determine memory route based on MC score and confidence.
        
        Internal method that determines the appropriate routing destination based
        on MC score and confidence thresholds. High MC (>=8.5) with high confidence
        (>=0.7) routes to LTM, low MC (<5.0) or low confidence (<0.3) routes to
        quarantine, otherwise routes to STM.
        
        Args:
            mc_score: MC score (0.0-10.0) for the content.
            confidence: Confidence score (0.0-1.0) for the content.
        
        Returns:
            Tuple containing:
            - MemoryRoute: The destination route (STM, LTM, or QUARANTINE)
            - str: Human-readable rationale for the routing decision
        """
        # High MC + high confidence -> LTM
        if mc_score >= self.LTM_THRESHOLD and confidence >= 0.7:
            return MemoryRoute.LTM, f"High MC ({mc_score:.2f}) and confidence ({confidence:.2f}) - promote to LTM"
        
        # Low MC or low confidence -> Quarantine
        if mc_score < self.QUARANTINE_THRESHOLD or confidence < 0.3:
            return MemoryRoute.QUARANTINE, f"Low MC ({mc_score:.2f}) or confidence ({confidence:.2f}) - quarantine"
        
        # Medium MC -> STM
        return MemoryRoute.STM, f"Medium MC ({mc_score:.2f}) - route to STM"
    
    def _detect_pii(self, content: str) -> bool:
        """Detect PII in content.
        
        Scans content for PII patterns including email addresses, phone numbers,
        and SSNs. This is a Sentinel compliance check for PII detection. Content
        with detected PII is automatically routed to quarantine.
        
        Args:
            content: Content string to scan for PII.
        
        Returns:
            True if any PII pattern is detected, False otherwise.
        """
        content_lower = content.lower()
        
        for pii_type, pattern in self.PII_PATTERNS.items():
            if re.search(pattern, content_lower, re.IGNORECASE):
                logger.warning(f"PII detected in memory content: {pii_type}")
                return True
        
        return False
    
    def _log_audit(
        self,
        decision_id: str,
        decision: RoutingDecision,
        pii_detected: bool
    ) -> None:
        """Log audit operation.
        
        Creates an audit log entry for the routing decision. This is a Sentinel
        compliance check for audit logging.
        
        Args:
            decision_id: Unique identifier for the routing decision.
            decision: RoutingDecision containing decision details.
            pii_detected: Boolean indicating if PII was detected in the content.
        """
        audit_entry = {
            "decision_id": decision_id,
            "timestamp": decision.created_at,
            "route": decision.route.value,
            "content_id": decision.content_id,
            "mc_score": decision.mc_score,
            "confidence": decision.confidence,
            "rationale": decision.rationale,
            "pii_detected": pii_detected
        }
        
        self._audit_log.append(audit_entry)
        logger.info(
            f"Mercury routed memory: {decision.content_id} -> {decision.route.value} "
            f"(MC: {decision.mc_score:.2f}, Conf: {decision.confidence:.2f})"
        )
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get agent statistics.
        
        Returns comprehensive statistics about routing operations performed
        by the agent.
        
        Returns:
            Dictionary containing:
            - total_routes: Total number of routing decisions made
            - stm_routes: Number of routes to STM
            - ltm_routes: Number of routes to LTM
            - quarantine_routes: Number of routes to quarantine
            - pii_detections: Number of times PII was detected
            - ltm_promotion_rate: Ratio of LTM routes to total routes
        """
        return {
            "total_routes": self._routing_count,
            "stm_routes": self._stm_routes,
            "ltm_routes": self._ltm_routes,
            "quarantine_routes": self._quarantine_routes,
            "pii_detections": self._pii_detections,
            "ltm_promotion_rate": (
                self._ltm_routes / self._routing_count 
                if self._routing_count > 0 else 0.0
            )
        }
    
    def get_health(self) -> Dict[str, Any]:
        """Get agent health status.
        
        Returns health status based on quarantine rate and operational metrics.
        Health is considered degraded if quarantine rate exceeds 30%.
        
        Returns:
            Dictionary containing:
            - status: Health status ("healthy" or "degraded")
            - message: Human-readable status message
            - statistics: Full statistics dictionary from get_statistics()
        """
        stats = self.get_statistics()
        
        # Health is degraded if quarantine rate is high
        quarantine_rate = (
            self._quarantine_routes / self._routing_count 
            if self._routing_count > 0 else 0.0
        )
        
        if quarantine_rate > 0.3:  # >30% quarantine rate
            status = "degraded"
            message = f"High quarantine rate: {quarantine_rate:.1%}"
        else:
            status = "healthy"
            message = "Mercury agent operational"
        
        return {
            "status": status,
            "message": message,
            "statistics": stats
        }

