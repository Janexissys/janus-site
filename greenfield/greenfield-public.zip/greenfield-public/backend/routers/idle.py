# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Idle Orchestrator API Router
============================

REST API endpoints for controlling and monitoring the idle orchestrator.

Endpoints:
- GET  /status     - Get current orchestrator status
- POST /run-once   - Manually trigger one idle cycle
- POST /toggle     - Update orchestrator configuration
"""

import logging
from typing import Any, Dict, Optional

from fastapi import APIRouter, HTTPException, Request, status
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field


logger = logging.getLogger(__name__)
router = APIRouter()


# ============================================================================
# REQUEST/RESPONSE MODELS
# ============================================================================


class ToggleConfigRequest(BaseModel):
    """Request model for updating orchestrator configuration."""

    enabled: Optional[bool] = Field(None, description="Enable/disable orchestrator")
    dry_run: Optional[bool] = Field(None, description="Enable/disable dry-run mode")
    idle_threshold_seconds: Optional[int] = Field(None, ge=0, description="Idle threshold in seconds")
    loop_interval_seconds: Optional[int] = Field(None, ge=1, description="Loop interval in seconds")


class RunOnceRequest(BaseModel):
    """Request model for manual task execution."""

    force: bool = Field(False, description="Force execution even if not idle")


class StatusResponse(BaseModel):
    """Response model for status endpoint."""

    success: bool
    data: Dict[str, Any]
    message: Optional[str] = None


class RunOnceResponse(BaseModel):
    """Response model for run-once endpoint."""

    success: bool
    results: list
    message: str


class ToggleResponse(BaseModel):
    """Response model for toggle endpoint."""

    success: bool
    updated: Dict[str, Any]
    message: str


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================


def get_orchestrator(request: Request):
    """
    Get orchestrator from app state.

    Args:
        request: FastAPI request object

    Returns:
        IdleOrchestrator instance

    Raises:
        HTTPException: If orchestrator not available (503)
    """
    orchestrator = getattr(request.app.state, "idle_orchestrator", None)

    if orchestrator is None:
        logger.warning("[idle] Orchestrator not available in app.state")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={
                "error": "Idle orchestrator not available",
                "message": "The idle orchestrator service is not running or not configured",
                "available": False,
            },
        )

    return orchestrator


# ============================================================================
# API ENDPOINTS
# ============================================================================


@router.get("/status", response_model=StatusResponse)
async def get_status(request: Request):
    """
    Get current idle orchestrator status.

    Returns comprehensive status including:
    - Configuration (enabled, dry_run, thresholds)
    - Runtime state (running, is_idle, last_activity)
    - Metrics (cycles, tasks executed, uptime)
    - Recent results (last 10 task executions)

    Returns:
        StatusResponse with orchestrator status

    Raises:
        HTTPException: 503 if orchestrator not available
    """
    try:
        orchestrator = get_orchestrator(request)
        status_data = orchestrator.status()

        return StatusResponse(success=True, data=status_data.to_dict(), message="Idle orchestrator status retrieved successfully")

    except HTTPException:
        # Re-raise HTTP exceptions (like 503)
        raise
    except Exception as e:
        logger.error(f"[idle] Error getting status: {e}", exc_info=True)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Failed to get orchestrator status: {str(e)}")


@router.post("/run-once", response_model=RunOnceResponse)
async def run_once(request: Request, body: RunOnceRequest = RunOnceRequest()):
    """
    Manually trigger one idle task cycle.

    Useful for:
    - Testing idle workflows
    - Manual maintenance operations
    - Cron-triggered maintenance

    By default, only runs if system is idle. Use force=true to override.

    Args:
        body: Request with force flag

    Returns:
        RunOnceResponse with task execution results

    Raises:
        HTTPException: 503 if orchestrator not available
        HTTPException: 400 if system not idle and force=false
    """
    try:
        orchestrator = get_orchestrator(request)

        # Check if orchestrator is enabled
        if not orchestrator.enabled:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Idle orchestrator is disabled. Enable it first with /toggle endpoint.")

        # Execute task cycle
        logger.info(f"[idle] API: Manual trigger requested (force={body.force})")
        results = await orchestrator.run_once(force=body.force)

        # Build response
        result_count = len(results)
        executed = sum(1 for r in results if r.status.value in ["success", "failed"])
        skipped = sum(1 for r in results if r.status.value == "skipped")
        failed = sum(1 for r in results if r.status.value == "failed")

        message = f"Executed {result_count} tasks: {executed} ran, {skipped} skipped, {failed} failed"

        return RunOnceResponse(success=True, results=[r.to_dict() for r in results], message=message)

    except HTTPException:
        # Re-raise HTTP exceptions
        raise
    except Exception as e:
        logger.error(f"[idle] Error in run-once: {e}", exc_info=True)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Failed to execute idle cycle: {str(e)}")


@router.post("/toggle", response_model=ToggleResponse)
async def toggle_config(request: Request, body: ToggleConfigRequest):
    """
    Update idle orchestrator configuration at runtime.

    Allows dynamic configuration changes without restart:
    - Enable/disable orchestrator
    - Toggle dry-run mode
    - Adjust idle threshold
    - Change loop interval

    Changes take effect immediately.

    Args:
        body: Configuration updates

    Returns:
        ToggleResponse with updated configuration

    Raises:
        HTTPException: 503 if orchestrator not available
        HTTPException: 400 if invalid configuration values
    """
    try:
        orchestrator = get_orchestrator(request)

        # Track what changed
        updates = {}

        if body.enabled is not None:
            updates["enabled"] = body.enabled
        if body.dry_run is not None:
            updates["dry_run"] = body.dry_run
        if body.idle_threshold_seconds is not None:
            updates["idle_threshold_seconds"] = body.idle_threshold_seconds
        if body.loop_interval_seconds is not None:
            updates["loop_interval_seconds"] = body.loop_interval_seconds

        if not updates:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="No configuration changes provided")

        # Apply updates
        logger.info(f"[idle] API: Configuration update requested: {updates}")
        orchestrator.update_config(**updates)

        # Get new status
        new_status = orchestrator.status()

        return ToggleResponse(success=True, updated=updates, message=f"Configuration updated successfully: {', '.join(updates.keys())}")

    except HTTPException:
        # Re-raise HTTP exceptions
        raise
    except Exception as e:
        logger.error(f"[idle] Error updating config: {e}", exc_info=True)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Failed to update configuration: {str(e)}")


@router.get("/health")
async def health_check(request: Request):
    """
    Quick health check for idle orchestrator.

    Returns basic availability status without full details.
    Useful for monitoring and health probes.

    Returns:
        Dict with basic health status
    """
    try:
        orchestrator = getattr(request.app.state, "idle_orchestrator", None)

        if orchestrator is None:
            return {"available": False, "enabled": False, "running": False, "message": "Idle orchestrator not configured"}

        return {"available": True, "enabled": orchestrator.enabled, "running": orchestrator._running, "message": "Idle orchestrator is available"}

    except Exception as e:
        logger.error(f"[idle] Error in health check: {e}")
        return {"available": False, "enabled": False, "running": False, "message": f"Error: {str(e)}"}


# ============================================================================
# ROUTER METADATA
# ============================================================================


__all__ = ["router"]
