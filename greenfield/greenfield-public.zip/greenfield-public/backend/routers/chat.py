# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Chat Router

Chat endpoint with command gateway and 6-phase pipeline integration.

Cards:
- CARD-V6B-DELTA-CHAT-GATEWAY (command routing)
- CARD-V6B-DELTA-CHAT-PIPELINE-INTEGRATION (pipeline integration)
"""

import logging
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel
from typing import Optional, Dict, Any

from ..services.chat_command_gateway import ChatCommandGateway, ChatCommandError
from ..services.chat_pipeline_adapter import ChatPipelineAdapter
from ..systems.task_card_system import TaskCardSystem
from ..systems.mc_engine import MCEngine

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/chat", tags=["chat"])

# Initialize services (singleton pattern)
_task_card_system: Optional[TaskCardSystem] = None
_mc_engine: Optional[MCEngine] = None
_chat_pipeline: Optional[ChatPipelineAdapter] = None

def get_task_card_system() -> TaskCardSystem:
    """Get or create TaskCardSystem instance."""
    global _task_card_system
    if _task_card_system is None:
        _task_card_system = TaskCardSystem()
    return _task_card_system

def get_mc_engine() -> MCEngine:
    """Get or create MCEngine instance."""
    global _mc_engine
    if _mc_engine is None:
        _mc_engine = MCEngine()
    return _mc_engine

def get_chat_pipeline() -> ChatPipelineAdapter:
    """Get or create ChatPipelineAdapter instance."""
    global _chat_pipeline
    if _chat_pipeline is None:
        _chat_pipeline = ChatPipelineAdapter()
    return _chat_pipeline

# Initialize gateway with dependencies
gateway = ChatCommandGateway(
    task_card_system=get_task_card_system(),
    mc_engine=get_mc_engine()
)


class ChatRequest(BaseModel):
    """Chat request model."""
    message: str
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    context: Optional[Dict[str, Any]] = None


class ChatResponse(BaseModel):
    """Chat response model."""
    type: str  # "command_result", "chat", "command_error"
    result: Optional[Dict[str, Any]] = None
    error: Optional[Dict[str, Any]] = None


@router.post("", response_model=ChatResponse)
async def chat_endpoint(request: ChatRequest):
    """Chat endpoint with command gateway integration.
    
    Routes commands through gateway, normal chat through existing pipeline.
    
    Args:
        request: Chat request with message and context
        
    Returns:
        ChatResponse with type and result/error
    """
    text = request.message
    context = {
        "user_id": request.user_id or "anonymous",
        "session_id": request.session_id or "default",
        **(request.context or {}),
    }
    
    try:
        # Branch point: Command vs Chat path
        if gateway.is_command(text):
            # Command path: Route through ChatCommandGateway
            logger.info(
                f"Command path: user={context.get('user_id')}, "
                f"session={context.get('session_id')}, command={text[:50]}"
            )
            result = gateway.process(text, context)
            return ChatResponse(
                type="command_result",
                result=result,
            )
        else:
            # Chat path: Route through 6-phase cognitive pipeline
            logger.info(
                f"Chat path: user={context.get('user_id')}, "
                f"session={context.get('session_id')}, message_length={len(text)}"
            )
            pipeline = get_chat_pipeline()
            chat_result = await pipeline.process_chat_message(text, context)
            
            # Ensure consistent response envelope
            return ChatResponse(
                type="chat_response",
                result=chat_result,
            )
    
    except ChatCommandError as e:
        # Command-level error: Return HTTP 200 with structured error
        logger.warning(
            f"Command error: code={e.code}, message={e.message}, "
            f"user={context.get('user_id')}"
        )
        return ChatResponse(
            type="command_error",
            error={
                "message": e.message,
                "code": e.code,
            },
        )
    
    except Exception as e:
        # Pipeline internal error: Return HTTP 5xx with minimal error body
        logger.error(
            f"Pipeline error: {type(e).__name__}: {str(e)}, "
            f"user={context.get('user_id')}, session={context.get('session_id')}",
            exc_info=True
        )
        raise HTTPException(
            status_code=500,
            detail="Internal server error processing chat request",
        )


@router.get("/health")
async def chat_health():
    """Health check for chat service."""
    pipeline = get_chat_pipeline()
    pipeline_ready = pipeline.cognitive_block is not None and (
        hasattr(pipeline.cognitive_block, '_initialized') and 
        pipeline.cognitive_block._initialized
    )
    
    return {
        "status": "healthy",
        "gateway_ready": True,
        "commands_registered": len(gateway.registry),
        "pipeline_ready": pipeline_ready,
    }

