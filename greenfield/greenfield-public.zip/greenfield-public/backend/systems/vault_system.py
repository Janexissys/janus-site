# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Vault System - STMVault/LTMVault management.

The VaultSystem coordinates STMVault and LTMVault operations at the system level.
It manages file read/write/list operations with access control, path validation,
and comprehensive audit logging. This is the system-level coordination layer,
different from VaultBlock which provides the underlying vault infrastructure.

**Card**: CARD-V6B-P1-COMP-VAULT_SYSTEM  
**MC Target**: 8.60  
**Dependencies**: VaultBlock

**Note**: System-level coordination, different from VaultBlock

**Key Responsibilities**:
- Read files from STMVault or LTMVault
- Write files to STMVault or LTMVault
- List files in STMVault or LTMVault
- Enforce vault access controls (authorization checks)
- Validate paths and prevent path traversal attacks
- Track vault operations and unauthorized attempts
- Provide health monitoring

**Sentinel Compliance**:
- Vault Access Controls: Enforces authorization checks for all vault operations (CRITICAL)
- Path Validation: Prevents path traversal attacks (../, ..\\, /etc/, C:\\Windows)
- Data Validation: Validates all inputs (vault_type, file_path, content)
- Audit Logging: Logs all vault operations with authorization status

**Example Usage**:
    ```python
    from systems.vault_system import VaultSystem
    
    vault = VaultSystem(vault_block=vault_block_instance)
    
    # Write file to STMVault
    op_id = vault.write_file(
        vault_type="stm",
        file_path="cards/CARD-123.md",
        content=b"# Card Content"
    )
    
    # Read file from LTMVault
    content = vault.read_file("ltm", "cards/CARD-123.md")
    
    # List files
    files = vault.list_files("stm", "cards/")
    ```
"""

import logging
import re
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

# Import shared PII detector and standardized exceptions
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
from utils.pii_detector import PIIDetector
from utils.exceptions import ValidationError

logger = logging.getLogger(__name__)


@dataclass
class VaultOperation:
    """Vault operation record.
    
    Contains metadata for a vault operation including operation type, vault
    type, path, timestamp, and authorization status.
    
    Attributes:
        operation_id: Unique identifier for the operation.
        operation_type: Type of operation ("read", "write", "list", "delete").
        vault_type: Vault type ("stm" or "ltm").
        path: File or directory path.
        timestamp: Timestamp when operation was performed.
        authorized: Boolean indicating if operation was authorized.
    """
    operation_id: str
    operation_type: str  # "read", "write", "list", "delete"
    vault_type: str  # "stm" or "ltm"
    path: str
    timestamp: float
    authorized: bool


class VaultSystem:
    """Vault System coordinates STMVault/LTMVault operations.
    
    The VaultSystem manages STMVault and LTMVault operations at the system level,
    coordinating with VaultBlock for file operations. It enforces access controls,
    validates paths, and tracks unauthorized attempts.
    """
    
    def __init__(self, vault_block: Optional[Any] = None) -> None:
        """Initialize vault system.
        
        Initializes the VaultSystem with an optional VaultBlock instance. Sets
        up internal state for operation tracking, statistics, and audit logging.
        
        Args:
            vault_block: Optional VaultBlock instance for vault operations.
        """
        self._vault_block: Optional[Any] = vault_block
        self._operation_count: int = 0
        self._stm_operations: int = 0
        self._ltm_operations: int = 0
        self._unauthorized_attempts: int = 0
        self._audit_log: List[Dict[str, Any]] = []
    
    def read_file(
        self,
        vault_type: str,
        file_path: str
    ) -> bytes:
        """Read file from vault.
        
        Reads a file from STMVault or LTMVault. Performs authorization check and
        path validation before reading. This is a Sentinel compliance check for
        Vault Access Controls (CRITICAL).
        
        Args:
            vault_type: Vault type ("stm" or "ltm").
            file_path: File path within the vault.
        
        Returns:
            File content as bytes.
        
        Raises:
            ValidationError: If vault_type is invalid, authorization fails, or
                path validation fails.
        
        Example:
            ```python
            content = vault.read_file("stm", "cards/CARD-123.md")
            ```
        """
        # SENTINEL: Data Validation
        if vault_type not in ["stm", "ltm"]:
            raise ValidationError(
                f"Vault System: Read File - Invalid vault_type: {vault_type}",
                component="VaultSystem",
                context={"vault_type": vault_type, "file_path": file_path, "valid_types": ["stm", "ltm"]}
            )
        
        # SENTINEL: Vault Access Controls (CRITICAL) - Authorization check
        if not self._check_authorization("read", vault_type, file_path):
            self._unauthorized_attempts += 1
            raise ValidationError(
                f"Vault System: Read File - Unauthorized access to {vault_type}:{file_path}",
                component="VaultSystem",
                context={"operation": "read", "vault_type": vault_type, "file_path": file_path}
            )
        
        operation_id = f"read_{int(time.time() * 1000)}"
        
        # Use VaultBlock if available
        if self._vault_block:
            content = self._vault_block.read_file(vault_type, file_path)
        else:
            content = b""  # Mock for greenfield
        
        self._operation_count += 1
        if vault_type == "stm":
            self._stm_operations += 1
        else:
            self._ltm_operations += 1
        
        # SENTINEL: Audit Logging
        self._log_operation(operation_id, "read", vault_type, file_path, True)
        
        return content
    
    def write_file(
        self,
        vault_type: str,
        file_path: str,
        content: bytes
    ) -> str:
        """Write file to vault.
        
        Writes a file to STMVault or LTMVault. Performs authorization check and
        path validation before writing. This is a Sentinel compliance check for
        Vault Access Controls (CRITICAL).
        
        Args:
            vault_type: Vault type ("stm" or "ltm").
            file_path: File path within the vault.
            content: File content as bytes.
        
        Returns:
            Operation ID string for the write operation.
        
        Raises:
            ValidationError: If vault_type is invalid, authorization fails, or
                path validation fails.
        
        Example:
            ```python
            op_id = vault.write_file(
                "stm",
                "cards/CARD-123.md",
                b"# Card Content"
            )
            ```
        """
        # SENTINEL: Data Validation
        if vault_type not in ["stm", "ltm"]:
            raise ValidationError(
                f"Vault System: Write File - Invalid vault_type: {vault_type}",
                component="VaultSystem",
                context={"vault_type": vault_type, "file_path": file_path, "valid_types": ["stm", "ltm"]}
            )
        
        # SENTINEL: Vault Access Controls (CRITICAL) - Authorization check
        if not self._check_authorization("write", vault_type, file_path):
            self._unauthorized_attempts += 1
            raise ValidationError(
                f"Vault System: Write File - Unauthorized write to {vault_type}:{file_path}",
                component="VaultSystem",
                context={"operation": "write", "vault_type": vault_type, "file_path": file_path}
            )
        
        # SENTINEL: PII Detection - Detect PII in file content
        if self._detect_pii(content):
            logger.warning(f"PII detected in file write: {file_path}")

        operation_id = f"write_{int(time.time() * 1000)}"
        
        # Use VaultBlock if available
        if self._vault_block:
            self._vault_block.write_file(vault_type, file_path, content)
        
        self._operation_count += 1
        if vault_type == "stm":
            self._stm_operations += 1
        else:
            self._ltm_operations += 1
        
        # SENTINEL: Audit Logging
        self._log_operation(operation_id, "write", vault_type, file_path, True)
        
        return operation_id
    
    def list_files(
        self,
        vault_type: str,
        directory: str = ""
    ) -> List[str]:
        """List files in vault.
        
        Lists files in STMVault or LTMVault directory. Performs authorization check
        and path validation before listing. This is a Sentinel compliance check for
        Vault Access Controls (CRITICAL).
        
        Args:
            vault_type: Vault type ("stm" or "ltm").
            directory: Directory path within the vault (default: "" for root).
        
        Returns:
            List of file path strings.
        
        Raises:
            ValidationError: If vault_type is invalid, authorization fails, or
                path validation fails.
        
        Example:
            ```python
            files = vault.list_files("stm", "cards/")
            ```
        """
        # SENTINEL: Data Validation
        if vault_type not in ["stm", "ltm"]:
            raise ValidationError(
                f"Vault System: List Files - Invalid vault_type: {vault_type}",
                component="VaultSystem",
                context={"vault_type": vault_type, "directory": directory, "valid_types": ["stm", "ltm"]}
            )
        
        # SENTINEL: Vault Access Controls (CRITICAL) - Authorization check
        if not self._check_authorization("list", vault_type, directory):
            self._unauthorized_attempts += 1
            raise ValidationError(
                f"Vault System: List Files - Unauthorized list access to {vault_type}:{directory}",
                component="VaultSystem",
                context={"operation": "list", "vault_type": vault_type, "directory": directory}
            )
        
        operation_id = f"list_{int(time.time() * 1000)}"
        
        # Use VaultBlock if available
        if self._vault_block:
            files = self._vault_block.list_files(vault_type, directory)
        else:
            files = []  # Mock for greenfield
        
        self._operation_count += 1
        
        # SENTINEL: Audit Logging
        self._log_operation(operation_id, "list", vault_type, directory, True)
        
        return files
    
    def _check_authorization(
        self,
        operation: str,
        vault_type: str,
        path: str
    ) -> bool:
        """Check authorization for vault operation.
        
        Performs authorization check for vault operations. Blocks dangerous paths
        (path traversal patterns, system directories). This is a Sentinel compliance
        check for Vault Access Controls (CRITICAL).
        
        Args:
            operation: Operation type ("read", "write", "list", "delete").
            vault_type: Vault type ("stm" or "ltm").
            path: File or directory path to check.
        
        Returns:
            Boolean indicating if operation is authorized (True) or not (False).
        """
        # Simplified authorization check for greenfield
        # In production, this would check user permissions, roles, etc.
        
        # Block dangerous paths
        dangerous_patterns = ["../", "..\\", "/etc/", "C:\\Windows"]
        for pattern in dangerous_patterns:
            if pattern in path:
                return False
        
        return True
    
    def _log_operation(
        self,
        operation_id: str,
        operation_type: str,
        vault_type: str,
        path: str,
        authorized: bool
    ) -> None:
        """Log vault operation.
        
        Creates an audit log entry for vault operations. This is a Sentinel
        compliance check for audit logging.
        
        Args:
            operation_id: Unique identifier of the operation.
            operation_type: Type of operation ("read", "write", "list", "delete").
            vault_type: Vault type ("stm" or "ltm").
            path: File or directory path.
            authorized: Boolean indicating if operation was authorized.
        """
        audit_entry = {
            "operation_id": operation_id,
            "timestamp": time.time(),
            "operation_type": operation_type,
            "vault_type": vault_type,
            "path": path,
            "authorized": authorized
        }
        
        self._audit_log.append(audit_entry)
        logger.info(
            f"Vault {operation_type}: {vault_type}:{path} "
            f"(authorized: {authorized})"
        )
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get system statistics.
        
        Returns operational statistics including total operations, STM/LTM operations,
        unauthorized attempts, and authorization rate.
        
        Returns:
            Dictionary with:
            - total_operations: Total number of vault operations
            - stm_operations: Number of STMVault operations
            - ltm_operations: Number of LTMVault operations
            - unauthorized_attempts: Number of unauthorized access attempts
            - authorization_rate: Rate of authorized operations (authorized / total)
        """
        return {
            "total_operations": self._operation_count,
            "stm_operations": self._stm_operations,
            "ltm_operations": self._ltm_operations,
            "unauthorized_attempts": self._unauthorized_attempts,
            "authorization_rate": (
                (self._operation_count - self._unauthorized_attempts) / self._operation_count 
                if self._operation_count > 0 else 1.0
            )
        }
    
    def get_health(self) -> Dict[str, Any]:
        """Get system health status.
        
        Returns health status based on unauthorized access attempts. Health is
        degraded if any unauthorized attempts are detected.
        
        Returns:
            Dictionary with:
            - status: Health status ("healthy" or "degraded")
            - message: Human-readable status message
            - statistics: Dictionary with operational statistics
        """
        stats = self.get_statistics()
        
        # Health is degraded if unauthorized attempts are high
        if stats["unauthorized_attempts"] > 0:
            status = "degraded"
            message = f"Unauthorized access attempts detected: {stats['unauthorized_attempts']}"
        else:
            status = "healthy"
            message = "Vault System operational"
        
        return {
            "status": status,
            "message": message,
            "statistics": stats
        }
    
    def validate(self, vault_type: str, file_path: str, content: Optional[bytes] = None) -> bool:
        """Validate inputs.
        
        Validates that vault_type, file_path, and content are of correct types
        and non-empty. This is a Sentinel compliance check for data validation.
        
        Args:
            vault_type: Vault type string to validate (must be "stm" or "ltm").
            file_path: File path string to validate (must be non-empty).
            content: Optional bytes content to validate (must be bytes or None).
        
        Returns:
            True if all inputs are valid.
        
        Raises:
            ValidationError: If any input is invalid (wrong type or empty).
        """
        if vault_type not in ["stm", "ltm"]:
            raise ValidationError(
                f"Vault System: Check Authorization - Invalid vault_type: {vault_type} (must be 'stm' or 'ltm')",
                component="VaultSystem",
                context={"vault_type": vault_type, "valid_types": ["stm", "ltm"]}
            )
        
        if not isinstance(file_path, str) or not file_path.strip():
            raise ValidationError(
                "Vault System: Check Authorization - file_path must be a non-empty string",
                component="VaultSystem",
                context={"file_path_type": type(file_path).__name__}
            )
        
        if content is not None and not isinstance(content, bytes):
            raise ValidationError(
                "Vault System: Check Authorization - content must be bytes or None",
                component="VaultSystem",
                context={"content_type": type(content).__name__}
            )
        
        return True
    
    def _detect_pii(self, content: str) -> bool:
        """Detect PII in content.
        
        Scans content for PII patterns using the shared PIIDetector. Converts
        bytes to string if needed. This is a Sentinel compliance check for PII
        detection.
        
        Args:
            content: Content to scan (string or bytes).
        
        Returns:
            Boolean indicating if any PII was detected.
        """
        # Convert bytes to string if needed
        if isinstance(content, bytes):
            content = content.decode('utf-8', errors='ignore')
        
        # Use optimized shared PII detector
        return PIIDetector.detect(content)

