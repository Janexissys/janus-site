# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Assembly Line Processor - Agent crew orchestration.

The AssemblyLineProcessor orchestrates the agent crew through a pipeline workflow.
It processes content through each agent in canonical order (Caretaker → Gardener →
Mercury → Sentinel → Conductor → Scribe), managing handoffs, PII detection, and
error handling. This is the orchestration layer, different from AssemblyLineBlock
which provides the underlying pipeline infrastructure.

**Card**: CARD-V6B-P1-COMP-ASSEMBLY_LINE  
**MC Target**: 8.60  
**Dependencies**: AssemblyLineBlock, AgentBlock

**Note**: This is the orchestration layer, different from AssemblyLineBlock

**Key Responsibilities**:
- Orchestrate agent crew through pipeline workflow
- Process content through canonical agent order (6 agents)
- Manage agent handoffs with security validation
- Detect PII in pipeline input and at each stage
- Track pipeline statistics and health
- Handle errors and failed pipelines
- Provide audit logging for all operations

**Sentinel Compliance**:
- Agent Handoff Security: Validates agent types and handoff security
- PII Detection: Detects PII in pipeline input and at each stage
- Data Validation: Validates all inputs (content, context)
- Error Handling: Handles pipeline failures gracefully
- Audit Logging: Logs all pipeline operations with PII detection status

**Agent Order**:
1. Caretaker (strategic intelligence)
2. Gardener (structural intelligence)
3. Mercury (communication)
4. Sentinel (security/compliance)
5. Conductor (orchestration)
6. Scribe (documentation/reporting)

**Example Usage**:
    ```python
    from systems.assembly_line_processor import AssemblyLineProcessor
    
    processor = AssemblyLineProcessor()
    
    # Process content through pipeline
    result = processor.process_pipeline(
        content="Card description with scope and acceptance criteria",
        context={"project": "greenfield", "phase": "4"}
    )
    
    print(f"Status: {result.status}")
    print(f"Stages: {result.stages_completed}")
    print(f"Duration: {result.duration_seconds:.2f}s")
    ```
"""

import logging
import time
import uuid
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

# Import standardized exceptions
try:
    from utils.exceptions import ValidationError
except ImportError:
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from utils.exceptions import ValidationError

logger = logging.getLogger(__name__)


@dataclass
class PipelineResult:
    """Pipeline processing result.
    
    Contains the result of processing content through the agent pipeline,
    including status, completed stages, final output, timing, and individual
    agent results.
    
    Attributes:
        pipeline_id: Unique identifier for the pipeline execution.
        status: Pipeline status ("completed" or "failed").
        stages_completed: List of agent types that completed successfully.
        final_output: Dictionary with final pipeline output (content, stages, or error).
        processed_at: Timestamp when pipeline processing completed.
        duration_seconds: Total duration of pipeline processing in seconds.
        agent_results: Dictionary mapping agent types to their individual results.
    """
    pipeline_id: str
    status: str
    stages_completed: List[str]
    final_output: Dict[str, Any]
    processed_at: float
    duration_seconds: float
    agent_results: Dict[str, Any]


class AssemblyLineProcessor:
    """Assembly Line Processor orchestrates agent crew through pipeline.
    
    The AssemblyLineProcessor manages the orchestration of the agent crew through
    a canonical pipeline workflow. It processes content sequentially through each
    agent, manages handoffs, detects PII, and tracks statistics.
    
    Attributes:
        AGENT_ORDER: List of agent types in canonical processing order.
    """
    
    # Agent order (from AssemblyLineBlock)
    AGENT_ORDER: List[str] = [
        "caretaker",
        "gardener",
        "mercury",
        "sentinel",
        "conductor",
        "scribe"
    ]
    
    def __init__(self, assembly_line_block: Optional[Any] = None, agent_block: Optional[Any] = None) -> None:
        """Initialize processor.
        
        Initializes the AssemblyLineProcessor with optional AssemblyLineBlock and
        AgentBlock instances. Sets up internal state for pipeline tracking, statistics,
        and audit logging.
        
        Args:
            assembly_line_block: Optional AssemblyLineBlock instance for pipeline processing.
            agent_block: Optional AgentBlock instance for agent management.
        """
        self._assembly_line_block: Optional[Any] = assembly_line_block
        self._agent_block: Optional[Any] = agent_block
        self._pipeline_count: int = 0
        self._successful_pipelines: int = 0
        self._failed_pipelines: int = 0
        self._pii_detections: int = 0
        self._audit_log: List[Dict[str, Any]] = []
        self._processing_history: List[Dict[str, Any]] = []  # Track card processing history
    
    def process_pipeline(
        self,
        content: str,
        context: Optional[Dict[str, Any]] = None
    ) -> PipelineResult:
        """Process content through agent pipeline.
        
        Processes content through the canonical agent pipeline workflow. Detects
        PII, processes through each agent in order (Caretaker → Gardener → Mercury →
        Sentinel → Conductor → Scribe), manages handoffs, and tracks results.
        
        Args:
            content: Content string to process through the pipeline.
            context: Optional dictionary with context information (project, phase, etc.).
        
        Returns:
            PipelineResult object with:
            - pipeline_id: Unique identifier
            - status: "completed" or "failed"
            - stages_completed: List of completed agent types
            - final_output: Dictionary with final output or error
            - processed_at: Completion timestamp
            - duration_seconds: Processing duration
            - agent_results: Dictionary with individual agent results
        
        Raises:
            ValidationError: If content is invalid (not a string or empty).
            Exception: If pipeline processing fails (re-raised after logging).
        
        Example:
            ```python
            result = processor.process_pipeline(
                content="Card with scope and acceptance criteria",
                context={"project": "greenfield"}
            )
            ```
        """
        # SENTINEL: Data Validation
        if not isinstance(content, str) or not content.strip():
            raise ValidationError(
                "Assembly Line: Process Pipeline - content must be a non-empty string",
                component="AssemblyLineProcessor",
                context={"content_type": type(content).__name__, "content_length": len(content) if isinstance(content, str) else None}
            )
        
        pipeline_id = str(uuid.uuid4())
        stages_completed = []
        agent_results = {}
        current_content = content
        
        # SENTINEL: PII Detection
        pii_detected = self._detect_pii(content)
        if pii_detected:
            self._pii_detections += 1
            logger.warning("PII detected in pipeline input")
        
        start_time = time.time()
        
        try:
            # Process through each agent stage
            for agent_type in self.AGENT_ORDER:
                # SENTINEL: Agent Handoff Security
                stage_result = self._process_agent_stage(
                    agent_type,
                    current_content,
                    context or {},
                    pipeline_id
                )
                
                stages_completed.append(agent_type)
                agent_results[agent_type] = stage_result
                
                # Update content for next stage
                if isinstance(stage_result, dict) and "output" in stage_result:
                    current_content = stage_result["output"]
                elif isinstance(stage_result, str):
                    current_content = stage_result
                else:
                    current_content = str(stage_result)
            
            # Pipeline completed successfully
            duration = time.time() - start_time
            result = PipelineResult(
                pipeline_id=pipeline_id,
                status="completed",
                stages_completed=stages_completed,
                final_output={"content": current_content, "stages": stages_completed},
                processed_at=time.time(),
                duration_seconds=duration,
                agent_results=agent_results
            )
            
            self._pipeline_count += 1
            self._successful_pipelines += 1
            
            # Track processing history for card (if card_id in context)
            card_id = (context or {}).get("card_id")
            if card_id:
                self._track_card_processing(card_id, result, stages_completed)
            
            # SENTINEL: Audit Logging
            self._log_audit(pipeline_id, result, pii_detected)
            
            return result
            
        except Exception as e:
            # Pipeline failed
            duration = time.time() - start_time
            result = PipelineResult(
                pipeline_id=pipeline_id,
                status="failed",
                stages_completed=stages_completed,
                final_output={"error": str(e)},
                processed_at=time.time(),
                duration_seconds=duration,
                agent_results=agent_results
            )
            
            self._pipeline_count += 1
            self._failed_pipelines += 1
            
            logger.error(f"Pipeline failed: {pipeline_id} - {e}")
            raise
    
    def _process_agent_stage(
        self,
        agent_type: str,
        content: str,
        context: Dict[str, Any],
        pipeline_id: str
    ) -> Any:
        """Process a single agent stage.
        
        Processes content through a single agent stage. Validates agent type,
        detects PII before handoff, and delegates to AssemblyLineBlock if available
        or simulates processing for greenfield. This is a Sentinel compliance check
        for Agent Handoff Security.
        
        Args:
            agent_type: Agent type string (must be in AGENT_ORDER).
            content: Content string to process.
            context: Dictionary with context information.
            pipeline_id: Unique identifier of the pipeline.
        
        Returns:
            Stage result (dictionary, string, or any type depending on agent).
        
        Raises:
            ValidationError: If agent_type is invalid (not in AGENT_ORDER).
        """
        # SENTINEL: Agent Handoff Security - Validate agent type
        if agent_type not in self.AGENT_ORDER:
            raise ValidationError(
                f"Assembly Line: Process Agent Stage - Invalid agent type: {agent_type}",
                component="AssemblyLineProcessor",
                context={"agent_type": agent_type, "valid_types": list(self.AGENT_ORDER)}
            )
        
        # SENTINEL: PII Detection - Check content before handoff
        pii_detected = self._detect_pii(content)
        if pii_detected:
            logger.warning(f"PII detected before {agent_type} stage")
        
        # Use AssemblyLineBlock if available, otherwise simulate
        if self._assembly_line_block:
            # Delegate to AssemblyLineBlock
            return self._assembly_line_block.process_pipeline({
                "content": content,
                "context": context,
                "pipeline_id": pipeline_id
            })
        else:
            # Simulate agent processing for greenfield
            return f"[{agent_type}] {content}"
    
    def validate(self, content: str, context: Optional[Dict[str, Any]] = None) -> bool:
        """Validate inputs.
        
        Validates that content and context are of correct types and non-empty.
        This is a Sentinel compliance check for data validation.
        
        Args:
            content: Content string to validate (must be non-empty).
            context: Optional dictionary with context (must be dict or None).
        
        Returns:
            True if all inputs are valid.
        
        Raises:
            ValidationError: If content is invalid (not a string or empty) or
                context is invalid (not a dict or None).
        """
        if not isinstance(content, str) or not content.strip():
            raise ValidationError(
                "Assembly Line: Validate - content must be a non-empty string",
                component="AssemblyLineProcessor",
                context={"content_type": type(content).__name__}
            )
        
        if context is not None and not isinstance(context, dict):
            raise ValidationError(
                "Assembly Line: Validate - context must be a dictionary or None",
                component="AssemblyLineProcessor",
                context={"context_type": type(context).__name__}
            )
        
        return True
    
    def _detect_pii(self, text: str) -> bool:
        """Detect PII in text.
        
        Scans text for PII patterns using the shared PIIDetector. This is a
        Sentinel compliance check for PII detection.
        
        Args:
            text: Text string to scan for PII.
        
        Returns:
            Boolean indicating if any PII was detected.
        """
        # Import shared PII detector
        import sys
        from pathlib import Path
        sys.path.insert(0, str(Path(__file__).parent.parent))
        from utils.pii_detector import PIIDetector
        
        # Use optimized shared PII detector
        return PIIDetector.detect(text)
    
    def _log_audit(
        self,
        pipeline_id: str,
        result: PipelineResult,
        pii_detected: bool
    ) -> None:
        """Log audit operation.
        
        Creates an audit log entry for pipeline operations. This is a Sentinel
        compliance check for audit logging.
        
        Args:
            pipeline_id: Unique identifier of the pipeline.
            result: PipelineResult object with processing results.
            pii_detected: Boolean indicating if PII was detected in the pipeline.
        """
        audit_entry = {
            "pipeline_id": pipeline_id,
            "timestamp": result.processed_at,
            "status": result.status,
            "stages_completed": result.stages_completed,
            "duration_seconds": result.duration_seconds,
            "pii_detected": pii_detected
        }
        
        self._audit_log.append(audit_entry)
        logger.info(
            f"Assembly Line processed: {pipeline_id} - "
            f"{result.status} ({len(result.stages_completed)} stages, {result.duration_seconds:.2f}s)"
        )
    
    def _track_card_processing(self, card_id: str, result: PipelineResult, stages_completed: List[str]) -> None:
        """Track card processing history.
        
        Records card processing through the assembly line pipeline for ledger tracking.
        
        Args:
            card_id: Card identifier.
            result: PipelineResult from processing.
            stages_completed: List of completed agent stages.
        """
        # Find existing history entry or create new one
        history_entry = None
        for entry in self._processing_history:
            if entry.get("card_id") == card_id:
                history_entry = entry
                break
        
        if not history_entry:
            history_entry = {
                "card_id": card_id,
                "stages": [],
                "current_stage": 0,
                "status": "pending",
                "last_updated": time.time()
            }
            self._processing_history.append(history_entry)
        
        # Update stages
        for i, agent_type in enumerate(stages_completed):
            # Check if stage already exists
            stage_exists = False
            for stage in history_entry["stages"]:
                if stage.get("agent") == agent_type:
                    # Update existing stage
                    stage["status"] = "completed"
                    stage["completed_at"] = result.processed_at
                    stage_exists = True
                    break
            
            if not stage_exists:
                # Add new stage
                history_entry["stages"].append({
                    "agent": agent_type,
                    "status": "completed",
                    "started_at": result.processed_at - result.duration_seconds + (i * (result.duration_seconds / len(stages_completed))),
                    "completed_at": result.processed_at - result.duration_seconds + ((i + 1) * (result.duration_seconds / len(stages_completed))),
                    "block_reason": None
                })
        
        # Update current stage and status
        history_entry["current_stage"] = len(stages_completed)
        if result.status == "completed":
            history_entry["status"] = "completed"
        elif result.status == "failed":
            history_entry["status"] = "failed"
        else:
            history_entry["status"] = "in_progress"
        
        history_entry["last_updated"] = time.time()
        
        # Keep only last 1000 card processing histories (prevent unbounded growth)
        if len(self._processing_history) > 1000:
            self._processing_history = self._processing_history[-1000:]
    
    def get_processing_history(self, card_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get processing history.
        
        Retrieves card processing history from the assembly line pipeline.
        
        Args:
            card_id: Optional card ID filter. If None, returns all processing histories.
        
        Returns:
            List of processing history dictionaries.
        """
        if card_id:
            return [h for h in self._processing_history if h.get("card_id") == card_id]
        else:
            return list(self._processing_history)
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get processor statistics.
        
        Returns operational statistics including total pipelines, successful/failed
        pipelines, PII detections, and success rate.
        
        Returns:
            Dictionary with:
            - total_pipelines: Total number of pipelines processed
            - successful_pipelines: Number of successful pipelines
            - failed_pipelines: Number of failed pipelines
            - pii_detections: Number of PII detections
            - success_rate: Success rate (successful / total)
        """
        return {
            "total_pipelines": self._pipeline_count,
            "successful_pipelines": self._successful_pipelines,
            "failed_pipelines": self._failed_pipelines,
            "pii_detections": self._pii_detections,
            "success_rate": (
                self._successful_pipelines / self._pipeline_count 
                if self._pipeline_count > 0 else 0.0
            )
        }
    
    def get_health(self) -> Dict[str, Any]:
        """Get processor health status.
        
        Returns health status based on pipeline failure rate. Health is degraded
        if failure rate exceeds 20%.
        
        Returns:
            Dictionary with:
            - status: Health status ("healthy" or "degraded")
            - message: Human-readable status message
            - statistics: Dictionary with operational statistics
        """
        stats = self.get_statistics()
        
        # Health is degraded if failure rate is high
        failure_rate = (
            self._failed_pipelines / self._pipeline_count 
            if self._pipeline_count > 0 else 0.0
        )
        
        if failure_rate > 0.2:  # >20% failure rate
            status = "degraded"
            message = f"High pipeline failure rate: {failure_rate:.1%}"
        else:
            status = "healthy"
            message = "Assembly Line Processor operational"
        
        return {
            "status": status,
            "message": message,
            "statistics": stats
        }

