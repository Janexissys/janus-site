# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Frontend Components - User interface.

The FrontendComponents provides data models and validation for frontend UI components.
It creates view data, validates component props, detects and redacts PII from frontend
data, and provides comprehensive audit logging. This is the backend layer for frontend
data management.

**Card**: CARD-V6B-P1-COMP-FRONTEND  
**MC Target**: 8.50  
**Dependencies**: API Layer

**Note**: For greenfield backend, this provides data models and validation for frontend

**Key Responsibilities**:
- Create view data for frontend rendering
- Validate component props and data
- Detect PII in frontend data (CRITICAL)
- Redact PII from frontend data before rendering
- Track view statistics and health
- Provide audit logging for all operations

**Sentinel Compliance**:
- Frontend Data PII: Detects PII in frontend view data (CRITICAL)
- PII Redaction: Automatically redacts PII from view data before rendering
- Data Validation: Validates all inputs (view_type, data, component_type, props)
- Audit Logging: Logs all frontend operations with PII detection status

**Example Usage**:
    ```python
    from systems.frontend_components import FrontendComponents
    
    frontend = FrontendComponents()
    
    # Create view data
    view = frontend.create_view(
        view_type="dashboard",
        data={"cards": [], "tasks": []}
    )
    
    # Validate component props
    valid, error = frontend.validate_component_props(
        component_type="CardList",
        props={"cards": []}
    )
    ```
"""

import logging
import re
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class UIComponent:
    """UI component definition.
    
    Represents a UI component with type, props, and creation timestamp.
    
    Attributes:
        component_id: Unique identifier for the component.
        component_type: Type of component (e.g., "CardList", "TaskView").
        props: Dictionary with component properties.
        created_at: Timestamp when component was created.
    """
    component_id: str
    component_type: str
    props: Dict[str, Any]
    created_at: float


@dataclass
class ViewData:
    """View data for frontend.
    
    Contains view data for frontend rendering with PII redaction status.
    
    Attributes:
        view_id: Unique identifier for the view.
        view_type: Type of view (e.g., "dashboard", "card_detail", "task_list").
        data: Dictionary with view data (PII redacted if detected).
        rendered_at: Timestamp when view was rendered.
        pii_redacted: Boolean indicating if PII was detected and redacted.
    """
    view_id: str
    view_type: str
    data: Dict[str, Any]
    rendered_at: float
    pii_redacted: bool


class FrontendComponents:
    """Frontend Components provides user interface data models and validation.
    
    The FrontendComponents manages frontend view data, validates component props,
    detects and redacts PII from frontend data, and provides comprehensive audit logging.
    
    Attributes:
        PII_PATTERNS: Dictionary of regex patterns for PII detection.
            Keys are PII types (email, phone, ssn), values are regex patterns.
    """
    
    # PII patterns (SENTINEL: PII Detection)
    PII_PATTERNS: Dict[str, str] = {
        "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        "phone": r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
        "ssn": r'\b\d{3}-\d{2}-\d{4}\b',
    }
    
    def __init__(self) -> None:
        """Initialize FrontendComponents.
        
        Sets up internal state for components, views, PII detection/redaction tracking,
        and audit logging.
        """
        self._components: Dict[str, UIComponent] = {}
        self._views: Dict[str, ViewData] = {}
        self._view_count: int = 0
        self._pii_detections: int = 0
        self._pii_redactions: int = 0
        self._audit_log: List[Dict[str, Any]] = []
        self.task_card_system: Optional[Any] = None
        self.mc_engine: Optional[Any] = None
        self.assembly_line_processor: Optional[Any] = None
        self.agent_block: Optional[Any] = None
        self.telemetry_system: Optional[Any] = None
        self.sentinel_agent: Optional[Any] = None
        self.idle_orchestrator: Optional[Any] = None

    def initialize(self, config: Dict[str, Any]) -> None:
        """Initialize with dependencies.
        
        Args:
            config: Configuration dictionary containing dependencies.
        """
        self.task_card_system = config.get("task_card_system")
        self.mc_engine = config.get("mc_engine")
        self.assembly_line_processor = config.get("assembly_line_processor")
        self.agent_block = config.get("agent_block")
        self.telemetry_system = config.get("telemetry_system")
        self.sentinel_agent = config.get("sentinel_agent")
        self.idle_orchestrator = config.get("idle_orchestrator")
        logger.info("FrontendComponents initialized with dependencies")
    
    def get_cards_board_data(self, project: Optional[str] = None) -> Dict[str, List[Dict[str, Any]]]:
        """Get cards board data.
        
        Retrieves cards from TaskCardSystem and formats them for the frontend.
        
        Args:
            project: Optional project filter.
        
        Returns:
            Dictionary with "cards" list.
        """
        if not self.task_card_system:
            logger.warning("TaskCardSystem not initialized")
            return {"cards": []}
        
        cards = self.task_card_system.list_cards(project=project)
        
        # Convert to dicts and redact PII
        cards_data = []
        for card in cards:
            card_dict = {
                "card_id": card.card_id,
                "title": card.title,
                "content": card.content,
                "status": card.status,
                "mc_score": card.mc_score,
                "created_at": card.created_at,
                "metadata": card.metadata
            }
            
            # Redact PII (Sentinel Requirement)
            # Although TaskCardSystem checks on creation, we should redact on view too
            # if patterns emerge later or if viewing context is different.
            # FrontendComponents responsibility includes redaction.
            
            # Note: _redact_pii handles nested dicts
            redacted_card = self._redact_pii(card_dict)
            cards_data.append(redacted_card)
            
        return {"cards": cards_data}
    
    def get_agent_soul_data(self) -> Dict[str, List[Dict[str, Any]]]:
        """Get agent soul pack data.
        
        Returns agent identities for the Agent Soul Pack view.
        Queries AgentBlock for agent instances and TaskCardSystem for agent cards,
        then merges the data to create complete agent identities.
        
        Returns:
            Dictionary with "agents" list containing AgentIdentity objects.
        """
        agents_list = []
        
        # Get agent cards from TaskCardSystem
        agent_cards = []
        if self.task_card_system:
            try:
                all_cards = self.task_card_system.list_cards(project="v6_greenfield")
                agent_cards = [card for card in all_cards if card.metadata.get("type") == "agent"]
            except Exception as e:
                logger.warning(f"Failed to get agent cards from TaskCardSystem: {e}")
        
        # Get agent instances from AgentBlock
        agent_instances = []
        if self.agent_block:
            try:
                agent_instances = self.agent_block.list_agents()
            except Exception as e:
                logger.warning(f"Failed to get agent instances from AgentBlock: {e}")
        
        # Create a map of agent cards by agent_id (extracted from canonical card_id or title)
        agent_cards_map = {}
        for card in agent_cards:
            # Extract agent_id from canonical card_id in metadata (e.g., "CARD-V6B-P1-AGENT-CARETAKER" -> "caretaker")
            agent_id = None
            # Use canonical card_id from metadata if available, otherwise fall back to UUID card_id
            canonical_card_id = ""
            if card.metadata and "card_id" in card.metadata:
                canonical_card_id = card.metadata["card_id"]
            else:
                canonical_card_id = card.card_id or ""
            
            if "AGENT-" in canonical_card_id.upper():
                parts = canonical_card_id.upper().split("AGENT-")
                if len(parts) > 1:
                    agent_id = parts[1].split("-")[0].lower()
            else:
                # Try to extract from title
                title_lower = (card.title or "").lower()
                for name in ["caretaker", "gardener", "mercury", "sentinel", "conductor", "scribe"]:
                    if name in title_lower:
                        agent_id = name
                        break
            
            if agent_id:
                agent_cards_map[agent_id] = card
        
        # Create agent identities from cards and instances
        # Use canonical agent names
        canonical_agents = ["caretaker", "gardener", "mercury", "sentinel", "conductor", "scribe"]
        
        for agent_id in canonical_agents:
            card = agent_cards_map.get(agent_id)
            instance = next((inst for inst in agent_instances if inst.agent_type == agent_id), None)
            
            # Build agent identity
            # Use canonical card_id from metadata if available, otherwise fall back to UUID card_id
            canonical_card_id = ""
            if card:
                canonical_card_id = card.metadata.get("card_id", "") if card.metadata else ""
                if not canonical_card_id:
                    canonical_card_id = card.card_id  # Fall back to UUID if no canonical ID
            
            agent_identity = {
                "agent_id": agent_id,
                "name": agent_id.capitalize(),
                "title": card.title if card else f"{agent_id.capitalize()} Agent",
                "obsession": card.metadata.get("obsession") if card and card.metadata else "",
                "stays_out_of": card.metadata.get("stays_out_of") if card and card.metadata else "",
                "soul_ref": "CARD-V6B-P0-AGENT-SOUL",
                "implementation_card_id": canonical_card_id,
                "metadata": {
                    "status": instance.status.value if instance else "idle",
                    "config": instance.config if instance else {}
                }
            }
            
            agents_list.append(agent_identity)
        
        return {"agents": agents_list}
    
    def get_assembly_line_data(self) -> Dict[str, List[Dict[str, Any]]]:
        """Get assembly line ledger data.
        
        Returns processing history for the Assembly Line view.
        Queries AssemblyLineProcessor for card processing history through the agent pipeline.
        
        Returns:
            Dictionary with "history" list containing CardProcessingHistory objects.
        """
        history_list = []
        
        if not self.assembly_line_processor:
            logger.warning("AssemblyLineProcessor not initialized")
            return {"history": []}
        
        try:
            # Get processing history from AssemblyLineProcessor
            processing_history = self.assembly_line_processor.get_processing_history()
            
            # Transform to CardProcessingHistory format
            for entry in processing_history:
                card_id = entry.get("card_id", "")
                stages = entry.get("stages", [])
                current_stage = entry.get("current_stage", 0)
                status = entry.get("status", "pending")
                
                # Transform stages to expected format
                transformed_stages = []
                for stage in stages:
                    transformed_stages.append({
                        "agent": stage.get("agent", ""),
                        "status": stage.get("status", "pending"),
                        "started_at": stage.get("started_at"),
                        "completed_at": stage.get("completed_at"),
                        "block_reason": stage.get("block_reason")
                    })
                
                history_item = {
                    "card_id": card_id,
                    "stages": transformed_stages,
                    "current_stage": current_stage,
                    "status": status
                }
                
                history_list.append(history_item)
            
        except Exception as e:
            logger.error(f"Failed to get assembly line data: {e}")
            return {"history": []}
        
        return {"history": history_list}
    
    def get_run_log_data(self, project: Optional[str] = None, type: Optional[str] = None, range: Optional[str] = None) -> Dict[str, List[Dict[str, Any]]]:
        """Get run log events.
        
        Returns run log events for the Run Log view.
        Queries TelemetrySystem for events filtered by project, type, and time range.
        
        Args:
            project: Optional project filter (defaults to "v6_greenfield" if not provided).
            type: Optional event type filter.
            range: Optional time range filter ("last_hour", "today", "all").
        
        Returns:
            Dictionary with "events" list containing RunLogEvent objects.
        """
        events_list = []
        
        if not self.telemetry_system:
            logger.warning("TelemetrySystem not initialized")
            return {"events": []}
        
        # Default to v6_greenfield project if not specified
        project_filter = project or "v6_greenfield"
        
        try:
            # Query events from TelemetrySystem
            telemetry_events = self.telemetry_system.query_events(
                project=project_filter,
                event_type=type,
                time_range=range or "all",
                limit=1000  # Get up to 1000 events
            )
            
            # Transform to RunLogEvent format
            for event in telemetry_events:
                event_type = event.get("event_type", "card_updated")
                event_data = event.get("event_data", {})
                metadata = event.get("metadata", {})
                
                # Normalize event type to RunLogEventType
                normalized_type = self._normalize_event_type(event_type)
                
                # Extract card_id and agent_id from event_data or metadata
                card_id = event_data.get("card_id") or metadata.get("card_id")
                agent_id = event_data.get("agent_id") or metadata.get("agent_id")
                
                # Build description from event_data
                description = event_data.get("description") or event_data.get("message") or f"{event_type} event"
                
                run_log_event = {
                    "id": event.get("event_id", f"event_{int(event.get('timestamp', time.time()) * 1000)}"),
                    "type": normalized_type,
                    "timestamp": event.get("timestamp", time.time()),
                    "card_id": card_id,
                    "agent_id": agent_id,
                    "description": description,
                    "metadata": metadata
                }
                
                events_list.append(run_log_event)
            
        except Exception as e:
            logger.error(f"Failed to get run log events: {e}")
            return {"events": []}
        
        return {"events": events_list}
    
    def get_mc_sentinel_status(self, card_id: str) -> Dict[str, Any]:
        """Get MC and Sentinel status for a card.
        
        Returns MC separation results and Sentinel status for a specific card.
        Queries TaskCardSystem for card MC score and checks Sentinel status.
        
        Args:
            card_id: Card identifier.
        
        Returns:
            Dictionary with MCSeparationResult format.
        """
        if not self.task_card_system:
            logger.warning("TaskCardSystem not initialized")
            return self._default_mc_status()
        
        try:
            # Get card from TaskCardSystem
            card = self.task_card_system.get_card(card_id)
            if not card:
                logger.warning(f"Card not found: {card_id}")
                return self._default_mc_status()
            
            # Get MC score from card
            mc_score = card.mc_score
            mc_gate = 8.50  # Standard gate threshold
            
            # Determine gate result
            gate_result = "pass" if mc_score >= mc_gate else "hold"
            
            # Determine confidence label
            if mc_score >= 8.5:
                confidence_label = "high_confidence"
            elif mc_score >= 7.0:
                confidence_label = "needs_review"
            else:
                confidence_label = "low_confidence"
            
            # Check Sentinel status using SentinelAgent if available
            sentinel_status = "clear"
            card_text = f"{card.title} {card.content}"
            
            if self.sentinel_agent:
                try:
                    # Use SentinelAgent to audit card content
                    audit_result = self.sentinel_agent.audit_content(
                        content=card_text,
                        context={"card_id": card_id, "operation": "mc_status_check"}
                    )
                    
                    # Determine sentinel status from audit result
                    if not audit_result.passed:
                        # Check for critical violations
                        critical_violations = [v for v in audit_result.violations if v.severity.value == "critical"]
                        if critical_violations:
                            sentinel_status = "blocked"
                        else:
                            sentinel_status = "warning"
                    else:
                        sentinel_status = "clear"
                except Exception as e:
                    logger.warning(f"SentinelAgent audit failed: {e}, defaulting to clear")
                    # Fallback to simple PII check
                    try:
                        from utils.pii_detector import PIIDetector
                        if PIIDetector.detect(card_text):
                            sentinel_status = "warning"
                    except Exception:
                        # PII detector import or detection failed - continue with clear status
                        pass
            else:
                # Fallback to simple PII check if SentinelAgent not available
                try:
                    from utils.pii_detector import PIIDetector
                    if PIIDetector.detect(card_text):
                        sentinel_status = "warning"
                except Exception:
                    # Fallback PII check failed - continue with default clear status
                    pass
            
            # Get last drift check from card metadata or updated_at
            last_drift_check = card.metadata.get("last_drift_check") or card.created_at
            
            return {
                "mc_score": mc_score,
                "mc_gate": mc_gate,
                "gate_result": gate_result,
                "confidence_label": confidence_label,
                "sentinel_status": sentinel_status,
                "last_drift_check": last_drift_check
            }
            
        except Exception as e:
            logger.error(f"Failed to get MC/Sentinel status for card {card_id}: {e}")
            return self._default_mc_status()
    
    def _default_mc_status(self) -> Dict[str, Any]:
        """Return default MC status when card not found or error.
        
        Returns:
            Dictionary with default MCSeparationResult values.
        """
        return {
            "mc_score": 0.0,
            "mc_gate": 8.50,
            "gate_result": "hold",
            "confidence_label": "low_confidence",
            "sentinel_status": "clear",
            "last_drift_check": None
        }
    
    def _normalize_event_type(self, event_type: str) -> str:
        """Normalize event type to RunLogEventType.
        
        Maps various event type strings to standard RunLogEventType values.
        
        Args:
            event_type: Raw event type string.
        
        Returns:
            Normalized event type string.
        """
        event_lower = event_type.lower()
        
        if "card_created" in event_lower or "create_card" in event_lower:
            return "card_created"
        elif "card_updated" in event_lower or "update_card" in event_lower:
            return "card_updated"
        elif "mc" in event_lower and ("threshold" in event_lower or "gate" in event_lower):
            return "mc_threshold_crossed"
        elif "sentinel" in event_lower and "block" in event_lower:
            return "sentinel_block"
        elif "soul" in event_lower and "pack" in event_lower:
            return "soul_pack_updated"
        elif "assembly" in event_lower and "line" in event_lower:
            return "assembly_line_run"
        else:
            return "card_updated"  # Default fallback

    def create_view(
        self,
        view_type: str,
        data: Dict[str, Any]
    ) -> ViewData:
        """Create view data for frontend.
        
        Creates view data for frontend rendering. Detects PII in the data and
        automatically redacts it if found. This is a Sentinel compliance check
        for Frontend Data PII (CRITICAL).
        
        Args:
            view_type: View type string (e.g., "dashboard", "card_detail", "task_list").
            data: Dictionary with view data (will be redacted if PII detected).
        
        Returns:
            ViewData object with view_id, view_type, data (PII redacted if detected),
            rendered_at, and pii_redacted flag.
        
        Raises:
            ValueError: If view_type is invalid (not a string or empty) or data
                is not a dictionary.
        
        Example:
            ```python
            view = frontend.create_view(
                view_type="dashboard",
                data={"cards": [], "tasks": []}
            )
            ```
        """
        # SENTINEL: Data Validation
        if not isinstance(view_type, str) or not view_type.strip():
            raise ValueError("view_type must be a non-empty string")
        
        if not isinstance(data, dict):
            raise ValueError("data must be a dictionary")
        
        # SENTINEL: PII Detection - Frontend data PII
        data_str = str(data)
        pii_detected = self._detect_pii(data_str)
        
        # Redact PII if detected
        redacted_data = data
        if pii_detected:
            self._pii_detections += 1
            self._pii_redactions += 1
            redacted_data = self._redact_pii(data)
            logger.warning("PII detected in frontend data - redacted")
        
        view_id = f"view_{int(time.time() * 1000)}"
        view = ViewData(
            view_id=view_id,
            view_type=view_type,
            data=redacted_data,
            rendered_at=time.time(),
            pii_redacted=pii_detected
        )
        
        self._view_count += 1
        
        # SENTINEL: Audit Logging
        self._log_audit("create_view", view_id, {
            "view_type": view_type,
            "pii_detected": pii_detected,
            "pii_redacted": pii_detected
        })
        
        return view
    
    def validate_component_props(
        self,
        component_type: str,
        props: Dict[str, Any]
    ) -> tuple[bool, Optional[str]]:
        """Validate component props.
        
        Validates component props for type correctness and detects PII. This is a
        Sentinel compliance check for data validation and PII detection.
        
        Args:
            component_type: Component type string (e.g., "CardList", "TaskView").
            props: Dictionary with component properties.
        
        Returns:
            Tuple of (valid, error_message):
            - valid: Boolean indicating if props are valid.
            - error_message: Error message string if invalid, None if valid.
        
        Example:
            ```python
            valid, error = frontend.validate_component_props(
                component_type="CardList",
                props={"cards": []}
            )
            ```
        """
        # SENTINEL: Data Validation
        if not isinstance(component_type, str):
            return False, "component_type must be a string"
        
        if not isinstance(props, dict):
            return False, "props must be a dictionary"
        
        # SENTINEL: PII Detection
        props_str = str(props)
        pii_detected = self._detect_pii(props_str)
        if pii_detected:
            self._pii_detections += 1
            logger.warning("PII detected in component props")
            # Don't fail validation, but log warning
        
        return True, None
    
    def _detect_pii(self, text: str) -> bool:
        """Detect PII in text.
        
        Scans text for PII patterns (email, phone, SSN). This is a Sentinel
        compliance check for PII detection.
        
        Args:
            text: Text string to scan for PII.
        
        Returns:
            Boolean indicating if any PII was detected.
        """
        text_lower = text.lower()
        
        for pii_type, pattern in self.PII_PATTERNS.items():
            if re.search(pattern, text_lower, re.IGNORECASE):
                logger.warning(f"PII detected in frontend data: {pii_type}")
                return True
        
        return False
    
    def _redact_pii(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Redact PII from data.
        
        Recursively redacts PII patterns from a data dictionary. Handles nested
        dictionaries and lists. Replaces email, phone, and SSN patterns with placeholders.
        This is a Sentinel compliance check for PII detection and redaction.
        
        Args:
            data: Dictionary with data to redact (may contain nested dictionaries
                and lists).
        
        Returns:
            Dictionary with PII redacted (same structure as input).
        """
        redacted = {}
        for key, value in data.items():
            if isinstance(value, str):
                # Redact PII patterns
                redacted_value = value
                redacted_value = re.sub(
                    r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
                    '[EMAIL_REDACTED]',
                    redacted_value
                )
                redacted_value = re.sub(
                    r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
                    '[PHONE_REDACTED]',
                    redacted_value
                )
                redacted_value = re.sub(
                    r'\b\d{3}-\d{2}-\d{4}\b',
                    '[SSN_REDACTED]',
                    redacted_value
                )
                redacted[key] = redacted_value
            elif isinstance(value, dict):
                redacted[key] = self._redact_pii(value)
            elif isinstance(value, list):
                redacted[key] = [
                    self._redact_pii(item) if isinstance(item, dict) else item
                    for item in value
                ]
            else:
                redacted[key] = value
        
        return redacted
    
    def _log_audit(
        self,
        operation: str,
        entity_id: str,
        details: Dict[str, Any]
    ) -> None:
        """Log audit operation.
        
        Creates an audit log entry for frontend operations. This is a Sentinel
        compliance check for audit logging.
        
        Args:
            operation: Name of the operation (e.g., "create_view", "validate_component_props").
            entity_id: Unique identifier of the entity (view_id, component_id, etc.).
            details: Dictionary with operation details.
        """
        audit_entry = {
            "operation": operation,
            "entity_id": entity_id,
            "timestamp": time.time(),
            "details": details
        }
        
        self._audit_log.append(audit_entry)
        logger.info(f"Frontend {operation}: {entity_id}")
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get system statistics.
        
        Returns operational statistics including total views, PII detections,
        PII redactions, and PII rate.
        
        Returns:
            Dictionary with:
            - total_views: Total number of views created
            - pii_detections: Number of PII detections
            - pii_redactions: Number of PII redactions performed
            - pii_rate: Rate of PII detections (detections / views)
        """
        return {
            "total_views": self._view_count,
            "pii_detections": self._pii_detections,
            "pii_redactions": self._pii_redactions,
            "pii_rate": (
                self._pii_detections / self._view_count 
                if self._view_count > 0 else 0.0
            )
        }
    
    def get_health(self) -> Dict[str, Any]:
        """Get system health status.
        
        Returns health status based on PII detection rate. Health is degraded
        if PII detection rate exceeds 20%.
        
        Returns:
            Dictionary with:
            - status: Health status ("healthy" or "degraded")
            - message: Human-readable status message
            - statistics: Dictionary with operational statistics
        """
        stats = self.get_statistics()
        
        # Health is degraded if PII detection rate is high
        if stats["pii_rate"] > 0.2:  # >20% PII detection rate
            status = "degraded"
            message = f"High PII detection rate: {stats['pii_rate']:.1%}"
        else:
            status = "healthy"
            message = "Frontend Components operational"
        
        return {
            "status": status,
            "message": message,
            "statistics": stats
        }
    
    def get_idle_tasks_status(self) -> Dict[str, Any]:
        """Get idle tasks orchestrator status.
        
        Returns idle orchestrator status and task list for the Idle Tasks view.
        Queries IdleOrchestrator for status and registered tasks.
        
        Returns:
            Dictionary with orchestrator status and task list.
        """
        if not self.idle_orchestrator:
            logger.warning("IdleOrchestrator not initialized")
            return {
                "orchestrator": {
                    "enabled": False,
                    "running": False,
                    "available": False
                },
                "tasks": []
            }
        
        try:
            # Get orchestrator status
            status_obj = self.idle_orchestrator.status()
            status_dict = status_obj.to_dict()
            
            # Get task list from orchestrator
            tasks_list = []
            for task in self.idle_orchestrator.tasks:
                task_dict = {
                    "name": task.name,
                    "description": task.description,
                    "enabled": task.enabled,
                    "interval_seconds": task.interval_seconds,
                    "last_run": task.last_run.isoformat() if task.last_run else None,
                    "last_result": task.last_result.to_dict() if task.last_result else None
                }
                tasks_list.append(task_dict)
            
            return {
                "orchestrator": {
                    "available": True,
                    **status_dict
                },
                "tasks": tasks_list
            }
            
        except Exception as e:
            logger.error(f"Failed to get idle tasks status: {e}")
            return {
                "orchestrator": {
                    "enabled": False,
                    "running": False,
                    "available": False,
                    "error": str(e)
                },
                "tasks": []
            }

