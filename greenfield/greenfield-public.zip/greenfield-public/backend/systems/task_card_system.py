# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Task & Card System - Task and card management.

The TaskCardSystem provides task and card management capabilities for Janus v6.0.
It manages Cards (work items with MC scores) and Tasks (actionable items with
status and priority), with PII detection, lifecycle management, and comprehensive
audit logging.

**Card**: CARD-V6B-P1-COMP-TASK_CARD_SYSTEM  
**MC Target**: 8.55  
**Dependencies**: None (foundational system)

**Key Responsibilities**:
- Create and manage Cards (work items with MC scores)
- Create and manage Tasks (actionable items with status/priority)
- Update task status (pending → in_progress → review → done → removed)
- List tasks with status and priority filters
- Detect PII in card and task data (CRITICAL)
- Track statistics and health
- Provide audit logging for all operations

**Sentinel Compliance**:
- Card Data PII: Detects PII in card title and content (CRITICAL)
- PII Detection: Detects PII in task title and description
- Data Validation: Validates all inputs (title, content, priority, status)
- Audit Logging: Logs all card and task operations with PII detection status

**Task Status Lifecycle**:
- PENDING: Task is pending and not yet started
- IN_PROGRESS: Task is currently being worked on
- REVIEW: Task is in review
- DONE: Task is completed
- REMOVED: Task was removed/cancelled

**Example Usage**:
    ```python
    from systems.task_card_system import TaskCardSystem, TaskStatus
    
    system = TaskCardSystem()
    
    # Create card
    card = system.create_card(
        title="Phase 4 Documentation",
        content="Add comprehensive docstrings",
        mc_score=8.5
    )
    
    # Create task
    task = system.create_task(
        title="Document MCEngine",
        description="Add module, class, and method docstrings",
        priority="P1",
        card_id=card.card_id
    )
    
    # Update task status
    task = system.update_task_status(task.task_id, TaskStatus.IN_PROGRESS)
    ```
"""

import logging
import re
import time
import uuid
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional

from .vault_system import VaultSystem

logger = logging.getLogger(__name__)


class TaskStatus(Enum):
    """Task status.
    
    Task status lifecycle: PENDING → IN_PROGRESS → REVIEW → DONE (or REMOVED).
    
    Attributes:
        PENDING: Task is pending and not yet started.
        IN_PROGRESS: Task is currently being worked on.
        REVIEW: Task is in review.
        DONE: Task is completed.
        REMOVED: Task was removed/cancelled.
    """
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    REVIEW = "review"
    DONE = "done"
    REMOVED = "removed"


@dataclass
class Card:
    """Card definition.
    
    A Card represents a work item with MC score, title, content, and metadata.
    Cards are used for tracking work items and their meta-cognitive scores.
    
    Attributes:
        card_id: Unique identifier for the card.
        title: Human-readable card title.
        content: Card content/description.
        status: Card status string (e.g., "active", "completed").
        mc_score: MC Gate Score (0.0-10.0) for the card.
        created_at: Timestamp when card was created.
        metadata: Dictionary with additional card metadata.
    """
    card_id: str
    title: str
    content: str
    status: str
    mc_score: float
    created_at: float
    metadata: Dict[str, Any]


@dataclass
class Task:
    """Task definition.
    
    A Task represents an actionable item with status, priority, and optional
    association to a Card. Tasks follow a lifecycle: PENDING → IN_PROGRESS →
    REVIEW → DONE (or REMOVED).
    
    Attributes:
        task_id: Unique identifier for the task.
        card_id: Optional identifier of associated card.
        title: Human-readable task title.
        description: Task description/details.
        status: TaskStatus enum value (PENDING, IN_PROGRESS, REVIEW, DONE, REMOVED).
        priority: Priority string (P0, P1, P2, or P3).
        created_at: Timestamp when task was created.
        metadata: Dictionary with additional task metadata.
    """
    task_id: str
    card_id: Optional[str]
    title: str
    description: str
    status: TaskStatus
    priority: str
    created_at: float
    metadata: Dict[str, Any]


class TaskCardSystem:
    """Task & Card System provides task and card management.
    
    The TaskCardSystem manages Cards (work items with MC scores) and Tasks
    (actionable items with status and priority). It detects PII in card and
    task data, manages task lifecycle, and provides comprehensive audit logging.
    
    Attributes:
        PII_PATTERNS: Dictionary of regex patterns for PII detection.
            Keys are PII types (email, phone, ssn), values are regex patterns.
    """
    
    # PII patterns (SENTINEL: PII Detection)
    PII_PATTERNS: Dict[str, str] = {
        "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        "phone": r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
        "ssn": r'\b\d{3}-\d{2}-\d{4}\b',
    }
    
    def __init__(self, vault_system: Optional[VaultSystem] = None) -> None:
        """Initialize TaskCardSystem.
        
        Sets up internal state for cards, tasks, operation tracking, PII detection,
        and audit logging.
        
        Args:
            vault_system: Optional VaultSystem for persistence.
        """
        self._cards: Dict[str, Card] = {}
        self._tasks: Dict[str, Task] = {}
        self._vault_system = vault_system
        self._card_count: int = 0
        self._task_count: int = 0
        self._pii_detections: int = 0
        self._audit_log: List[Dict[str, Any]] = []
    
    def create_card(
        self,
        title: str,
        content: str,
        mc_score: float = 8.0,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Card:
        """Create a card.
        
        Creates a new card with title, content, MC score, and optional metadata.
        Detects PII in card title and content before creating. This is a Sentinel
        compliance check for Card Data PII (CRITICAL).
        
        Args:
            title: Card title string (must be non-empty).
            content: Card content/description string.
            mc_score: MC Gate Score (0.0-10.0) - default: 8.0.
            metadata: Optional dictionary with additional metadata.
        
        Returns:
            Card object with card_id, title, content, status ("active"), mc_score,
            created_at, and metadata.
        
        Raises:
            ValueError: If title is invalid (not a string or empty) or content
                is not a string.
        
        Example:
            ```python
            card = system.create_card(
                title="Phase 4 Documentation",
                content="Add comprehensive docstrings to all components",
                mc_score=8.5,
                metadata={"phase": "4", "priority": "P1"}
            )
            ```
        """
        # SENTINEL: Data Validation
        if not isinstance(title, str) or not title.strip():
            raise ValueError("title must be a non-empty string")
        
        if not isinstance(content, str):
            raise ValueError("content must be a string")
        
        # SENTINEL: PII Detection - Card data PII
        card_text = f"{title} {content}"
        pii_detected = self._detect_pii(card_text)
        if pii_detected:
            self._pii_detections += 1
            logger.warning("PII detected in card - proceeding with caution")
        
        card_id = str(uuid.uuid4())
        card = Card(
            card_id=card_id,
            title=title,
            content=content,
            status="active",
            mc_score=mc_score,
            created_at=time.time(),
            metadata=metadata or {}
        )
        
        self._cards[card_id] = card
        self._card_count += 1
        
        # Persist to vault if available
        if self._vault_system:
            try:
                # Simple JSON persistence for now
                import json
                card_data = {
                    "card_id": card.card_id,
                    "title": card.title,
                    "content": card.content,
                    "status": card.status,
                    "mc_score": card.mc_score,
                    "created_at": card.created_at,
                    "metadata": card.metadata
                }
                content_bytes = json.dumps(card_data, indent=2).encode('utf-8')
                # Store in STM vault under cards/
                self._vault_system.write_file("stm", f"cards/{card_id}.json", content_bytes)
            except Exception as e:
                logger.error(f"Failed to persist card {card_id}: {e}")
        
        # SENTINEL: Audit Logging
        self._log_audit("create_card", card_id, {"pii_detected": pii_detected})
        
        return card
    
    def get_card(self, card_id: str) -> Optional[Card]:
        """Get card by ID.
        
        Retrieves a card by its unique identifier.
        
        Args:
            card_id: Unique identifier of the card to retrieve.
        
        Returns:
            Card object if found, None otherwise.
        """
        return self._cards.get(card_id)
    
    def list_cards(
        self,
        status: Optional[str] = None,
        project: Optional[str] = None
    ) -> List[Card]:
        """List cards with optional filters.
        
        Retrieves cards, optionally filtered by status and/or project.
        
        Args:
            status: Optional status string to filter by.
            project: Optional project string to filter by (currently unused/metadata).
        
        Returns:
            List of Card objects matching the filters (all cards if no filters).
        """
        cards = list(self._cards.values())
        
        if status:
            cards = [c for c in cards if c.status == status]
            
        # Project filtering would check metadata or relations
        # For now, if project is specified, maybe check metadata?
        if project:
             cards = [c for c in cards if c.metadata.get("project") == project or c.metadata.get("source") == project]
        
        return cards

    def create_task(
        self,
        title: str,
        description: str,
        priority: str = "P2",
        card_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Task:
        """Create a task.
        
        Creates a new task with title, description, priority, optional card association,
        and optional metadata. Detects PII in task title and description. This is a
        Sentinel compliance check for PII detection.
        
        Args:
            title: Task title string (must be non-empty).
            description: Task description string.
            priority: Priority string (P0, P1, P2, or P3) - default: "P2".
            card_id: Optional unique identifier of associated card.
            metadata: Optional dictionary with additional metadata.
        
        Returns:
            Task object with task_id, card_id, title, description, status (PENDING),
            priority, created_at, and metadata.
        
        Raises:
            ValueError: If title is invalid (not a string or empty) or priority
                is invalid (not P0, P1, P2, or P3).
        
        Example:
            ```python
            task = system.create_task(
                title="Document MCEngine",
                description="Add comprehensive docstrings",
                priority="P1",
                card_id=card.card_id
            )
            ```
        """
        # SENTINEL: Data Validation
        if not isinstance(title, str) or not title.strip():
            raise ValueError("title must be a non-empty string")
        
        if priority not in ["P0", "P1", "P2", "P3"]:
            raise ValueError(f"Invalid priority: {priority}")
        
        # SENTINEL: PII Detection
        task_text = f"{title} {description}"
        pii_detected = self._detect_pii(task_text)
        if pii_detected:
            self._pii_detections += 1
            logger.warning("PII detected in task - proceeding with caution")
        
        task_id = str(uuid.uuid4())
        task = Task(
            task_id=task_id,
            card_id=card_id,
            title=title,
            description=description,
            status=TaskStatus.PENDING,
            priority=priority,
            created_at=time.time(),
            metadata=metadata or {}
        )
        
        self._tasks[task_id] = task
        self._task_count += 1
        
        # SENTINEL: Audit Logging
        self._log_audit("create_task", task_id, {"pii_detected": pii_detected})
        
        return task
    
    def update_task_status(
        self,
        task_id: str,
        status: TaskStatus
    ) -> Task:
        """Update task status.
        
        Updates the status of a task. This is a Sentinel compliance check for
        data validation and audit logging.
        
        Args:
            task_id: Unique identifier of the task to update.
            status: New TaskStatus enum value.
        
        Returns:
            Updated Task object with new status.
        
        Raises:
            ValueError: If task_id is not found.
        
        Example:
            ```python
            task = system.update_task_status(task.task_id, TaskStatus.IN_PROGRESS)
            ```
        """
        # SENTINEL: Data Validation
        if task_id not in self._tasks:
            raise ValueError(f"Task not found: {task_id}")
        
        task = self._tasks[task_id]
        task.status = status
        
        # SENTINEL: Audit Logging
        self._log_audit("update_task_status", task_id, {"status": status.value})
        
        return task
    
    def get_task(self, task_id: str) -> Optional[Task]:
        """Get task by ID.
        
        Retrieves a task by its unique identifier.
        
        Args:
            task_id: Unique identifier of the task to retrieve.
        
        Returns:
            Task object if found, None otherwise.
        """
        return self._tasks.get(task_id)
    
    def list_tasks(
        self,
        status: Optional[TaskStatus] = None,
        priority: Optional[str] = None
    ) -> List[Task]:
        """List tasks with optional filters.
        
        Retrieves tasks, optionally filtered by status and/or priority.
        
        Args:
            status: Optional TaskStatus enum to filter by.
            priority: Optional priority string (P0, P1, P2, P3) to filter by.
        
        Returns:
            List of Task objects matching the filters (all tasks if no filters).
        """
        tasks = list(self._tasks.values())
        
        if status:
            tasks = [t for t in tasks if t.status == status]
        
        if priority:
            tasks = [t for t in tasks if t.priority == priority]
        
        return tasks
    
    def _detect_pii(self, text: str) -> bool:
        """Detect PII in text.
        
        Scans text for PII patterns (email, phone, SSN). This is a Sentinel
        compliance check for PII detection.
        
        Args:
            text: Text string to scan for PII.
        
        Returns:
            Boolean indicating if any PII was detected.
        """
        text_lower = text.lower()
        
        for pii_type, pattern in self.PII_PATTERNS.items():
            if re.search(pattern, text_lower, re.IGNORECASE):
                logger.warning(f"PII detected in task/card: {pii_type}")
                return True
        
        return False
    
    def _log_audit(
        self,
        operation: str,
        entity_id: str,
        details: Dict[str, Any]
    ) -> None:
        """Log audit operation.
        
        Creates an audit log entry for task and card operations. This is a Sentinel
        compliance check for audit logging.
        
        Args:
            operation: Name of the operation (e.g., "create_card", "create_task", "update_task_status").
            entity_id: Unique identifier of the entity (card_id, task_id, etc.).
            details: Dictionary with operation details.
        """
        audit_entry = {
            "operation": operation,
            "entity_id": entity_id,
            "timestamp": time.time(),
            "details": details
        }
        
        self._audit_log.append(audit_entry)
        logger.info(f"TaskCard {operation}: {entity_id}")
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get system statistics.
        
        Returns operational statistics including total cards, total tasks, PII
        detections, and tasks grouped by status.
        
        Returns:
            Dictionary with:
            - total_cards: Total number of cards created
            - total_tasks: Total number of tasks created
            - pii_detections: Number of PII detections
            - tasks_by_status: Dictionary mapping TaskStatus values to counts
        """
        return {
            "total_cards": self._card_count,
            "total_tasks": self._task_count,
            "pii_detections": self._pii_detections,
            "tasks_by_status": {
                status.value: sum(1 for t in self._tasks.values() if t.status == status)
                for status in TaskStatus
            }
        }
    
    def get_health(self) -> Dict[str, Any]:
        """Get system health status.
        
        Returns health status based on PII detection rate. Health is degraded
        if PII detection rate exceeds 20%.
        
        Returns:
            Dictionary with:
            - status: Health status ("healthy" or "degraded")
            - message: Human-readable status message
            - statistics: Dictionary with operational statistics
        """
        stats = self.get_statistics()
        
        # Health is degraded if PII detection rate is high
        total_entities = self._card_count + self._task_count
        pii_rate = (
            self._pii_detections / total_entities 
            if total_entities > 0 else 0.0
        )
        
        if pii_rate > 0.2:  # >20% PII detection rate
            status = "degraded"
            message = f"High PII detection rate: {pii_rate:.1%}"
        else:
            status = "healthy"
            message = "Task & Card System operational"
        
        return {
            "status": status,
            "message": message,
            "statistics": stats
        }

