# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Memory System (STM/LTM) - STM/LTM memory coordination.

The MemorySystem coordinates STM (Short-Term Memory) and LTM (Long-Term Memory)
operations at the system level. It manages memory storage, retrieval, and promotion
with PII detection, MC score validation, and comprehensive audit logging. This is
the system-level coordination layer, different from MemoryBlock which provides the
underlying memory infrastructure.

**Card**: CARD-V6B-P1-COMP-MEMORY_SYSTEM  
**MC Target**: 8.65  
**Dependencies**: MemoryBlock, VaultBlock

**Note**: System-level coordination, different from MemoryBlock

**Key Responsibilities**:
- Store content in STM (Short-Term Memory)
- Store content in LTM (Long-Term Memory)
- Promote STM content to LTM (requires MC score >= 8.5)
- Retrieve content from STM or LTM
- Detect PII in memory storage (CRITICAL)
- Track memory operations and statistics
- Provide health monitoring

**Sentinel Compliance**:
- PII Detection: Detects PII in memory storage (CRITICAL - warns but proceeds)
- MC Score Validation: Validates MC score >= 8.5 for LTM promotion
- Data Validation: Validates all inputs (content, content_id, metadata)
- Audit Logging: Logs all memory operations with PII detection status

**Example Usage**:
    ```python
    from systems.memory_system import MemorySystem
    
    memory = MemorySystem(memory_block=memory_block_instance)
    
    # Store in STM
    op_id = memory.store_stm(
        content_id="CARD-123",
        content="Card description",
        metadata={"project": "greenfield"}
    )
    
    # Promote to LTM (requires MC score >= 8.5)
    promote_id = memory.promote_to_ltm("CARD-123", mc_score=8.7)
    
    # Retrieve from LTM
    content = memory.retrieve("CARD-123", memory_type="ltm")
    ```
"""

import logging
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

# Import standardized exceptions
try:
    from utils.exceptions import ValidationError
except ImportError:
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from utils.exceptions import ValidationError

logger = logging.getLogger(__name__)


@dataclass
class MemoryOperation:
    """Memory operation record.
    
    Contains metadata for a memory operation including operation type, memory
    type, content identifier, timestamp, and PII detection status.
    
    Attributes:
        operation_id: Unique identifier for the operation.
        operation_type: Type of operation ("store_stm", "store_ltm", "retrieve", "promote").
        memory_type: Memory type ("stm" or "ltm").
        content_id: Unique identifier of the content.
        timestamp: Timestamp when operation was performed.
        pii_detected: Boolean indicating if PII was detected in the content.
    """
    operation_id: str
    operation_type: str  # "store_stm", "store_ltm", "retrieve", "promote"
    memory_type: str  # "stm" or "ltm"
    content_id: str
    timestamp: float
    pii_detected: bool


class MemorySystem:
    """Memory System coordinates STM/LTM memory operations.
    
    The MemorySystem manages STM/LTM memory operations at the system level,
    coordinating with MemoryBlock and VaultBlock for storage and retrieval.
    It enforces MC score thresholds for promotion and detects PII in all
    memory operations.
    """
    
    def __init__(self, memory_block: Optional[Any] = None, vault_block: Optional[Any] = None) -> None:
        """Initialize memory system.
        
        Initializes the MemorySystem with optional MemoryBlock and VaultBlock
        instances. Sets up internal state for operation tracking, statistics,
        and audit logging.
        
        Args:
            memory_block: Optional MemoryBlock instance for memory operations.
            vault_block: Optional VaultBlock instance for vault operations.
        """
        self._memory_block: Optional[Any] = memory_block
        self._vault_block: Optional[Any] = vault_block
        self._operation_count: int = 0
        self._stm_operations: int = 0
        self._ltm_operations: int = 0
        self._promotions: int = 0
        self._pii_detections: int = 0
        self._audit_log: List[Dict[str, Any]] = []
    
    def store_stm(
        self,
        content_id: str,
        content: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> str:
        """Store content in STM.
        
        Stores content in Short-Term Memory (STM). Detects PII before storage
        and logs warnings if detected. This is a Sentinel compliance check for
        PII in memory storage (CRITICAL).
        
        Args:
            content_id: Unique identifier for the content.
            content: Content string to store in STM.
            metadata: Optional dictionary with additional metadata.
        
        Returns:
            Operation ID string for the storage operation.
        
        Raises:
            ValidationError: If content is invalid (not a string or empty).
        
        Example:
            ```python
            op_id = memory.store_stm(
                content_id="CARD-123",
                content="Card description",
                metadata={"project": "greenfield"}
            )
            ```
        """
        # SENTINEL: Data Validation
        if not isinstance(content, str) or not content.strip():
            raise ValidationError(
                "Memory System: Store STM - content must be a non-empty string",
                component="MemorySystem",
                context={"content_id": content_id, "content_type": type(content).__name__}
            )
        
        # SENTINEL: PII Detection - PII in memory storage (CRITICAL)
        pii_detected = self._detect_pii(content)
        if pii_detected:
            self._pii_detections += 1
            logger.warning("PII detected in STM storage - proceeding with caution")
        
        operation_id = f"stm_{int(time.time() * 1000)}"
        
        # Use MemoryBlock if available
        if self._memory_block:
            self._memory_block.store_memory(
                content_id=content_id,
                content=content,
                memory_type="stm",
                metadata=metadata
            )
        
        self._operation_count += 1
        self._stm_operations += 1
        
        # SENTINEL: Audit Logging
        self._log_operation(operation_id, "store_stm", "stm", content_id, pii_detected)
        
        return operation_id
    
    def store_ltm(
        self,
        content_id: str,
        content: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> str:
        """Store content in LTM.
        
        Stores content directly in Long-Term Memory (LTM). Detects PII before
        storage and logs warnings if detected. This is a Sentinel compliance check
        for PII in memory storage (CRITICAL).
        
        Args:
            content_id: Unique identifier for the content.
            content: Content string to store in LTM.
            metadata: Optional dictionary with additional metadata.
        
        Returns:
            Operation ID string for the storage operation.
        
        Raises:
            ValidationError: If content is invalid (not a string or empty).
        
        Example:
            ```python
            op_id = memory.store_ltm(
                content_id="CARD-123",
                content="High-quality card with MC score >= 8.5",
                metadata={"project": "greenfield", "mc_score": 8.7}
            )
            ```
        """
        # SENTINEL: Data Validation
        if not isinstance(content, str) or not content.strip():
            raise ValidationError(
                "Memory System: Store STM - content must be a non-empty string",
                component="MemorySystem",
                context={"content_id": content_id, "content_type": type(content).__name__}
            )
        
        # SENTINEL: PII Detection - PII in memory storage (CRITICAL)
        pii_detected = self._detect_pii(content)
        if pii_detected:
            self._pii_detections += 1
            logger.warning("PII detected in LTM storage - proceeding with caution")
        
        operation_id = f"ltm_{int(time.time() * 1000)}"
        
        # Use MemoryBlock if available
        if self._memory_block:
            self._memory_block.store_memory(
                content_id=content_id,
                content=content,
                memory_type="ltm",
                metadata=metadata
            )
        
        self._operation_count += 1
        self._ltm_operations += 1
        
        # SENTINEL: Audit Logging
        self._log_operation(operation_id, "store_ltm", "ltm", content_id, pii_detected)
        
        return operation_id
    
    def promote_to_ltm(
        self,
        content_id: str,
        mc_score: float
    ) -> str:
        """Promote STM content to LTM.
        
        Promotes content from STM to LTM. Requires MC score >= 8.5 for promotion.
        This enforces the MC threshold for LTM storage. This is a Sentinel compliance
        check for MC score validation.
        
        Args:
            content_id: Unique identifier of the content to promote.
            mc_score: MC Gate Score (must be >= 8.5 for promotion).
        
        Returns:
            Operation ID string for the promotion operation.
        
        Raises:
            ValidationError: If mc_score < 8.5 (below promotion threshold).
        
        Example:
            ```python
            promote_id = memory.promote_to_ltm("CARD-123", mc_score=8.7)
            ```
        """
        # SENTINEL: Data Validation
        if mc_score < 8.5:
            raise ValidationError(
                f"Memory System: Promote to LTM - MC score {mc_score} too low for LTM promotion (requires >= 8.5)",
                component="MemorySystem",
                context={"content_id": content_id, "mc_score": mc_score, "min_score": 8.5}
            )
        
        operation_id = f"promote_{int(time.time() * 1000)}"
        
        # Use MemoryBlock if available
        if self._memory_block:
            self._memory_block.promote_to_ltm(content_id, mc_score)
        
        self._operation_count += 1
        self._promotions += 1
        
        # SENTINEL: Audit Logging
        self._log_operation(operation_id, "promote", "ltm", content_id, False)
        
        return operation_id
    
    def retrieve(
        self,
        content_id: str,
        memory_type: str = "stm"
    ) -> Optional[str]:
        """Retrieve content from memory.
        
        Retrieves content from STM or LTM by content_id. This is a Sentinel
        compliance check for data validation.
        
        Args:
            content_id: Unique identifier of the content to retrieve.
            memory_type: Memory type ("stm" or "ltm") - default: "stm".
        
        Returns:
            Content string if found, None otherwise.
        
        Raises:
            ValidationError: If memory_type is invalid (not "stm" or "ltm").
        """
        # SENTINEL: Data Validation
        if memory_type not in ["stm", "ltm"]:
            raise ValidationError(
                f"Memory System: Retrieve - Invalid memory_type: {memory_type}",
                component="MemorySystem",
                context={"memory_type": memory_type, "valid_types": ["stm", "ltm"]}
            )
        
        # Use MemoryBlock if available
        if self._memory_block:
            return self._memory_block.retrieve_memory(content_id, memory_type)
        
        return None
    
    def validate(self, content: str, content_id: str, metadata: Optional[Dict[str, Any]] = None) -> bool:
        """Validate inputs.
        
        Validates that content, content_id, and metadata are of correct types
        and non-empty. This is a Sentinel compliance check for data validation.
        
        Args:
            content: Content string to validate (must be non-empty).
            content_id: Content identifier string to validate (must be non-empty).
            metadata: Optional dictionary with metadata (must be dict or None).
        
        Returns:
            True if all inputs are valid.
        
        Raises:
            ValidationError: If any input is invalid (wrong type or empty).
        """
        if not isinstance(content, str) or not content.strip():
            raise ValidationError(
                "Memory System: Store STM - content must be a non-empty string",
                component="MemorySystem",
                context={"content_id": content_id, "content_type": type(content).__name__}
            )
        
        if not isinstance(content_id, str) or not content_id.strip():
            raise ValidationError(
                "Memory System: Validate - content_id must be a non-empty string",
                component="MemorySystem",
                context={"content_id_type": type(content_id).__name__}
            )
        
        if metadata is not None and not isinstance(metadata, dict):
            raise ValidationError(
                "Memory System: Validate - metadata must be a dictionary or None",
                component="MemorySystem",
                context={"metadata_type": type(metadata).__name__}
            )
        
        return True
    
    def _detect_pii(self, content: str) -> bool:
        """Detect PII in content.
        
        Scans content for PII patterns using the shared PIIDetector. This is a
        Sentinel compliance check for PII detection.
        
        Args:
            content: Content string to scan for PII.
        
        Returns:
            Boolean indicating if any PII was detected.
        """
        # Import shared PII detector
        import sys
        from pathlib import Path
        sys.path.insert(0, str(Path(__file__).parent.parent))
        from utils.pii_detector import PIIDetector
        
        # Use optimized shared PII detector
        return PIIDetector.detect(content)
    
    def _log_operation(
        self,
        operation_id: str,
        operation_type: str,
        memory_type: str,
        content_id: str,
        pii_detected: bool
    ) -> None:
        """Log memory operation.
        
        Creates an audit log entry for memory operations. This is a Sentinel
        compliance check for audit logging.
        
        Args:
            operation_id: Unique identifier of the operation.
            operation_type: Type of operation ("store_stm", "store_ltm", "retrieve", "promote").
            memory_type: Memory type ("stm" or "ltm").
            content_id: Unique identifier of the content.
            pii_detected: Boolean indicating if PII was detected.
        """
        audit_entry = {
            "operation_id": operation_id,
            "timestamp": time.time(),
            "operation_type": operation_type,
            "memory_type": memory_type,
            "content_id": content_id,
            "pii_detected": pii_detected
        }
        
        self._audit_log.append(audit_entry)
        logger.info(
            f"Memory {operation_type}: {content_id} -> {memory_type} "
            f"(PII: {pii_detected})"
        )
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get system statistics.
        
        Returns operational statistics including total operations, STM/LTM operations,
        promotions, PII detections, and PII rate.
        
        Returns:
            Dictionary with:
            - total_operations: Total number of memory operations
            - stm_operations: Number of STM operations
            - ltm_operations: Number of LTM operations
            - promotions: Number of STM-to-LTM promotions
            - pii_detections: Number of PII detections
            - pii_rate: Rate of PII detections (detections / operations)
        """
        return {
            "total_operations": self._operation_count,
            "stm_operations": self._stm_operations,
            "ltm_operations": self._ltm_operations,
            "promotions": self._promotions,
            "pii_detections": self._pii_detections,
            "pii_rate": (
                self._pii_detections / self._operation_count 
                if self._operation_count > 0 else 0.0
            )
        }
    
    def get_health(self) -> Dict[str, Any]:
        """Get system health status.
        
        Returns health status based on PII detection rate. Health is degraded
        if PII detection rate exceeds 20%.
        
        Returns:
            Dictionary with:
            - status: Health status ("healthy" or "degraded")
            - message: Human-readable status message
            - statistics: Dictionary with operational statistics
        """
        stats = self.get_statistics()
        
        # Health is degraded if PII detection rate is high
        if stats["pii_rate"] > 0.2:  # >20% PII detection rate
            status = "degraded"
            message = f"High PII detection rate: {stats['pii_rate']:.1%}"
        else:
            status = "healthy"
            message = "Memory System operational"
        
        return {
            "status": status,
            "message": message,
            "statistics": stats
        }

