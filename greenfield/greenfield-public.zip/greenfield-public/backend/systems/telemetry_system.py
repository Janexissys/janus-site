# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Telemetry & Metrics - System observability.

The TelemetrySystem provides system-level observability and metrics collection.
It emits telemetry events, records metrics, and aggregates health data with PII
detection and redaction. This is the system-level coordination layer, different
from TelemetryBlock which provides the underlying NDJSON logging infrastructure.

**Card**: CARD-V6B-P1-COMP-TELEMETRY  
**MC Target**: 8.50  
**Dependencies**: TelemetryBlock

**Note**: System-level coordination, different from TelemetryBlock

**Key Responsibilities**:
- Emit telemetry events with PII detection and redaction
- Record metrics (counters, gauges, histograms)
- Aggregate metrics by name and type
- Detect and redact PII from telemetry events (CRITICAL)
- Track telemetry statistics and health
- Provide health monitoring

**Sentinel Compliance**:
- PII Detection: Detects PII in telemetry events (CRITICAL)
- PII Redaction: Automatically redacts PII from events before logging
- Data Validation: Validates all inputs (event_type, event_data, metric_name, etc.)
- Audit Logging: Logs all telemetry operations with PII detection status

**Example Usage**:
    ```python
    from systems.telemetry_system import TelemetrySystem
    
    telemetry = TelemetrySystem(telemetry_block=telemetry_block_instance)
    
    # Emit event
    event_id = telemetry.emit_event(
        event_type="api_request",
        event_data={"endpoint": "/api/cards", "status_code": 200},
        metadata={"user_id": "user-123"}
    )
    
    # Record metric
    metric_id = telemetry.record_metric(
        metric_name="api_requests_total",
        value=1.0,
        metric_type="counter",
        tags={"endpoint": "/api/cards"}
    )
    ```
"""

import logging
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class Metric:
    """Metric definition.
    
    Contains metric data including name, type, value, timestamp, and tags.
    
    Attributes:
        metric_name: Name of the metric.
        metric_type: Type of metric ("counter", "gauge", "histogram").
        value: Metric value (float).
        timestamp: Timestamp when metric was recorded.
        tags: Dictionary with metric tags (key-value pairs).
    """
    metric_name: str
    metric_type: str  # "counter", "gauge", "histogram"
    value: float
    timestamp: float
    tags: Dict[str, str]


class TelemetrySystem:
    """Telemetry System provides system observability and metrics.
    
    The TelemetrySystem manages telemetry events and metrics at the system level,
    coordinating with TelemetryBlock for NDJSON logging. It detects and redacts
    PII from all telemetry events before logging.
    """
    
    def __init__(self, telemetry_block: Optional[Any] = None) -> None:
        """Initialize telemetry system.
        
        Initializes the TelemetrySystem with an optional TelemetryBlock instance.
        Sets up internal state for event tracking, metrics storage, PII detection,
        and audit logging.
        
        Args:
            telemetry_block: Optional TelemetryBlock instance for NDJSON logging.
        """
        self._telemetry_block: Optional[Any] = telemetry_block
        self._event_count: int = 0
        self._metric_count: int = 0
        self._pii_detections: int = 0
        self._metrics: Dict[str, List[Metric]] = {}
        self._audit_log: List[Dict[str, Any]] = []
        self._event_history: List[Dict[str, Any]] = []  # In-memory event history
    
    def emit_event(
        self,
        event_type: str,
        event_data: Dict[str, Any],
        metadata: Optional[Dict[str, Any]] = None
    ) -> str:
        """Emit telemetry event.
        
        Emits a telemetry event with PII detection and redaction. Detects PII in
        event data, redacts it if found, and logs the event. This is a Sentinel
        compliance check for PII in telemetry logs (CRITICAL).
        
        Args:
            event_type: Event type string (e.g., "api_request", "error", "user_action").
            event_data: Dictionary with event data (will be redacted if PII detected).
            metadata: Optional dictionary with additional metadata.
        
        Returns:
            Event ID string for the emitted event.
        
        Raises:
            ValueError: If event_type is invalid (not a string or empty) or
                event_data is not a dictionary.
        
        Example:
            ```python
            event_id = telemetry.emit_event(
                event_type="api_request",
                event_data={"endpoint": "/api/cards", "status_code": 200},
                metadata={"user_id": "user-123"}
            )
            ```
        """
        # SENTINEL: Data Validation
        if not isinstance(event_type, str) or not event_type.strip():
            raise ValueError("event_type must be a non-empty string")
        
        if not isinstance(event_data, dict):
            raise ValueError("event_data must be a dictionary")
        
        # SENTINEL: PII Detection - PII in telemetry logs
        event_str = str(event_data)
        pii_detected = self._detect_pii(event_str)
        if pii_detected:
            self._pii_detections += 1
            logger.warning("PII detected in telemetry event - redacting")
            # Redact PII from event data
            event_data = self._redact_pii(event_data)
        
        event_id = f"event_{int(time.time() * 1000)}"
        
        # Use TelemetryBlock if available
        if self._telemetry_block:
            self._telemetry_block.emit_event({
                "event_id": event_id,
                "event_type": event_type,
                "event_data": event_data,
                "metadata": metadata or {},
                "timestamp": time.time()
            })
        
        self._event_count += 1
        
        # Store event in history for querying
        event_record = {
            "event_id": event_id,
            "event_type": event_type,
            "event_data": event_data,
            "metadata": metadata or {},
            "timestamp": time.time(),
            "pii_detected": pii_detected
        }
        self._event_history.append(event_record)
        
        # Keep only last 1000 events in memory (prevent unbounded growth)
        if len(self._event_history) > 1000:
            self._event_history = self._event_history[-1000:]
        
        # SENTINEL: Audit Logging
        self._log_audit("emit_event", event_id, {
            "event_type": event_type,
            "pii_detected": pii_detected
        })
        
        return event_id
    
    def record_metric(
        self,
        metric_name: str,
        value: float,
        metric_type: str = "gauge",
        tags: Optional[Dict[str, str]] = None
    ) -> str:
        """Record a metric.
        
        Records a metric with name, value, type, and optional tags. Stores the
        metric for aggregation and retrieval. This is a Sentinel compliance check
        for data validation.
        
        Args:
            metric_name: Name of the metric (must be non-empty string).
            value: Metric value (float).
            metric_type: Type of metric ("counter", "gauge", "histogram") - default: "gauge".
            tags: Optional dictionary with metric tags (key-value pairs).
        
        Returns:
            Metric ID string for the recorded metric.
        
        Raises:
            ValueError: If metric_name is invalid (not a string or empty) or
                metric_type is invalid (not one of the supported types).
        
        Example:
            ```python
            metric_id = telemetry.record_metric(
                metric_name="api_requests_total",
                value=1.0,
                metric_type="counter",
                tags={"endpoint": "/api/cards", "method": "GET"}
            )
            ```
        """
        # SENTINEL: Data Validation
        if not isinstance(metric_name, str) or not metric_name.strip():
            raise ValueError("metric_name must be a non-empty string")
        
        if metric_type not in ["counter", "gauge", "histogram"]:
            raise ValueError(f"Invalid metric_type: {metric_type}")
        
        metric_id = f"metric_{int(time.time() * 1000)}"
        metric = Metric(
            metric_name=metric_name,
            metric_type=metric_type,
            value=value,
            timestamp=time.time(),
            tags=tags or {}
        )
        
        # Store metric
        if metric_name not in self._metrics:
            self._metrics[metric_name] = []
        self._metrics[metric_name].append(metric)
        
        self._metric_count += 1
        
        # SENTINEL: Audit Logging
        self._log_audit("record_metric", metric_id, {
            "metric_name": metric_name,
            "value": value,
            "metric_type": metric_type
        })
        
        return metric_id
    
    def get_metrics(
        self,
        metric_name: Optional[str] = None
    ) -> Dict[str, List[Metric]]:
        """Get metrics.
        
        Retrieves recorded metrics, optionally filtered by metric name. Returns
        a dictionary mapping metric names to lists of Metric objects.
        
        Args:
            metric_name: Optional metric name to filter by (returns only that metric).
        
        Returns:
            Dictionary mapping metric names to lists of Metric objects.
            If metric_name is provided, returns only that metric (empty list if not found).
        """
        if metric_name:
            return {metric_name: self._metrics.get(metric_name, [])}
        return self._metrics.copy()
    
    def _detect_pii(self, text: str) -> bool:
        """Detect PII in text.
        
        Scans text for PII patterns (email, phone, SSN). This is a Sentinel
        compliance check for PII detection.
        
        Args:
            text: Text string to scan for PII.
        
        Returns:
            Boolean indicating if any PII was detected.
        """
        import re
        
        pii_patterns = [
            r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',  # Email
            r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',  # Phone
            r'\b\d{3}-\d{2}-\d{4}\b',  # SSN
        ]
        
        for pattern in pii_patterns:
            if re.search(pattern, text, re.IGNORECASE):
                return True
        
        return False
    
    def _redact_pii(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Redact PII from data.
        
        Recursively redacts PII patterns from a data dictionary. Replaces email,
        phone, and SSN patterns with placeholders. This is a Sentinel compliance
        check for PII detection and redaction.
        
        Args:
            data: Dictionary with data to redact (may contain nested dictionaries).
        
        Returns:
            Dictionary with PII redacted (same structure as input).
        """
        import re
        
        redacted = {}
        for key, value in data.items():
            if isinstance(value, str):
                # Redact PII patterns
                redacted_value = value
                redacted_value = re.sub(
                    r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
                    '[EMAIL_REDACTED]',
                    redacted_value
                )
                redacted_value = re.sub(
                    r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
                    '[PHONE_REDACTED]',
                    redacted_value
                )
                redacted_value = re.sub(
                    r'\b\d{3}-\d{2}-\d{4}\b',
                    '[SSN_REDACTED]',
                    redacted_value
                )
                redacted[key] = redacted_value
            elif isinstance(value, dict):
                redacted[key] = self._redact_pii(value)
            else:
                redacted[key] = value
        
        return redacted
    
    def _log_audit(
        self,
        operation: str,
        entity_id: str,
        details: Dict[str, Any]
    ) -> None:
        """Log audit operation.
        
        Creates an audit log entry for telemetry operations. This is a Sentinel
        compliance check for audit logging.
        
        Args:
            operation: Name of the operation (e.g., "emit_event", "record_metric").
            entity_id: Unique identifier of the entity (event_id, metric_id, etc.).
            details: Dictionary with operation details.
        """
        audit_entry = {
            "operation": operation,
            "entity_id": entity_id,
            "timestamp": time.time(),
            "details": details
        }
        
        self._audit_log.append(audit_entry)
        logger.info(f"Telemetry {operation}: {entity_id}")
    
    def query_events(
        self,
        project: Optional[str] = None,
        event_type: Optional[str] = None,
        time_range: Optional[str] = None,
        limit: int = 100
    ) -> List[Dict[str, Any]]:
        """Query telemetry events.
        
        Queries telemetry events with optional filters for project, event type, and time range.
        Returns events from in-memory history and optionally from TelemetryBlock log file.
        
        Args:
            project: Optional project filter (checks metadata.project).
            event_type: Optional event type filter.
            time_range: Optional time range filter ("last_hour", "today", "all").
            limit: Maximum number of events to return (default: 100).
        
        Returns:
            List of event dictionaries matching the filters.
        """
        events = []
        
        # Get events from in-memory history
        events.extend(self._event_history)
        
        # Also try to read from TelemetryBlock if available
        if self._telemetry_block:
            try:
                # Calculate start_time based on time_range
                start_time = None
                if time_range == "last_hour":
                    start_time = time.time() - 3600
                elif time_range == "today":
                    start_time = time.time() - (24 * 3600)
                
                block_events = self._telemetry_block.read_events(limit=limit, start_time=start_time)
                # Merge with in-memory events (avoid duplicates)
                existing_ids = {e.get("event_id") for e in events}
                for event in block_events:
                    if event.get("event_id") not in existing_ids:
                        events.append(event)
            except Exception as e:
                logger.warning(f"Failed to read events from TelemetryBlock: {e}")
        
        # Apply filters
        filtered_events = []
        for event in events:
            # Filter by project
            if project:
                metadata = event.get("metadata", {})
                if metadata.get("project") != project:
                    continue
            
            # Filter by event type
            if event_type:
                if event.get("event_type") != event_type:
                    continue
            
            # Filter by time range (if not already filtered by TelemetryBlock)
            if time_range and not start_time:
                event_time = event.get("timestamp", 0)
                if time_range == "last_hour":
                    if event_time < (time.time() - 3600):
                        continue
                elif time_range == "today":
                    if event_time < (time.time() - (24 * 3600)):
                        continue
            
            filtered_events.append(event)
        
        # Sort by timestamp (newest first) and limit
        filtered_events.sort(key=lambda e: e.get("timestamp", 0), reverse=True)
        return filtered_events[:limit]
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get system statistics.
        
        Returns operational statistics including total events, total metrics,
        PII detections, unique metrics, and PII rate.
        
        Returns:
            Dictionary with:
            - total_events: Total number of events emitted
            - total_metrics: Total number of metrics recorded
            - pii_detections: Number of PII detections
            - unique_metrics: Number of unique metric names
            - pii_rate: Rate of PII detections (detections / events)
        """
        return {
            "total_events": self._event_count,
            "total_metrics": self._metric_count,
            "pii_detections": self._pii_detections,
            "unique_metrics": len(self._metrics),
            "pii_rate": (
                self._pii_detections / self._event_count 
                if self._event_count > 0 else 0.0
            )
        }
    
    def get_health(self) -> Dict[str, Any]:
        """Get system health status.
        
        Returns health status based on PII detection rate. Health is degraded
        if PII detection rate exceeds 20%.
        
        Returns:
            Dictionary with:
            - status: Health status ("healthy" or "degraded")
            - message: Human-readable status message
            - statistics: Dictionary with operational statistics
        """
        stats = self.get_statistics()
        
        # Health is degraded if PII detection rate is high
        if stats["pii_rate"] > 0.2:  # >20% PII detection rate
            status = "degraded"
            message = f"High PII detection rate: {stats['pii_rate']:.1%}"
        else:
            status = "healthy"
            message = "Telemetry System operational"
        
        return {
            "status": status,
            "message": message,
            "statistics": stats
        }

