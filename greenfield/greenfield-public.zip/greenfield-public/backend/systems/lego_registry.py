# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""LEGO Registry - Block registry and dependency management.

The LEGORegistry provides centralized registration and dependency management for
all LEGO blocks in the Janus v6.0 system. It tracks block classes, metadata,
instances, and dependencies, ensuring proper initialization order and dependency
resolution.

**Card**: CARD-V6B-P1-COMP-LEGO_REGISTRY  
**MC Target**: 8.70  
**Dependencies**: None (foundational system)

**Key Responsibilities**:
- Register LEGO block classes with metadata (name, version, dependencies)
- Create block instances with dependency validation
- Track block instances and instance counts
- Manage dependency graph and resolve dependency order
- Provide block lookup and health monitoring
- Enforce registry security (prevent duplicate registration, validate dependencies)

**Sentinel Compliance**:
- Registry Security: Prevents duplicate block registration
- Dependency Validation: Validates dependencies exist before instance creation
- Data Validation: Validates all inputs (block_class, block_name, config)
- Audit Logging: Logs all registry operations (register_block, create_instance)

**Example Usage**:
    ```python
    from systems.lego_registry import LEGORegistry
    from blocks.vault_block import VaultBlock
    from blocks.memory_block import MemoryBlock
    
    registry = LEGORegistry()
    
    # Register blocks
    registry.register_block(VaultBlock)
    registry.register_block(MemoryBlock)
    
    # Create instances
    vault = registry.create_instance("vault", {"vault_path": "/var/janus/vault"})
    memory = registry.create_instance("memory", {"vault_block": vault})
    
    # Get registration order
    order = registry.get_registration_order()
    ```
"""

import logging
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Type

logger = logging.getLogger(__name__)


@dataclass
class BlockMetadata:
    """Block metadata.
    
    Contains metadata for a registered LEGO block including name, version,
    dependencies, registration timestamp, and instance count.
    
    Attributes:
        block_name: Unique identifier for the block.
        version: Version string of the block.
        requires: Tuple of dependency block names (empty tuple if no dependencies).
        registered_at: Timestamp when block was registered.
        instance_count: Number of instances created for this block (default: 0).
    """
    block_name: str
    version: str
    requires: tuple  # Dependencies
    registered_at: float
    instance_count: int = 0


class LEGORegistry:
    """LEGO Registry provides block registration and dependency management.
    
    The LEGORegistry manages the lifecycle of all LEGO blocks in the system.
    It tracks block classes, metadata, instances, and dependencies, ensuring
    proper initialization order and dependency resolution.
    """
    
    def __init__(self) -> None:
        """Initialize LEGORegistry.
        
        Sets up internal state for block types, metadata, instances, dependencies,
        registration tracking, and audit logging.
        """
        self._block_types: Dict[str, Type] = {}
        self._block_metadata: Dict[str, BlockMetadata] = {}
        self._instances: Dict[str, Any] = {}  # block_name -> instance
        self._dependencies: Dict[str, List[str]] = {}  # block_name -> [dependency_names]
        self._registration_count: int = 0
        self._audit_log: List[Dict[str, Any]] = []
    
    def register_block(
        self,
        block_class: Type,
        block_name: Optional[str] = None
    ) -> None:
        """Register a LEGO block class.
        
        Registers a LEGO block class with the registry. Extracts metadata (name,
        version, dependencies) from the class or parameters. Validates that the
        block is not already registered and logs warnings for missing dependencies.
        This is a Sentinel compliance check for Registry Security.
        
        Args:
            block_class: Block class to register (must be a class type, and should
                have block_name, version, requires attributes).
            block_name: Optional block name override (uses block_class.block_name if not provided).
        
        Raises:
            ValueError: If block_class is not a class, block_name is missing,
                or block is already registered.
        
        Example:
            ```python
            registry.register_block(VaultBlock)
            registry.register_block(MemoryBlock, block_name="memory")
            ```
        """
        # SENTINEL: Data Validation
        if not isinstance(block_class, type):
            raise ValueError("block_class must be a class")
        
        # Get block name from class or parameter
        name = block_name or getattr(block_class, 'block_name', None)
        if not name:
            raise ValueError("block_class must have 'block_name' attribute or provide block_name parameter")
        
        # SENTINEL: Registry Security - Check for duplicate registration
        if name in self._block_types:
            raise ValueError(f"Block '{name}' already registered")
        
        # Get block metadata
        version = getattr(block_class, 'version', '1.0.0')
        requires = getattr(block_class, 'requires', ())
        
        # Validate dependencies exist (if already registered)
        for dep in requires:
            if dep not in self._block_types and dep not in self._block_metadata:
                logger.warning(f"Block '{name}' depends on '{dep}' which is not yet registered")
        
        # Register block
        self._block_types[name] = block_class
        self._block_metadata[name] = BlockMetadata(
            block_name=name,
            version=version,
            requires=requires,
            registered_at=time.time()
        )
        self._dependencies[name] = list(requires)
        
        self._registration_count += 1
        
        # SENTINEL: Audit Logging
        self._log_audit("register_block", name, {
            "version": version,
            "requires": list(requires)
        })
        
        logger.info(f"Registered LEGO block: {name} v{version} (requires: {requires})")
    
    def register_instance(self, block_name: str, instance: Any) -> None:
        """Register an existing block instance.
        
        Registers an already instantiated block. Useful for manual bootstrapping
        or dependency injection scenarios.
        
        Args:
            block_name: Unique identifier for the block instance.
            instance: The initialized block instance.
        """
        if not block_name:
            raise ValueError("block_name is required")
        
        # Register class if not already registered
        block_class = type(instance)
        class_name = getattr(block_class, 'block_name', block_name)
        
        if class_name not in self._block_types:
            try:
                self.register_block(block_class, class_name)
            except ValueError:
                pass # Already registered
        
        # Store instance
        # Note: This bypasses the instance_key generation used in create_instance
        # which uses {block_name}_{index}. We use the provided block_name here.
        self._instances[block_name] = instance
        
        # Update metadata instance count if available
        if class_name in self._block_metadata:
            self._block_metadata[class_name].instance_count += 1
            
        self._log_audit("register_instance", block_name, {"class": class_name})
        logger.info(f"Registered block instance: {block_name}")

    def get_block_class(self, block_name: str) -> Type:
        """Get registered block class.
        
        Retrieves the registered block class by name. This is a Sentinel compliance
        check for data validation.
        
        Args:
            block_name: Name of the block to retrieve.
        
        Returns:
            Block class (Type) for the specified block name.
        
        Raises:
            ValueError: If block_name is not registered.
        """
        # SENTINEL: Data Validation
        if block_name not in self._block_types:
            raise ValueError(f"Block '{block_name}' not registered")
        
        return self._block_types[block_name]
    
    def create_instance(
        self,
        block_name: str,
        config: Optional[Dict[str, Any]] = None
    ) -> Any:
        """Create a block instance.
        
        Creates a new instance of a registered block. Validates that all dependencies
        have existing instances before creating the new instance. Initializes the
        instance with config if provided. This is a Sentinel compliance check for
        Registry Security (dependency validation).
        
        Args:
            block_name: Name of the block to instantiate.
            config: Optional dictionary with configuration for block initialization.
        
        Returns:
            Block instance (initialized if config provided).
        
        Raises:
            ValueError: If block_name is not registered, or if required dependencies
                do not have existing instances.
        
        Example:
            ```python
            vault = registry.create_instance("vault", {"vault_path": "/var/janus/vault"})
            memory = registry.create_instance("memory", {"vault_block": vault})
            ```
        """
        # SENTINEL: Data Validation
        if block_name not in self._block_types:
            raise ValueError(f"Block '{block_name}' not registered")
        
        # SENTINEL: Registry Security - Check dependencies
        metadata = self._block_metadata[block_name]
        for dep in metadata.requires:
            if dep not in self._instances:
                raise ValueError(
                    f"Block '{block_name}' requires '{dep}' but no instance exists. "
                    f"Create dependencies first."
                )
        
        # Create instance
        block_class = self._block_types[block_name]
        instance = block_class()
        
        # Initialize if config provided
        if config:
            if hasattr(instance, 'initialize'):
                instance.initialize(config)
        
        # Store instance
        instance_key = f"{block_name}_{len([k for k in self._instances.keys() if k.startswith(block_name)])}"
        self._instances[instance_key] = instance
        metadata.instance_count += 1
        
        # SENTINEL: Audit Logging
        self._log_audit("create_instance", block_name, {"instance_key": instance_key})
        
        return instance
    
    def get_instance(self, block_name: str) -> Optional[Any]:
        """Get block instance by name.
        
        Retrieves the first instance matching the block name. Returns None if
        no instance exists.
        
        Args:
            block_name: Name of the block to retrieve instance for.
        
        Returns:
            Block instance if found, None otherwise.
        """
        # Find first instance matching block_name
        for key, instance in self._instances.items():
            if key.startswith(block_name):
                return instance
        
        return None
    
    def get_dependencies(self) -> Dict[str, List[str]]:
        """Get dependency graph.
        
        Returns a copy of the dependency graph showing which blocks depend on
        which other blocks.
        
        Returns:
            Dictionary mapping block names to lists of dependency block names.
        """
        return self._dependencies.copy()
    
    def get_registration_order(self) -> List[str]:
        """Get recommended registration order based on dependencies.
        
        Performs a topological sort of registered blocks to determine the recommended
        registration order. Dependencies are listed before dependents.
        
        Returns:
            List of block names in dependency order (dependencies first, dependents last).
        """
        # Topological sort for dependency order
        visited = set()
        result = []
        
        def visit(block_name: str):
            if block_name in visited:
                return
            
            visited.add(block_name)
            
            # Visit dependencies first
            for dep in self._dependencies.get(block_name, []):
                if dep in self._block_types:
                    visit(dep)
            
            result.append(block_name)
        
        for block_name in self._block_types.keys():
            if block_name not in visited:
                visit(block_name)
        
        return result
    
    def list_registered_blocks(self) -> List[str]:
        """List all registered block names.
        
        Returns a list of all block names that have been registered.
        
        Returns:
            List of registered block name strings.
        """
        return list(self._block_types.keys())
    
    def has_block(self, block_name: str) -> bool:
        """Check if block is registered.
        
        Checks whether a block with the given name has been registered.
        
        Args:
            block_name: Name of the block to check.
        
        Returns:
            Boolean indicating if block is registered (True) or not (False).
        """
        return block_name in self._block_types
    
    def _log_audit(
        self,
        operation: str,
        block_name: str,
        details: Dict[str, Any]
    ) -> None:
        """Log audit operation.
        
        Creates an audit log entry for registry operations. This is a Sentinel
        compliance check for audit logging.
        
        Args:
            operation: Name of the operation (e.g., "register_block", "create_instance").
            block_name: Name of the block involved in the operation.
            details: Dictionary with operation details.
        """
        audit_entry = {
            "operation": operation,
            "block_name": block_name,
            "timestamp": time.time(),
            "details": details
        }
        
        self._audit_log.append(audit_entry)
        logger.info(f"LEGO Registry {operation}: {block_name}")
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get registry statistics.
        
        Returns operational statistics including total registered blocks, total
        instances, registration count, and detailed block information.
        
        Returns:
            Dictionary with:
            - total_registered: Total number of registered blocks
            - total_instances: Total number of block instances created
            - registration_count: Total number of registration operations
            - blocks: List of dictionaries with block details (name, version, requires, instance_count)
        """
        return {
            "total_registered": len(self._block_types),
            "total_instances": len(self._instances),
            "registration_count": self._registration_count,
            "blocks": [
                {
                    "name": name,
                    "version": meta.version,
                    "requires": list(meta.requires),
                    "instance_count": meta.instance_count
                }
                for name, meta in self._block_metadata.items()
            ]
        }
    
    def get_health(self) -> Dict[str, Any]:
        """Get registry health status.
        
        Returns health status based on registration state. Health is unhealthy
        if no blocks are registered, healthy otherwise.
        
        Returns:
            Dictionary with:
            - status: Health status ("healthy" or "unhealthy")
            - message: Human-readable status message
            - statistics: Dictionary with operational statistics
        """
        # Health is based on registration success
        if len(self._block_types) == 0:
            status = "unhealthy"
            message = "No blocks registered"
        else:
            status = "healthy"
            message = f"Registry operational with {len(self._block_types)} blocks"
        
        return {
            "status": status,
            "message": message,
            "statistics": self.get_statistics()
        }

