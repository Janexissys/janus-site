# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""North Star Integration - Soul and system direction.

The NorthStarIntegration provides the foundational soul and system direction for
Janus v6.0. It manages North Star Meta (soul/non-negotiables with hard rules
and ingest policy) and Projects (user goals for system direction and context
enrichment). This is a critical foundational system that guides all operations.

**Card**: CARD-V6B-P1-COMP-NORTH_STAR  
**MC Target**: 8.80  
**Dependencies**: None (foundational system)

**CRITICAL**: Includes Projects (system direction component)

**Key Responsibilities**:
- Manage North Star Meta (soul, non-negotiables, hard rules, ingest policy)
- Manage Projects (user goals with alignment validation)
- Enforce project limits (1 primary + 2 secondary active projects)
- Validate project alignment scores (must be >= 0.7)
- Enforce ingest policy (raises_truth_alignment, improves_project_progress, enhances_reasoning_clarity)
- Provide project context for agent enrichment
- Track policy enforcement and alignment validation

**Sentinel Compliance**:
- Project Alignment: Validates alignment scores >= 0.7 for all projects
- Project Switching: Enforces limits (1 primary, 2 secondary active projects)
- Ingest Policy: Validates three criteria (truth alignment, project progress, reasoning clarity)
- Policy Enforcement: Enforces hard rules and ingest policy
- Data Validation: Validates all inputs (config, project data, content)
- PII Detection: Detects PII in content
- Audit Logging: Logs all operations (add_project, enforce_policy)

**Example Usage**:
    ```python
    from systems.north_star import NorthStarIntegration
    
    north_star = NorthStarIntegration()
    north_star.initialize({
        "north_star_meta": {
            "version": "v6-core.0.1",
            "statement": "Build intelligent systems",
            "purpose": ["Speed", "Quality", "Alignment"],
            "hard_rules": ["Never bypass security"],
            "ingest_policy": {"accept_if": []}
        }
    })
    
    # Add project
    project = north_star.add_project({
        "title": "Greenfield Implementation",
        "goal": "Build v6.0 greenfield system",
        "priority": "primary",
        "alignment_score": 0.85
    })
    
    # Get project context
    context = north_star.get_project_context()
    ```
"""

import logging
import re
import time
import uuid
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional

# Import shared PII detector and standardized exceptions
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
from utils.pii_detector import PIIDetector
from utils.exceptions import ValidationError, ConfigurationError

logger = logging.getLogger(__name__)


class ProjectPriority(Enum):
    """Project priority levels.
    
    Attributes:
        PRIMARY: Primary project (maximum 1 active).
        SECONDARY: Secondary project (maximum 2 active).
        SYSTEM: System project (no limit).
    """
    PRIMARY = "primary"
    SECONDARY = "secondary"
    SYSTEM = "system"


class ProjectStatus(Enum):
    """Project status.
    
    Attributes:
        ACTIVE: Project is currently active.
        INACTIVE: Project is inactive (not currently worked on).
        ARCHIVED: Project is archived (completed or cancelled).
    """
    ACTIVE = "active"
    INACTIVE = "inactive"
    ARCHIVED = "archived"


@dataclass
class Project:
    """Project definition.
    
    A Project represents a user goal with alignment validation. Projects provide
    system direction and context enrichment for agents. Alignment score must be
    >= 0.7 to be accepted.
    
    Attributes:
        project_id: Unique identifier for the project.
        title: Human-readable project title.
        priority: ProjectPriority enum value (PRIMARY, SECONDARY, or SYSTEM).
        status: ProjectStatus enum value (ACTIVE, INACTIVE, or ARCHIVED).
        goal: Project goal description.
        alignment_score: Alignment score from 0.0 to 1.0 (must be >= 0.7).
        created_at: Timestamp when project was created.
        metadata: Dictionary with additional project metadata.
    """
    project_id: str
    title: str
    priority: ProjectPriority
    status: ProjectStatus
    goal: str
    alignment_score: float  # Must be >= 0.7
    created_at: float
    metadata: Dict[str, Any]


@dataclass
class NorthStarMeta:
    """North Star meta (soul/non-negotiables).
    
    The North Star Meta contains the foundational soul and non-negotiable rules
    for Janus v6.0. It includes hard rules (blocking violations) and ingest policy
    (three criteria: raises_truth_alignment, improves_project_progress, enhances_reasoning_clarity).
    
    Attributes:
        version: Version string of the North Star meta.
        statement: North Star statement (core vision).
        purpose: List of purpose statements.
        optimization_order: List of optimization priorities.
        hard_rules: List of hard rules (non-negotiables, blocking violations).
        ingest_policy: Dictionary with ingest policy configuration.
    """
    version: str
    statement: str
    purpose: List[str]
    optimization_order: List[str]
    hard_rules: List[str]
    ingest_policy: Dict[str, Any]


class NorthStarIntegration:
    """North Star Integration provides soul and system direction.
    
    The NorthStarIntegration manages the foundational soul and system direction
    for Janus v6.0. It has two main components:
    - North Star Meta (soul/non-negotiables): Blocking violations, hard rules, ingest policy
    - Projects (user goals): System direction, context enrichment for agents
    
    Attributes:
        MIN_ALIGNMENT_SCORE: Minimum alignment score (0.7) required for projects.
        MAX_ACTIVE_PROJECTS: Maximum active projects (3: 1 primary + 2 secondary).
    """
    
    # Alignment threshold
    MIN_ALIGNMENT_SCORE: float = 0.7
    
    # Project limits
    MAX_ACTIVE_PROJECTS: int = 3  # 1 primary + 2 secondary
    
    def __init__(self) -> None:
        """Initialize NorthStarIntegration.
        
        Sets up internal state for North Star Meta, projects, policy enforcement
        tracking, alignment validation, and audit logging.
        """
        self._north_star_meta: Optional[NorthStarMeta] = None
        self._projects: Dict[str, Project] = {}
        self._policy_enforcement_count: int = 0
        self._alignment_validation_count: int = 0
        self._alignment_failures: int = 0
        self._audit_log: List[Dict[str, Any]] = []
    
    def initialize(self, north_star_config: Dict[str, Any]) -> None:
        """Initialize North Star Integration.
        
        Initializes the NorthStarIntegration with North Star Meta configuration.
        Loads version, statement, purpose, optimization_order, hard_rules, and
        ingest_policy from the configuration.
        
        Args:
            north_star_config: Dictionary containing:
                - north_star_meta: Dictionary with version, statement, purpose,
                    optimization_order, hard_rules, ingest_policy
        
        Raises:
            ConfigurationError: If north_star_config is not a dictionary.
        
        Example:
            ```python
            north_star.initialize({
                "north_star_meta": {
                    "version": "v6-core.0.1",
                    "statement": "Build intelligent systems",
                    "purpose": ["Speed", "Quality"],
                    "hard_rules": ["Never bypass security"],
                    "ingest_policy": {}
                }
            })
            ```
        """
        # SENTINEL: Data Validation
        if not isinstance(north_star_config, dict):
            raise ConfigurationError(
                "North Star: Initialize - north_star_config must be a dictionary",
                component="NorthStarIntegration",
                context={"config_type": type(north_star_config).__name__}
            )
        
        # Load North Star Meta
        meta_data = north_star_config.get("north_star_meta", {})
        self._north_star_meta = NorthStarMeta(
            version=meta_data.get("version", "v6-core.0.1"),
            statement=meta_data.get("statement", ""),
            purpose=meta_data.get("purpose", []),
            optimization_order=meta_data.get("optimization_order", []),
            hard_rules=meta_data.get("hard_rules", []),
            ingest_policy=meta_data.get("ingest_policy", {})
        )
        
        logger.info("North Star Integration initialized")
    
    def add_project(self, project_data: Dict[str, Any]) -> Project:
        """Add a project.
        
        Creates a new project with alignment validation and project limit enforcement.
        Validates that alignment score >= 0.7 and that project limits are not exceeded
        (1 primary, 2 secondary active projects). This is a Sentinel compliance check
        for Project Alignment and Project Switching.
        
        Args:
            project_data: Dictionary containing:
                - project_id: Optional unique identifier (auto-generated if missing)
                - title: Project title (required, non-empty)
                - goal: Project goal (required, non-empty)
                - priority: Priority string ("primary", "secondary", "system") - default: "secondary"
                - alignment_score: Alignment score (required, must be >= 0.7)
                - metadata: Optional dictionary with additional metadata
        
        Returns:
            Project object with project_id, title, priority, status (ACTIVE), goal,
            alignment_score, created_at, and metadata.
        
        Raises:
            ValidationError: If project_data is invalid, title/goal is empty,
                alignment_score < 0.7, priority is invalid, or project limits exceeded.
        
        Example:
            ```python
            project = north_star.add_project({
                "title": "Greenfield Implementation",
                "goal": "Build v6.0 greenfield system",
                "priority": "primary",
                "alignment_score": 0.85
            })
            ```
        """
        # SENTINEL: Data Validation
        if not isinstance(project_data, dict):
            raise ValidationError(
                "North Star: Add Project - project_data must be a dictionary",
                component="NorthStarIntegration",
                context={"project_data_type": type(project_data).__name__}
            )
        
        project_id = project_data.get("project_id") or str(uuid.uuid4())
        title = project_data.get("title", "")
        priority_str = project_data.get("priority", "secondary")
        goal = project_data.get("goal", "")
        alignment_score = project_data.get("alignment_score", 0.0)
        
        # Validate required fields
        if not title.strip():
            raise ValidationError(
                "North Star: Add Project - project title is required",
                component="NorthStarIntegration",
                context={"project_id": project_id}
            )
        
        if not goal.strip():
            raise ValidationError(
                "North Star: Add Project - project goal is required",
                component="NorthStarIntegration",
                context={"project_id": project_id, "title": title}
            )
        
        # SENTINEL: Project Alignment - Validate alignment score
        if not isinstance(alignment_score, (int, float)) or alignment_score < self.MIN_ALIGNMENT_SCORE:
            self._alignment_failures += 1
            raise ValidationError(
                f"North Star: Add Project - Project alignment score ({alignment_score}) must be >= {self.MIN_ALIGNMENT_SCORE}",
                component="NorthStarIntegration",
                context={"project_id": project_id, "alignment_score": alignment_score, "min_score": self.MIN_ALIGNMENT_SCORE}
            )
        
        # Validate priority
        try:
            priority = ProjectPriority(priority_str.lower())
        except ValueError:
            raise ValidationError(
                f"North Star: Add Project - Invalid priority: {priority_str}",
                component="NorthStarIntegration",
                context={"project_id": project_id, "priority": priority_str, "valid_priorities": [p.value for p in ProjectPriority]}
            )
        
        # SENTINEL: Project Switching - Check active project limits
        active_projects = self.get_active_projects()
        primary_count = sum(1 for p in active_projects if p.priority == ProjectPriority.PRIMARY)
        secondary_count = sum(1 for p in active_projects if p.priority == ProjectPriority.SECONDARY)
        
        if priority == ProjectPriority.PRIMARY and primary_count >= 1:
            raise ValidationError(
                "North Star: Add Project - Maximum 1 primary project allowed",
                component="NorthStarIntegration",
                context={"project_id": project_id, "active_primary_count": primary_count}
            )
        
        if priority == ProjectPriority.SECONDARY and secondary_count >= 2:
            raise ValidationError(
                "North Star: Add Project - Maximum 2 secondary projects allowed",
                component="NorthStarIntegration",
                context={"project_id": project_id, "active_secondary_count": secondary_count}
            )
        
        # Create project
        project = Project(
            project_id=project_id,
            title=title,
            priority=priority,
            status=ProjectStatus.ACTIVE,
            goal=goal,
            alignment_score=alignment_score,
            created_at=time.time(),
            metadata=project_data.get("metadata", {})
        )
        
        self._projects[project_id] = project
        self._alignment_validation_count += 1
        
        # SENTINEL: Audit Logging
        self._log_audit("add_project", project_id, {"alignment_score": alignment_score})
        
        return project
    
    def get_active_projects(self) -> List[Project]:
        """Get active projects.
        
        Retrieves all projects with ACTIVE status.
        
        Returns:
            List of Project objects with status == ACTIVE.
        """
        return [
            project for project in self._projects.values()
            if project.status == ProjectStatus.ACTIVE
        ]
    
    def get_project_context(self) -> Dict[str, Any]:
        """Get project context for agent enrichment.
        
        Retrieves project context formatted for agent enrichment. Includes primary
        project (if any) and secondary projects (if any), along with project count.
        
        Returns:
            Dictionary with:
            - primary_project: Dictionary with project_id, title, goal (None if no primary)
            - secondary_projects: List of dictionaries with project_id, title, goal
            - project_count: Total number of active projects
        """
        active_projects = self.get_active_projects()
        
        primary_project = next(
            (p for p in active_projects if p.priority == ProjectPriority.PRIMARY),
            None
        )
        
        secondary_projects = [
            p for p in active_projects
            if p.priority == ProjectPriority.SECONDARY
        ]
        
        return {
            "primary_project": {
                "project_id": primary_project.project_id,
                "title": primary_project.title,
                "goal": primary_project.goal
            } if primary_project else None,
            "secondary_projects": [
                {
                    "project_id": p.project_id,
                    "title": p.title,
                    "goal": p.goal
                }
                for p in secondary_projects
            ],
            "project_count": len(active_projects)
        }
    
    def validate_ingest_policy(
        self,
        content: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> tuple[bool, Optional[str]]:
        """Validate ingest policy compliance.
        
        Validates that content meets the North Star ingest policy requirements.
        All three criteria must be met: raises_truth_alignment, improves_project_progress,
        enhances_reasoning_clarity. This is a Sentinel compliance check for Ingest Policy.
        
        Args:
            content: Content string to validate (not currently used, but required).
            metadata: Optional dictionary with:
                - raises_truth_alignment: Boolean (required, must be True)
                - improves_project_progress: Boolean (required, must be True)
                - enhances_reasoning_clarity: Boolean (required, must be True)
        
        Returns:
            Tuple containing:
            - Boolean indicating if policy passed (True) or failed (False)
            - Optional violation code string:
                - "NS-ERROR": North Star not initialized
                - "NS-01": fails raises_truth_alignment
                - "NS-02": fails improves_project_progress
                - "NS-03": fails enhances_reasoning_clarity
                - None: Policy passed
        """
        if not self._north_star_meta:
            return False, "NS-ERROR"  # North Star not initialized
        
        ingest_policy = self._north_star_meta.ingest_policy
        accept_if = ingest_policy.get("accept_if", [])
        
        # Check all three criteria must be met
        raises_truth_alignment = metadata.get("raises_truth_alignment", False) if metadata else False
        improves_project_progress = metadata.get("improves_project_progress", False) if metadata else False
        enhances_reasoning_clarity = metadata.get("enhances_reasoning_clarity", False) if metadata else False
        
        # SENTINEL: Policy Enforcement - Ingest policy compliance
        if not raises_truth_alignment:
            self._policy_enforcement_count += 1
            return False, "NS-01"  # fails raises_truth_alignment
        
        if not improves_project_progress:
            self._policy_enforcement_count += 1
            return False, "NS-02"  # fails improves_project_progress
        
        if not enhances_reasoning_clarity:
            self._policy_enforcement_count += 1
            return False, "NS-03"  # fails enhances_reasoning_clarity
        
        return True, None
    
    def enforce_policy(self, operation: str, context: Dict[str, Any]) -> bool:
        """Enforce North Star policy.
        
        Enforces North Star hard rules and policy for operations. This is a Sentinel
        compliance check for Policy Enforcement. Simplified implementation for greenfield.
        
        Args:
            operation: Name of the operation being performed.
            context: Dictionary with operation context.
        
        Returns:
            Boolean indicating if policy is compliant (True) or not (False).
            Returns False if North Star meta is not initialized.
        """
        if not self._north_star_meta:
            return False
        
        # Check hard rules
        hard_rules = self._north_star_meta.hard_rules
        
        # Simplified policy enforcement for greenfield
        # In production, this would check against all hard rules
        
        self._policy_enforcement_count += 1
        
        # SENTINEL: Audit Logging
        self._log_audit("enforce_policy", operation, context)
        
        return True
    
    def _log_audit(
        self,
        operation: str,
        entity_id: str,
        details: Dict[str, Any]
    ) -> None:
        """Log audit operation.
        
        Creates an audit log entry for North Star operations. This is a Sentinel
        compliance check for audit logging.
        
        Args:
            operation: Name of the operation (e.g., "add_project", "enforce_policy").
            entity_id: Unique identifier of the entity (project_id, operation name, etc.).
            details: Dictionary with operation details.
        """
        audit_entry = {
            "operation": operation,
            "entity_id": entity_id,
            "timestamp": time.time(),
            "details": details
        }
        
        self._audit_log.append(audit_entry)
        logger.info(f"North Star {operation}: {entity_id}")
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get integration statistics.
        
        Returns operational statistics including project counts, policy enforcement
        count, alignment validation count, and alignment failures.
        
        Returns:
            Dictionary with:
            - total_projects: Total number of projects (all statuses)
            - active_projects: Number of active projects
            - primary_projects: Number of active primary projects
            - secondary_projects: Number of active secondary projects
            - policy_enforcement_count: Number of policy enforcement operations
            - alignment_validation_count: Number of alignment validations performed
            - alignment_failures: Number of alignment validation failures
        """
        active_projects = self.get_active_projects()
        
        return {
            "total_projects": len(self._projects),
            "active_projects": len(active_projects),
            "primary_projects": sum(
                1 for p in active_projects if p.priority == ProjectPriority.PRIMARY
            ),
            "secondary_projects": sum(
                1 for p in active_projects if p.priority == ProjectPriority.SECONDARY
            ),
            "policy_enforcement_count": self._policy_enforcement_count,
            "alignment_validation_count": self._alignment_validation_count,
            "alignment_failures": self._alignment_failures
        }
    
    def get_health(self) -> Dict[str, Any]:
        """Get integration health status.
        
        Returns health status based on alignment failure rate and initialization
        state. Health is degraded if alignment failure rate > 20%, unhealthy if
        North Star meta is not initialized.
        
        Returns:
            Dictionary with:
            - status: Health status ("healthy", "degraded", or "unhealthy")
            - message: Human-readable status message
            - statistics: Dictionary with operational statistics
        """
        stats = self.get_statistics()
        
        # Health is degraded if alignment failures are high
        failure_rate = (
            self._alignment_failures / self._alignment_validation_count 
            if self._alignment_validation_count > 0 else 0.0
        )
        
        if failure_rate > 0.2:  # >20% failure rate
            status = "degraded"
            message = f"High alignment validation failure rate: {failure_rate:.1%}"
        elif not self._north_star_meta:
            status = "unhealthy"
            message = "North Star meta not initialized"
        else:
            status = "healthy"
            message = "North Star Integration operational"
        
        return {
            "status": status,
            "message": message,
            "statistics": stats
        }
    
    def _detect_pii(self, content: str) -> bool:
        """Detect PII in content.
        
        Scans content for PII patterns using the shared PIIDetector. This is a
        Sentinel compliance check for PII detection.
        
        Args:
            content: Content string to scan for PII.
        
        Returns:
            Boolean indicating if any PII was detected.
        """
        # Use optimized shared PII detector
        return PIIDetector.detect(content)

