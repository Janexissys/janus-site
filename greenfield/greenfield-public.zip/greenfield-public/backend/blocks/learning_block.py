# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""LearningBlock - Drift detection and learning capabilities.

The LearningBlock provides drift detection and learning capabilities by tracking
observations, calculating baseline statistics, and detecting deviations from
expected patterns. It integrates with MemoryBlock to store drift detections
and maintains audit logs of all learning operations.

**Card**: CARD-V6B-P1-LEGO-LEARNING  
**MC Target**: 8.55  
**Dependencies**: MemoryBlock (required)

**Key Responsibilities**:
- Record learning observations with categories and values
- Calculate baseline statistics (mean, std) for each category
- Detect drift using z-score based analysis
- Store drift detections in memory
- Maintain audit logs of all observations
- Provide drift summaries by category

**Sentinel Compliance**:
- PII Detection: Scans observation metadata for PII patterns
- Data Validation: Validates category names and numeric values
- Learning Data Privacy: Protects sensitive learning data
- Audit Logging: Logs all observation recordings with context
- Access Control: Validates access to drift summaries

**Example Usage**:
    ```python
    from blocks.learning_block import LearningBlock
    from blocks.memory_block import MemoryBlock
    
    memory_block = MemoryBlock()
    memory_block.initialize({"vault_block": vault_block})
    
    learning_block = LearningBlock()
    learning_block.initialize({
        "memory_block": memory_block,
        "drift_threshold": 0.4,
        "min_observations": 10
    })
    
    # Record observation
    result = learning_block.record_observation(
        category="error_rate",
        value=0.15,
        metadata={"source": "api"}
    )
    
    if result.drift_detected:
        print(f"Drift detected: {result.drift_score:.2f}")
    ```
"""

import logging
import re
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

from .base_block import BlockHealth, HealthStatus, LEGOBlock
from .memory_block import MemoryBlock

# Import standardized exceptions
try:
    from utils.exceptions import ValidationError, ConfigurationError
except ImportError:
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from utils.exceptions import ValidationError, ConfigurationError

logger = logging.getLogger(__name__)


@dataclass
class DriftResult:
    """Drift detection result.
    
    Attributes:
        drift_detected: Boolean indicating if drift was detected.
        category: Category name for the observation.
        drift_score: Normalized drift score (0.0-1.0) based on z-score.
        details: Dictionary with baseline stats, current value, z-score, and observation count.
    """
    drift_detected: bool
    category: str
    drift_score: float
    details: Dict[str, Any]


@dataclass
class LearningObservation:
    """Learning observation for drift detection.
    
    Attributes:
        observation_id: Unique identifier for the observation.
        category: Category name (e.g., "error_rate", "latency").
        value: Numeric value of the observation.
        timestamp: Timestamp when observation was recorded.
        metadata: Dictionary with additional observation metadata.
    """
    observation_id: str
    category: str
    value: float
    timestamp: float
    metadata: Dict[str, Any]


class LearningBlock(LEGOBlock):
    """LearningBlock provides drift detection and learning capabilities.
    
    The LearningBlock tracks observations, calculates baseline statistics, and
    detects drift from expected patterns using z-score based analysis. It stores
    drift detections in memory and maintains comprehensive audit logs.
    
    Attributes:
        block_name: Block identifier ("learning").
        version: Block version ("1.0.0").
        requires: Tuple containing ("memory",) - requires MemoryBlock.
        PII_PATTERNS: Dictionary of regex patterns for PII detection.
            Keys are PII types (email, phone, ssn), values are regex patterns.
        DRIFT_THRESHOLD: Default drift detection threshold (0.4).
        MIN_OBSERVATIONS: Minimum observations required before drift detection (10).
        memory_block: MemoryBlock instance (set during initialization).
        drift_threshold: Configurable drift threshold (set during initialization).
        min_observations: Configurable minimum observations (set during initialization).
    """
    
    block_name: str = "learning"
    version: str = "1.0.0"
    requires: tuple = ("memory",)  # Depends on MemoryBlock
    
    # PII patterns (SENTINEL: PII Detection)
    PII_PATTERNS: Dict[str, str] = {
        "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        "phone": r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
        "ssn": r'\b\d{3}-\d{2}-\d{4}\b',
    }
    
    # Drift detection thresholds
    DRIFT_THRESHOLD: float = 0.4  # Threshold for drift detection
    MIN_OBSERVATIONS: int = 10  # Minimum observations before drift detection
    
    def __init__(self) -> None:
        """Initialize LearningBlock.
        
        Sets up internal state for observations storage, baseline statistics,
        operation tracking, PII detection, and audit logging. MemoryBlock
        dependency and thresholds are set during initialization via initialize().
        """
        super().__init__()
        self.memory_block: Optional[MemoryBlock] = None
        self._observations: Dict[str, List[LearningObservation]] = {}  # category -> observations
        self._baseline_stats: Dict[str, Dict[str, float]] = {}  # category -> {mean, std, count}
        self._operation_count: int = 0
        self._error_count: int = 0
        self._pii_detections: int = 0
        self._drift_detections: int = 0
        self._audit_log: List[Dict[str, Any]] = []
    
    def get_schema(self) -> Dict[str, Any]:
        """Get configuration schema.
        
        Returns the JSON schema for LearningBlock configuration. Required field
        is memory_block (MemoryBlock instance). Optional fields are drift_threshold
        (default: 0.4) and min_observations (default: 10).
        
        Returns:
            Dictionary containing JSON schema for configuration validation.
        """
        return {
            "type": "object",
            "required": ["memory_block"],
            "properties": {
                "memory_block": {"type": "object", "description": "MemoryBlock instance"},
                "drift_threshold": {"type": "number", "default": self.DRIFT_THRESHOLD},
                "min_observations": {"type": "integer", "default": self.MIN_OBSERVATIONS},
            },
        }
    
    def initialize(self, config: Dict[str, Any]) -> None:
        """Initialize learning block with MemoryBlock dependency.
        
        Initializes the LearningBlock with a MemoryBlock instance and optional
        drift detection thresholds. Validates that the MemoryBlock is properly
        initialized. Must be called before recording observations.
        
        Args:
            config: Configuration dictionary containing:
                - memory_block: MemoryBlock instance (required, must be initialized)
                - drift_threshold: Optional float drift threshold (default: 0.4)
                - min_observations: Optional integer minimum observations (default: 10)
        
        Raises:
            ConfigurationError: If memory_block is missing, not a MemoryBlock instance,
                or not initialized.
            ValidationError: If configuration schema validation fails.
        
        Example:
            ```python
            learning_block = LearningBlock()
            learning_block.initialize({
                "memory_block": memory_block,
                "drift_threshold": 0.4,
                "min_observations": 10
            })
            ```
        """
        self.validate_config(config)
        
        # SENTINEL: Security - validate memory block
        memory_block = config.get("memory_block")
        if not isinstance(memory_block, MemoryBlock):
            raise ConfigurationError(
                "Learning Block: Initialize - memory_block must be a MemoryBlock instance",
                component="LearningBlock",
                context={"memory_block_type": type(memory_block).__name__ if memory_block else None}
            )
        
        if not memory_block._initialized:
            raise ConfigurationError(
                "Learning Block: Initialize - MemoryBlock must be initialized before LearningBlock",
                component="LearningBlock",
                context={}
            )
        
        self.memory_block = memory_block
        self.drift_threshold = config.get("drift_threshold", self.DRIFT_THRESHOLD)
        self.min_observations = config.get("min_observations", self.MIN_OBSERVATIONS)
        self._initialized = True
        logger.info(f"LearningBlock initialized with drift_threshold={self.drift_threshold}")
    
    def _detect_pii(self, text: str) -> Tuple[bool, List[str]]:
        """Detect PII in text.
        
        Scans text for PII patterns including email addresses, phone numbers,
        and SSNs. This is a Sentinel compliance check for PII detection.
        
        Args:
            text: Text string to scan for PII.
        
        Returns:
            Tuple containing:
            - Boolean indicating if any PII was detected
            - List of PII types detected (empty list if none)
        """
        detected_types = []
        for pii_type, pattern in self.PII_PATTERNS.items():
            if re.search(pattern, text, re.IGNORECASE):
                detected_types.append(pii_type)
        return len(detected_types) > 0, detected_types
    
    def _calculate_baseline_stats(self, category: str) -> Dict[str, float]:
        """Calculate baseline statistics for a category.
        
        Calculates mean, standard deviation, and count for observations in a
        category. Returns zeros if insufficient observations.
        
        Args:
            category: Category name to calculate stats for.
        
        Returns:
            Dictionary with "mean", "std", and "count" keys.
        """
        observations = self._observations.get(category, [])
        
        if len(observations) < self.min_observations:
            return {"mean": 0.0, "std": 0.0, "count": len(observations)}
        
        values = [obs.value for obs in observations]
        mean = sum(values) / len(values)
        variance = sum((x - mean) ** 2 for x in values) / len(values)
        std = variance ** 0.5
        
        return {"mean": mean, "std": std, "count": len(observations)}
    
    def _detect_drift(self, category: str, value: float) -> DriftResult:
        """Detect drift for a category and value.
        
        Detects drift by calculating z-score based on baseline statistics and
        comparing against drift threshold. Initializes category if needed.
        
        Args:
            category: Category name for the observation.
            value: Numeric value to check for drift.
        
        Returns:
            DriftResult object with drift detection status, score, and details.
        """
        # Initialize category if needed
        if category not in self._observations:
            self._observations[category] = []
            self._baseline_stats[category] = {"mean": value, "std": 0.0, "count": 1}
            return DriftResult(
                drift_detected=False,
                category=category,
                drift_score=0.0,
                details={"message": "Initializing drift detection for category"}
            )
        
        # Add observation
        observation = LearningObservation(
            observation_id=f"obs_{int(time.time() * 1000)}",
            category=category,
            value=value,
            timestamp=time.time(),
            metadata={}
        )
        self._observations[category].append(observation)
        
        # Keep only recent observations (limit memory)
        if len(self._observations[category]) > 1000:
            self._observations[category] = self._observations[category][-1000:]
        
        # Check if we have enough observations
        if len(self._observations[category]) < self.min_observations:
            return DriftResult(
                drift_detected=False,
                category=category,
                drift_score=0.0,
                details={"message": f"Need {self.min_observations - len(self._observations[category])} more observations"}
            )
        
        # Calculate baseline stats
        baseline = self._calculate_baseline_stats(category)
        self._baseline_stats[category] = baseline
        
        # Calculate drift score (z-score based)
        if baseline["std"] == 0:
            drift_score = 0.0
        else:
            z_score = abs((value - baseline["mean"]) / baseline["std"])
            drift_score = min(1.0, z_score / 3.0)  # Normalize to [0, 1]
        
        # Check if drift detected
        drift_detected = drift_score >= self.drift_threshold
        
        if drift_detected:
            self._drift_detections += 1
        
        return DriftResult(
            drift_detected=drift_detected,
            category=category,
            drift_score=drift_score,
            details={
                "baseline_mean": baseline["mean"],
                "baseline_std": baseline["std"],
                "current_value": value,
                "z_score": (value - baseline["mean"]) / baseline["std"] if baseline["std"] > 0 else 0.0,
                "observation_count": baseline["count"]
            }
        )
    
    def _log_audit(self, operation: str, observation_id: str, details: Optional[Dict[str, Any]] = None) -> None:
        """Log audit trail.
        
        Creates an audit log entry for learning operations. This is a Sentinel
        compliance check for audit logging.
        
        Args:
            operation: Name of the operation (e.g., "record_observation").
            observation_id: Unique identifier of the observation.
            details: Optional dictionary with additional operation details.
        """
        audit_entry = {
            "timestamp": time.time(),
            "operation": operation,
            "observation_id": observation_id,
            "details": details or {},
        }
        self._audit_log.append(audit_entry)
        logger.info(f"Audit: {operation} - Observation: {observation_id}")
    
    def record_observation(self, category: str, value: float, metadata: Optional[Dict[str, Any]] = None) -> DriftResult:
        """Record learning observation and detect drift.
        
        Records a learning observation, performs drift detection, and stores
        drift detections in memory. Performs PII detection on metadata and
        validates input data. This is a Sentinel compliance check for learning
        data privacy and PII detection.
        
        Args:
            category: Category name for the observation (e.g., "error_rate", "latency").
            value: Numeric value of the observation.
            metadata: Optional dictionary with additional observation metadata.
        
        Returns:
            DriftResult object with:
            - drift_detected: Boolean indicating if drift was detected
            - category: Category name
            - drift_score: Normalized drift score (0.0-1.0)
            - details: Dictionary with baseline stats, current value, z-score
        
        Raises:
            RuntimeError: If LearningBlock is not initialized.
            ValidationError: If category is empty or value is not numeric.
        
        Example:
            ```python
            result = learning_block.record_observation(
                category="api_latency",
                value=250.5,
                metadata={"endpoint": "/api/users"}
            )
            
            if result.drift_detected:
                print(f"Drift detected: score={result.drift_score:.2f}")
            ```
        """
        if not self._initialized:
            raise RuntimeError("LearningBlock not initialized")
        
        # SENTINEL: Data Validation
        if not category or len(category.strip()) == 0:
            raise ValidationError(
                "Learning Block: Record Observation - Category cannot be empty",
                component="LearningBlock",
                context={}
            )
        
        if not isinstance(value, (int, float)):
            raise ValidationError(
                "Learning Block: Record Observation - Value must be numeric",
                component="LearningBlock",
                context={"value_type": type(value).__name__, "category": category}
            )
        
        # SENTINEL: PII Detection - check metadata for PII
        if metadata:
            metadata_str = str(metadata)
            pii_detected, pii_types = self._detect_pii(metadata_str)
            if pii_detected:
                self._pii_detections += 1
                logger.warning(f"PII detected in learning observation metadata: {pii_types}")
                # In production, might reject or sanitize
        
        self._operation_count += 1
        
        # Detect drift
        drift_result = self._detect_drift(category, value)
        
        # Store in memory if MemoryBlock available
        if self.memory_block and drift_result.drift_detected:
            try:
                # Store drift detection in memory
                content = f"Drift detected in {category}: score={drift_result.drift_score:.2f}, value={value}"
                mc_score = 8.0  # Default score for drift detections
                self.memory_block.store_memory(
                    content=content,
                    mc_score=mc_score,
                    metadata={
                        "category": category,
                        "drift_score": drift_result.drift_score,
                        "value": value,
                        "observation_id": drift_result.details.get("observation_id", "unknown")
                    }
                )
            except Exception as e:
                logger.warning(f"Failed to store drift detection in memory: {e}")
        
        # SENTINEL: Audit Logging
        self._log_audit("record_observation", drift_result.details.get("observation_id", "unknown"), {
            "category": category,
            "value": value,
            "drift_detected": drift_result.drift_detected,
            "drift_score": drift_result.drift_score
        })
        
        return drift_result
    
    def get_drift_summary(self, category: Optional[str] = None) -> Dict[str, Any]:
        """Get drift detection summary.
        
        Retrieves drift detection summary for a specific category or all
        categories. Includes observation counts, baseline statistics, and
        drift detection counts. Performs access control validation.
        
        Args:
            category: Optional category name. If None, returns summary for all categories.
        
        Returns:
            Dictionary with:
            - For specific category: category, observations count, baseline stats, drift_detections
            - For all categories: total_observations, categories dictionary
        
        Raises:
            RuntimeError: If LearningBlock is not initialized.
        """
        if not self._initialized:
            raise RuntimeError("LearningBlock not initialized")
        
        # SENTINEL: Security - check authorization
        # (In production, check user/service permissions)
        
        if category:
            if category not in self._observations:
                return {"category": category, "observations": 0, "baseline": None, "drift_detections": 0}
            
            baseline = self._baseline_stats.get(category, {})
            return {
                "category": category,
                "observations": len(self._observations[category]),
                "baseline": baseline,
                "drift_detections": sum(1 for obs in self._observations[category] if obs.metadata.get("drift_detected", False))
            }
        
        # Summary for all categories
        summary = {
            "total_observations": sum(len(obs) for obs in self._observations.values()),
            "categories": {}
        }
        
        for cat in self._observations.keys():
            baseline = self._baseline_stats.get(cat, {})
            summary["categories"][cat] = {
                "observations": len(self._observations[cat]),
                "baseline": baseline
            }
        
        return summary
    
    def get_health(self) -> BlockHealth:
        """Get learning block health status.
        
        Returns the health status of the LearningBlock based on initialization
        state, MemoryBlock health, error rates, and PII detection rates. Health
        is degraded if MemoryBlock is unhealthy or error rate exceeds 10%.
        
        Returns:
            BlockHealth object containing:
            - status: HealthStatus (HEALTHY, DEGRADED, or UNHEALTHY)
            - message: Human-readable status message
            - details: Dictionary with operational metrics (total_observations,
                categories, drift_detections, rates, audit_log_entries)
        """
        if not self._initialized:
            return BlockHealth(
                status=HealthStatus.UNHEALTHY,
                message="LearningBlock not initialized",
                details={}
            )
        
        if not self.memory_block:
            return BlockHealth(
                status=HealthStatus.UNHEALTHY,
                message="MemoryBlock not configured",
                details={}
            )
        
        memory_health = self.memory_block.get_health()
        if memory_health.status != HealthStatus.HEALTHY:
            return BlockHealth(
                status=HealthStatus.DEGRADED,
                message=f"MemoryBlock unhealthy: {memory_health.message}",
                details={"memory_health": memory_health.details}
            )
        
        error_rate = self._error_count / max(self._operation_count, 1)
        pii_rate = self._pii_detections / max(self._operation_count, 1)
        total_observations = sum(len(obs) for obs in self._observations.values())
        drift_rate = self._drift_detections / max(total_observations, 1)
        
        if error_rate > 0.1:
            return BlockHealth(
                status=HealthStatus.DEGRADED,
                message=f"High error rate: {error_rate:.2%}",
                details={"error_rate": error_rate, "operations": self._operation_count, "errors": self._error_count}
            )
        
        return BlockHealth(
            status=HealthStatus.HEALTHY,
            message="LearningBlock operating normally",
            details={
                "total_observations": total_observations,
                "categories": len(self._observations),
                "drift_detections": self._drift_detections,
                "drift_rate": drift_rate,
                "operations": self._operation_count,
                "errors": self._error_count,
                "error_rate": error_rate,
                "pii_detections": self._pii_detections,
                "pii_rate": pii_rate,
                "audit_log_entries": len(self._audit_log)
            }
        )
    
    def get_audit_log(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get audit log entries.
        
        Retrieves recent audit log entries for learning operations. This is a
        Sentinel compliance check for audit logging access.
        
        Args:
            limit: Maximum number of entries to return (default: 100).
        
        Returns:
            List of audit log entry dictionaries, most recent first.
        """
        return self._audit_log[-limit:]

