# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""IngestBlock - Canonical ingest access point with North Star policy validation.

The IngestBlock provides the canonical access point for ingesting files into
the system with comprehensive security checks including file type validation,
size limits, malware scanning, PII detection, and North Star policy validation.
It enforces the three North Star ingest criteria: raises_truth_alignment,
improves_project_progress, and enhances_reasoning_clarity.

**Card**: CARD-V6B-P1-LEGO-INGEST  
**MC Target**: 8.60  
**Dependencies**: None (foundational block, but optionally uses VaultBlock/MemoryBlock)

**Key Responsibilities**:
- Validate file types against allowed list
- Enforce file size limits (prevent DoS)
- Scan for malware signatures
- Detect PII in file content
- Validate North Star ingest policy (all 3 criteria must pass)
- Store ingested content in memory (if MemoryBlock available)
- Maintain audit logs of all ingest operations

**Sentinel Compliance**:
- File Type Validation: Validates file extensions against allowed list
- Size Limits: Enforces maximum file size to prevent DoS attacks
- Malware Scanning: Scans file content for malware signatures
- PII Detection: Scans file content for PII patterns
- Policy Validation: Validates North Star ingest policy (NS-01, NS-02, NS-03)
- Audit Logging: Logs all ingest operations with context

**North Star Policy Violations**:
- NS-01: Fails raises_truth_alignment (missing evidence, sources, citations)
- NS-02: Fails improves_project_progress (not related to projects/goals)
- NS-03: Fails enhances_reasoning_clarity (missing explanations, reasoning)

**Example Usage**:
    ```python
    from blocks.ingest_block import IngestBlock
    from pathlib import Path
    
    ingest_block = IngestBlock()
    ingest_block.initialize({
        "vault_block": vault_block,  # Optional
        "memory_block": memory_block,  # Optional
        "max_file_size_bytes": 100 * 1024 * 1024
    })
    
    # Ingest file
    file_path = Path("document.md")
    result = await ingest_block.ingest_file(file_path, context={"source": "user"})
    
    if result.policy_passed:
        print(f"Ingest successful: {result.ingest_id}")
    else:
        print(f"Policy violation: {result.policy_violation}")
    ```
"""

import logging
import re
import time
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .base_block import BlockHealth, HealthStatus, LEGOBlock

# Import shared PII detector
try:
    from utils.pii_detector import PIIDetector
except ImportError:
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from utils.pii_detector import PIIDetector

logger = logging.getLogger(__name__)


class IngestStatus(Enum):
    """Ingest processing status.
    
    Attributes:
        PENDING: File is pending ingestion.
        VALIDATING: File is being validated.
        PROCESSING: File is being processed.
        COMPLETED: File ingestion completed successfully.
        REJECTED: File was rejected (policy violation, file type, size, malware).
        ERROR: Error occurred during ingestion.
    """
    PENDING = "pending"
    VALIDATING = "validating"
    PROCESSING = "processing"
    COMPLETED = "completed"
    REJECTED = "rejected"
    ERROR = "error"


class PolicyViolation(Enum):
    """North Star ingest policy violation codes.
    
    Attributes:
        NS_01: Fails raises_truth_alignment (missing evidence, sources, citations, facts).
        NS_02: Fails improves_project_progress (not related to projects, goals, milestones).
        NS_03: Fails enhances_reasoning_clarity (missing explanations, reasoning, insights).
    """
    NS_01 = "NS-01"  # fails raises_truth_alignment
    NS_02 = "NS-02"  # fails improves_project_progress
    NS_03 = "NS-03"  # fails enhances_reasoning_clarity


@dataclass
class IngestFile:
    """File to be ingested.
    
    Attributes:
        file_path: Path object pointing to the file.
        file_type: File extension/type (e.g., ".md", ".py").
        size_bytes: File size in bytes.
        content: Bytes content of the file.
    """
    file_path: Path
    file_type: str
    size_bytes: int
    content: bytes


@dataclass
class IngestResult:
    """Ingest processing result.
    
    Attributes:
        ingest_id: Unique identifier for the ingest operation.
        status: IngestStatus indicating final status.
        file_path: Path object of the ingested file.
        policy_passed: Boolean indicating if North Star policy validation passed.
        policy_violation: Optional PolicyViolation code if policy failed.
        error: Optional error message if ingestion failed.
        pii_detected: Boolean indicating if PII was detected in file content.
        metadata: Optional dictionary with ingest metadata (file_type, size_bytes, pii_types).
    """
    ingest_id: str
    status: IngestStatus
    file_path: Path
    policy_passed: bool
    policy_violation: Optional[PolicyViolation] = None
    error: Optional[str] = None
    pii_detected: bool = False
    metadata: Optional[Dict[str, Any]] = None


class IngestBlock(LEGOBlock):
    """IngestBlock provides canonical ingest access point with policy validation.
    
    The IngestBlock serves as the canonical entry point for file ingestion with
    comprehensive security checks. It validates file types, enforces size limits,
    scans for malware, detects PII, and validates North Star ingest policy. All
    three North Star criteria must pass for ingestion to succeed.
    
    Attributes:
        block_name: Block identifier ("ingest").
        version: Block version ("1.0.0").
        requires: Empty tuple (foundational block, optional dependencies).
        ALLOWED_FILE_TYPES: Set of allowed file extensions.
        MAX_FILE_SIZE_BYTES: Maximum file size in bytes (default: 100 MB).
        PII_PATTERNS: Dictionary of regex patterns for PII detection.
            Keys are PII types (email, phone, ssn, credit_card), values are regex patterns.
        MALWARE_SIGNATURES: List of byte patterns indicating malware.
        vault_block: Optional VaultBlock instance (set during initialization).
        memory_block: Optional MemoryBlock instance (set during initialization).
    """
    
    block_name: str = "ingest"
    version: str = "1.0.0"
    requires: tuple = ()  # Foundational block (uses other blocks but doesn't require them)
    
    # Allowed file types (SENTINEL: File Type Validation)
    ALLOWED_FILE_TYPES: set = {
        ".md", ".rmd", ".txt", ".yaml", ".yml", ".json",
        ".py", ".js", ".ts", ".tsx", ".css", ".html",
        ".pdf", ".docx", ".csv"
    }
    
    # File size limits (SENTINEL: Size Limits - prevent DoS)
    MAX_FILE_SIZE_BYTES: int = 100 * 1024 * 1024  # 100 MB
    
    # PII patterns (delegated to shared PIIDetector)
    
    # Malware signatures (simplified - SENTINEL: Malware Scanning)
    MALWARE_SIGNATURES: List[bytes] = [
        b"<script>eval(",
        b"<?php system(",
        b"powershell -encodedcommand",
        b"cmd.exe /c",
        b"/bin/sh -c",
        b"/bin/bash -c",
        b"wget http",
        b"curl http",
    ]
    
    def __init__(self) -> None:
        """Initialize IngestBlock.
        
        Sets up internal state for ingest queue, results, operation tracking,
        PII detection, malware detection, and audit logging. Optional dependencies
        (VaultBlock, MemoryBlock) and configuration are set during initialization
        via initialize().
        """
        super().__init__()
        self.vault_block: Optional[Any] = None  # VaultBlock (optional dependency)
        self.memory_block: Optional[Any] = None  # MemoryBlock (optional dependency)
        self.north_star: Optional[Any] = None  # NorthStarIntegration (optional dependency)
        self._ingest_queue: List[IngestFile] = []
        self._ingest_results: Dict[str, IngestResult] = {}
        self._operation_count: int = 0
        self._error_count: int = 0
        self._policy_rejections: int = 0
        self._pii_detections = 0
        self._malware_detections = 0
        self._audit_log: List[Dict[str, Any]] = []
    
    def get_schema(self) -> Dict[str, Any]:
        """Get configuration schema.
        
        Returns the JSON schema for IngestBlock configuration. All fields are
        optional: vault_block (VaultBlock instance), memory_block (MemoryBlock
        instance), north_star_integration (NorthStarIntegration instance),
        and max_file_size_bytes (default: 100 MB).
        
        Returns:
            Dictionary containing JSON schema for configuration validation.
        """
        return {
            "type": "object",
            "required": [],
            "properties": {
                "vault_block": {"type": "object", "description": "Optional VaultBlock instance"},
                "memory_block": {"type": "object", "description": "Optional MemoryBlock instance"},
                "north_star_integration": {"type": "object", "description": "Optional NorthStarIntegration instance"},
                "max_file_size_bytes": {"type": "integer", "default": self.MAX_FILE_SIZE_BYTES},
            },
        }
    
    def initialize(self, config: Dict[str, Any]) -> None:
        """Initialize ingest block.
        
        Initializes the IngestBlock with optional VaultBlock, MemoryBlock, and
        NorthStarIntegration dependencies, and configurable file size limits.
        Dependencies are optional and the block can function without them (using
        fallback logic).
        
        Args:
            config: Configuration dictionary containing:
                - vault_block: Optional VaultBlock instance
                - memory_block: Optional MemoryBlock instance
                - north_star_integration: Optional NorthStarIntegration instance
                - max_file_size_bytes: Optional integer maximum file size (default: 100 MB)
        
        Raises:
            ValidationError: If configuration schema validation fails.
        
        Example:
            ```python
            ingest_block = IngestBlock()
            ingest_block.initialize({
                "vault_block": vault_block,
                "memory_block": memory_block,
                "north_star_integration": north_star,
                "max_file_size_bytes": 50 * 1024 * 1024
            })
            ```
        """
        self.validate_config(config)
        
        # Optional dependencies (blocks can use IngestBlock without these)
        self.vault_block = config.get("vault_block")
        self.memory_block = config.get("memory_block")
        self.north_star = config.get("north_star_integration")
        
        self.max_file_size_bytes = config.get("max_file_size_bytes", self.MAX_FILE_SIZE_BYTES)
        self._initialized = True
        logger.info(f"IngestBlock initialized: max_file_size={self.max_file_size_bytes}")
    
    def _detect_pii(self, content: bytes) -> Tuple[bool, List[str]]:
        """Detect PII in content.
        
        Scans file content for PII patterns using the shared PIIDetector. This is a
        Sentinel compliance check for PII detection.
        
        Args:
            content: Bytes content to scan for PII.
        
        Returns:
            Tuple containing:
            - Boolean indicating if any PII was detected
            - List of PII types detected (empty list if none)
        """
        try:
            text = content.decode('utf-8', errors='ignore')
        except Exception:
            return False, []
        
        # Use optimized shared PII detector
        return PIIDetector.detect_with_types(text)
    
    def _scan_malware(self, content: bytes) -> Tuple[bool, List[str]]:
        """Scan for malware signatures.
        
        Scans file content for known malware signatures. This is a Sentinel
        compliance check for malware scanning.
        
        Args:
            content: Bytes content to scan for malware.
        
        Returns:
            Tuple containing:
            - Boolean indicating if malware was detected
            - List of detected malware signatures (empty list if none)
        """
        detected_signatures = []
        for signature in self.MALWARE_SIGNATURES:
            if signature in content:
                detected_signatures.append(signature.decode('utf-8', errors='ignore'))
        
        return len(detected_signatures) > 0, detected_signatures
    
    def _validate_file_type(self, file_path: Path) -> bool:
        """Validate file type.
        
        Validates that the file extension is in the allowed file types list.
        This is a Sentinel compliance check for file type validation.
        
        Args:
            file_path: Path object of the file to validate.
        
        Returns:
            Boolean indicating if file type is allowed.
        """
        suffix = file_path.suffix.lower()
        return suffix in self.ALLOWED_FILE_TYPES
    
    def _validate_file_size(self, size_bytes: int) -> bool:
        """Validate file size.
        
        Validates that file size does not exceed the maximum allowed size.
        This is a Sentinel compliance check for size limits (prevents DoS).
        
        Args:
            size_bytes: File size in bytes to validate.
        
        Returns:
            Boolean indicating if file size is within limits.
        """
        return size_bytes <= self.max_file_size_bytes
    
    def _validate_north_star_policy(self, content: str, context: Optional[Dict[str, Any]] = None) -> Tuple[bool, Optional[PolicyViolation]]:
        """Validate North Star ingest policy.
        
        Validates that file content meets all three North Star ingest criteria:
        1. raises_truth_alignment (evidence, sources, citations, facts)
        2. improves_project_progress (relates to projects, goals, milestones)
        3. enhances_reasoning_clarity (explanations, reasoning, insights)
        
        All three criteria must pass for policy validation to succeed. This is
        a Sentinel compliance check for policy validation.
        
        Delegates to NorthStarIntegration if available, otherwise falls back
        to heuristic validation.
        
        Args:
            content: Text content of the file to validate.
            context: Optional dictionary with validation context.
        
        Returns:
            Tuple containing:
            - Boolean indicating if policy validation passed
            - Optional PolicyViolation code if validation failed
        """
        # North Star ingest policy requires ALL three criteria:
        # 1. raises_truth_alignment: true
        # 2. improves_project_progress: true
        # 3. enhances_reasoning_clarity: true
        
        # Use heuristic validation to generate metadata for North Star
        
        # Check 1: raises_truth_alignment (evidence, sources, citations, facts)
        has_truth_indicators = any(indicator in content.lower() for indicator in [
            "source", "citation", "reference", "evidence", "data", "fact", "study", "research"
        ])
        
        # Check 2: improves_project_progress (relates to projects, goals, milestones)
        has_project_indicators = any(indicator in content.lower() for indicator in [
            "project", "goal", "milestone", "objective", "task", "action", "progress"
        ])
        
        # Check 3: enhances_reasoning_clarity (explanations, reasoning, insights)
        has_reasoning_indicators = any(indicator in content.lower() for indicator in [
            "because", "reason", "explain", "insight", "analysis", "logic", "why", "how"
        ])
        
        # If North Star Integration is available, delegate to it
        if self.north_star:
            metadata = {
                "raises_truth_alignment": has_truth_indicators,
                "improves_project_progress": has_project_indicators,
                "enhances_reasoning_clarity": has_reasoning_indicators
            }
            
            try:
                passed, violation_code = self.north_star.validate_ingest_policy(content, metadata)
                
                if passed:
                    return True, None
                
                # Map NS violation codes to PolicyViolation enum
                if violation_code == "NS-01":
                    return False, PolicyViolation.NS_01
                elif violation_code == "NS-02":
                    return False, PolicyViolation.NS_02
                elif violation_code == "NS-03":
                    return False, PolicyViolation.NS_03
                elif violation_code == "NS-ERROR":
                    # Fallback if NS errors (e.g. not initialized)
                    logger.warning("North Star policy validation error, falling back to heuristics")
                else:
                    # Unknown violation, assume generic policy failure
                    logger.warning(f"Unknown North Star violation code: {violation_code}")
                    return False, PolicyViolation.NS_03
                    
            except Exception as e:
                logger.error(f"North Star policy validation exception: {e}")
                # Fallback to heuristics
        
        # Fallback / Standalone Heuristics
        if not has_truth_indicators:
            return False, PolicyViolation.NS_01
        
        if not has_project_indicators:
            return False, PolicyViolation.NS_02
        
        if not has_reasoning_indicators:
            return False, PolicyViolation.NS_03
        
        return True, None
    
    def _log_audit(self, operation: str, ingest_id: str, details: Optional[Dict[str, Any]] = None) -> None:
        """Log audit trail.
        
        Creates an audit log entry for ingest operations. This is a Sentinel
        compliance check for audit logging.
        
        Args:
            operation: Name of the operation (e.g., "ingest_completed", "ingest_rejected").
            ingest_id: Unique identifier of the ingest operation.
            details: Optional dictionary with additional operation details.
        """
        audit_entry = {
            "timestamp": time.time(),
            "operation": operation,
            "ingest_id": ingest_id,
            "details": details or {},
        }
        self._audit_log.append(audit_entry)
        logger.info(f"Audit: {operation} - Ingest: {ingest_id}")
    
    async def ingest_file(self, file_path: Path, context: Optional[Dict[str, Any]] = None) -> IngestResult:
        """Ingest a file with full Sentinel checks.
        
        Ingests a file with comprehensive security checks including file type
        validation, size limits, malware scanning, PII detection, and North Star
        policy validation. All checks must pass for ingestion to succeed.
        
        Args:
            file_path: Path object pointing to the file to ingest.
            context: Optional dictionary with ingest context (source, user info, etc.).
        
        Returns:
            IngestResult object with:
            - ingest_id: Unique identifier
            - status: IngestStatus (COMPLETED if successful, REJECTED/ERROR if failed)
            - file_path: Path object of the file
            - policy_passed: Boolean indicating if policy validation passed
            - policy_violation: Optional PolicyViolation code if policy failed
            - error: Optional error message if ingestion failed
            - pii_detected: Boolean indicating if PII was detected
            - metadata: Dictionary with file_type, size_bytes, pii_types
        
        Raises:
            RuntimeError: If IngestBlock is not initialized.
        
        Example:
            ```python
            file_path = Path("document.md")
            result = await ingest_block.ingest_file(file_path, context={"source": "user"})
            
            if result.status == IngestStatus.COMPLETED:
                print(f"Ingest successful: {result.ingest_id}")
            elif result.status == IngestStatus.REJECTED:
                print(f"Rejected: {result.policy_violation} - {result.error}")
            ```
        """
        if not self._initialized:
            raise RuntimeError("IngestBlock not initialized")
        
        ingest_id = f"ingest_{int(time.time() * 1000)}"
        self._operation_count += 1
        
        # SENTINEL: File Type Validation
        if not self._validate_file_type(file_path):
            error_msg = f"File type not allowed: {file_path.suffix}"
            self._error_count += 1
            self._log_audit("ingest_rejected", ingest_id, {"reason": "file_type", "error": error_msg})
            return IngestResult(
                ingest_id=ingest_id,
                status=IngestStatus.REJECTED,
                file_path=file_path,
                policy_passed=False,
                error=error_msg
            )
        
        # Read file
        try:
            content = file_path.read_bytes()
            size_bytes = len(content)
        except Exception as e:
            self._error_count += 1
            error_msg = f"Failed to read file: {e}"
            self._log_audit("ingest_error", ingest_id, {"error": error_msg})
            return IngestResult(
                ingest_id=ingest_id,
                status=IngestStatus.ERROR,
                file_path=file_path,
                policy_passed=False,
                error=error_msg
            )
        
        # SENTINEL: Size Limits
        if not self._validate_file_size(size_bytes):
            error_msg = f"File size exceeds limit: {size_bytes} > {self.max_file_size_bytes}"
            self._error_count += 1
            self._log_audit("ingest_rejected", ingest_id, {"reason": "file_size", "error": error_msg})
            return IngestResult(
                ingest_id=ingest_id,
                status=IngestStatus.REJECTED,
                file_path=file_path,
                policy_passed=False,
                error=error_msg
            )
        
        # SENTINEL: Malware Scanning
        malware_detected, malware_signatures = self._scan_malware(content)
        if malware_detected:
            self._malware_detections += 1
            error_msg = f"Malware detected: {malware_signatures}"
            self._error_count += 1
            self._log_audit("ingest_rejected", ingest_id, {"reason": "malware", "signatures": malware_signatures})
            return IngestResult(
                ingest_id=ingest_id,
                status=IngestStatus.REJECTED,
                file_path=file_path,
                policy_passed=False,
                error=error_msg
            )
        
        # SENTINEL: PII Detection
        pii_detected, pii_types = self._detect_pii(content)
        if pii_detected:
            self._pii_detections += 1
            logger.warning(f"PII detected in ingest: {pii_types}")
            # In production, might reject or sanitize
        
        # SENTINEL: Policy Validation (North Star ingest policy)
        try:
            content_text = content.decode('utf-8', errors='ignore')
            policy_passed, policy_violation = self._validate_north_star_policy(content_text, context)
        except Exception as e:
            self._error_count += 1
            error_msg = f"Policy validation failed: {e}"
            self._log_audit("ingest_error", ingest_id, {"error": error_msg})
            return IngestResult(
                ingest_id=ingest_id,
                status=IngestStatus.ERROR,
                file_path=file_path,
                policy_passed=False,
                error=error_msg
            )
        
        if not policy_passed:
            self._policy_rejections += 1
            self._log_audit("ingest_rejected", ingest_id, {
                "reason": "policy_violation",
                "violation": policy_violation.value if policy_violation else None
            })
            return IngestResult(
                ingest_id=ingest_id,
                status=IngestStatus.REJECTED,
                file_path=file_path,
                policy_passed=False,
                policy_violation=policy_violation,
                error=f"North Star policy violation: {policy_violation.value if policy_violation else 'unknown'}"
            )
        
        # Store in memory if MemoryBlock available
        if self.memory_block:
            try:
                # Calculate MC score (simplified - in production, use MC Engine)
                mc_score = 8.5  # Default score
                self.memory_block.store_memory(
                    content=content_text,
                    mc_score=mc_score,
                    metadata={"ingest_id": ingest_id, "file_path": str(file_path)}
                )
            except Exception as e:
                logger.warning(f"Failed to store ingested content in memory: {e}")
                # Don't fail ingest if memory storage fails
        
        # Success
        result = IngestResult(
            ingest_id=ingest_id,
            status=IngestStatus.COMPLETED,
            file_path=file_path,
            policy_passed=True,
            pii_detected=pii_detected,
            metadata={
                "file_type": file_path.suffix,
                "size_bytes": size_bytes,
                "pii_types": pii_types if pii_detected else []
            }
        )
        
        self._ingest_results[ingest_id] = result
        
        # SENTINEL: Audit Logging
        self._log_audit("ingest_completed", ingest_id, {
            "policy_passed": True,
            "pii_detected": pii_detected,
            "file_type": file_path.suffix,
            "size_bytes": size_bytes
        })
        
        logger.info(f"Ingest completed: {ingest_id} - {file_path}")
        return result
    
    def get_ingest_result(self, ingest_id: str) -> Optional[IngestResult]:
        """Get ingest result by ID.
        
        Retrieves the ingest result for a previously ingested file.
        
        Args:
            ingest_id: Unique identifier of the ingest operation.
        
        Returns:
            IngestResult object if found, None otherwise.
        """
        return self._ingest_results.get(ingest_id)
    
    def get_health(self) -> BlockHealth:
        """Get ingest block health status.
        
        Returns the health status of the IngestBlock based on initialization
        state, error rates, policy rejection rates, and PII detection rates.
        Health is unhealthy if error rate exceeds 20%, degraded if policy
        rejection rate exceeds 50%.
        
        Returns:
            BlockHealth object containing:
            - status: HealthStatus (HEALTHY, DEGRADED, or UNHEALTHY)
            - message: Human-readable status message
            - details: Dictionary with operational metrics (operations, errors,
                policy_rejections, PII detections, malware detections, rates)
        """
        if not self._initialized:
            return BlockHealth(
                status=HealthStatus.UNHEALTHY,
                message="IngestBlock not initialized",
                details={}
            )
        
        error_rate = self._error_count / max(self._operation_count, 1)
        rejection_rate = self._policy_rejections / max(self._operation_count, 1)
        pii_rate = self._pii_detections / max(self._operation_count, 1)
        
        if error_rate > 0.2:
            return BlockHealth(
                status=HealthStatus.UNHEALTHY,
                message=f"High error rate: {error_rate:.2%}",
                details={"error_rate": error_rate, "operations": self._operation_count, "errors": self._error_count}
            )
        
        if rejection_rate > 0.5:  # More than 50% policy rejections
            return BlockHealth(
                status=HealthStatus.DEGRADED,
                message=f"High policy rejection rate: {rejection_rate:.2%}",
                details={"rejection_rate": rejection_rate, "policy_rejections": self._policy_rejections}
            )
        
        return BlockHealth(
            status=HealthStatus.HEALTHY,
            message="IngestBlock operating normally",
            details={
                "operations": self._operation_count,
                "errors": self._error_count,
                "error_rate": error_rate,
                "policy_rejections": self._policy_rejections,
                "rejection_rate": rejection_rate,
                "pii_detections": self._pii_detections,
                "pii_rate": pii_rate,
                "malware_detections": self._malware_detections,
                "audit_log_entries": len(self._audit_log)
            }
        )
    
    def get_audit_log(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get audit log entries.
        
        Retrieves recent audit log entries for ingest operations. This is a
        Sentinel compliance check for audit logging access.
        
        Args:
            limit: Maximum number of entries to return (default: 100).
        
        Returns:
            List of audit log entry dictionaries, most recent first.
        """
        return self._audit_log[-limit:]

