# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""AgentBlock - Agent management and lifecycle.

The AgentBlock provides agent lifecycle management including creation, status
tracking, termination, and listing. It enforces security policies including
agent limits, duplicate prevention, and PII detection in agent configurations.

**Card**: CARD-V6B-P1-LEGO-AGENT  
**MC Target**: 8.55  
**Dependencies**: None (foundational block)

**Key Responsibilities**:
- Create and manage agent instances
- Track agent status (IDLE, RUNNING, ERROR, TERMINATED)
- Enforce maximum agent limits
- Detect PII in agent configurations
- Maintain audit logs of all agent operations
- Provide agent listing and retrieval

**Sentinel Compliance**:
- PII Detection: Scans agent configurations for PII patterns
- Data Validation: Validates agent IDs, types, and status values
- Access Control: Validates agent access and enforces limits
- Audit Logging: Logs all agent operations with context
- Security: Prevents duplicate agent IDs and enforces limits

**Example Usage**:
    ```python
    from blocks.agent_block import AgentBlock, AgentConfig, AgentStatus
    
    block = AgentBlock()
    block.initialize({"max_agents": 50})
    
    # Create agent
    config = AgentConfig(
        agent_id="agent-001",
        agent_type="caretaker",
        config={"priority": "high"}
    )
    agent = block.create_agent(config)
    
    # Update status
    block.update_agent_status("agent-001", AgentStatus.RUNNING)
    
    # List agents
    agents = block.list_agents(agent_type="caretaker")
    ```
"""

import logging
import re
import time
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

from .base_block import BlockHealth, HealthStatus, LEGOBlock

# Import standardized exceptions
try:
    from utils.exceptions import ValidationError
except ImportError:
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from utils.exceptions import ValidationError

logger = logging.getLogger(__name__)


class AgentStatus(Enum):
    """Agent status.
    
    Attributes:
        IDLE: Agent is created but not currently executing.
        RUNNING: Agent is currently executing a task.
        ERROR: Agent encountered an error during execution.
        TERMINATED: Agent has been terminated and will be cleaned up.
    """
    IDLE = "idle"
    RUNNING = "running"
    ERROR = "error"
    TERMINATED = "terminated"


@dataclass
class AgentConfig:
    """Agent configuration.
    
    Attributes:
        agent_id: Unique identifier for the agent (must be non-empty string).
        agent_type: Type of agent (e.g., "caretaker", "gardener", "mercury").
        config: Dictionary of agent-specific configuration parameters.
    """
    agent_id: str
    agent_type: str
    config: Dict[str, Any]


@dataclass
class AgentInstance:
    """Agent instance.
    
    Attributes:
        agent_id: Unique identifier for the agent.
        agent_type: Type of agent.
        status: Current status of the agent (IDLE, RUNNING, ERROR, TERMINATED).
        created_at: Timestamp when the agent was created.
        last_activity: Timestamp of last activity (updated on access).
        config: Dictionary of agent configuration parameters.
    """
    agent_id: str
    agent_type: str
    status: AgentStatus
    created_at: float
    last_activity: float
    config: Dict[str, Any]


class AgentBlock(LEGOBlock):
    """AgentBlock provides agent management and lifecycle.
    
    The AgentBlock manages the lifecycle of agent instances including creation,
    status tracking, termination, and listing. It enforces security policies
    and maintains audit logs of all agent operations.
    
    Attributes:
        block_name: Block identifier ("agent").
        version: Block version ("1.0.0").
        requires: Empty tuple (foundational block, no dependencies).
        PII_PATTERNS: Dictionary of regex patterns for PII detection.
            Keys are PII types (email, phone, ssn), values are regex patterns.
        max_agents: Maximum number of agents allowed (set during initialization).
        agent_timeout: Timeout in seconds for agent operations (set during initialization).
    """
    
    block_name: str = "agent"
    version: str = "1.0.0"
    requires: tuple = ()  # Foundational block
    
    # PII patterns (SENTINEL: PII Detection)
    PII_PATTERNS: Dict[str, str] = {
        "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        "phone": r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
        "ssn": r'\b\d{3}-\d{2}-\d{4}\b',
    }
    
    def __init__(self) -> None:
        """Initialize AgentBlock.
        
        Sets up internal state for agent storage, operation tracking, PII detection,
        and audit logging. Configuration (max_agents, agent_timeout) is set during
        initialization via initialize().
        """
        super().__init__()
        self._agents: Dict[str, AgentInstance] = {}
        self._operation_count: int = 0
        self._error_count: int = 0
        self._pii_detections: int = 0
        self._audit_log: List[Dict[str, Any]] = []
    
    def get_schema(self) -> Dict[str, Any]:
        """Get configuration schema.
        
        Returns the JSON schema for AgentBlock configuration. Optional fields
        are max_agents (default: 100) and agent_timeout (default: 3600 seconds).
        
        Returns:
            Dictionary containing JSON schema for configuration validation.
        """
        return {
            "type": "object",
            "required": [],
            "properties": {
                "max_agents": {"type": "integer", "default": 100},
                "agent_timeout": {"type": "integer", "default": 3600},
            },
        }
    
    def initialize(self, config: Dict[str, Any]) -> None:
        """Initialize agent block.
        
        Initializes the AgentBlock with maximum agent limit and timeout settings.
        Must be called before creating agents.
        
        Args:
            config: Configuration dictionary containing:
                - max_agents: Optional integer maximum number of agents (default: 100)
                - agent_timeout: Optional integer timeout in seconds (default: 3600)
        
        Raises:
            ValidationError: If configuration schema validation fails.
        
        Example:
            ```python
            block = AgentBlock()
            block.initialize({"max_agents": 50, "agent_timeout": 1800})
            ```
        """
        self.validate_config(config)
        self.max_agents = config.get("max_agents", 100)
        self.agent_timeout = config.get("agent_timeout", 3600)
        self._initialized = True
        logger.info(f"AgentBlock initialized: max_agents={self.max_agents}")
    
    def _detect_pii(self, text: str) -> Tuple[bool, List[str]]:
        """Detect PII in text.
        
        Scans text for PII patterns including email addresses, phone numbers,
        and SSNs. This is a Sentinel compliance check for PII detection.
        
        Args:
            text: Text string to scan for PII.
        
        Returns:
            Tuple containing:
            - Boolean indicating if any PII was detected
            - List of PII types detected (empty list if none)
        """
        detected_types = []
        for pii_type, pattern in self.PII_PATTERNS.items():
            if re.search(pattern, text, re.IGNORECASE):
                detected_types.append(pii_type)
        return len(detected_types) > 0, detected_types
    
    def _validate_agent_config(self, config: AgentConfig) -> None:
        """Validate agent configuration.
        
        Validates agent configuration including agent ID, agent type, and PII
        detection in config data. This is a Sentinel compliance check for data
        validation and PII detection.
        
        Args:
            config: AgentConfig object to validate.
        
        Raises:
            ValidationError: If agent_id or agent_type is empty.
        """
        if not config.agent_id or len(config.agent_id.strip()) == 0:
            raise ValidationError(
                "Agent Block: Validate Config - Agent ID cannot be empty",
                component="AgentBlock",
                context={"agent_type": config.agent_type}
            )
        
        if not config.agent_type or len(config.agent_type.strip()) == 0:
            raise ValidationError(
                "Agent Block: Validate Config - Agent type cannot be empty",
                component="AgentBlock",
                context={"agent_id": config.agent_id}
            )
        
        # Check for PII in config
        config_str = str(config.config)
        pii_detected, pii_types = self._detect_pii(config_str)
        if pii_detected:
            self._pii_detections += 1
            logger.warning(f"PII detected in agent config: {pii_types}")
            # In production, might reject or sanitize
    
    def _log_audit(self, operation: str, agent_id: str, details: Optional[Dict[str, Any]] = None) -> None:
        """Log audit trail.
        
        Creates an audit log entry for agent operations. This is a Sentinel
        compliance check for audit logging.
        
        Args:
            operation: Name of the operation (e.g., "create_agent", "update_status").
            agent_id: Unique identifier of the agent.
            details: Optional dictionary with additional operation details.
        """
        audit_entry = {
            "timestamp": time.time(),
            "operation": operation,
            "agent_id": agent_id,
            "details": details or {},
        }
        self._audit_log.append(audit_entry)
        logger.info(f"Audit: {operation} - Agent: {agent_id}")
    
    def create_agent(self, config: AgentConfig) -> AgentInstance:
        """Create agent instance.
        
        Creates a new agent instance with the specified configuration. Performs
        validation, PII detection, and enforces security limits. Agent is created
        with IDLE status.
        
        Args:
            config: AgentConfig object containing agent_id, agent_type, and config.
        
        Returns:
            AgentInstance object with:
            - agent_id: Unique identifier
            - agent_type: Agent type
            - status: AgentStatus.IDLE
            - created_at: Timestamp of creation
            - last_activity: Timestamp of creation
            - config: Configuration dictionary
        
        Raises:
            RuntimeError: If AgentBlock is not initialized.
            ValidationError: If agent limit reached, duplicate agent_id, or
                validation fails.
            Exception: If agent creation fails.
        
        Example:
            ```python
            config = AgentConfig(
                agent_id="caretaker-001",
                agent_type="caretaker",
                config={"priority": "high"}
            )
            agent = block.create_agent(config)
            assert agent.status == AgentStatus.IDLE
            ```
        """
        if not self._initialized:
            raise RuntimeError("AgentBlock not initialized")
        
        # SENTINEL: Security - check agent limit
        if len(self._agents) >= self.max_agents:
            raise ValidationError(
                f"Agent Block: Create Agent - Maximum agent limit reached: {self.max_agents}",
                component="AgentBlock",
                context={"current_count": len(self._agents), "max_agents": self.max_agents}
            )
        
        # SENTINEL: Data Validation
        self._validate_agent_config(config)
        
        # SENTINEL: Security - check for duplicate agent ID
        if config.agent_id in self._agents:
            raise ValidationError(
                f"Agent Block: Create Agent - Agent ID already exists: {config.agent_id}",
                component="AgentBlock",
                context={"agent_id": config.agent_id, "existing_agents": list(self._agents.keys())}
            )
        
        self._operation_count += 1
        
        try:
            agent = AgentInstance(
                agent_id=config.agent_id,
                agent_type=config.agent_type,
                status=AgentStatus.IDLE,
                created_at=time.time(),
                last_activity=time.time(),
                config=config.config
            )
            
            self._agents[config.agent_id] = agent
            
            # SENTINEL: Audit Logging
            self._log_audit("create_agent", config.agent_id, {"agent_type": config.agent_type})
            
            logger.info(f"Agent created: {config.agent_id} ({config.agent_type})")
            return agent
            
        except Exception as e:
            self._error_count += 1
            error_msg = str(e)
            logger.error(f"Failed to create agent {config.agent_id}: {error_msg}")
            raise
    
    def get_agent(self, agent_id: str) -> Optional[AgentInstance]:
        """Get agent instance.
        
        Retrieves an agent instance by ID and updates its last_activity timestamp.
        Performs access control validation and audit logging.
        
        Args:
            agent_id: Unique identifier of the agent to retrieve.
        
        Returns:
            AgentInstance object if found, None otherwise.
        
        Raises:
            RuntimeError: If AgentBlock is not initialized.
        """
        if not self._initialized:
            raise RuntimeError("AgentBlock not initialized")
        
        # SENTINEL: Security - validate agent ID
        if not agent_id or agent_id not in self._agents:
            return None
        
        agent = self._agents[agent_id]
        agent.last_activity = time.time()
        
        # SENTINEL: Audit Logging
        self._log_audit("get_agent", agent_id)
        
        return agent
    
    def update_agent_status(self, agent_id: str, status: AgentStatus) -> None:
        """Update agent status.
        
        Updates the status of an agent instance and records the activity timestamp.
        Validates that the agent exists and the status is valid.
        
        Args:
            agent_id: Unique identifier of the agent.
            status: New AgentStatus value (IDLE, RUNNING, ERROR, TERMINATED).
        
        Raises:
            RuntimeError: If AgentBlock is not initialized.
            ValidationError: If agent_id is not found or status is invalid.
        
        Example:
            ```python
            block.update_agent_status("agent-001", AgentStatus.RUNNING)
            ```
        """
        if not self._initialized:
            raise RuntimeError("AgentBlock not initialized")
        
        if agent_id not in self._agents:
            raise ValidationError(
                f"Agent Block: Update Status - Agent not found: {agent_id}",
                component="AgentBlock",
                context={"agent_id": agent_id, "available_agents": list(self._agents.keys())}
            )
        
        # SENTINEL: Data Validation
        if not isinstance(status, AgentStatus):
            raise ValidationError(
                f"Agent Block: Update Status - Invalid status: {status}",
                component="AgentBlock",
                context={"agent_id": agent_id, "status": str(status), "valid_statuses": [s.value for s in AgentStatus]}
            )
        
        self._agents[agent_id].status = status
        self._agents[agent_id].last_activity = time.time()
        
        # SENTINEL: Audit Logging
        self._log_audit("update_status", agent_id, {"status": status.value})
    
    def terminate_agent(self, agent_id: str) -> None:
        """Terminate agent instance.
        
        Terminates an agent instance by setting its status to TERMINATED and
        removing it from the active agents list. Performs audit logging.
        
        Args:
            agent_id: Unique identifier of the agent to terminate.
        
        Raises:
            RuntimeError: If AgentBlock is not initialized.
            ValidationError: If agent_id is not found.
        
        Example:
            ```python
            block.terminate_agent("agent-001")
            ```
        """
        if not self._initialized:
            raise RuntimeError("AgentBlock not initialized")
        
        if agent_id not in self._agents:
            raise ValidationError(
                f"Agent Block: Terminate Agent - Agent not found: {agent_id}",
                component="AgentBlock",
                context={"agent_id": agent_id, "available_agents": list(self._agents.keys())}
            )
        
        self._agents[agent_id].status = AgentStatus.TERMINATED
        
        # SENTINEL: Audit Logging
        self._log_audit("terminate_agent", agent_id)
        
        # Clean up terminated agents after timeout
        # (In production, might keep for audit purposes)
        del self._agents[agent_id]
        
        logger.info(f"Agent terminated: {agent_id}")
    
    def list_agents(self, agent_type: Optional[str] = None) -> List[AgentInstance]:
        """List agents.
        
        Lists all agent instances, optionally filtered by agent type. Performs
        audit logging of the listing operation.
        
        Args:
            agent_type: Optional agent type filter (e.g., "caretaker"). If None,
                returns all agents.
        
        Returns:
            List of AgentInstance objects matching the filter (empty list if none).
        
        Raises:
            RuntimeError: If AgentBlock is not initialized.
        
        Example:
            ```python
            # List all agents
            all_agents = block.list_agents()
            
            # List only caretaker agents
            caretakers = block.list_agents(agent_type="caretaker")
            ```
        """
        if not self._initialized:
            raise RuntimeError("AgentBlock not initialized")
        
        agents = list(self._agents.values())
        
        if agent_type:
            agents = [a for a in agents if a.agent_type == agent_type]
        
        # SENTINEL: Audit Logging
        self._log_audit("list_agents", "all", {"count": len(agents), "filter": agent_type})
        
        return agents
    
    def get_health(self) -> BlockHealth:
        """Get agent block health status.
        
        Returns the health status of the AgentBlock based on initialization state,
        error rates, and PII detection rates. Health is unhealthy if error rate
        exceeds 20%, degraded if PII detection rate exceeds 10%.
        
        Returns:
            BlockHealth object containing:
            - status: HealthStatus (HEALTHY, DEGRADED, or UNHEALTHY)
            - message: Human-readable status message
            - details: Dictionary with operational metrics (active agents, operations, errors, PII detections, rates)
        """
        if not self._initialized:
            return BlockHealth(
                status=HealthStatus.UNHEALTHY,
                message="AgentBlock not initialized",
                details={}
            )
        
        error_rate = self._error_count / max(self._operation_count, 1)
        active_agents = len([a for a in self._agents.values() if a.status != AgentStatus.TERMINATED])
        pii_rate = self._pii_detections / max(self._operation_count, 1)
        
        if error_rate > 0.2:
            return BlockHealth(
                status=HealthStatus.UNHEALTHY,
                message=f"High error rate: {error_rate:.2%}",
                details={"error_rate": error_rate, "operations": self._operation_count, "errors": self._error_count}
            )
        
        if pii_rate > 0.1:
            return BlockHealth(
                status=HealthStatus.DEGRADED,
                message=f"High PII detection rate: {pii_rate:.2%}",
                details={"pii_rate": pii_rate, "pii_detections": self._pii_detections}
            )
        
        return BlockHealth(
            status=HealthStatus.HEALTHY,
            message="AgentBlock operating normally",
            details={
                "active_agents": active_agents,
                "total_agents": len(self._agents),
                "operations": self._operation_count,
                "errors": self._error_count,
                "error_rate": error_rate,
                "pii_detections": self._pii_detections,
                "audit_log_entries": len(self._audit_log)
            }
        )
    
    def get_audit_log(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get audit log entries.
        
        Retrieves recent audit log entries for agent operations. This is a
        Sentinel compliance check for audit logging access.
        
        Args:
            limit: Maximum number of entries to return (default: 100).
        
        Returns:
            List of audit log entry dictionaries, most recent first.
        """
        return self._audit_log[-limit:]

