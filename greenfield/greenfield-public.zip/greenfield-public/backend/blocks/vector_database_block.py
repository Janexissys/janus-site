# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""VectorDatabaseBlock - Vector indexing and semantic search.

The VectorDatabaseBlock provides vector indexing and semantic search capabilities
for content. It generates embeddings, indexes documents, and performs similarity
search using cosine similarity. Includes PII detection and audit logging.

**Card**: CARD-V6B-P1-LEGO-VECTOR_DB  
**MC Target**: 8.60  
**Dependencies**: None (foundational block)

**Key Responsibilities**:
- Index documents with vector embeddings
- Generate embeddings from text content
- Search for similar vectors using cosine similarity
- Detect PII in indexed content
- Maintain audit logs of all operations
- Provide vector retrieval and deletion

**Sentinel Compliance**:
- PII Detection: Scans content before indexing
- Vector Data Privacy: Protects sensitive vector data
- Data Validation: Validates content length and metadata size
- Access Control: Validates access to vectors
- Audit Logging: Logs all vector operations with context

**Example Usage**:
    ```python
    from blocks.vector_database_block import VectorDatabaseBlock
    
    vector_db = VectorDatabaseBlock()
    vector_db.initialize({"embedding_dimensions": 384})
    
    # Index vector
    await vector_db.index_vector(
        vector_id="doc-001",
        content="Document content...",
        metadata={"source": "api"}
    )
    
    # Search similar
    results = await vector_db.search_similar(
        query="search query",
        limit=5,
        min_similarity=0.7
    )
    ```
"""

import logging
import re
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

from .base_block import BlockHealth, HealthStatus, LEGOBlock

logger = logging.getLogger(__name__)


@dataclass
class VectorDocument:
    """Vector document with embedding and metadata.
    
    Attributes:
        vector_id: Unique identifier for the vector document.
        content: Original text content of the document.
        embedding: List of float values representing the vector embedding.
        metadata: Dictionary with document metadata (source, tags, PII info, etc.).
    """
    vector_id: str
    content: str
    embedding: List[float]
    metadata: Dict[str, Any]


@dataclass
class SearchResult:
    """Vector search result.
    
    Attributes:
        vector_id: Unique identifier of the matching vector document.
        content: Text content of the matching document.
        similarity_score: Cosine similarity score (0.0-1.0) indicating match quality.
        metadata: Dictionary with document metadata.
    """
    vector_id: str
    content: str
    similarity_score: float
    metadata: Dict[str, Any]


class VectorDatabaseBlock(LEGOBlock):
    """VectorDatabaseBlock provides vector indexing and semantic search.
    
    The VectorDatabaseBlock manages vector embeddings for semantic search. It
    generates embeddings from text content, indexes documents, and performs
    similarity search using cosine similarity. Includes PII detection and
    comprehensive audit logging.
    
    Attributes:
        block_name: Block identifier ("vector_database").
        version: Block version ("1.0.0").
        requires: Empty tuple (foundational block, no dependencies).
        PII_PATTERNS: Dictionary of regex patterns for PII detection.
            Keys are PII types (email, phone, ssn, credit_card), values are regex patterns.
        EMBEDDING_DIMENSIONS: Default embedding dimensions (384).
        embedding_dimensions: Configurable embedding dimensions (set during initialization).
    """
    
    block_name: str = "vector_database"
    version: str = "1.0.0"
    requires: tuple = ()  # Foundational block
    
    # PII patterns (SENTINEL: PII Detection)
    PII_PATTERNS: Dict[str, str] = {
        "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        "phone": r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
        "ssn": r'\b\d{3}-\d{2}-\d{4}\b',
        "credit_card": r'\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b',
    }
    
    # Embedding dimensions (simplified - in production, use actual embedding model)
    EMBEDDING_DIMENSIONS: int = 384
    
    def __init__(self) -> None:
        """Initialize VectorDatabaseBlock.
        
        Sets up internal state for vector storage, operation tracking, PII
        detection, and audit logging. Embedding dimensions are set during
        initialization via initialize().
        """
        super().__init__()
        self._vectors: Dict[str, VectorDocument] = {}
        self._operation_count: int = 0
        self._error_count: int = 0
        self._pii_detections: int = 0
        self._audit_log: List[Dict[str, Any]] = []
    
    def get_schema(self) -> Dict[str, Any]:
        """Get configuration schema.
        
        Returns the JSON schema for VectorDatabaseBlock configuration. Optional
        field is embedding_dimensions (default: 384).
        
        Returns:
            Dictionary containing JSON schema for configuration validation.
        """
        return {
            "type": "object",
            "required": [],
            "properties": {
                "embedding_dimensions": {"type": "integer", "default": self.EMBEDDING_DIMENSIONS},
            },
        }
    
    def initialize(self, config: Dict[str, Any]) -> None:
        """Initialize vector database block.
        
        Initializes the VectorDatabaseBlock with configurable embedding dimensions.
        Must be called before indexing or searching vectors.
        
        Args:
            config: Configuration dictionary containing:
                - embedding_dimensions: Optional integer embedding dimensions (default: 384)
        
        Raises:
            ValidationError: If configuration schema validation fails.
        
        Example:
            ```python
            vector_db = VectorDatabaseBlock()
            vector_db.initialize({"embedding_dimensions": 512})
            ```
        """
        self.validate_config(config)
        self.embedding_dimensions = config.get("embedding_dimensions", self.EMBEDDING_DIMENSIONS)
        self._initialized = True
        logger.info(f"VectorDatabaseBlock initialized: embedding_dimensions={self.embedding_dimensions}")
    
    def _detect_pii(self, text: str) -> Tuple[bool, List[str]]:
        """Detect PII in text.
        
        Scans text for PII patterns including email addresses, phone numbers,
        SSNs, and credit card numbers. This is a Sentinel compliance check
        for PII detection.
        
        Args:
            text: Text string to scan for PII.
        
        Returns:
            Tuple containing:
            - Boolean indicating if any PII was detected
            - List of PII types detected (empty list if none)
        """
        detected_types = []
        for pii_type, pattern in self.PII_PATTERNS.items():
            if re.search(pattern, text, re.IGNORECASE):
                detected_types.append(pii_type)
        return len(detected_types) > 0, detected_types
    
    def _generate_embedding(self, text: str) -> List[float]:
        """Generate vector embedding.
        
        Generates a vector embedding from text content. For greenfield, uses
        a simplified hash-based approach. In production, would use actual
        embedding models (sentence-transformers, OpenAI, etc.).
        
        Args:
            text: Text content to generate embedding for.
        
        Returns:
            List of float values representing the embedding vector.
        """
        # Simplified embedding generation (in production, use sentence-transformers, OpenAI, etc.)
        # For greenfield, return mock embedding
        import hashlib
        hash_obj = hashlib.md5(text.encode('utf-8'))
        hash_bytes = hash_obj.digest()
        
        # Convert hash to embedding-like vector
        embedding = []
        for i in range(0, min(len(hash_bytes), self.embedding_dimensions)):
            embedding.append(float(hash_bytes[i]) / 255.0)
        
        # Pad to required dimensions
        while len(embedding) < self.embedding_dimensions:
            embedding.append(0.0)
        
        return embedding[:self.embedding_dimensions]
    
    def _cosine_similarity(self, vec1: List[float], vec2: List[float]) -> float:
        """Calculate cosine similarity between two vectors.
        
        Calculates the cosine similarity score (0.0-1.0) between two embedding
        vectors. Returns 0.0 if vectors have different dimensions or zero magnitude.
        
        Args:
            vec1: First embedding vector.
            vec2: Second embedding vector.
        
        Returns:
            Cosine similarity score (0.0-1.0).
        """
        if len(vec1) != len(vec2):
            return 0.0
        
        dot_product = sum(a * b for a, b in zip(vec1, vec2))
        magnitude1 = sum(a * a for a in vec1) ** 0.5
        magnitude2 = sum(b * b for b in vec2) ** 0.5
        
        if magnitude1 == 0 or magnitude2 == 0:
            return 0.0
        
        return dot_product / (magnitude1 * magnitude2)
    
    def _validate_input(self, content: str, metadata: Optional[Dict[str, Any]] = None) -> None:
        """Validate input.
        
        Validates content and metadata for indexing. This is a Sentinel
        compliance check for data validation.
        
        Args:
            content: Text content to validate.
            metadata: Optional metadata dictionary to validate.
        
        Raises:
            ValueError: If content is empty, too long, or metadata is too large.
        """
        if not content or len(content.strip()) == 0:
            raise ValueError("Content cannot be empty")
        
        if len(content) > 1000000:  # Reasonable limit
            raise ValueError("Content too long (max 1000000 characters)")
        
        if metadata and len(str(metadata)) > 100000:  # Reasonable limit
            raise ValueError("Metadata too large")
    
    def _log_audit(self, operation: str, vector_id: str, details: Optional[Dict[str, Any]] = None) -> None:
        """Log audit trail.
        
        Creates an audit log entry for vector operations. This is a Sentinel
        compliance check for audit logging.
        
        Args:
            operation: Name of the operation (e.g., "index_vector", "search_similar").
            vector_id: Unique identifier of the vector (or "search" for search operations).
            details: Optional dictionary with additional operation details.
        """
        audit_entry = {
            "timestamp": time.time(),
            "operation": operation,
            "vector_id": vector_id,
            "details": details or {},
        }
        self._audit_log.append(audit_entry)
        logger.info(f"Audit: {operation} - Vector: {vector_id}")
    
    async def index_vector(self, vector_id: str, content: str, metadata: Optional[Dict[str, Any]] = None) -> str:
        """Index a vector document.
        
        Indexes a document by generating an embedding and storing it with metadata.
        Performs PII detection, validates input, and maintains audit logs. This is
        a Sentinel compliance check for vector data privacy and PII detection.
        
        Args:
            vector_id: Unique identifier for the vector document.
            content: Text content to index.
            metadata: Optional dictionary with document metadata.
        
        Returns:
            String vector_id of the indexed document.
        
        Raises:
            RuntimeError: If VectorDatabaseBlock is not initialized.
            ValueError: If input validation fails.
            Exception: If indexing fails.
        
        Example:
            ```python
            vector_id = await vector_db.index_vector(
                vector_id="doc-001",
                content="Document content...",
                metadata={"source": "api", "tags": ["important"]}
            )
            ```
        """
        if not self._initialized:
            raise RuntimeError("VectorDatabaseBlock not initialized")
        
        # SENTINEL: Data Validation
        self._validate_input(content, metadata)
        
        # SENTINEL: PII Detection - scan before indexing
        pii_detected, pii_types = self._detect_pii(content)
        if pii_detected:
            self._pii_detections += 1
            logger.warning(f"PII detected in vector content: {pii_types}")
            # In production, might reject or sanitize
        
        # SENTINEL: Security - check authorization
        # (In production, check user/service permissions)
        
        self._operation_count += 1
        
        try:
            # Generate embedding
            embedding = self._generate_embedding(content)
            
            # Create vector document
            vector_doc = VectorDocument(
                vector_id=vector_id,
                content=content,
                embedding=embedding,
                metadata=(metadata or {}) | {"pii_detected": pii_detected, "pii_types": pii_types if pii_detected else []}
            )
            
            # Store vector
            self._vectors[vector_id] = vector_doc
            
            # SENTINEL: Audit Logging
            self._log_audit("index_vector", vector_id, {
                "content_length": len(content),
                "pii_detected": pii_detected,
                "embedding_dimensions": len(embedding)
            })
            
            logger.info(f"Vector indexed: {vector_id}")
            return vector_id
            
        except Exception as e:
            self._error_count += 1
            error_msg = str(e)
            logger.error(f"Failed to index vector {vector_id}: {error_msg}")
            
            # SENTINEL: Audit Logging
            self._log_audit("index_vector_error", vector_id, {"error": error_msg})
            
            raise
    
    async def search_similar(self, query: str, limit: int = 10, min_similarity: float = 0.0) -> List[SearchResult]:
        """Search for similar vectors.
        
        Searches for vectors similar to the query using cosine similarity.
        Generates a query embedding and compares it against all indexed vectors.
        Results are sorted by similarity score (descending) and limited to the
        specified count. This is a Sentinel compliance check for vector data
        privacy and access control.
        
        Args:
            query: Search query text.
            limit: Maximum number of results to return (default: 10).
            min_similarity: Minimum similarity score threshold (default: 0.0, range: 0.0-1.0).
        
        Returns:
            List of SearchResult objects sorted by similarity score (descending),
            limited to specified count.
        
        Raises:
            RuntimeError: If VectorDatabaseBlock is not initialized.
            ValueError: If query is empty.
            Exception: If search fails.
        
        Example:
            ```python
            results = await vector_db.search_similar(
                query="search query",
                limit=5,
                min_similarity=0.7
            )
            
            for result in results:
                print(f"{result.vector_id}: {result.similarity_score:.2f}")
            ```
        """
        if not self._initialized:
            raise RuntimeError("VectorDatabaseBlock not initialized")
        
        # SENTINEL: Data Validation
        if not query or len(query.strip()) == 0:
            raise ValueError("Query cannot be empty")
        
        # SENTINEL: Security - check authorization
        # (In production, check user/service permissions)
        
        self._operation_count += 1
        
        try:
            # Generate query embedding
            query_embedding = self._generate_embedding(query)
            
            # Search similar vectors
            results = []
            for vector_id, vector_doc in self._vectors.items():
                similarity = self._cosine_similarity(query_embedding, vector_doc.embedding)
                
                if similarity >= min_similarity:
                    results.append(SearchResult(
                        vector_id=vector_id,
                        content=vector_doc.content,
                        similarity_score=similarity,
                        metadata=vector_doc.metadata
                    ))
            
            # Sort by similarity (descending)
            results.sort(key=lambda r: r.similarity_score, reverse=True)
            
            # Limit results
            results = results[:limit]
            
            # SENTINEL: Audit Logging
            self._log_audit("search_similar", "search", {
                "query": query[:100],  # Truncate for audit
                "results_count": len(results),
                "min_similarity": min_similarity
            })
            
            logger.info(f"Vector search completed: {len(results)} results for query")
            return results
            
        except Exception as e:
            self._error_count += 1
            error_msg = str(e)
            logger.error(f"Vector search failed: {error_msg}")
            
            # SENTINEL: Audit Logging
            self._log_audit("search_similar_error", "search", {"error": error_msg})
            
            raise
    
    def get_vector(self, vector_id: str) -> Optional[VectorDocument]:
        """Get vector by ID.
        
        Retrieves a vector document by its ID. Performs access control validation
        and audit logging.
        
        Args:
            vector_id: Unique identifier of the vector to retrieve.
        
        Returns:
            VectorDocument object if found, None otherwise.
        
        Raises:
            RuntimeError: If VectorDatabaseBlock is not initialized.
        """
        if not self._initialized:
            raise RuntimeError("VectorDatabaseBlock not initialized")
        
        # SENTINEL: Security - check authorization
        # (In production, check user/service permissions)
        
        vector_doc = self._vectors.get(vector_id)
        
        if vector_doc:
            # SENTINEL: Audit Logging
            self._log_audit("get_vector", vector_id)
        
        return vector_doc
    
    def delete_vector(self, vector_id: str) -> bool:
        """Delete vector by ID.
        
        Deletes a vector document by its ID. Performs access control validation
        and audit logging.
        
        Args:
            vector_id: Unique identifier of the vector to delete.
        
        Returns:
            Boolean indicating if vector was deleted (True) or not found (False).
        
        Raises:
            RuntimeError: If VectorDatabaseBlock is not initialized.
        """
        if not self._initialized:
            raise RuntimeError("VectorDatabaseBlock not initialized")
        
        # SENTINEL: Security - check authorization
        # (In production, check user/service permissions)
        
        if vector_id in self._vectors:
            del self._vectors[vector_id]
            
            # SENTINEL: Audit Logging
            self._log_audit("delete_vector", vector_id)
            
            logger.info(f"Vector deleted: {vector_id}")
            return True
        
        return False
    
    def get_health(self) -> BlockHealth:
        """Get vector database block health status.
        
        Returns the health status of the VectorDatabaseBlock based on initialization
        state, error rates, and PII detection rates. Health is unhealthy if error
        rate exceeds 20%, degraded if PII detection rate exceeds 10%.
        
        Returns:
            BlockHealth object containing:
            - status: HealthStatus (HEALTHY, DEGRADED, or UNHEALTHY)
            - message: Human-readable status message
            - details: Dictionary with operational metrics (vector_count, operations,
                errors, PII detections, rates, audit_log_entries)
        """
        if not self._initialized:
            return BlockHealth(
                status=HealthStatus.UNHEALTHY,
                message="VectorDatabaseBlock not initialized",
                details={}
            )
        
        error_rate = self._error_count / max(self._operation_count, 1)
        pii_rate = self._pii_detections / max(self._operation_count, 1)
        vector_count = len(self._vectors)
        
        if error_rate > 0.2:
            return BlockHealth(
                status=HealthStatus.UNHEALTHY,
                message=f"High error rate: {error_rate:.2%}",
                details={"error_rate": error_rate, "operations": self._operation_count, "errors": self._error_count}
            )
        
        if pii_rate > 0.1:
            return BlockHealth(
                status=HealthStatus.DEGRADED,
                message=f"High PII detection rate: {pii_rate:.2%}",
                details={"pii_rate": pii_rate, "pii_detections": self._pii_detections}
            )
        
        return BlockHealth(
            status=HealthStatus.HEALTHY,
            message="VectorDatabaseBlock operating normally",
            details={
                "vector_count": vector_count,
                "operations": self._operation_count,
                "errors": self._error_count,
                "error_rate": error_rate,
                "pii_detections": self._pii_detections,
                "pii_rate": pii_rate,
                "audit_log_entries": len(self._audit_log)
            }
        )
    
    def get_audit_log(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get audit log entries.
        
        Retrieves recent audit log entries for vector operations. This is a
        Sentinel compliance check for audit logging access.
        
        Args:
            limit: Maximum number of entries to return (default: 100).
        
        Returns:
            List of audit log entry dictionaries, most recent first.
        """
        return self._audit_log[-limit:]

