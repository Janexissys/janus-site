# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""ActionsBlock - Webhook execution.

The ActionsBlock provides webhook execution capabilities for external integrations.
It executes HTTP webhooks with retry logic, domain allowlisting, PII detection,
and comprehensive error handling. Supports configurable timeouts and retry policies.

**Card**: CARD-V6B-P1-LEGO-ACTIONS  
**MC Target**: 8.50  
**Dependencies**: None (foundational block)

**Key Responsibilities**:
- Execute HTTP webhooks (GET, POST, PUT, PATCH, DELETE)
- Validate URLs and enforce domain allowlisting
- Detect PII in webhook payloads
- Implement retry logic with exponential backoff
- Track action status and execution history
- Provide health monitoring and audit logs

**Sentinel Compliance**:
- PII Detection: Scans webhook payloads for PII patterns
- Data Validation: Validates URLs, HTTP methods, and payloads
- Security: Enforces domain allowlisting and URL validation
- Error Handling: Implements retry logic and error recovery
- Audit Logging: Logs all webhook executions with context
- HTTPS Enforcement: Warns on non-HTTPS URLs

**Example Usage**:
    ```python
    from blocks.actions_block import ActionsBlock
    
    actions = ActionsBlock()
    actions.initialize({
        "timeout_seconds": 10,
        "max_retries": 3,
        "allowlist_domains": ["api.example.com"]
    })
    
    # Execute webhook
    result = actions.execute_webhook(
        url="https://api.example.com/webhook",
        payload={"event": "user_created", "user_id": "123"},
        method="POST"
    )
    ```
"""

import logging
import re
import time
import uuid
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional

import requests

from .base_block import BlockHealth, HealthStatus, LEGOBlock

logger = logging.getLogger(__name__)


class ActionStatus(Enum):
    """Action execution status.
    
    Attributes:
        QUEUED: Action is queued and waiting to be executed.
        EXECUTING: Action is currently being executed.
        COMPLETED: Action completed successfully.
        FAILED: Action failed during execution.
        CANCELLED: Action was cancelled before completion.
    """
    QUEUED = "queued"
    EXECUTING = "executing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class Action:
    """Action to execute.
    
    Attributes:
        action_id: Unique identifier for the action.
        action_type: Type of action (e.g., "webhook").
        payload: Dictionary containing action payload (URL, method, body, headers).
        status: Current ActionStatus of the action.
        created_at: Timestamp when action was created.
        started_at: Optional timestamp when execution started.
        completed_at: Optional timestamp when execution completed.
        error: Optional error message if action failed.
        result: Optional dictionary with execution result (status_code, headers, body).
        retry_count: Number of retry attempts made.
        max_retries: Maximum number of retry attempts allowed.
    """
    action_id: str
    action_type: str
    payload: Dict[str, Any]
    status: ActionStatus
    created_at: float
    started_at: Optional[float] = None
    completed_at: Optional[float] = None
    error: Optional[str] = None
    result: Optional[Dict[str, Any]] = None
    retry_count: int = 0
    max_retries: int = 3


class ActionsBlock(LEGOBlock):
    """ActionsBlock provides webhook execution capabilities.
    
    The ActionsBlock manages webhook execution with retry logic, domain allowlisting,
    PII detection, and comprehensive error handling. It tracks action status and
    provides health monitoring and audit logs.
    
    Attributes:
        block_name: Block identifier ("actions").
        version: Block version ("1.0.0").
        requires: Empty tuple (foundational block, no dependencies).
        DEFAULT_TIMEOUT_SECONDS: Default webhook timeout in seconds (8).
        DEFAULT_MAX_RETRIES: Default maximum retry attempts (3).
        DEFAULT_ALLOWLIST_DOMAINS: Default empty allowlist (no restrictions for greenfield).
        PII_PATTERNS: Dictionary of regex patterns for PII detection.
            Keys are PII types (email, phone, ssn, credit_card), values are regex patterns.
    """
    
    block_name: str = "actions"
    version: str = "1.0.0"
    requires: tuple = ()  # Foundational block
    
    # Webhook configuration
    DEFAULT_TIMEOUT_SECONDS: int = 8
    DEFAULT_MAX_RETRIES: int = 3
    DEFAULT_ALLOWLIST_DOMAINS: List[str] = []  # Empty = no restrictions (for greenfield)
    
    # PII patterns (SENTINEL: PII Detection)
    PII_PATTERNS: Dict[str, str] = {
        "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        "phone": r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
        "ssn": r'\b\d{3}-\d{2}-\d{4}\b',
        "credit_card": r'\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b',
    }
    
    def __init__(self) -> None:
        """Initialize ActionsBlock.
        
        Sets up internal state for action tracking, operation counting, and
        configuration. Configuration (timeouts, retries, allowlist) is set during
        initialization via initialize().
        """
        super().__init__()
        self._timeout_seconds: int = self.DEFAULT_TIMEOUT_SECONDS
        self._max_retries: int = self.DEFAULT_MAX_RETRIES
        self._allowlist_domains: List[str] = self.DEFAULT_ALLOWLIST_DOMAINS
        self._actions: Dict[str, Action] = {}
        self._total_executed: int = 0
        self._total_failed: int = 0
    
    def get_schema(self) -> Dict[str, Any]:
        """Get block configuration schema.
        
        Returns the JSON schema for ActionsBlock configuration. Optional fields
        are timeout_seconds (default: 8), max_retries (default: 3), and
        allowlist_domains (default: empty list, no restrictions).
        
        Returns:
            Dictionary containing JSON schema for configuration validation.
        """
        return {
            "type": "object",
            "properties": {
                "timeout_seconds": {
                    "type": "integer",
                    "description": "Webhook timeout in seconds",
                    "default": self.DEFAULT_TIMEOUT_SECONDS
                },
                "max_retries": {
                    "type": "integer",
                    "description": "Maximum retry attempts",
                    "default": self.DEFAULT_MAX_RETRIES
                },
                "allowlist_domains": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Allowed webhook domains (empty = no restrictions)",
                    "default": []
                }
            }
        }
    
    def initialize(self, config: Dict[str, Any]) -> None:
        """Initialize the block with configuration.
        
        Initializes the ActionsBlock with webhook timeout, maximum retries, and
        domain allowlist settings. Validates all configuration values.
        
        Args:
            config: Configuration dictionary containing:
                - timeout_seconds: Optional number timeout in seconds (default: 8)
                - max_retries: Optional integer maximum retries (default: 3)
                - allowlist_domains: Optional list of allowed domains (default: empty)
        
        Raises:
            ValueError: If any configuration value is invalid.
            ValidationError: If configuration schema validation fails.
        
        Example:
            ```python
            actions = ActionsBlock()
            actions.initialize({
                "timeout_seconds": 10,
                "max_retries": 5,
                "allowlist_domains": ["api.example.com"]
            })
            ```
        """
        self.validate_config(config)
        
        # SENTINEL: Data Validation
        timeout_seconds = config.get("timeout_seconds", self.DEFAULT_TIMEOUT_SECONDS)
        if not isinstance(timeout_seconds, (int, float)) or timeout_seconds < 1:
            raise ValueError("timeout_seconds must be a positive number")
        
        max_retries = config.get("max_retries", self.DEFAULT_MAX_RETRIES)
        if not isinstance(max_retries, int) or max_retries < 0:
            raise ValueError("max_retries must be a non-negative integer")
        
        allowlist_domains = config.get("allowlist_domains", self.DEFAULT_ALLOWLIST_DOMAINS)
        if not isinstance(allowlist_domains, list):
            raise ValueError("allowlist_domains must be a list")
        
        self._timeout_seconds = timeout_seconds
        self._max_retries = max_retries
        self._allowlist_domains = allowlist_domains
        self._config = config
        self._initialized = True
        
        # SENTINEL: Audit Logging
        logger.info(
            f"ActionsBlock initialized: timeout={timeout_seconds}s, "
            f"max_retries={max_retries}, allowlist={len(allowlist_domains)} domains"
        )
    
    def execute_webhook(
        self,
        url: str,
        payload: Dict[str, Any],
        method: str = "POST",
        headers: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Execute a webhook action.
        
        Executes an HTTP webhook with retry logic, domain allowlisting, and PII
        detection. Creates an action record, performs validation, and executes
        the webhook with exponential backoff retry on failures.
        
        Args:
            url: Webhook URL (must start with http:// or https://).
            payload: Dictionary containing webhook payload data.
            method: HTTP method (GET, POST, PUT, PATCH, DELETE) - default: POST.
            headers: Optional dictionary with HTTP headers.
        
        Returns:
            Dictionary with:
            - action_id: Unique identifier of the action
            - status: "completed"
            - result: Dictionary with status_code, headers, body
            - duration_seconds: Execution duration
        
        Raises:
            ValueError: If URL is invalid, method is invalid, or domain not in allowlist.
            RuntimeError: If webhook execution fails after all retries.
        
        Example:
            ```python
            result = actions.execute_webhook(
                url="https://api.example.com/webhook",
                payload={"event": "user_created"},
                method="POST",
                headers={"Content-Type": "application/json"}
            )
            ```
        """
        # SENTINEL: Data Validation
        if not isinstance(url, str) or not url:
            raise ValueError("url must be a non-empty string")
        
        if not isinstance(payload, dict):
            raise ValueError("payload must be a dictionary")
        
        if method not in ["GET", "POST", "PUT", "PATCH", "DELETE"]:
            raise ValueError(f"Invalid HTTP method: {method}")
        
        # SENTINEL: Security - URL validation
        if not url.startswith(("http://", "https://")):
            raise ValueError("URL must start with http:// or https://")
        
        # SENTINEL: Security - Domain allowlist check
        if self._allowlist_domains:
            from urllib.parse import urlparse
            parsed_url = urlparse(url)
            domain = parsed_url.netloc.split(":")[0]  # Remove port if present
            
            if not any(domain == allowed or domain.endswith(f".{allowed}") for allowed in self._allowlist_domains):
                raise ValueError(f"Domain not in allowlist: {domain}")
        
        # SENTINEL: PII Detection
        pii_detected = self._detect_pii(payload)
        if pii_detected:
            logger.warning("PII detected in webhook payload - proceeding with caution")
        
        # Create action record
        action_id = str(uuid.uuid4())
        action = Action(
            action_id=action_id,
            action_type="webhook",
            payload={"url": url, "method": method, "body": payload, "headers": headers or {}},
            status=ActionStatus.QUEUED,
            created_at=time.time(),
            max_retries=self._max_retries
        )
        
        self._actions[action_id] = action
        
        # SENTINEL: Audit Logging
        self._audit_operation("execute_webhook", {"action_id": action_id, "url": url, "method": method})
        
        # Execute webhook
        action.status = ActionStatus.EXECUTING
        action.started_at = time.time()
        
        try:
            # SENTINEL: Error Handling - Execute with retry logic
            result = self._execute_with_retry(action, url, method, payload, headers)
            
            action.status = ActionStatus.COMPLETED
            action.completed_at = time.time()
            action.result = result
            self._total_executed += 1
            
            # SENTINEL: Audit Logging
            logger.info(
                f"Webhook executed successfully: action_id={action_id}, "
                f"url={url}, duration={action.completed_at - action.started_at:.2f}s"
            )
            
            return {
                "action_id": action_id,
                "status": "completed",
                "result": result,
                "duration_seconds": action.completed_at - action.started_at
            }
            
        except Exception as e:
            # SENTINEL: Error Handling - Handle execution failures
            action.status = ActionStatus.FAILED
            action.completed_at = time.time()
            action.error = str(e)
            self._total_failed += 1
            
            logger.error(f"Webhook execution failed: action_id={action_id}, url={url}, error={e}")
            
            raise RuntimeError(f"Webhook execution failed: {e}")
    
    def get_action_status(self, action_id: str) -> Dict[str, Any]:
        """Get action execution status.
        
        Retrieves the current status and metadata for a webhook action.
        
        Args:
            action_id: Unique identifier of the action.
        
        Returns:
            Dictionary with:
            - action_id: Action identifier
            - status: Current ActionStatus value
            - action_type: Type of action
            - created_at: Creation timestamp
            - started_at: Execution start timestamp (None if not started)
            - completed_at: Completion timestamp (None if not completed)
            - error: Error message (None if no error)
            - retry_count: Number of retry attempts
            - result: Execution result (None if not completed)
        
        Raises:
            ValueError: If action_id is invalid or action not found.
        """
        # SENTINEL: Data Validation
        if not isinstance(action_id, str) or not action_id:
            raise ValueError("action_id must be a non-empty string")
        
        if action_id not in self._actions:
            raise ValueError(f"Action not found: {action_id}")
        
        action = self._actions[action_id]
        
        return {
            "action_id": action_id,
            "status": action.status.value,
            "action_type": action.action_type,
            "created_at": action.created_at,
            "started_at": action.started_at,
            "completed_at": action.completed_at,
            "error": action.error,
            "retry_count": action.retry_count,
            "result": action.result
        }
    
    def get_health(self) -> BlockHealth:
        """Get block health status.
        
        Returns the health status of the ActionsBlock based on initialization
        state, failure rates, and active action counts. Health is degraded if
        failure rate exceeds 20%.
        
        Returns:
            BlockHealth object containing:
            - status: HealthStatus (HEALTHY, DEGRADED, or UNHEALTHY)
            - message: Human-readable status message
            - details: Dictionary with operational metrics (total_actions, active_actions,
                failed_actions, total_executed, total_failed, timeout_seconds, max_retries)
        """
        if not self._initialized:
            return BlockHealth(
                HealthStatus.UNHEALTHY,
                "Block not initialized",
                {}
            )
        
        # Calculate health metrics
        total_actions = len(self._actions)
        active_actions = sum(1 for a in self._actions.values() if a.status == ActionStatus.EXECUTING)
        failed_actions = sum(1 for a in self._actions.values() if a.status == ActionStatus.FAILED)
        
        # Health is degraded if failure rate is high
        failure_rate = failed_actions / total_actions if total_actions > 0 else 0.0
        if failure_rate > 0.2:  # >20% failure rate
            status = HealthStatus.DEGRADED
            message = f"High failure rate: {failure_rate:.1%}"
        else:
            status = HealthStatus.HEALTHY
            message = "Webhook execution operational"
        
        return BlockHealth(
            status,
            message,
            {
                "total_actions": total_actions,
                "active_actions": active_actions,
                "failed_actions": failed_actions,
                "total_executed": self._total_executed,
                "total_failed": self._total_failed,
                "timeout_seconds": self._timeout_seconds,
                "max_retries": self._max_retries
            }
        )
    
    def _execute_with_retry(
        self,
        action: Action,
        url: str,
        method: str,
        payload: Dict[str, Any],
        headers: Optional[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """Execute webhook with retry logic.
        
        Executes a webhook request with exponential backoff retry logic. Retries
        up to max_retries times on failure. Warns on non-HTTPS URLs.
        
        Args:
            action: Action record to track retry attempts.
            url: Webhook URL to execute.
            method: HTTP method to use.
            payload: Webhook payload data.
            headers: Optional HTTP headers.
        
        Returns:
            Dictionary with status_code, headers, and body from successful response.
        
        Raises:
            RuntimeError: If all retry attempts fail.
        """
        last_error = None
        
        for attempt in range(action.max_retries + 1):
            try:
                # SENTINEL: Security - HTTPS enforcement (warning only for greenfield)
                if not url.startswith("https://"):
                    logger.warning(f"Non-HTTPS webhook URL: {url}")
                
                # Execute request
                response = requests.request(
                    method=method,
                    url=url,
                    json=payload,
                    headers=headers or {},
                    timeout=self._timeout_seconds
                )
                
                # SENTINEL: Error Handling - Check response status
                response.raise_for_status()
                
                return {
                    "status_code": response.status_code,
                    "headers": dict(response.headers),
                    "body": response.json() if response.content else None
                }
                
            except requests.exceptions.RequestException as e:
                last_error = e
                action.retry_count = attempt + 1
                
                if attempt < action.max_retries:
                    # Exponential backoff
                    delay = min(2 ** attempt, 60)  # Max 60 seconds
                    logger.warning(
                        f"Webhook attempt {attempt + 1} failed, retrying in {delay}s: {e}"
                    )
                    time.sleep(delay)
                else:
                    logger.error(f"Webhook failed after {action.max_retries + 1} attempts: {e}")
        
        raise RuntimeError(f"Webhook execution failed after {action.max_retries + 1} attempts: {last_error}")
    
    def _detect_pii(self, payload: Dict[str, Any]) -> bool:
        """Detect PII in webhook payload.
        
        Scans webhook payload for PII patterns. This is a Sentinel compliance
        check for PII detection.
        
        Args:
            payload: Dictionary containing webhook payload to scan.
        
        Returns:
            Boolean indicating if any PII was detected.
        """
        # SENTINEL: PII Detection
        payload_str = str(payload).lower()
        
        for pii_type, pattern in self.PII_PATTERNS.items():
            if re.search(pattern, payload_str, re.IGNORECASE):
                logger.warning(f"PII detected in webhook payload: {pii_type}")
                return True
        
        return False
    
    def _audit_operation(self, operation: str, details: Dict[str, Any]) -> None:
        """Audit an operation for security and compliance.
        
        Creates an audit log entry for webhook operations. This is a Sentinel
        compliance check for audit logging.
        
        Args:
            operation: Name of the operation (e.g., "execute_webhook").
            details: Dictionary with operation details.
        """
        # SENTINEL: Audit Logging
        logger.info(f"ActionsBlock audit: operation={operation}, details={details}")

