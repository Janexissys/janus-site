# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""RmdBlock - Markdown with YAML headers for AI speed of read (simple formatter).

The RmdBlock provides formatting capabilities for RMD (Markdown with YAML headers)
files, optimized for AI readability. It formats content with YAML frontmatter,
detects PII, sanitizes dangerous HTML/script patterns, and provides parsing
capabilities. This is a simple formatter with low complexity.

**Card**: CARD-V6B-P1-LEGO-RMD  
**MC Target**: 8.45 (low complexity - simple formatter)  
**Dependencies**: None (foundational block)

**Key Responsibilities**:
- Format content as RMD (Markdown with YAML frontmatter)
- Parse RMD content into YAML frontmatter and markdown body
- Detect PII in RMD content
- Sanitize dangerous HTML/script patterns (XSS prevention)
- Convert between dictionaries and YAML strings
- Provide health monitoring

**Sentinel Compliance**:
- PII Detection: Scans RMD content for PII patterns
- Output Sanitization: Removes dangerous HTML/script patterns to prevent XSS
- Data Validation: Validates content and YAML frontmatter types
- Audit Logging: Logs all formatting and parsing operations

**Example Usage**:
    ```python
    from blocks.rmd_block import RmdBlock
    
    rmd = RmdBlock()
    rmd.initialize({})
    
    # Format RMD
    content = "# Document Title\n\nContent here..."
    frontmatter = {"title": "Document", "author": "John Doe"}
    rmd_content = rmd.format_rmd(content, yaml_frontmatter=frontmatter)
    
    # Parse RMD
    parsed = rmd.parse_rmd(rmd_content)
    print(f"Frontmatter: {parsed['frontmatter']}")
    print(f"Body: {parsed['body']}")
    ```
"""

import logging
import re
from typing import Any, Dict, List, Optional

from .base_block import BlockHealth, HealthStatus, LEGOBlock

logger = logging.getLogger(__name__)


class RmdBlock(LEGOBlock):
    """RmdBlock provides markdown with YAML headers formatting for AI speed of read.
    
    The RmdBlock manages RMD (Markdown with YAML headers) formatting and parsing.
    It formats content with YAML frontmatter, detects PII, sanitizes dangerous
    patterns, and provides parsing capabilities. This is a simple formatter with
    low complexity.
    
    Attributes:
        block_name: Block identifier ("rmd").
        version: Block version ("1.0.0").
        requires: Empty tuple (foundational block, no dependencies).
        YAML_DELIMITER: YAML frontmatter delimiter string ("---").
        PII_PATTERNS: Dictionary of regex patterns for PII detection.
            Keys are PII types (email, phone, ssn, credit_card), values are regex patterns.
        DANGEROUS_PATTERNS: List of regex patterns for dangerous HTML/script content
            (XSS prevention).
    """
    
    block_name: str = "rmd"
    version: str = "1.0.0"
    requires: tuple = ()  # Foundational block
    
    # YAML frontmatter delimiter
    YAML_DELIMITER: str = "---"
    
    # PII patterns (SENTINEL: PII Detection)
    PII_PATTERNS: Dict[str, str] = {
        "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        "phone": r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
        "ssn": r'\b\d{3}-\d{2}-\d{4}\b',
        "credit_card": r'\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b',
    }
    
    # Dangerous HTML/script patterns (SENTINEL: Output Sanitization)
    DANGEROUS_PATTERNS: List[str] = [
        r'<script[^>]*>.*?</script>',
        r'javascript:',
        r'on\w+\s*=',
        r'<iframe[^>]*>',
        r'<object[^>]*>',
        r'<embed[^>]*>',
    ]
    
    def __init__(self) -> None:
        """Initialize RmdBlock.
        
        Sets up internal state for operation tracking. Configuration is set during
        initialization via initialize().
        """
        super().__init__()
        self._total_formatted: int = 0
        self._total_errors: int = 0
    
    def get_schema(self) -> Dict[str, Any]:
        """Get block configuration schema.
        
        Returns the JSON schema for RmdBlock configuration. No configuration
        fields are required (empty properties).
        
        Returns:
            Dictionary containing JSON schema for configuration validation.
        """
        return {
            "type": "object",
            "properties": {}
        }
    
    def initialize(self, config: Dict[str, Any]) -> None:
        """Initialize the block with configuration.
        
        Initializes the RmdBlock. No configuration is required for this simple
        formatter.
        
        Args:
            config: Configuration dictionary (empty for this block).
        
        Raises:
            ValidationError: If configuration schema validation fails.
        
        Example:
            ```python
            rmd = RmdBlock()
            rmd.initialize({})
            ```
        """
        self.validate_config(config)
        
        self._config = config
        self._initialized = True
        
        # SENTINEL: Audit Logging
        logger.info("RmdBlock initialized")
    
    def format_rmd(
        self,
        content: str,
        yaml_frontmatter: Optional[Dict[str, Any]] = None
    ) -> str:
        """Format content as RMD (Markdown with YAML headers).
        
        Formats markdown content with optional YAML frontmatter. Performs PII
        detection, sanitizes dangerous patterns, and creates RMD format with
        YAML delimiters.
        
        Args:
            content: Markdown content string to format.
            yaml_frontmatter: Optional dictionary with YAML frontmatter data.
        
        Returns:
            Formatted RMD content string with YAML frontmatter (if provided)
            and sanitized markdown body.
        
        Raises:
            ValueError: If content is not a string or yaml_frontmatter is not a dict.
        
        Example:
            ```python
            content = "# Title\n\nContent here..."
            frontmatter = {"title": "Document", "author": "John"}
            rmd_content = rmd.format_rmd(content, yaml_frontmatter=frontmatter)
            ```
        """
        # SENTINEL: Data Validation
        if not isinstance(content, str):
            raise ValueError("content must be a string")
        
        if yaml_frontmatter is not None and not isinstance(yaml_frontmatter, dict):
            raise ValueError("yaml_frontmatter must be a dictionary or None")
        
        # SENTINEL: PII Detection
        pii_detected = self._detect_pii(content)
        if pii_detected:
            logger.warning("PII detected in RMD content - proceeding with caution")
        
        # SENTINEL: Output Sanitization
        sanitized_content = self._sanitize_output(content)
        
        # Build RMD format
        rmd_parts = []
        
        # Add YAML frontmatter if provided
        if yaml_frontmatter:
            rmd_parts.append(self.YAML_DELIMITER)
            rmd_parts.append(self._dict_to_yaml(yaml_frontmatter))
            rmd_parts.append(self.YAML_DELIMITER)
            rmd_parts.append("")  # Empty line between frontmatter and content
        
        # Add markdown content
        rmd_parts.append(sanitized_content)
        
        rmd_content = "\n".join(rmd_parts)
        
        self._total_formatted += 1
        
        # SENTINEL: Audit Logging
        self._audit_operation("format_rmd", {
            "content_length": len(content),
            "has_frontmatter": yaml_frontmatter is not None,
            "pii_detected": pii_detected
        })
        
        return rmd_content
    
    def parse_rmd(self, rmd_content: str) -> Dict[str, Any]:
        """Parse RMD content into YAML frontmatter and markdown body.
        
        Parses RMD content to extract YAML frontmatter and markdown body. Checks
        for dangerous patterns and performs PII detection on the body.
        
        Args:
            rmd_content: RMD formatted content string to parse.
        
        Returns:
            Dictionary with:
            - frontmatter: Dictionary with YAML frontmatter data (empty dict if none)
            - body: String containing markdown body content
        
        Raises:
            ValueError: If rmd_content is not a string.
        
        Example:
            ```python
            parsed = rmd.parse_rmd(rmd_content)
            print(f"Title: {parsed['frontmatter'].get('title')}")
            print(f"Body: {parsed['body']}")
            ```
        """
        # SENTINEL: Data Validation
        if not isinstance(rmd_content, str):
            raise ValueError("rmd_content must be a string")
        
        # SENTINEL: Output Sanitization - Check for dangerous patterns
        if self._has_dangerous_patterns(rmd_content):
            logger.warning("Dangerous patterns detected in RMD content")
        
        lines = rmd_content.split('\n')
        
        # Check if YAML frontmatter exists
        if len(lines) < 3 or lines[0].strip() != self.YAML_DELIMITER:
            # No frontmatter, return content as body
            return {
                "frontmatter": {},
                "body": rmd_content
            }
        
        # Find closing delimiter
        closing_idx = None
        for i in range(1, len(lines)):
            if lines[i].strip() == self.YAML_DELIMITER:
                closing_idx = i
                break
        
        if closing_idx is None:
            # No closing delimiter, treat entire content as body
            return {
                "frontmatter": {},
                "body": rmd_content
            }
        
        # Extract frontmatter and body
        frontmatter_lines = lines[1:closing_idx]
        body_lines = lines[closing_idx + 1:]
        
        # Parse YAML frontmatter
        frontmatter = self._yaml_to_dict('\n'.join(frontmatter_lines))
        
        # SENTINEL: PII Detection
        pii_detected = self._detect_pii('\n'.join(body_lines))
        if pii_detected:
            logger.warning("PII detected in parsed RMD body")
        
        # SENTINEL: Audit Logging
        self._audit_operation("parse_rmd", {
            "has_frontmatter": bool(frontmatter),
            "body_length": len('\n'.join(body_lines)),
            "pii_detected": pii_detected
        })
        
        return {
            "frontmatter": frontmatter,
            "body": '\n'.join(body_lines).strip()
        }
    
    def get_health(self) -> BlockHealth:
        """Get block health status.
        
        Returns the health status of the RmdBlock based on initialization state
        and error rates. Health is degraded if error rate exceeds 10%.
        
        Returns:
            BlockHealth object containing:
            - status: HealthStatus (HEALTHY, DEGRADED, or UNHEALTHY)
            - message: Human-readable status message
            - details: Dictionary with operational metrics (total_formatted,
                total_errors, error_rate)
        """
        if not self._initialized:
            return BlockHealth(
                HealthStatus.UNHEALTHY,
                "Block not initialized",
                {}
            )
        
        # Simple formatter - health is based on error rate
        error_rate = self._total_errors / self._total_formatted if self._total_formatted > 0 else 0.0
        
        if error_rate > 0.1:  # >10% error rate
            status = HealthStatus.DEGRADED
            message = f"High error rate: {error_rate:.1%}"
        else:
            status = HealthStatus.HEALTHY
            message = "RMD formatting operational"
        
        return BlockHealth(
            status,
            message,
            {
                "total_formatted": self._total_formatted,
                "total_errors": self._total_errors,
                "error_rate": error_rate
            }
        )
    
    def _sanitize_output(self, content: str) -> str:
        """Sanitize output content to prevent XSS and injection attacks.
        
        Removes dangerous HTML/script patterns from content. This is a Sentinel
        compliance check for output sanitization.
        
        Args:
            content: Content string to sanitize.
        
        Returns:
            Sanitized content string with dangerous patterns removed.
        """
        # SENTINEL: Output Sanitization
        sanitized = content
        
        # Remove dangerous patterns
        for pattern in self.DANGEROUS_PATTERNS:
            sanitized = re.sub(pattern, '', sanitized, flags=re.IGNORECASE | re.DOTALL)
        
        return sanitized
    
    def _has_dangerous_patterns(self, content: str) -> bool:
        """Check if content has dangerous patterns.
        
        Checks content for dangerous HTML/script patterns. This is a Sentinel
        compliance check for output sanitization.
        
        Args:
            content: Content string to check.
        
        Returns:
            Boolean indicating if any dangerous patterns were found.
        """
        # SENTINEL: Output Sanitization
        for pattern in self.DANGEROUS_PATTERNS:
            if re.search(pattern, content, re.IGNORECASE | re.DOTALL):
                return True
        
        return False
    
    def _detect_pii(self, content: str) -> bool:
        """Detect PII in content.
        
        Scans content for PII patterns including email addresses, phone numbers,
        SSNs, and credit card numbers. This is a Sentinel compliance check for
        PII detection.
        
        Args:
            content: Content string to scan for PII.
        
        Returns:
            Boolean indicating if any PII was detected.
        """
        # SENTINEL: PII Detection
        content_lower = content.lower()
        
        for pii_type, pattern in self.PII_PATTERNS.items():
            if re.search(pattern, content_lower, re.IGNORECASE):
                logger.warning(f"PII detected in RMD content: {pii_type}")
                return True
        
        return False
    
    def _dict_to_yaml(self, data: Dict[str, Any]) -> str:
        """Convert dictionary to YAML string.
        
        Converts a dictionary to a simple YAML string format. This is a simplified
        implementation for greenfield.
        
        Args:
            data: Dictionary to convert to YAML.
        
        Returns:
            YAML string representation of the dictionary.
        """
        yaml_lines = []
        
        for key, value in data.items():
            if isinstance(value, str):
                # Escape quotes in strings
                value_str = value.replace('"', '\\"')
                yaml_lines.append(f'{key}: "{value_str}"')
            elif isinstance(value, (int, float, bool)):
                yaml_lines.append(f'{key}: {value}')
            elif isinstance(value, list):
                yaml_lines.append(f'{key}: {value}')
            elif isinstance(value, dict):
                # Simple nested dict handling
                yaml_lines.append(f'{key}:')
                for sub_key, sub_value in value.items():
                    yaml_lines.append(f'  {sub_key}: {sub_value}')
            else:
                yaml_lines.append(f'{key}: {value}')
        
        return '\n'.join(yaml_lines)
    
    def _yaml_to_dict(self, yaml_str: str) -> Dict[str, Any]:
        """Convert YAML string to dictionary.
        
        Converts a simple YAML string to a dictionary. This is a simplified
        implementation for greenfield that handles basic key-value pairs.
        
        Args:
            yaml_str: YAML string to parse into dictionary.
        
        Returns:
            Dictionary parsed from YAML string (empty dict if yaml_str is empty).
        """
        # SENTINEL: Data Validation
        if not yaml_str.strip():
            return {}
        
        result = {}
        lines = yaml_str.split('\n')
        
        for line in lines:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            
            if ':' in line:
                key, value = line.split(':', 1)
                key = key.strip()
                value = value.strip()
                
                # Remove quotes
                if value.startswith('"') and value.endswith('"'):
                    value = value[1:-1]
                elif value.startswith("'") and value.endswith("'"):
                    value = value[1:-1]
                
                # Try to parse as number or boolean
                if value.lower() == 'true':
                    value = True
                elif value.lower() == 'false':
                    value = False
                elif value.isdigit():
                    value = int(value)
                elif value.replace('.', '', 1).isdigit():
                    value = float(value)
                
                result[key] = value
        
        return result
    
    def _audit_operation(self, operation: str, details: Dict[str, Any]) -> None:
        """Audit an operation for security and compliance.
        
        Creates an audit log entry for RMD operations. This is a Sentinel
        compliance check for audit logging.
        
        Args:
            operation: Name of the operation (e.g., "format_rmd", "parse_rmd").
            details: Dictionary with operation details.
        """
        # SENTINEL: Audit Logging
        logger.info(f"RmdBlock audit: operation={operation}, details={details}")

