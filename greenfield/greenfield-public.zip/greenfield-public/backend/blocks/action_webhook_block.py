# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""ActionWebhookBlock - Alternative webhooks with authentication.

The ActionWebhookBlock provides alternative webhook execution capabilities with
multiple authentication methods (HMAC, Bearer, Basic, None). It executes HTTP
webhooks with authentication, retry logic, domain allowlisting, and comprehensive
error handling. Supports configurable timeouts and retry policies.

**Card**: CARD-V6B-P1-LEGO-ACTION_WEBHOOK  
**MC Target**: 8.50  
**Dependencies**: None (foundational block)

**Key Responsibilities**:
- Execute HTTP webhooks with authentication (HMAC, Bearer, Basic, None)
- Generate HMAC-SHA256 signatures for webhook authentication
- Validate URLs and enforce domain allowlisting
- Detect PII in webhook payloads
- Implement retry logic with exponential backoff
- Track webhook status and execution history
- Provide health monitoring and audit logs

**Sentinel Compliance**:
- PII Detection: Scans webhook payloads for PII patterns
- Data Validation: Validates URLs, HTTP methods, and payloads
- Security: Enforces domain allowlisting, URL validation, and webhook authentication
- Error Handling: Implements retry logic and error recovery
- Audit Logging: Logs all webhook executions with context
- HTTPS Enforcement: Warns on non-HTTPS URLs

**Supported Authentication Methods**:
- HMAC: HMAC-SHA256 signature in X-Webhook-Signature header
- Bearer: Bearer token in Authorization header
- Basic: Basic authentication in Authorization header
- None: No authentication

**Example Usage**:
    ```python
    from blocks.action_webhook_block import ActionWebhookBlock
    
    webhook = ActionWebhookBlock()
    webhook.initialize({
        "timeout_seconds": 10,
        "max_retries": 3,
        "allowlist_domains": ["api.example.com"]
    })
    
    # Execute webhook with HMAC authentication
    result = webhook.execute_webhook(
        url="https://api.example.com/webhook",
        payload={"event": "user_created"},
        auth_method="hmac",
        auth_secret="secret-key"
    )
    ```
"""

import hashlib
import hmac
import logging
import re
import time
import uuid
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional

import requests

from .base_block import BlockHealth, HealthStatus, LEGOBlock

logger = logging.getLogger(__name__)


class WebhookStatus(Enum):
    """Webhook execution status.
    
    Attributes:
        QUEUED: Webhook is queued and waiting to be executed.
        AUTHENTICATING: Webhook is being authenticated.
        EXECUTING: Webhook is currently being executed.
        COMPLETED: Webhook completed successfully.
        FAILED: Webhook failed during execution.
        AUTH_FAILED: Webhook authentication failed.
        CANCELLED: Webhook was cancelled before completion.
    """
    QUEUED = "queued"
    AUTHENTICATING = "authenticating"
    EXECUTING = "executing"
    COMPLETED = "completed"
    FAILED = "failed"
    AUTH_FAILED = "auth_failed"
    CANCELLED = "cancelled"


@dataclass
class WebhookAction:
    """Alternative webhook action.
    
    Attributes:
        webhook_id: Unique identifier for the webhook.
        url: Webhook URL to execute.
        payload: Dictionary containing webhook payload data.
        headers: Dictionary with HTTP headers (including auth headers).
        auth_method: Authentication method ("hmac", "bearer", "basic", "none").
        auth_secret: Optional authentication secret (for HMAC, Bearer, Basic).
        status: Current WebhookStatus of the webhook.
        created_at: Timestamp when webhook was created.
        started_at: Optional timestamp when execution started.
        completed_at: Optional timestamp when execution completed.
        error: Optional error message if webhook failed.
        result: Optional dictionary with execution result (status_code, headers, body).
        retry_count: Number of retry attempts made.
        max_retries: Maximum number of retry attempts allowed.
    """
    webhook_id: str
    url: str
    payload: Dict[str, Any]
    headers: Dict[str, Any]
    auth_method: str  # "hmac", "bearer", "basic", "none"
    auth_secret: Optional[str] = None
    status: WebhookStatus = WebhookStatus.QUEUED
    created_at: float = 0.0
    started_at: Optional[float] = None
    completed_at: Optional[float] = None
    error: Optional[str] = None
    result: Optional[Dict[str, Any]] = None
    retry_count: int = 0
    max_retries: int = 3


class ActionWebhookBlock(LEGOBlock):
    """ActionWebhookBlock provides alternative webhook execution with authentication.
    
    The ActionWebhookBlock manages webhook execution with multiple authentication
    methods (HMAC, Bearer, Basic, None), retry logic, domain allowlisting, and
    comprehensive error handling. It tracks webhook status and provides health
    monitoring and audit logs.
    
    Attributes:
        block_name: Block identifier ("action_webhook").
        version: Block version ("1.0.0").
        requires: Empty tuple (foundational block, no dependencies).
        DEFAULT_TIMEOUT_SECONDS: Default webhook timeout in seconds (8).
        DEFAULT_MAX_RETRIES: Default maximum retry attempts (3).
        DEFAULT_ALLOWLIST_DOMAINS: Default empty allowlist (no restrictions for greenfield).
        AUTH_METHODS: List of supported authentication methods (["hmac", "bearer", "basic", "none"]).
        PII_PATTERNS: Dictionary of regex patterns for PII detection.
            Keys are PII types (email, phone, ssn, credit_card), values are regex patterns.
    """
    
    block_name: str = "action_webhook"
    version: str = "1.0.0"
    requires: tuple = ()  # Foundational block
    
    # Webhook configuration
    DEFAULT_TIMEOUT_SECONDS: int = 8
    DEFAULT_MAX_RETRIES: int = 3
    DEFAULT_ALLOWLIST_DOMAINS: List[str] = []  # Empty = no restrictions (for greenfield)
    
    # Supported authentication methods
    AUTH_METHODS: List[str] = ["hmac", "bearer", "basic", "none"]
    
    # PII patterns (SENTINEL: PII Detection)
    PII_PATTERNS: Dict[str, str] = {
        "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        "phone": r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
        "ssn": r'\b\d{3}-\d{2}-\d{4}\b',
        "credit_card": r'\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b',
    }
    
    def __init__(self) -> None:
        """Initialize ActionWebhookBlock.
        
        Sets up internal state for webhook tracking, operation counting, and
        configuration. Configuration (timeouts, retries, allowlist) is set during
        initialization via initialize().
        """
        super().__init__()
        self._timeout_seconds: int = self.DEFAULT_TIMEOUT_SECONDS
        self._max_retries: int = self.DEFAULT_MAX_RETRIES
        self._allowlist_domains: List[str] = self.DEFAULT_ALLOWLIST_DOMAINS
        self._webhooks: Dict[str, WebhookAction] = {}
        self._total_executed: int = 0
        self._total_failed: int = 0
        self._total_auth_failed: int = 0
    
    def get_schema(self) -> Dict[str, Any]:
        """Get block configuration schema.
        
        Returns the JSON schema for ActionWebhookBlock configuration. Optional
        fields are timeout_seconds (default: 8), max_retries (default: 3), and
        allowlist_domains (default: empty list, no restrictions).
        
        Returns:
            Dictionary containing JSON schema for configuration validation.
        """
        return {
            "type": "object",
            "properties": {
                "timeout_seconds": {
                    "type": "integer",
                    "description": "Webhook timeout in seconds",
                    "default": self.DEFAULT_TIMEOUT_SECONDS
                },
                "max_retries": {
                    "type": "integer",
                    "description": "Maximum retry attempts",
                    "default": self.DEFAULT_MAX_RETRIES
                },
                "allowlist_domains": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Allowed webhook domains (empty = no restrictions)",
                    "default": []
                }
            }
        }
    
    def initialize(self, config: Dict[str, Any]) -> None:
        """Initialize the block with configuration.
        
        Initializes the ActionWebhookBlock with webhook timeout, maximum retries,
        and domain allowlist settings. Validates all configuration values.
        
        Args:
            config: Configuration dictionary containing:
                - timeout_seconds: Optional number timeout in seconds (default: 8)
                - max_retries: Optional integer maximum retries (default: 3)
                - allowlist_domains: Optional list of allowed domains (default: empty)
        
        Raises:
            ValueError: If any configuration value is invalid.
            ValidationError: If configuration schema validation fails.
        
        Example:
            ```python
            webhook = ActionWebhookBlock()
            webhook.initialize({
                "timeout_seconds": 10,
                "max_retries": 5,
                "allowlist_domains": ["api.example.com"]
            })
            ```
        """
        self.validate_config(config)
        
        # SENTINEL: Data Validation
        timeout_seconds = config.get("timeout_seconds", self.DEFAULT_TIMEOUT_SECONDS)
        if not isinstance(timeout_seconds, (int, float)) or timeout_seconds < 1:
            raise ValueError("timeout_seconds must be a positive number")
        
        max_retries = config.get("max_retries", self.DEFAULT_MAX_RETRIES)
        if not isinstance(max_retries, int) or max_retries < 0:
            raise ValueError("max_retries must be a non-negative integer")
        
        allowlist_domains = config.get("allowlist_domains", self.DEFAULT_ALLOWLIST_DOMAINS)
        if not isinstance(allowlist_domains, list):
            raise ValueError("allowlist_domains must be a list")
        
        self._timeout_seconds = timeout_seconds
        self._max_retries = max_retries
        self._allowlist_domains = allowlist_domains
        self._config = config
        self._initialized = True
        
        # SENTINEL: Audit Logging
        logger.info(
            f"ActionWebhookBlock initialized: timeout={timeout_seconds}s, "
            f"max_retries={max_retries}, allowlist={len(allowlist_domains)} domains"
        )
    
    def execute_webhook(
        self,
        url: str,
        payload: Dict[str, Any],
        auth_method: str = "none",
        auth_secret: Optional[str] = None,
        headers: Optional[Dict[str, Any]] = None,
        method: str = "POST"
    ) -> Dict[str, Any]:
        """Execute an alternative webhook with authentication.
        
        Executes an HTTP webhook with authentication, retry logic, domain allowlisting,
        and PII detection. Creates a webhook record, authenticates the request, and
        executes the webhook with exponential backoff retry on failures.
        
        Args:
            url: Webhook URL (must start with http:// or https://).
            payload: Dictionary containing webhook payload data.
            auth_method: Authentication method ("hmac", "bearer", "basic", "none") - default: "none".
            auth_secret: Optional authentication secret (required for HMAC, Bearer, Basic).
            headers: Optional dictionary with HTTP headers.
            method: HTTP method (GET, POST, PUT, PATCH, DELETE) - default: POST.
        
        Returns:
            Dictionary with:
            - webhook_id: Unique identifier of the webhook
            - status: "completed"
            - result: Dictionary with status_code, headers, body
            - duration_seconds: Execution duration
        
        Raises:
            ValueError: If URL is invalid, method is invalid, auth_method is invalid,
                auth_secret is missing for auth methods that require it, or domain not in allowlist.
            RuntimeError: If webhook execution fails after all retries.
        
        Example:
            ```python
            # HMAC authentication
            result = webhook.execute_webhook(
                url="https://api.example.com/webhook",
                payload={"event": "user_created"},
                auth_method="hmac",
                auth_secret="secret-key"
            )
            
            # Bearer token authentication
            result = webhook.execute_webhook(
                url="https://api.example.com/webhook",
                payload={"event": "user_created"},
                auth_method="bearer",
                auth_secret="token-12345"
            )
            ```
        """
        # SENTINEL: Data Validation
        if not isinstance(url, str) or not url:
            raise ValueError("url must be a non-empty string")
        
        if not isinstance(payload, dict):
            raise ValueError("payload must be a dictionary")
        
        if auth_method not in self.AUTH_METHODS:
            raise ValueError(f"auth_method must be one of: {', '.join(self.AUTH_METHODS)}")
        
        if method not in ["GET", "POST", "PUT", "PATCH", "DELETE"]:
            raise ValueError(f"Invalid HTTP method: {method}")
        
        # SENTINEL: Security - URL validation
        if not url.startswith(("http://", "https://")):
            raise ValueError("URL must start with http:// or https://")
        
        # SENTINEL: Security - Domain allowlist check
        if self._allowlist_domains:
            from urllib.parse import urlparse
            parsed_url = urlparse(url)
            domain = parsed_url.netloc.split(":")[0]  # Remove port if present
            
            if not any(domain == allowed or domain.endswith(f".{allowed}") for allowed in self._allowlist_domains):
                raise ValueError(f"Domain not in allowlist: {domain}")
        
        # SENTINEL: PII Detection
        pii_detected = self._detect_pii(payload)
        if pii_detected:
            logger.warning("PII detected in webhook payload - proceeding with caution")
        
        # Create webhook action record
        webhook_id = str(uuid.uuid4())
        webhook = WebhookAction(
            webhook_id=webhook_id,
            url=url,
            payload=payload,
            headers=headers or {},
            auth_method=auth_method,
            auth_secret=auth_secret,
            status=WebhookStatus.QUEUED,
            created_at=time.time(),
            max_retries=self._max_retries
        )
        
        self._webhooks[webhook_id] = webhook
        
        # SENTINEL: Audit Logging
        self._audit_operation("execute_webhook", {
            "webhook_id": webhook_id,
            "url": url,
            "method": method,
            "auth_method": auth_method
        })
        
        # Authenticate and execute webhook
        webhook.status = WebhookStatus.AUTHENTICATING
        
        try:
            # SENTINEL: Security - Webhook authentication
            auth_headers = self._authenticate_webhook(webhook)
            webhook.headers.update(auth_headers)
            
            webhook.status = WebhookStatus.EXECUTING
            webhook.started_at = time.time()
            
            # SENTINEL: Error Handling - Execute with retry logic
            result = self._execute_with_retry(webhook, url, method, payload, webhook.headers)
            
            webhook.status = WebhookStatus.COMPLETED
            webhook.completed_at = time.time()
            webhook.result = result
            self._total_executed += 1
            
            # SENTINEL: Audit Logging
            logger.info(
                f"Webhook executed successfully: webhook_id={webhook_id}, "
                f"url={url}, auth_method={auth_method}, "
                f"duration={webhook.completed_at - webhook.started_at:.2f}s"
            )
            
            return {
                "webhook_id": webhook_id,
                "status": "completed",
                "result": result,
                "duration_seconds": webhook.completed_at - webhook.started_at
            }
            
        except ValueError as e:
            # Authentication failure
            webhook.status = WebhookStatus.AUTH_FAILED
            webhook.completed_at = time.time()
            webhook.error = str(e)
            self._total_auth_failed += 1
            
            logger.error(f"Webhook authentication failed: webhook_id={webhook_id}, error={e}")
            
            raise ValueError(f"Webhook authentication failed: {e}")
            
        except Exception as e:
            # Execution failure
            webhook.status = WebhookStatus.FAILED
            webhook.completed_at = time.time()
            webhook.error = str(e)
            self._total_failed += 1
            
            logger.error(f"Webhook execution failed: webhook_id={webhook_id}, url={url}, error={e}")
            
            raise RuntimeError(f"Webhook execution failed: {e}")
    
    def get_webhook_status(self, webhook_id: str) -> Dict[str, Any]:
        """Get webhook execution status.
        
        Retrieves the current status and metadata for a webhook action.
        
        Args:
            webhook_id: Unique identifier of the webhook.
        
        Returns:
            Dictionary with:
            - webhook_id: Webhook identifier
            - status: Current WebhookStatus value
            - url: Webhook URL
            - auth_method: Authentication method used
            - created_at: Creation timestamp
            - started_at: Execution start timestamp (None if not started)
            - completed_at: Completion timestamp (None if not completed)
            - error: Error message (None if no error)
            - retry_count: Number of retry attempts
            - result: Execution result (None if not completed)
        
        Raises:
            ValueError: If webhook_id is invalid or webhook not found.
        """
        # SENTINEL: Data Validation
        if not isinstance(webhook_id, str) or not webhook_id:
            raise ValueError("webhook_id must be a non-empty string")
        
        if webhook_id not in self._webhooks:
            raise ValueError(f"Webhook not found: {webhook_id}")
        
        webhook = self._webhooks[webhook_id]
        
        return {
            "webhook_id": webhook_id,
            "status": webhook.status.value,
            "url": webhook.url,
            "auth_method": webhook.auth_method,
            "created_at": webhook.created_at,
            "started_at": webhook.started_at,
            "completed_at": webhook.completed_at,
            "error": webhook.error,
            "retry_count": webhook.retry_count,
            "result": webhook.result
        }
    
    def get_health(self) -> BlockHealth:
        """Get block health status.
        
        Returns the health status of the ActionWebhookBlock based on initialization
        state, failure rates, and active webhook counts. Health is degraded if
        failure rate exceeds 20% or authentication failures are detected.
        
        Returns:
            BlockHealth object containing:
            - status: HealthStatus (HEALTHY, DEGRADED, or UNHEALTHY)
            - message: Human-readable status message
            - details: Dictionary with operational metrics (total_webhooks, active_webhooks,
                failed_webhooks, auth_failed_webhooks, total_executed, total_failed,
                total_auth_failed, timeout_seconds, max_retries)
        """
        if not self._initialized:
            return BlockHealth(
                HealthStatus.UNHEALTHY,
                "Block not initialized",
                {}
            )
        
        # Calculate health metrics
        total_webhooks = len(self._webhooks)
        active_webhooks = sum(1 for w in self._webhooks.values() if w.status == WebhookStatus.EXECUTING)
        failed_webhooks = sum(1 for w in self._webhooks.values() if w.status == WebhookStatus.FAILED)
        auth_failed_webhooks = sum(1 for w in self._webhooks.values() if w.status == WebhookStatus.AUTH_FAILED)
        
        # Health is degraded if failure rate is high
        total_failures = failed_webhooks + auth_failed_webhooks
        failure_rate = total_failures / total_webhooks if total_webhooks > 0 else 0.0
        
        if failure_rate > 0.2:  # >20% failure rate
            status = HealthStatus.DEGRADED
            message = f"High failure rate: {failure_rate:.1%}"
        elif auth_failed_webhooks > 0:
            status = HealthStatus.DEGRADED
            message = f"Authentication failures detected: {auth_failed_webhooks}"
        else:
            status = HealthStatus.HEALTHY
            message = "Alternative webhook execution operational"
        
        return BlockHealth(
            status,
            message,
            {
                "total_webhooks": total_webhooks,
                "active_webhooks": active_webhooks,
                "failed_webhooks": failed_webhooks,
                "auth_failed_webhooks": auth_failed_webhooks,
                "total_executed": self._total_executed,
                "total_failed": self._total_failed,
                "total_auth_failed": self._total_auth_failed,
                "timeout_seconds": self._timeout_seconds,
                "max_retries": self._max_retries
            }
        )
    
    def _authenticate_webhook(self, webhook: WebhookAction) -> Dict[str, str]:
        """Authenticate webhook request.
        
        Generates authentication headers based on the webhook's auth_method.
        Supports HMAC-SHA256 signatures, Bearer tokens, and Basic authentication.
        This is a Sentinel compliance check for webhook authentication.
        
        Args:
            webhook: WebhookAction object to authenticate.
        
        Returns:
            Dictionary with authentication headers (empty dict for "none" method).
        
        Raises:
            ValueError: If auth_secret is missing for methods that require it,
                or auth_method is unsupported.
        """
        # SENTINEL: Security - Webhook authentication
        if webhook.auth_method == "none":
            return {}
        
        if not webhook.auth_secret:
            raise ValueError(f"auth_secret required for auth_method: {webhook.auth_method}")
        
        if webhook.auth_method == "hmac":
            # HMAC-SHA256 signature
            payload_str = str(webhook.payload)
            signature = hmac.new(
                webhook.auth_secret.encode('utf-8'),
                payload_str.encode('utf-8'),
                hashlib.sha256
            ).hexdigest()
            
            return {
                "X-Webhook-Signature": f"sha256={signature}",
                "X-Webhook-Timestamp": str(int(webhook.created_at))
            }
        
        elif webhook.auth_method == "bearer":
            return {
                "Authorization": f"Bearer {webhook.auth_secret}"
            }
        
        elif webhook.auth_method == "basic":
            import base64
            credentials = base64.b64encode(
                webhook.auth_secret.encode('utf-8')
            ).decode('utf-8')
            return {
                "Authorization": f"Basic {credentials}"
            }
        
        else:
            raise ValueError(f"Unsupported auth_method: {webhook.auth_method}")
    
    def _execute_with_retry(
        self,
        webhook: WebhookAction,
        url: str,
        method: str,
        payload: Dict[str, Any],
        headers: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Execute webhook with retry logic.
        
        Executes a webhook request with exponential backoff retry logic. Retries
        up to max_retries times on failure. Warns on non-HTTPS URLs.
        
        Args:
            webhook: WebhookAction record to track retry attempts.
            url: Webhook URL to execute.
            method: HTTP method to use.
            payload: Webhook payload data.
            headers: HTTP headers dictionary (including authentication headers).
        
        Returns:
            Dictionary with status_code, headers, and body from successful response.
        
        Raises:
            RuntimeError: If all retry attempts fail.
        """
        last_error = None
        
        for attempt in range(webhook.max_retries + 1):
            try:
                # SENTINEL: Security - HTTPS enforcement (warning only for greenfield)
                if not url.startswith("https://"):
                    logger.warning(f"Non-HTTPS webhook URL: {url}")
                
                # Execute request
                response = requests.request(
                    method=method,
                    url=url,
                    json=payload,
                    headers=headers,
                    timeout=self._timeout_seconds
                )
                
                # SENTINEL: Error Handling - Check response status
                response.raise_for_status()
                
                return {
                    "status_code": response.status_code,
                    "headers": dict(response.headers),
                    "body": response.json() if response.content else None
                }
                
            except requests.exceptions.RequestException as e:
                last_error = e
                webhook.retry_count = attempt + 1
                
                if attempt < webhook.max_retries:
                    # Exponential backoff
                    delay = min(2 ** attempt, 60)  # Max 60 seconds
                    logger.warning(
                        f"Webhook attempt {attempt + 1} failed, retrying in {delay}s: {e}"
                    )
                    time.sleep(delay)
                else:
                    logger.error(f"Webhook failed after {webhook.max_retries + 1} attempts: {e}")
        
        raise RuntimeError(f"Webhook execution failed after {webhook.max_retries + 1} attempts: {last_error}")
    
    def _detect_pii(self, payload: Dict[str, Any]) -> bool:
        """Detect PII in webhook payload.
        
        Scans webhook payload for PII patterns. This is a Sentinel compliance
        check for PII detection.
        
        Args:
            payload: Dictionary containing webhook payload to scan.
        
        Returns:
            Boolean indicating if any PII was detected.
        """
        # SENTINEL: PII Detection
        payload_str = str(payload).lower()
        
        for pii_type, pattern in self.PII_PATTERNS.items():
            if re.search(pattern, payload_str, re.IGNORECASE):
                logger.warning(f"PII detected in webhook payload: {pii_type}")
                return True
        
        return False
    
    def _audit_operation(self, operation: str, details: Dict[str, Any]) -> None:
        """Audit an operation for security and compliance.
        
        Creates an audit log entry for webhook operations. This is a Sentinel
        compliance check for audit logging.
        
        Args:
            operation: Name of the operation (e.g., "execute_webhook").
            details: Dictionary with operation details.
        """
        # SENTINEL: Audit Logging
        logger.info(f"ActionWebhookBlock audit: operation={operation}, details={details}")

