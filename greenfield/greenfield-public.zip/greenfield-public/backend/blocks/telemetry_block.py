# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""TelemetryBlock - NDJSON logging with PII protection.

The TelemetryBlock provides NDJSON (Newline Delimited JSON) logging capabilities
with comprehensive PII protection. It detects PII in telemetry events, redacts
sensitive information before logging, and maintains secure file permissions.

**Card**: CARD-V6B-P1-LEGO-TELEMETRY  
**MC Target**: 8.50  
**Dependencies**: None (foundational block)

**Key Responsibilities**:
- Emit telemetry events as NDJSON lines
- Detect PII in telemetry events
- Redact PII before logging to protect sensitive data
- Validate event data and enforce size limits
- Maintain secure file permissions
- Read telemetry events from log files
- Provide audit logs of all operations

**Sentinel Compliance**:
- PII Detection: Scans events for PII patterns before logging
- PII Redaction: Automatically redacts PII from events
- Data Validation: Validates event structure and size limits
- File Permissions: Sets secure permissions on log files
- Access Control: Validates read/write permissions
- Audit Logging: Logs all telemetry operations with context

**Example Usage**:
    ```python
    from blocks.telemetry_block import TelemetryBlock
    
    telemetry = TelemetryBlock()
    telemetry.initialize({"log_file_path": "/var/log/janus/telemetry.ndjson"})
    
    # Emit event
    telemetry.emit({
        "event_type": "api_request",
        "endpoint": "/api/users",
        "status_code": 200,
        "timestamp": 1234567890.0
    })
    
    # Read events
    events = telemetry.read_events(limit=100)
    ```
"""

import json
import logging
import os
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .base_block import BlockHealth, HealthStatus, LEGOBlock

logger = logging.getLogger(__name__)


class TelemetryBlock(LEGOBlock):
    """TelemetryBlock provides NDJSON logging with PII protection.
    
    The TelemetryBlock manages telemetry event logging in NDJSON format with
    comprehensive PII protection. It detects and redacts PII before writing
    to log files, validates event data, and maintains secure file permissions.
    
    Attributes:
        block_name: Block identifier ("telemetry").
        version: Block version ("1.0.0").
        requires: Empty tuple (foundational block, no dependencies).
        PII_PATTERNS: Dictionary of regex patterns for PII detection.
            Keys are PII types (email, phone, ssn, credit_card), values are regex patterns.
        log_file_path: Path object to the NDJSON log file (set during initialization).
    """
    
    block_name: str = "telemetry"
    version: str = "1.0.0"
    requires: tuple = ()  # Foundational block
    
    # PII patterns (SENTINEL: PII Detection)
    PII_PATTERNS: Dict[str, str] = {
        "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        "phone": r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
        "ssn": r'\b\d{3}-\d{2}-\d{4}\b',
        "credit_card": r'\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b',
    }
    
    def __init__(self) -> None:
        """Initialize TelemetryBlock.
        
        Sets up internal state for operation tracking, PII detection/redaction,
        and audit logging. Log file path is set during initialization via initialize().
        """
        super().__init__()
        self.log_file_path: Optional[Path] = None
        self._operation_count: int = 0
        self._error_count: int = 0
        self._pii_detections: int = 0
        self._pii_redactions: int = 0
        self._audit_log: List[Dict[str, Any]] = []
    
    def get_schema(self) -> Dict[str, Any]:
        """Get configuration schema.
        
        Returns the JSON schema for TelemetryBlock configuration. Required field
        is log_file_path (string path to NDJSON log file).
        
        Returns:
            Dictionary containing JSON schema for configuration validation.
        """
        return {
            "type": "object",
            "required": ["log_file_path"],
            "properties": {
                "log_file_path": {"type": "string", "description": "Path to NDJSON log file"},
            },
        }
    
    def initialize(self, config: Dict[str, Any]) -> None:
        """Initialize telemetry block.
        
        Initializes the TelemetryBlock with a log file path. Creates the log
        directory if needed and sets secure file permissions (0o644).
        
        Args:
            config: Configuration dictionary containing:
                - log_file_path: String path to NDJSON log file (required)
        
        Raises:
            ValueError: If log_file_path is missing or empty.
            ValidationError: If configuration schema validation fails.
        
        Example:
            ```python
            telemetry = TelemetryBlock()
            telemetry.initialize({"log_file_path": "/var/log/janus/telemetry.ndjson"})
            ```
        """
        self.validate_config(config)
        
        log_file_path = config.get("log_file_path")
        if not log_file_path:
            raise ValueError("log_file_path is required")
        
        self.log_file_path = Path(log_file_path)
        
        # Ensure log directory exists
        self.log_file_path.parent.mkdir(parents=True, exist_ok=True)
        
        # SENTINEL: Security - set secure permissions
        if self.log_file_path.exists():
            os.chmod(self.log_file_path, 0o644)
        else:
            # Create empty file with secure permissions
            self.log_file_path.touch()
            os.chmod(self.log_file_path, 0o644)
        
        self._initialized = True
        logger.info(f"TelemetryBlock initialized: log_file={self.log_file_path}")
    
    def _detect_pii(self, text: str) -> Tuple[bool, List[str]]:
        """Detect PII in text.
        
        Scans text for PII patterns including email addresses, phone numbers,
        SSNs, and credit card numbers. This is a Sentinel compliance check
        for PII detection.
        
        Args:
            text: Text string to scan for PII.
        
        Returns:
            Tuple containing:
            - Boolean indicating if any PII was detected
            - List of PII types detected (empty list if none)
        """
        detected_types = []
        for pii_type, pattern in self.PII_PATTERNS.items():
            if re.search(pattern, text, re.IGNORECASE):
                detected_types.append(pii_type)
        return len(detected_types) > 0, detected_types
    
    def _redact_pii(self, text: str) -> Tuple[str, List[str]]:
        """Redact PII from text.
        
        Redacts PII patterns from text by replacing them with placeholders
        like [EMAIL_REDACTED]. This is a Sentinel compliance check for PII
        detection and redaction.
        
        Args:
            text: Text string to redact PII from.
        
        Returns:
            Tuple containing:
            - Redacted text string
            - List of PII types that were redacted
        """
        redacted_text = text
        redacted_types = []
        
        for pii_type, pattern in self.PII_PATTERNS.items():
            matches = re.finditer(pattern, redacted_text, re.IGNORECASE)
            for match in reversed(list(matches)):  # Reverse to maintain positions
                redacted_text = redacted_text[:match.start()] + f"[{pii_type.upper()}_REDACTED]" + redacted_text[match.end():]
                if pii_type not in redacted_types:
                    redacted_types.append(pii_type)
        
        return redacted_text, redacted_types
    
    def _validate_event(self, event: Dict[str, Any]) -> None:
        """Validate telemetry event.
        
        Validates telemetry event structure and size limits. Adds timestamp
        if missing. This is a Sentinel compliance check for data validation.
        
        Args:
            event: Event dictionary to validate.
        
        Raises:
            ValueError: If event is not a dictionary, is empty, or exceeds size limits.
        """
        if not isinstance(event, dict):
            raise ValueError("Event must be a dictionary")
        
        if not event:
            raise ValueError("Event cannot be empty")
        
        # Check for required fields (timestamp recommended)
        if "timestamp" not in event:
            event["timestamp"] = time.time()
        
        # Validate event size (prevent DoS)
        event_str = json.dumps(event)
        if len(event_str) > 1000000:  # 1MB limit
            raise ValueError("Event too large (max 1MB)")
    
    def _log_audit(self, operation: str, event_id: str, details: Optional[Dict[str, Any]] = None) -> None:
        """Log audit trail.
        
        Creates an audit log entry for telemetry operations. This is a Sentinel
        compliance check for audit logging.
        
        Args:
            operation: Name of the operation (e.g., "emit", "read_events").
            event_id: Unique identifier of the event (or "read" for read operations).
            details: Optional dictionary with additional operation details.
        """
        audit_entry = {
            "timestamp": time.time(),
            "operation": operation,
            "event_id": event_id,
            "details": details or {},
        }
        self._audit_log.append(audit_entry)
        logger.info(f"Audit: {operation} - Event: {event_id}")
    
    def emit(self, event: Dict[str, Any]) -> None:
        """Emit telemetry event as NDJSON.
        
        Emits a telemetry event as a single NDJSON line. Performs PII detection,
        redacts PII if detected, validates event data, and writes to the log file.
        This is a Sentinel compliance check for PII detection and data validation.
        
        Args:
            event: Dictionary containing telemetry event data. Should include
                "event_type" and optionally "timestamp" (auto-added if missing).
        
        Raises:
            RuntimeError: If TelemetryBlock is not initialized.
            ValueError: If event validation fails.
            PermissionError: If write access to log file is denied.
            Exception: If file write fails.
        
        Example:
            ```python
            telemetry.emit({
                "event_type": "api_request",
                "endpoint": "/api/users",
                "status_code": 200,
                "duration_ms": 150
            })
            ```
        """
        if not self._initialized:
            raise RuntimeError("TelemetryBlock not initialized")
        
        # SENTINEL: Data Validation
        self._validate_event(event)
        
        event_id = event.get("event_id", f"event_{int(time.time() * 1000)}")
        self._operation_count += 1
        
        # SENTINEL: PII Detection - scan event for PII
        event_str = json.dumps(event)
        pii_detected, pii_types = self._detect_pii(event_str)
        
        if pii_detected:
            self._pii_detections += 1
            logger.warning(f"PII detected in telemetry event: {pii_types}")
            
            # SENTINEL: PII Detection - redact PII before logging
            redacted_str, redacted_types = self._redact_pii(event_str)
            self._pii_redactions += 1
            
            # Parse redacted event
            try:
                event = json.loads(redacted_str)
                event["_pii_redacted"] = True
                event["_pii_types"] = redacted_types
            except json.JSONDecodeError:
                # If redaction breaks JSON, create safe event
                event = {
                    "timestamp": event.get("timestamp", time.time()),
                    "event_id": event_id,
                    "event_type": event.get("event_type", "unknown"),
                    "_pii_redacted": True,
                    "_pii_types": redacted_types,
                    "_error": "PII redaction required - original event contained PII"
                }
        else:
            # No PII detected, log original event
            event["_pii_redacted"] = False
        
        # SENTINEL: Security - check write permissions
        if not os.access(self.log_file_path.parent, os.W_OK):
            raise PermissionError(f"Write access denied: {self.log_file_path.parent}")
        
        try:
            # Write NDJSON line (one JSON object per line)
            with open(self.log_file_path, "a", encoding="utf-8") as f:
                json_line = json.dumps(event, ensure_ascii=False)
                f.write(json_line + "\n")
            
            # SENTINEL: Audit Logging
            self._log_audit("emit", event_id, {
                "event_type": event.get("event_type", "unknown"),
                "pii_detected": pii_detected,
                "pii_redacted": pii_detected
            })
            
        except Exception as e:
            self._error_count += 1
            error_msg = str(e)
            logger.error(f"Failed to emit telemetry event: {error_msg}")
            
            # SENTINEL: Audit Logging
            self._log_audit("emit_error", event_id, {"error": error_msg})
            
            raise
    
    def read_events(self, limit: int = 100, start_time: Optional[float] = None) -> List[Dict[str, Any]]:
        """Read telemetry events from log file.
        
        Reads telemetry events from the NDJSON log file, optionally filtered
        by start_time. Performs access control validation and audit logging.
        
        Args:
            limit: Maximum number of events to return (default: 100).
            start_time: Optional timestamp to filter events (only events with
                timestamp >= start_time are returned).
        
        Returns:
            List of event dictionaries, most recent first (up to limit).
        
        Raises:
            RuntimeError: If TelemetryBlock is not initialized.
            PermissionError: If read access to log file is denied.
            Exception: If file read fails.
        """
        if not self._initialized:
            raise RuntimeError("TelemetryBlock not initialized")
        
        # SENTINEL: Security - check read permissions
        if not os.access(self.log_file_path, os.R_OK):
            raise PermissionError(f"Read access denied: {self.log_file_path}")
        
        events = []
        
        try:
            if not self.log_file_path.exists():
                return events
            
            with open(self.log_file_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    
                    try:
                        event = json.loads(line)
                        
                        # Filter by start_time if provided
                        if start_time and event.get("timestamp", 0) < start_time:
                            continue
                        
                        events.append(event)
                        
                        if len(events) >= limit:
                            break
                    except json.JSONDecodeError:
                        # Skip invalid JSON lines
                        continue
            
            # SENTINEL: Audit Logging
            self._log_audit("read_events", "read", {
                "events_read": len(events),
                "limit": limit
            })
            
            return events
            
        except Exception as e:
            self._error_count += 1
            error_msg = str(e)
            logger.error(f"Failed to read telemetry events: {error_msg}")
            raise
    
    def get_health(self) -> BlockHealth:
        """Get telemetry block health status.
        
        Returns the health status of the TelemetryBlock based on initialization
        state, log file existence, error rates, and PII detection rates. Health
        is unhealthy if error rate exceeds 20%, degraded if PII detection rate
        exceeds 10% or log file doesn't exist.
        
        Returns:
            BlockHealth object containing:
            - status: HealthStatus (HEALTHY, DEGRADED, or UNHEALTHY)
            - message: Human-readable status message
            - details: Dictionary with operational metrics (log_file_path, log_file_size,
                operations, errors, PII detections/redactions, rates, audit_log_entries)
        """
        if not self._initialized:
            return BlockHealth(
                status=HealthStatus.UNHEALTHY,
                message="TelemetryBlock not initialized",
                details={}
            )
        
        if not self.log_file_path or not self.log_file_path.exists():
            return BlockHealth(
                status=HealthStatus.DEGRADED,
                message="Log file does not exist",
                details={"log_file_path": str(self.log_file_path) if self.log_file_path else None}
            )
        
        error_rate = self._error_count / max(self._operation_count, 1)
        pii_rate = self._pii_detections / max(self._operation_count, 1)
        
        # Check log file size
        log_file_size = self.log_file_path.stat().st_size if self.log_file_path.exists() else 0
        
        if error_rate > 0.2:
            return BlockHealth(
                status=HealthStatus.UNHEALTHY,
                message=f"High error rate: {error_rate:.2%}",
                details={"error_rate": error_rate, "operations": self._operation_count, "errors": self._error_count}
            )
        
        if pii_rate > 0.1:
            return BlockHealth(
                status=HealthStatus.DEGRADED,
                message=f"High PII detection rate: {pii_rate:.2%}",
                details={"pii_rate": pii_rate, "pii_detections": self._pii_detections, "pii_redactions": self._pii_redactions}
            )
        
        return BlockHealth(
            status=HealthStatus.HEALTHY,
            message="TelemetryBlock operating normally",
            details={
                "log_file_path": str(self.log_file_path),
                "log_file_size_bytes": log_file_size,
                "operations": self._operation_count,
                "errors": self._error_count,
                "error_rate": error_rate,
                "pii_detections": self._pii_detections,
                "pii_redactions": self._pii_redactions,
                "pii_rate": pii_rate,
                "audit_log_entries": len(self._audit_log)
            }
        )
    
    def get_audit_log(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get audit log entries.
        
        Retrieves recent audit log entries for telemetry operations. This is a
        Sentinel compliance check for audit logging access.
        
        Args:
            limit: Maximum number of entries to return (default: 100).
        
        Returns:
            List of audit log entry dictionaries, most recent first.
        """
        return self._audit_log[-limit:]

