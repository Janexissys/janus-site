# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""MemoryBlock - STM/LTM coordination and memory services.

The MemoryBlock coordinates Short-Term Memory (STM) and Long-Term Memory (LTM)
systems, handling memory storage, retrieval, promotion, and search. It uses
MC scores to determine memory placement and enforces security policies including
PII detection and encryption.

**Card**: CARD-V6B-P1-LEGO-MEMORY  
**MC Target**: 8.70  
**Dependencies**: VaultBlock (required)

**Key Responsibilities**:
- Store memories in STM or LTM based on MC score
- Retrieve memories by ID
- Promote STM memories to LTM when MC score exceeds threshold (≥8.5)
- Search memories by query string
- Detect PII in memory content
- Encrypt sensitive content
- Maintain audit logs of all memory operations

**Sentinel Compliance**:
- PII Detection: Scans memory content for PII patterns before storage
- Encryption: Encrypts sensitive content when PII is detected
- Access Control: Validates access to memory entries
- Data Retention: Manages STM→LTM promotion and cleanup
- Audit Logging: Logs all memory operations with context

**Example Usage**:
    ```python
    from blocks.memory_block import MemoryBlock, MemoryType
    from blocks.vault_block import VaultBlock
    
    vault_block = VaultBlock()
    vault_block.initialize({
        "stmvault_path": "/data/stm",
        "ltmvault_path": "/data/ltm"
    })
    
    memory_block = MemoryBlock()
    memory_block.initialize({
        "vault_block": vault_block,
        "promotion_threshold": 8.5
    })
    
    # Store memory
    memory = memory_block.store_memory(
        content="Important insight...",
        mc_score=8.7,
        metadata={"source": "analysis"}
    )
    
    # Promote to LTM
    if memory.mc_score >= 8.5:
        memory_block.promote_to_ltm(memory.memory_id)
    ```
"""

import logging
import re
import time
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

from .base_block import BlockHealth, HealthStatus, LEGOBlock
from .vault_block import VaultBlock

# Import standardized exceptions
try:
    from utils.exceptions import ValidationError, ConfigurationError
except ImportError:
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from utils.exceptions import ValidationError, ConfigurationError

logger = logging.getLogger(__name__)


class MemoryType(Enum):
    """Memory type.
    
    Attributes:
        STM: Short-Term Memory (MC score < 8.5, temporary storage).
        LTM: Long-Term Memory (MC score ≥ 8.5, permanent storage).
    """
    STM = "stm"  # Short-Term Memory
    LTM = "ltm"  # Long-Term Memory


@dataclass
class MemoryEntry:
    """Memory entry.
    
    Attributes:
        memory_id: Unique identifier for the memory entry.
        content: Text content of the memory.
        memory_type: MemoryType (STM or LTM) indicating storage location.
        mc_score: MC (Memory Consolidation) score (0.0-10.0).
        created_at: Timestamp when the memory was created.
        accessed_at: Timestamp of last access (updated on retrieval).
        metadata: Dictionary of additional metadata (source, tags, etc.).
    """
    memory_id: str
    content: str
    memory_type: MemoryType
    mc_score: float
    created_at: float
    accessed_at: float
    metadata: Dict[str, Any]


class MemoryBlock(LEGOBlock):
    """MemoryBlock coordinates STM and LTM systems.
    
    The MemoryBlock manages memory storage, retrieval, and promotion between
    Short-Term Memory (STM) and Long-Term Memory (LTM) based on MC scores. It
    integrates with VaultBlock for persistent storage and enforces security
    policies including PII detection and encryption.
    
    Attributes:
        block_name: Block identifier ("memory").
        version: Block version ("1.0.0").
        requires: Tuple containing ("vault",) - requires VaultBlock.
        PII_PATTERNS: Dictionary of regex patterns for PII detection.
            Keys are PII types (email, phone, ssn, credit_card), values are regex patterns.
        PROMOTION_THRESHOLD: MC score threshold for STM→LTM promotion (default: 8.5).
        vault_block: VaultBlock instance (set during initialization).
        promotion_threshold: Configurable promotion threshold (set during initialization).
    """
    
    block_name: str = "memory"
    version: str = "1.0.0"
    requires: tuple = ("vault",)  # Depends on VaultBlock
    
    # PII patterns (SENTINEL: PII Detection)
    PII_PATTERNS: Dict[str, str] = {
        "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        "phone": r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
        "ssn": r'\b\d{3}-\d{2}-\d{4}\b',
        "credit_card": r'\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b',
    }
    
    # Promotion threshold (MC score for STM → LTM)
    PROMOTION_THRESHOLD: float = 8.5
    
    def __init__(self) -> None:
        """Initialize MemoryBlock.
        
        Sets up internal state for memory storage, operation tracking, PII detection,
        and audit logging. VaultBlock dependency and promotion threshold are set
        during initialization via initialize().
        """
        super().__init__()
        self.vault_block: Optional[VaultBlock] = None
        self._memories: Dict[str, MemoryEntry] = {}
        self._operation_count: int = 0
        self._error_count: int = 0
        self._pii_detections: int = 0
        self._promotions: int = 0
        self._audit_log: List[Dict[str, Any]] = []
    
    def get_schema(self) -> Dict[str, Any]:
        """Get configuration schema.
        
        Returns the JSON schema for MemoryBlock configuration. Required field
        is vault_block (VaultBlock instance). Optional field is promotion_threshold
        (default: 8.5).
        
        Returns:
            Dictionary containing JSON schema for configuration validation.
        """
        return {
            "type": "object",
            "required": ["vault_block"],
            "properties": {
                "vault_block": {"type": "object", "description": "VaultBlock instance"},
                "promotion_threshold": {"type": "number", "default": 8.5},
            },
        }
    
    def initialize(self, config: Dict[str, Any]) -> None:
        """Initialize memory block with VaultBlock dependency.
        
        Initializes the MemoryBlock with a VaultBlock instance and optional promotion
        threshold. Validates that the VaultBlock is properly initialized. Must be
        called before storing or retrieving memories.
        
        Args:
            config: Configuration dictionary containing:
                - vault_block: VaultBlock instance (required, must be initialized)
                - promotion_threshold: Optional float MC score threshold (default: 8.5)
        
        Raises:
            ConfigurationError: If vault_block is missing, not a VaultBlock instance,
                or not initialized.
            ValidationError: If configuration schema validation fails.
        
        Example:
            ```python
            vault_block = VaultBlock()
            vault_block.initialize({"stmvault_path": "/data/stm", "ltmvault_path": "/data/ltm"})
            
            memory_block = MemoryBlock()
            memory_block.initialize({
                "vault_block": vault_block,
                "promotion_threshold": 8.5
            })
            ```
        """
        self.validate_config(config)
        
        # SENTINEL: Access Control - validate vault block
        vault_block = config.get("vault_block")
        if not isinstance(vault_block, VaultBlock):
            raise ConfigurationError(
                "Memory Block: Initialize - vault_block must be a VaultBlock instance",
                component="MemoryBlock",
                context={"vault_block_type": type(vault_block).__name__ if vault_block else None}
            )
        
        if not vault_block._initialized:
            raise ConfigurationError(
                "Memory Block: Initialize - VaultBlock must be initialized before MemoryBlock",
                component="MemoryBlock",
                context={}
            )
        
        self.vault_block = vault_block
        self.promotion_threshold = config.get("promotion_threshold", self.PROMOTION_THRESHOLD)
        self._initialized = True
        logger.info(f"MemoryBlock initialized with promotion threshold: {self.promotion_threshold}")
    
    def _detect_pii(self, text: str) -> Tuple[bool, List[str]]:
        """Detect PII in text.
        
        Scans text for PII patterns including email addresses, phone numbers,
        SSNs, and credit card numbers. This is a Sentinel compliance check
        for PII detection.
        
        Args:
            text: Text string to scan for PII.
        
        Returns:
            Tuple containing:
            - Boolean indicating if any PII was detected
            - List of PII types detected (empty list if none)
        """
        detected_types = []
        for pii_type, pattern in self.PII_PATTERNS.items():
            if re.search(pattern, text, re.IGNORECASE):
                detected_types.append(pii_type)
        return len(detected_types) > 0, detected_types
    
    def _encrypt_content(self, content: str) -> bytes:
        """Encrypt sensitive content.
        
        Encrypts content when PII is detected. This is a Sentinel compliance
        check for encryption. For greenfield, returns UTF-8 encoded bytes.
        In production, would use AES-256 encryption.
        
        Args:
            content: Text content to encrypt.
        
        Returns:
            Encrypted bytes (UTF-8 encoded for greenfield).
        """
        # In production, use proper encryption (AES-256)
        # For greenfield, return encoded bytes
        return content.encode('utf-8')
    
    def _log_audit(self, operation: str, memory_id: str, details: Optional[Dict[str, Any]] = None) -> None:
        """Log audit trail.
        
        Creates an audit log entry for memory operations. This is a Sentinel
        compliance check for audit logging.
        
        Args:
            operation: Name of the operation (e.g., "store_memory", "promote_to_ltm").
            memory_id: Unique identifier of the memory entry.
            details: Optional dictionary with additional operation details.
        """
        audit_entry = {
            "timestamp": time.time(),
            "operation": operation,
            "memory_id": memory_id,
            "details": details or {},
        }
        self._audit_log.append(audit_entry)
        logger.info(f"Audit: {operation} - Memory: {memory_id}")
    
    def store_memory(self, content: str, mc_score: float, metadata: Optional[Dict[str, Any]] = None) -> MemoryEntry:
        """Store memory entry.
        
        Stores a memory entry in STM or LTM based on MC score. Performs PII
        detection and encrypts content if PII is detected. Automatically
        determines storage location (STM if MC < threshold, LTM if MC ≥ threshold).
        
        Args:
            content: Text content to store.
            mc_score: MC (Memory Consolidation) score (0.0-10.0).
            metadata: Optional dictionary of metadata (source, tags, etc.).
        
        Returns:
            MemoryEntry object with:
            - memory_id: Unique identifier
            - content: Original content
            - memory_type: STM or LTM based on MC score
            - mc_score: MC score
            - created_at: Timestamp
            - accessed_at: Timestamp
            - metadata: Metadata dictionary
        
        Raises:
            RuntimeError: If MemoryBlock is not initialized.
            Exception: If vault storage fails.
        
        Example:
            ```python
            memory = memory_block.store_memory(
                content="Key insight from analysis...",
                mc_score=8.7,
                metadata={"source": "caretaker_analysis", "tags": ["important"]}
            )
            assert memory.memory_type == MemoryType.LTM  # MC >= 8.5
            ```
        """
        if not self._initialized:
            raise RuntimeError("MemoryBlock not initialized")
        
        # SENTINEL: PII Detection - scan before storage
        pii_detected, pii_types = self._detect_pii(content)
        if pii_detected:
            self._pii_detections += 1
            logger.warning(f"PII detected in memory content: {pii_types}")
            # In production, might reject or sanitize
        
        # Determine memory type based on MC score
        memory_type = MemoryType.LTM if mc_score >= self.promotion_threshold else MemoryType.STM
        
        memory_id = f"mem_{int(time.time() * 1000)}"
        
        # SENTINEL: Encryption - encrypt sensitive content
        encrypted_content = self._encrypt_content(content) if pii_detected else content.encode('utf-8')
        
        # Store in vault
        vault_type = "stm" if memory_type == MemoryType.STM else "ltm"
        vault_path = f"memories/{memory_id}.bin"
        
        try:
            self.vault_block.write_file(vault_type, vault_path, encrypted_content)
        except Exception as e:
            self._error_count += 1
            logger.error(f"Failed to store memory in vault: {e}")
            raise
        
        memory = MemoryEntry(
            memory_id=memory_id,
            content=content,
            memory_type=memory_type,
            mc_score=mc_score,
            created_at=time.time(),
            accessed_at=time.time(),
            metadata=metadata or {}
        )
        
        self._memories[memory_id] = memory
        self._operation_count += 1
        
        # SENTINEL: Audit Logging
        self._log_audit("store_memory", memory_id, {
            "memory_type": memory_type.value,
            "mc_score": mc_score,
            "pii_detected": pii_detected
        })
        
        logger.info(f"Memory stored: {memory_id} ({memory_type.value}, MC: {mc_score:.2f})")
        return memory
    
    def retrieve_memory(self, memory_id: str) -> Optional[MemoryEntry]:
        """Retrieve memory entry.
        
        Retrieves a memory entry by ID and updates its accessed_at timestamp.
        Performs access control validation and audit logging.
        
        Args:
            memory_id: Unique identifier of the memory to retrieve.
        
        Returns:
            MemoryEntry object if found, None otherwise.
        
        Raises:
            RuntimeError: If MemoryBlock is not initialized.
        """
        if not self._initialized:
            raise RuntimeError("MemoryBlock not initialized")
        
        if memory_id not in self._memories:
            return None
        
        memory = self._memories[memory_id]
        memory.accessed_at = time.time()
        
        # SENTINEL: Access Control - check authorization
        # (In production, check user/service permissions)
        
        # SENTINEL: Audit Logging
        self._log_audit("retrieve_memory", memory_id)
        
        return memory
    
    def promote_to_ltm(self, memory_id: str) -> bool:
        """Promote STM memory to LTM.
        
        Promotes a memory entry from STM to LTM by moving it from STM vault
        to LTM vault. Validates that MC score meets promotion threshold.
        This is a Sentinel compliance check for data retention.
        
        Args:
            memory_id: Unique identifier of the memory to promote.
        
        Returns:
            Boolean indicating if promotion was successful (False if already LTM).
        
        Raises:
            RuntimeError: If MemoryBlock is not initialized.
            ValidationError: If memory_id is not found or MC score is below threshold.
            Exception: If vault operations fail.
        
        Example:
            ```python
            # Store in STM (MC < 8.5)
            memory = memory_block.store_memory("Content...", mc_score=7.5)
            assert memory.memory_type == MemoryType.STM
            
            # Promote to LTM (if MC score updated)
            memory.mc_score = 8.7
            success = memory_block.promote_to_ltm(memory.memory_id)
            assert success == True
            ```
        """
        if not self._initialized:
            raise RuntimeError("MemoryBlock not initialized")
        
        if memory_id not in self._memories:
            raise ValidationError(
                f"Memory Block: Promote to LTM - Memory not found: {memory_id}",
                component="MemoryBlock",
                context={"memory_id": memory_id}
            )
        
        memory = self._memories[memory_id]
        
        if memory.memory_type == MemoryType.LTM:
            return False  # Already LTM
        
        if memory.mc_score < self.promotion_threshold:
            raise ValidationError(
                f"Memory Block: Promote to LTM - Memory MC score {memory.mc_score} below promotion threshold {self.promotion_threshold}",
                component="MemoryBlock",
                context={"memory_id": memory_id, "mc_score": memory.mc_score, "promotion_threshold": self.promotion_threshold}
            )
        
        # Move from STM to LTM vault
        stm_path = f"memories/{memory_id}.bin"
        ltm_path = f"memories/{memory_id}.bin"
        
        try:
            # Read from STM
            content = self.vault_block.read_file("stm", stm_path)
            
            # Write to LTM
            self.vault_block.write_file("ltm", ltm_path, content)
            
            # Delete from STM (SENTINEL: Data Retention)
            self.vault_block.delete_file("stm", stm_path)
            
            # Update memory entry
            memory.memory_type = MemoryType.LTM
            
            self._promotions += 1
            
            # SENTINEL: Audit Logging
            self._log_audit("promote_to_ltm", memory_id, {"mc_score": memory.mc_score})
            
            logger.info(f"Memory promoted to LTM: {memory_id}")
            return True
            
        except Exception as e:
            self._error_count += 1
            logger.error(f"Failed to promote memory {memory_id}: {e}")
            raise
    
    def search_memories(self, query: str, memory_type: Optional[MemoryType] = None, limit: int = 10) -> List[MemoryEntry]:
        """Search memories.
        
        Searches memory entries by query string, optionally filtered by memory
        type. Results are sorted by MC score (descending). Performs audit logging.
        
        Args:
            query: Search query string (case-insensitive substring match).
            memory_type: Optional MemoryType filter (STM or LTM). If None, searches all.
            limit: Maximum number of results to return (default: 10).
        
        Returns:
            List of MemoryEntry objects matching the query, sorted by MC score
            (descending), limited to specified count.
        
        Raises:
            RuntimeError: If MemoryBlock is not initialized.
        
        Example:
            ```python
            # Search all memories
            results = memory_block.search_memories("insight", limit=5)
            
            # Search only LTM memories
            ltm_results = memory_block.search_memories("analysis", memory_type=MemoryType.LTM)
            ```
        """
        if not self._initialized:
            raise RuntimeError("MemoryBlock not initialized")
        
        results = []
        for memory in self._memories.values():
            if memory_type and memory.memory_type != memory_type:
                continue
            
            # Simple text search (in production, use vector search)
            if query.lower() in memory.content.lower():
                results.append(memory)
        
        # Sort by MC score (descending)
        results.sort(key=lambda m: m.mc_score, reverse=True)
        
        # SENTINEL: Audit Logging
        self._log_audit("search_memories", "search", {
            "query": query,
            "results_count": len(results[:limit])
        })
        
        return results[:limit]
    
    def get_health(self) -> BlockHealth:
        """Get memory block health status.
        
        Returns the health status of the MemoryBlock based on initialization state,
        VaultBlock health, error rates, and PII detection rates. Health is degraded
        if VaultBlock is unhealthy or error rate exceeds 10%.
        
        Returns:
            BlockHealth object containing:
            - status: HealthStatus (HEALTHY, DEGRADED, or UNHEALTHY)
            - message: Human-readable status message
            - details: Dictionary with operational metrics (STM/LTM counts, promotions,
                operations, errors, PII detections, rates)
        """
        if not self._initialized:
            return BlockHealth(
                status=HealthStatus.UNHEALTHY,
                message="MemoryBlock not initialized",
                details={}
            )
        
        if not self.vault_block:
            return BlockHealth(
                status=HealthStatus.UNHEALTHY,
                message="VaultBlock not configured",
                details={}
            )
        
        vault_health = self.vault_block.get_health()
        if vault_health.status != HealthStatus.HEALTHY:
            return BlockHealth(
                status=HealthStatus.DEGRADED,
                message=f"VaultBlock unhealthy: {vault_health.message}",
                details={"vault_health": vault_health.details}
            )
        
        error_rate = self._error_count / max(self._operation_count, 1)
        stm_count = len([m for m in self._memories.values() if m.memory_type == MemoryType.STM])
        ltm_count = len([m for m in self._memories.values() if m.memory_type == MemoryType.LTM])
        pii_rate = self._pii_detections / max(self._operation_count, 1)
        
        if error_rate > 0.1:
            return BlockHealth(
                status=HealthStatus.DEGRADED,
                message=f"High error rate: {error_rate:.2%}",
                details={"error_rate": error_rate, "operations": self._operation_count, "errors": self._error_count}
            )
        
        return BlockHealth(
            status=HealthStatus.HEALTHY,
            message="MemoryBlock operating normally",
            details={
                "stm_count": stm_count,
                "ltm_count": ltm_count,
                "total_memories": len(self._memories),
                "promotions": self._promotions,
                "operations": self._operation_count,
                "errors": self._error_count,
                "error_rate": error_rate,
                "pii_detections": self._pii_detections,
                "pii_rate": pii_rate,
                "audit_log_entries": len(self._audit_log)
            }
        )

