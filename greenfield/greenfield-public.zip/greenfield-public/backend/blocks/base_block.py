# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Base LEGO block interface for greenfield implementation."""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Dict, Optional

# Import standardized exceptions
try:
    from utils.exceptions import ConfigurationError
except ImportError:
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from utils.exceptions import ConfigurationError


class HealthStatus(Enum):
    """Block health status."""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"


@dataclass
class BlockHealth:
    """Block health information."""
    status: HealthStatus
    message: str
    details: Dict[str, Any]


class LEGOBlock(ABC):
    """Base LEGO block interface."""
    
    block_name: str
    version: str
    requires: tuple = ()  # Dependencies
    
    def __init__(self):
        self._initialized = False
        self._config: Dict[str, Any] = {}
    
    @abstractmethod
    def initialize(self, config: Dict[str, Any]) -> None:
        """Initialize the block with configuration."""
        pass
    
    @abstractmethod
    def get_health(self) -> BlockHealth:
        """Get block health status."""
        pass
    
    @abstractmethod
    def get_schema(self) -> Dict[str, Any]:
        """Get block configuration schema."""
        pass
    
    def validate_config(self, config: Dict[str, Any]) -> None:
        """Validate configuration against schema."""
        schema = self.get_schema()
        required = schema.get("required", [])
        for field in required:
            if field not in config:
                raise ConfigurationError(
                    f"Base Block: Validate Config - Missing required config field: {field}",
                    component=self.__class__.__name__,
                    context={"missing_field": field, "required_fields": required, "provided_fields": list(config.keys())}
                )

