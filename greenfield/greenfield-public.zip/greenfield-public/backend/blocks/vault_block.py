# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""VaultBlock - Foundational storage for STMVault and LTMVault.

The VaultBlock provides foundational file storage operations for STMVault
(Short-Term Memory) and LTMVault (Long-Term Memory). It handles file I/O
operations with security enforcement including path traversal protection,
concurrent access control, and file permissions.

**Card**: CARD-V6B-P1-LEGO-VAULT  
**MC Target**: 8.65  
**Dependencies**: None (foundational block)

**Key Responsibilities**:
- Read/write/delete files in STMVault and LTMVault
- Protect against path traversal attacks
- Manage concurrent file access with locks
- Enforce file permissions
- Create vault backups with integrity verification

**Sentinel Compliance**:
- Path Traversal Protection: Validates all paths to prevent directory traversal
- Access Control: Checks file permissions before operations
- Concurrent Access: Uses locks to prevent race conditions
- File Permissions: Sets secure permissions on vault directories and files
- Backup Integrity: Verifies backup completeness

**Example Usage**:
    ```python
    from blocks.vault_block import VaultBlock
    
    block = VaultBlock()
    block.initialize({
        "stmvault_path": "/path/to/stmvault",
        "ltmvault_path": "/path/to/ltmvault"
    })
    
    # Write file
    block.write_file("stm", "documents/note.md", b"# Note\n\nContent...")
    
    # Read file
    content = block.read_file("stm", "documents/note.md")
    
    # List files
    files = block.list_files("stm", "documents/*.md")
    ```
"""

import logging
import os
import shutil
from pathlib import Path
from threading import Lock
from typing import Any, Dict, List, Optional

from .base_block import BlockHealth, HealthStatus, LEGOBlock

# Import standardized exceptions
try:
    from utils.exceptions import ValidationError
except ImportError:
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from utils.exceptions import ValidationError

logger = logging.getLogger(__name__)


class VaultBlock(LEGOBlock):
    """VaultBlock provides foundational storage for STMVault and LTMVault.
    
    The VaultBlock manages file storage operations for both STMVault and LTMVault
    with security enforcement. It provides thread-safe file operations with path
    traversal protection, access control, and backup capabilities.
    
    Attributes:
        block_name: Block identifier ("vault").
        version: Block version ("1.0.0").
        requires: Empty tuple (foundational block, no dependencies).
        stmvault_path: Path to STMVault directory (set during initialization).
        ltmvault_path: Path to LTMVault directory (set during initialization).
    """
    
    block_name: str = "vault"
    version: str = "1.0.0"
    requires: tuple = ()  # Foundational block
    
    def __init__(self) -> None:
        """Initialize VaultBlock.
        
        Sets up internal state for file locks, operation tracking, and vault paths.
        Vault paths are set during initialization via the initialize() method.
        """
        super().__init__()
        self.stmvault_path: Optional[Path] = None
        self.ltmvault_path: Optional[Path] = None
        self._file_locks: Dict[str, Lock] = {}
        self._locks_lock: Lock = Lock()  # Protects _file_locks dict
        self._operation_count: int = 0
        self._error_count: int = 0
    
    def get_schema(self) -> Dict[str, Any]:
        """Get configuration schema.
        
        Returns the JSON schema for VaultBlock configuration. Required fields
        are stmvault_path and ltmvault_path, both string paths to vault directories.
        
        Returns:
            Dictionary containing JSON schema for configuration validation.
        """
        return {
            "type": "object",
            "required": ["stmvault_path", "ltmvault_path"],
            "properties": {
                "stmvault_path": {"type": "string", "description": "Path to STMVault directory"},
                "ltmvault_path": {"type": "string", "description": "Path to LTMVault directory"},
            },
        }
    
    def initialize(self, config: Dict[str, Any]) -> None:
        """Initialize vault block with paths.
        
        Initializes the VaultBlock with STMVault and LTMVault directory paths.
        Creates the directories if they don't exist and sets secure permissions.
        Must be called before any file operations.
        
        Args:
            config: Configuration dictionary containing:
                - stmvault_path: String path to STMVault directory
                - ltmvault_path: String path to LTMVault directory
        
        Raises:
            ValidationError: If configuration is invalid or paths cannot be created.
        
        Example:
            ```python
            block = VaultBlock()
            block.initialize({
                "stmvault_path": "/data/stmvault",
                "ltmvault_path": "/data/ltmvault"
            })
            ```
        """
        self.validate_config(config)
        
        self.stmvault_path = Path(config["stmvault_path"]).resolve()
        self.ltmvault_path = Path(config["ltmvault_path"]).resolve()
        
        # Ensure vault directories exist
        self.stmvault_path.mkdir(parents=True, exist_ok=True)
        self.ltmvault_path.mkdir(parents=True, exist_ok=True)
        
        # Set secure permissions (SENTINEL: File Permissions)
        os.chmod(self.stmvault_path, 0o755)
        os.chmod(self.ltmvault_path, 0o755)
        
        self._initialized = True
        logger.info(f"VaultBlock initialized: STM={self.stmvault_path}, LTM={self.ltmvault_path}")
    
    def _get_file_lock(self, file_path: str) -> Lock:
        """Get or create lock for a file.
        
        Retrieves or creates a thread lock for the specified file path to ensure
        thread-safe file operations. This is a Sentinel compliance check for
        concurrent access control.
        
        Args:
            file_path: String path to the file requiring a lock.
        
        Returns:
            Thread Lock object for the file path.
        """
        with self._locks_lock:
            if file_path not in self._file_locks:
                self._file_locks[file_path] = Lock()
            return self._file_locks[file_path]
    
    def _validate_path(self, vault_path: Path, target_path: Path) -> Path:
        """Validate and resolve path.
        
        Validates that a target path is within the vault directory, preventing
        path traversal attacks. This is a Sentinel compliance check for path
        traversal protection.
        
        Args:
            vault_path: Base Path object for the vault directory.
            target_path: Path object for the target file (relative to vault).
        
        Returns:
            Resolved Path object within the vault directory.
        
        Raises:
            ValidationError: If path traversal is detected or path is invalid.
        """
        try:
            resolved = (vault_path / target_path).resolve()
            # Ensure resolved path is within vault
            if not str(resolved).startswith(str(vault_path.resolve())):
                raise ValidationError(
                    f"Vault Block: Validate Path - Path traversal detected: {target_path}",
                    component="VaultBlock",
                    context={"target_path": str(target_path), "vault_path": str(vault_path)}
                )
            return resolved
        except (ValueError, OSError) as e:
            raise ValidationError(
                f"Vault Block: Validate Path - Invalid path: {target_path}",
                component="VaultBlock",
                context={"target_path": str(target_path), "error": str(e)}
            ) from e
    
    def read_file(self, vault_type: str, relative_path: str) -> bytes:
        """Read file from vault.
        
        Reads a file from the specified vault (STM or LTM) with path traversal
        protection and access control. Uses file locks to ensure thread-safe access.
        
        Args:
            vault_type: Vault type ("stm" or "ltm").
            relative_path: Relative path to the file within the vault.
        
        Returns:
            Bytes content of the file.
        
        Raises:
            RuntimeError: If VaultBlock is not initialized.
            ValidationError: If vault_type is invalid or path traversal detected.
            PermissionError: If read access is denied.
            Exception: If file read operation fails.
        
        Example:
            ```python
            content = block.read_file("stm", "documents/note.md")
            print(content.decode('utf-8'))
            ```
        """
        if not self._initialized:
            raise RuntimeError("VaultBlock not initialized")
        
        vault_path = self.stmvault_path if vault_type == "stm" else self.ltmvault_path
        if vault_path is None:
            raise ValidationError(
                f"Vault Block: Read File - Invalid vault type: {vault_type}",
                component="VaultBlock",
                context={"vault_type": vault_type, "valid_types": ["stm", "ltm"]}
            )
        
        file_path = self._validate_path(vault_path, Path(relative_path))
        
        # SENTINEL: Access Control - check file permissions
        if not os.access(file_path, os.R_OK):
            raise PermissionError(f"Read access denied: {relative_path}")
        
        lock = self._get_file_lock(str(file_path))
        with lock:  # SENTINEL: Concurrent Access
            self._operation_count += 1
            try:
                with open(file_path, "rb") as f:
                    return f.read()
            except Exception as e:
                self._error_count += 1
                logger.error(f"Failed to read file {relative_path}: {e}")
                raise
    
    def write_file(self, vault_type: str, relative_path: str, content: bytes) -> None:
        """Write file to vault.
        
        Writes content to a file in the specified vault (STM or LTM) with path
        traversal protection, access control, and thread-safe concurrent access.
        Creates parent directories if needed and sets secure file permissions.
        
        Args:
            vault_type: Vault type ("stm" or "ltm").
            relative_path: Relative path to the file within the vault.
            content: Bytes content to write to the file.
        
        Raises:
            RuntimeError: If VaultBlock is not initialized.
            ValidationError: If vault_type is invalid or path traversal detected.
            PermissionError: If write access is denied.
            Exception: If file write operation fails.
        
        Example:
            ```python
            block.write_file("stm", "documents/note.md", b"# Note\n\nContent...")
            ```
        """
        if not self._initialized:
            raise RuntimeError("VaultBlock not initialized")
        
        vault_path = self.stmvault_path if vault_type == "stm" else self.ltmvault_path
        if vault_path is None:
            raise ValidationError(
                f"Vault Block: Write File - Invalid vault type: {vault_type}",
                component="VaultBlock",
                context={"vault_type": vault_type, "valid_types": ["stm", "ltm"]}
            )
        
        file_path = self._validate_path(vault_path, Path(relative_path))
        
        # Ensure parent directory exists
        file_path.parent.mkdir(parents=True, exist_ok=True)
        
        # SENTINEL: Access Control - check write permissions
        if not os.access(file_path.parent, os.W_OK):
            raise PermissionError(f"Write access denied: {relative_path}")
        
        lock = self._get_file_lock(str(file_path))
        with lock:  # SENTINEL: Concurrent Access
            self._operation_count += 1
            try:
                with open(file_path, "wb") as f:
                    f.write(content)
                # SENTINEL: File Permissions - set secure permissions
                os.chmod(file_path, 0o644)
            except Exception as e:
                self._error_count += 1
                logger.error(f"Failed to write file {relative_path}: {e}")
                raise
    
    def list_files(self, vault_type: str, pattern: str = "**/*") -> List[str]:
        """List files in vault.
        
        Lists all files in the specified vault matching the given glob pattern.
        Performs access control checks before listing.
        
        Args:
            vault_type: Vault type ("stm" or "ltm").
            pattern: Glob pattern for file matching (default: "**/*" for all files).
        
        Returns:
            List of relative file paths (strings) matching the pattern.
        
        Raises:
            RuntimeError: If VaultBlock is not initialized.
            ValidationError: If vault_type is invalid.
            PermissionError: If read access is denied.
            Exception: If listing operation fails.
        
        Example:
            ```python
            # List all markdown files
            files = block.list_files("stm", "**/*.md")
            
            # List all files in documents directory
            files = block.list_files("ltm", "documents/*")
            ```
        """
        if not self._initialized:
            raise RuntimeError("VaultBlock not initialized")
        
        vault_path = self.stmvault_path if vault_type == "stm" else self.ltmvault_path
        if vault_path is None:
            raise ValidationError(
                f"Vault Block: List Files - Invalid vault type: {vault_type}",
                component="VaultBlock",
                context={"vault_type": vault_type, "valid_types": ["stm", "ltm"]}
            )
        
        # SENTINEL: Access Control - check read permissions
        if not os.access(vault_path, os.R_OK):
            raise PermissionError(f"Read access denied for vault: {vault_type}")
        
        try:
            files = []
            for file_path in vault_path.glob(pattern):
                if file_path.is_file():
                    files.append(str(file_path.relative_to(vault_path)))
            return files
        except Exception as e:
            self._error_count += 1
            logger.error(f"Failed to list files in {vault_type}: {e}")
            raise
    
    def delete_file(self, vault_type: str, relative_path: str) -> None:
        """Delete file from vault.
        
        Deletes a file from the specified vault with path traversal protection
        and access control. Uses file locks to ensure thread-safe deletion.
        
        Args:
            vault_type: Vault type ("stm" or "ltm").
            relative_path: Relative path to the file within the vault.
        
        Raises:
            RuntimeError: If VaultBlock is not initialized.
            ValidationError: If vault_type is invalid or path traversal detected.
            PermissionError: If delete access is denied.
            Exception: If file deletion fails.
        
        Example:
            ```python
            block.delete_file("stm", "documents/old_note.md")
            ```
        """
        if not self._initialized:
            raise RuntimeError("VaultBlock not initialized")
        
        vault_path = self.stmvault_path if vault_type == "stm" else self.ltmvault_path
        if vault_path is None:
            raise ValidationError(
                f"Vault Block: Delete File - Invalid vault type: {vault_type}",
                component="VaultBlock",
                context={"vault_type": vault_type, "valid_types": ["stm", "ltm"]}
            )
        
        file_path = self._validate_path(vault_path, Path(relative_path))
        
        # SENTINEL: Access Control - check delete permissions
        if not os.access(file_path.parent, os.W_OK):
            raise PermissionError(f"Delete access denied: {relative_path}")
        
        lock = self._get_file_lock(str(file_path))
        with lock:  # SENTINEL: Concurrent Access
            self._operation_count += 1
            try:
                if file_path.exists():
                    file_path.unlink()
            except Exception as e:
                self._error_count += 1
                logger.error(f"Failed to delete file {relative_path}: {e}")
                raise
    
    def create_backup(self, vault_type: str, backup_path: Optional[Path] = None) -> Path:
        """Create vault backup.
        
        Creates a complete backup of the specified vault by copying all files
        to a backup directory. Performs integrity verification to ensure all
        files were copied successfully. This is a Sentinel compliance check
        for backup integrity.
        
        Args:
            vault_type: Vault type ("stm" or "ltm") to backup.
            backup_path: Optional Path object for backup location. If None,
                creates backup at "{vault_path}_backup".
        
        Returns:
            Path object pointing to the backup directory.
        
        Raises:
            RuntimeError: If VaultBlock is not initialized.
            ValidationError: If vault_type is invalid or backup integrity check fails.
            Exception: If backup creation fails.
        
        Example:
            ```python
            backup_path = block.create_backup("stm", Path("/backups/stm_backup"))
            print(f"Backup created at: {backup_path}")
            ```
        """
        if not self._initialized:
            raise RuntimeError("VaultBlock not initialized")
        
        vault_path = self.stmvault_path if vault_type == "stm" else self.ltmvault_path
        if vault_path is None:
            raise ValidationError(
                f"Vault Block: Create Backup - Invalid vault type: {vault_type}",
                component="VaultBlock",
                context={"vault_type": vault_type, "valid_types": ["stm", "ltm"]}
            )
        
        if backup_path is None:
            backup_path = Path(f"{vault_path}_backup")
        
        try:
            # Create backup directory
            backup_path.mkdir(parents=True, exist_ok=True)
            
            # Copy vault contents
            shutil.copytree(vault_path, backup_path, dirs_exist_ok=True)
            
            # SENTINEL: Backup Integrity - verify backup
            source_files = set(p.relative_to(vault_path) for p in vault_path.rglob("*") if p.is_file())
            backup_files = set(p.relative_to(backup_path) for p in backup_path.rglob("*") if p.is_file())
            
            if source_files != backup_files:
                raise ValidationError(
                    "Vault Block: Backup Vault - Backup integrity check failed: file count mismatch",
                    component="VaultBlock",
                    context={"vault_type": vault_type, "source_file_count": len(source_files), "backup_file_count": len(backup_files)}
                )
            
            logger.info(f"Backup created: {backup_path}")
            return backup_path
        except Exception as e:
            self._error_count += 1
            logger.error(f"Failed to create backup: {e}")
            raise
    
    def get_health(self) -> BlockHealth:
        """Get vault block health status.
        
        Returns the health status of the VaultBlock based on initialization state,
        vault directory existence, and error rates. Health is degraded if error
        rate exceeds 10%, unhealthy if not initialized or vaults don't exist.
        
        Returns:
            BlockHealth object containing:
            - status: HealthStatus (HEALTHY, DEGRADED, or UNHEALTHY)
            - message: Human-readable status message
            - details: Dictionary with operational metrics (paths, operation counts, error rates)
        """
        if not self._initialized:
            return BlockHealth(
                status=HealthStatus.UNHEALTHY,
                message="VaultBlock not initialized",
                details={}
            )
        
        error_rate = self._error_count / max(self._operation_count, 1)
        stm_exists = self.stmvault_path and self.stmvault_path.exists()
        ltm_exists = self.ltmvault_path and self.ltmvault_path.exists()
        
        if not stm_exists or not ltm_exists:
            return BlockHealth(
                status=HealthStatus.UNHEALTHY,
                message="Vault paths do not exist",
                details={"stm_exists": stm_exists, "ltm_exists": ltm_exists}
            )
        
        if error_rate > 0.1:  # More than 10% error rate
            return BlockHealth(
                status=HealthStatus.DEGRADED,
                message=f"High error rate: {error_rate:.2%}",
                details={"error_rate": error_rate, "operations": self._operation_count, "errors": self._error_count}
            )
        
        return BlockHealth(
            status=HealthStatus.HEALTHY,
            message="VaultBlock operating normally",
            details={
                "stmvault_path": str(self.stmvault_path),
                "ltmvault_path": str(self.ltmvault_path),
                "operations": self._operation_count,
                "errors": self._error_count,
                "error_rate": error_rate
            }
        )

