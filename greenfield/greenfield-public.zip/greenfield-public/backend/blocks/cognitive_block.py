# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""CognitiveBlock - LLM provider adapter.

The CognitiveBlock provides a unified interface for LLM providers (OpenAI,
Anthropic, Local) with security enforcement including PII detection, input/output
validation, and audit logging. It acts as a secure adapter layer between the
system and LLM providers.

**Card**: CARD-V6B-P1-LEGO-COGNITIVE  
**MC Target**: 8.65  
**Dependencies**: None (foundational block)

**Key Responsibilities**:
- Generate LLM responses via multiple providers
- Detect PII in prompts and responses
- Validate input parameters (prompt length, temperature, max tokens)
- Validate output content (length, format)
- Maintain audit logs of all LLM operations
- Manage API keys securely

**Sentinel Compliance**:
- PII Detection: Scans prompts and responses for PII patterns
- Data Validation: Validates input parameters and output content
- API Key Security: Validates and securely stores API keys
- Audit Logging: Logs all LLM operations with context
- Error Handling: Proper error handling and reporting

**Example Usage**:
    ```python
    from blocks.cognitive_block import CognitiveBlock, LLMRequest, LLMProvider
    
    block = CognitiveBlock()
    block.initialize({
        "api_keys": {
            "openai": "sk-...",
            "anthropic": "sk-ant-..."
        }
    })
    
    request = LLMRequest(
        prompt="Summarize this document...",
        provider=LLMProvider.OPENAI,
        max_tokens=500,
        temperature=0.7
    )
    
    response = await block.generate(request)
    print(f"Response: {response.content}")
    print(f"PII detected: {response.pii_detected}")
    ```
"""

import logging
import os
import re
import time
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

from .base_block import BlockHealth, HealthStatus, LEGOBlock

# Import standardized exceptions
try:
    from utils.exceptions import ValidationError, ConfigurationError
except ImportError:
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from utils.exceptions import ValidationError, ConfigurationError

# Import LLM cache wrapper for repeatability harness
try:
    from services.llm_call_cached import call_llm_cached_async
except ImportError:
    # Fallback if services not in path
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from services.llm_call_cached import call_llm_cached_async

# Import MC engine for repeatability validation
try:
    from systems.mc_engine import MCEngine
except ImportError:
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from systems.mc_engine import MCEngine

logger = logging.getLogger(__name__)

# Prompt pack version for repeatability fingerprinting
PROMPT_PACK_VERSION = "v6.0"


class LLMProvider(Enum):
    """Supported LLM providers.
    
    Attributes:
        OPENAI: OpenAI API provider (GPT models).
        ANTHROPIC: Anthropic API provider (Claude models).
        LOCAL: Local LLM provider (on-premise models).
    """
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    LOCAL = "local"


@dataclass
class LLMRequest:
    """LLM request configuration.
    
    Attributes:
        prompt: Main prompt text to send to the LLM (required).
        system_prompt: Optional system prompt for context.
        max_tokens: Maximum tokens in response (default: 1000, range: 1-100000).
        temperature: Sampling temperature (default: 0.7, range: 0.0-2.0).
        provider: LLM provider to use (default: OPENAI).
    """
    prompt: str
    system_prompt: Optional[str] = None
    max_tokens: int = 1000
    temperature: float = 0.7
    provider: LLMProvider = LLMProvider.OPENAI


@dataclass
class LLMResponse:
    """LLM response.
    
    Attributes:
        content: Generated content from the LLM (empty if failed).
        provider: LLM provider that generated the response.
        latency_ms: Response latency in milliseconds.
        success: Boolean indicating if generation succeeded.
        error: Error message if generation failed (None if successful).
        pii_detected: Boolean indicating if PII was detected in response.
        pii_types: List of PII types detected (empty list if none).
    """
    content: str
    provider: LLMProvider
    latency_ms: float
    success: bool
    error: Optional[str] = None
    pii_detected: bool = False
    pii_types: List[str] = None


class CognitiveBlock(LEGOBlock):
    """CognitiveBlock provides LLM provider interface with security enforcement.
    
    The CognitiveBlock acts as a secure adapter layer for LLM providers, handling
    API key management, input/output validation, PII detection, and audit logging.
    It supports multiple providers (OpenAI, Anthropic, Local) with a unified interface.
    
    Attributes:
        block_name: Block identifier ("cognitive").
        version: Block version ("1.0.0").
        requires: Empty tuple (foundational block, no dependencies).
        PII_PATTERNS: Dictionary of regex patterns for PII detection.
            Keys are PII types (email, phone, ssn, credit_card), values are regex patterns.
        api_keys: Dictionary mapping provider names to API keys (set during initialization).
    """
    
    block_name: str = "cognitive"
    version: str = "1.0.0"
    requires: tuple = ()  # Foundational block
    
    # PII patterns (SENTINEL: PII Detection)
    PII_PATTERNS: Dict[str, str] = {
        "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        "phone": r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
        "ssn": r'\b\d{3}-\d{2}-\d{4}\b',
        "credit_card": r'\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b',
    }
    
    def __init__(self) -> None:
        """Initialize CognitiveBlock.
        
        Sets up internal state for API keys, operation tracking, PII detection,
        and audit logging. API keys are set during initialization via initialize().
        """
        super().__init__()
        self.api_keys: Dict[str, str] = {}
        self._operation_count: int = 0
        self._error_count: int = 0
        self._pii_detections: int = 0
        self._audit_log: List[Dict[str, Any]] = []
        self._mc_engine: Optional[MCEngine] = None
        self._enable_mc_capture = os.getenv("ENABLE_MC_CAPTURE", "true").lower() in {"1", "true", "yes"}
        self._mc_engine: Optional[MCEngine] = None
        self._enable_mc_capture = os.getenv("ENABLE_MC_CAPTURE", "true").lower() in {"1", "true", "yes"}
    
    def get_schema(self) -> Dict[str, Any]:
        """Get configuration schema.
        
        Returns the JSON schema for CognitiveBlock configuration. Required field
        is api_keys, a dictionary mapping provider names to API key strings.
        
        Returns:
            Dictionary containing JSON schema for configuration validation.
        """
        return {
            "type": "object",
            "required": ["api_keys"],
            "properties": {
                "api_keys": {
                    "type": "object",
                    "description": "API keys for LLM providers",
                    "properties": {
                        "openai": {"type": "string"},
                        "anthropic": {"type": "string"},
                    }
                }
            },
        }
    
    def initialize(self, config: Dict[str, Any]) -> None:
        """Initialize cognitive block with API keys.
        
        Initializes the CognitiveBlock with API keys for LLM providers. Validates
        that API keys are present and meet minimum length requirements. Must be
        called before generating LLM responses.
        
        Args:
            config: Configuration dictionary containing:
                - api_keys: Dictionary mapping provider names to API key strings
                    (e.g., {"openai": "sk-...", "anthropic": "sk-ant-..."})
        
        Raises:
            ConfigurationError: If API keys are missing or invalid.
            ValidationError: If configuration schema validation fails.
        
        Example:
            ```python
            block = CognitiveBlock()
            block.initialize({
                "api_keys": {
                    "openai": "sk-...",
                    "anthropic": "sk-ant-..."
                }
            })
            ```
        """
        self.validate_config(config)
        
        # SENTINEL: API Key Security - validate and store securely
        api_keys = config.get("api_keys", {})
        for provider, key in api_keys.items():
            # For local LLM, key can be a URL (e.g., "http://localhost:11434")
            # For cloud providers, key must be a valid API key
            if provider == "local":
                # Local LLM: key is optional (uses env var or default)
                if key:
                    self.api_keys[provider] = key
                else:
                    # Default to localhost:11434 (Ollama default)
                    self.api_keys[provider] = "http://localhost:11434"
            else:
                # Cloud providers: only store if key is provided and valid
                # Empty strings are allowed (means provider not configured)
                if key and len(key) >= 10:
                    self.api_keys[provider] = key
                elif key and key.startswith("sk-mock"):
                    # Allow mock keys for development
                    self.api_keys[provider] = key
                # If empty, don't store (provider not configured, but that's OK)
        
        # Initialize MC engine for repeatability capture
        if self._enable_mc_capture:
            self._mc_engine = MCEngine()
            logger.info("CognitiveBlock: MC engine initialized for repeatability capture")
        
        self._initialized = True
        logger.info("CognitiveBlock initialized with API keys")
    
    def _detect_pii(self, text: str) -> Tuple[bool, List[str]]:
        """Detect PII in text.
        
        Scans text for PII patterns including email addresses, phone numbers,
        SSNs, and credit card numbers. This is a Sentinel compliance check
        for PII detection.
        
        Args:
            text: Text string to scan for PII.
        
        Returns:
            Tuple containing:
            - Boolean indicating if any PII was detected
            - List of PII types detected (empty list if none)
        """
        detected_types = []
        for pii_type, pattern in self.PII_PATTERNS.items():
            if re.search(pattern, text, re.IGNORECASE):
                detected_types.append(pii_type)
        
        return len(detected_types) > 0, detected_types
    
    def _validate_input(self, request: LLMRequest) -> None:
        """Validate input.
        
        Validates LLM request parameters including prompt length, temperature range,
        and max tokens range. This is a Sentinel compliance check for data validation.
        
        Args:
            request: LLMRequest object to validate.
        
        Raises:
            ValidationError: If any validation check fails (empty prompt, invalid
                temperature, invalid max_tokens, or prompt too long).
        """
        if not request.prompt or len(request.prompt.strip()) == 0:
            raise ValidationError(
                "Cognitive Block: Validate Input - Prompt cannot be empty",
                component="CognitiveBlock",
                context={"provider": request.provider.value}
            )
        
        if len(request.prompt) > 100000:  # Reasonable limit
            raise ValidationError(
                "Cognitive Block: Validate Input - Prompt too long (max 100000 characters)",
                component="CognitiveBlock",
                context={"provider": request.provider.value, "prompt_length": len(request.prompt)}
            )
        
        if request.temperature < 0 or request.temperature > 2:
            raise ValidationError(
                "Cognitive Block: Validate Input - Temperature must be between 0 and 2",
                component="CognitiveBlock",
                context={"provider": request.provider.value, "temperature": request.temperature}
            )
        
        if request.max_tokens < 1 or request.max_tokens > 100000:
            raise ValidationError(
                "Cognitive Block: Validate Input - Max tokens must be between 1 and 100000",
                component="CognitiveBlock",
                context={"provider": request.provider.value, "max_tokens": request.max_tokens}
            )
    
    def _validate_output(self, content: str) -> None:
        """Validate output.
        
        Validates LLM response content including length checks. This is a Sentinel
        compliance check for data validation.
        
        Args:
            content: Response content string to validate.
        
        Raises:
            ValidationError: If content is empty or exceeds maximum length.
        """
        if not content:
            raise ValidationError(
                "Cognitive Block: Validate Output - Empty response from LLM",
                component="CognitiveBlock",
                context={}
            )
        
        if len(content) > 1000000:  # Reasonable limit
            raise ValidationError(
                "Cognitive Block: Validate Output - Response too long",
                component="CognitiveBlock",
                context={"response_length": len(content)}
            )
    
    def _log_audit(self, operation: str, request: LLMRequest, response: Optional[LLMResponse] = None, error: Optional[str] = None) -> None:
        """Log audit trail.
        
        Creates an audit log entry for LLM operations. This is a Sentinel compliance
        check for audit logging.
        
        Args:
            operation: Name of the operation (e.g., "generate").
            request: LLMRequest object containing request details.
            response: Optional LLMResponse object (None if operation failed).
            error: Optional error message if operation failed.
        """
        audit_entry = {
            "timestamp": time.time(),
            "operation": operation,
            "provider": request.provider.value,
            "prompt_length": len(request.prompt),
            "success": response.success if response else False,
            "error": error,
            "pii_detected": response.pii_detected if response else False,
        }
        self._audit_log.append(audit_entry)
        logger.info(f"Audit: {operation} - Provider: {request.provider.value}, Success: {audit_entry['success']}")
    
    async def generate(self, request: LLMRequest) -> LLMResponse:
        """Generate LLM response with security checks.
        
        Generates a response from the specified LLM provider with comprehensive
        security checks including PII detection, input/output validation, and
        audit logging. Performs PII detection on both input prompt and output
        response.
        
        Args:
            request: LLMRequest object containing prompt, provider, and parameters.
        
        Returns:
            LLMResponse object containing:
            - content: Generated content (empty if failed)
            - provider: Provider used
            - latency_ms: Response latency
            - success: Boolean indicating success
            - error: Error message if failed
            - pii_detected: Boolean indicating if PII was detected
            - pii_types: List of detected PII types
        
        Raises:
            RuntimeError: If CognitiveBlock is not initialized.
            ConfigurationError: If API key is not configured for the provider.
            ValidationError: If input validation fails or output validation fails.
            Exception: If LLM generation fails.
        
        Example:
            ```python
            request = LLMRequest(
                prompt="Summarize this document...",
                provider=LLMProvider.OPENAI,
                max_tokens=500
            )
            response = await block.generate(request)
            if response.success:
                print(response.content)
            else:
                print(f"Error: {response.error}")
            ```
        """
        if not self._initialized:
            raise RuntimeError("CognitiveBlock not initialized")
        
        # SENTINEL: Security - check API key exists (except LOCAL which has default)
        if request.provider == LLMProvider.LOCAL:
            # LOCAL provider: use default if not configured
            if "local" not in self.api_keys:
                self.api_keys["local"] = "http://localhost:11434"
        elif request.provider.value not in self.api_keys:
            raise ConfigurationError(
                f"Cognitive Block: Generate - API key not configured for provider: {request.provider.value}",
                component="CognitiveBlock",
                context={"provider": request.provider.value, "configured_providers": list(self.api_keys.keys())}
            )
        
        # SENTINEL: Data Validation
        self._validate_input(request)
        
        # SENTINEL: PII Detection - check input
        pii_detected, pii_types = self._detect_pii(request.prompt)
        if pii_detected:
            self._pii_detections += 1
            logger.warning(f"PII detected in input: {pii_types}")
            # In production, might reject or sanitize
        
        start_time = time.time()
        self._operation_count += 1
        
        try:
            # Simulate LLM call (in production, call actual provider)
            content = await self._call_provider(request)
            
            # SENTINEL: PII Detection - check output
            output_pii_detected, output_pii_types = self._detect_pii(content)
            if output_pii_detected:
                self._pii_detections += 1
                logger.warning(f"PII detected in output: {output_pii_types}")
            
            # SENTINEL: Data Validation
            self._validate_output(content)
            
            latency_ms = (time.time() - start_time) * 1000
            
            response = LLMResponse(
                content=content,
                provider=request.provider,
                latency_ms=latency_ms,
                success=True,
                pii_detected=output_pii_detected,
                pii_types=output_pii_types if output_pii_detected else []
            )
            
            # SENTINEL: Audit Logging
            self._log_audit("generate", request, response)
            
            return response
            
        except Exception as e:
            self._error_count += 1
            error_msg = str(e)
            logger.error(f"LLM generation failed: {error_msg}")
            
            # SENTINEL: Error Handling
            response = LLMResponse(
                content="",
                provider=request.provider,
                latency_ms=(time.time() - start_time) * 1000,
                success=False,
                error=error_msg
            )
            
            # SENTINEL: Audit Logging
            self._log_audit("generate", request, response, error_msg)
            
            raise
    
    async def _call_provider(self, request: LLMRequest) -> str:
        """Call actual LLM provider.
        
        Internal method that calls the actual LLM provider API. Supports
        OpenAI, Anthropic, and Local LLM (Ollama) providers.
        
        Args:
            request: LLMRequest object with provider and prompt details.
        
        Returns:
            Generated content string from the LLM provider.
        
        Raises:
            ConfigurationError: If provider is not properly configured.
            Exception: If API call fails.
        """
        if request.provider == LLMProvider.OPENAI:
            return await self._call_openai(request)
        elif request.provider == LLMProvider.ANTHROPIC:
            return await self._call_anthropic(request)
        elif request.provider == LLMProvider.LOCAL:
            return await self._call_local(request)
        else:
            raise ConfigurationError(
                f"Cognitive Block: Call Provider - Unsupported provider: {request.provider.value}",
                component="CognitiveBlock",
                context={"provider": request.provider.value}
            )
    
    async def _call_openai(self, request: LLMRequest) -> str:
        """Call OpenAI API with caching support."""
        try:
            import openai
            
            api_key = self.api_keys.get("openai")
            if not api_key or api_key.startswith("sk-mock"):
                raise ConfigurationError(
                    "Cognitive Block: Call OpenAI - Invalid or mock API key",
                    component="CognitiveBlock",
                    context={"provider": "openai"}
                )
            
            client = openai.AsyncOpenAI(api_key=api_key)
            
            messages = []
            if request.system_prompt:
                messages.append({"role": "system", "content": request.system_prompt})
            messages.append({"role": "user", "content": request.prompt})
            
            # Build canonical request payload for caching
            request_payload = {
                "model": "gpt-4o-mini",
                "prompt_pack_version": PROMPT_PACK_VERSION,
                "agent_id": "cognitive_block",
                "provider": "openai",
                "messages": messages,
                "max_tokens": request.max_tokens,
                "temperature": request.temperature,
            }
            
            # Wrapper for actual OpenAI call
            async def _real_call(payload: Dict[str, Any]) -> Dict[str, Any]:
                resp = await client.chat.completions.create(
                    model=payload["model"],
                    messages=payload["messages"],
                    max_tokens=payload["max_tokens"],
                    temperature=payload["temperature"]
                )
                return {
                    "content": resp.choices[0].message.content,
                    "model": payload["model"],
                    "usage": resp.usage.model_dump() if resp.usage else {},
                }
            
            # Build cache metadata with MC scores
            cache_meta = {"source": "cognitive_block", "provider": "openai"}
            
            # Calculate MC scores if enabled (for repeatability validation)
            if self._enable_mc_capture and self._mc_engine:
                try:
                    # Calculate MC on the prompt for repeatability tracking
                    mc_result = self._mc_engine.calculate_mc(
                        content=request.prompt,
                        content_id=f"cognitive_block_{request.provider.value}",
                        context={"provider": "openai", "model": "gpt-4o-mini"}
                    )
                    cache_meta.update({
                        "mc_gate_score": mc_result.gate_score.score,
                        "mc_confidence": mc_result.confidence_score.score,
                        "mc_gate_decision": mc_result.gate_score.decision,
                        "mc_bins": {k: v.score for k, v in mc_result.bin_scores.items()},
                    })
                except Exception as e:
                    logger.warning(f"Failed to calculate MC scores for caching: {e}")
            
            # Call with caching
            response_dict = await call_llm_cached_async(
                request_payload=request_payload,
                llm_call=_real_call,
                meta=cache_meta,
            )
            
            return response_dict["content"]
            
        except ImportError:
            raise ConfigurationError(
                "Cognitive Block: Call OpenAI - openai package not installed",
                component="CognitiveBlock",
                context={"provider": "openai"}
            )
        except Exception as e:
            logger.error(f"OpenAI API error: {e}")
            raise
    
    async def _call_anthropic(self, request: LLMRequest) -> str:
        """Call Anthropic API with caching support."""
        try:
            import anthropic
            
            api_key = self.api_keys.get("anthropic")
            if not api_key or api_key.startswith("sk-ant-mock"):
                raise ConfigurationError(
                    "Cognitive Block: Call Anthropic - Invalid or mock API key",
                    component="CognitiveBlock",
                    context={"provider": "anthropic"}
                )
            
            client = anthropic.AsyncAnthropic(api_key=api_key)
            
            system_prompt = request.system_prompt or "You are a helpful AI assistant."
            
            # Build canonical request payload for caching
            request_payload = {
                "model": "claude-3-5-haiku-20241022",
                "prompt_pack_version": PROMPT_PACK_VERSION,
                "agent_id": "cognitive_block",
                "provider": "anthropic",
                "system": system_prompt,
                "messages": [{"role": "user", "content": request.prompt}],
                "max_tokens": request.max_tokens,
                "temperature": request.temperature,
            }
            
            # Wrapper for actual Anthropic call
            async def _real_call(payload: Dict[str, Any]) -> Dict[str, Any]:
                resp = await client.messages.create(
                    model=payload["model"],
                    max_tokens=payload["max_tokens"],
                    temperature=payload["temperature"],
                    system=payload["system"],
                    messages=payload["messages"]
                )
                return {
                    "content": resp.content[0].text,
                    "model": payload["model"],
                    "usage": {"input_tokens": resp.usage.input_tokens, "output_tokens": resp.usage.output_tokens},
                }
            
            # Build cache metadata with MC scores
            cache_meta = {"source": "cognitive_block", "provider": "anthropic"}
            
            # Calculate MC scores if enabled (for repeatability validation)
            if self._enable_mc_capture and self._mc_engine:
                try:
                    # Calculate MC on the prompt for repeatability tracking
                    mc_result = self._mc_engine.calculate_mc(
                        content=request.prompt,
                        content_id=f"cognitive_block_{request.provider.value}",
                        context={"provider": "anthropic", "model": "claude-3-5-haiku-20241022"}
                    )
                    cache_meta.update({
                        "mc_gate_score": mc_result.gate_score.score,
                        "mc_confidence": mc_result.confidence_score.score,
                        "mc_gate_decision": mc_result.gate_score.decision,
                        "mc_bins": {k: v.score for k, v in mc_result.bin_scores.items()},
                    })
                except Exception as e:
                    logger.warning(f"Failed to calculate MC scores for caching: {e}")
            
            # Call with caching
            response_dict = await call_llm_cached_async(
                request_payload=request_payload,
                llm_call=_real_call,
                meta=cache_meta,
            )
            
            return response_dict["content"]
            
        except ImportError:
            raise ConfigurationError(
                "Cognitive Block: Call Anthropic - anthropic package not installed",
                component="CognitiveBlock",
                context={"provider": "anthropic"}
            )
        except Exception as e:
            logger.error(f"Anthropic API error: {e}")
            raise
    
    async def _call_local(self, request: LLMRequest) -> str:
        """Call local LLM API server (Ollama)."""
        try:
            import aiohttp
            
            # Get local LLM configuration
            base_url = self.api_keys.get("local") or os.getenv("LOCAL_LLM_BASE_URL", "http://localhost:11434")
            model = os.getenv("LOCAL_LLM_MODEL", "mistral:7b")
            timeout = int(os.getenv("LOCAL_LLM_TIMEOUT", "600"))  # 10 minutes default
            
            # Prepare the request payload for Ollama API
            payload = {
                "model": model,
                "prompt": request.prompt,
                "stream": False,
                "options": {
                    "temperature": request.temperature,
                    "num_predict": request.max_tokens,
                }
            }
            
            # Add system prompt if provided
            if request.system_prompt:
                payload["system"] = request.system_prompt
            
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{base_url}/api/generate",
                    json=payload,
                    timeout=aiohttp.ClientTimeout(total=timeout)
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        return data.get("response", "No response from local LLM")
                    else:
                        error_text = await response.text()
                        raise Exception(f"Local LLM API error {response.status}: {error_text}")
                        
        except ImportError:
            raise ConfigurationError(
                "Cognitive Block: Call Local - aiohttp package not installed",
                component="CognitiveBlock",
                context={"provider": "local"}
            )
        except Exception as e:
            logger.error(f"Local LLM API error: {e}")
            raise
    
    def get_health(self) -> BlockHealth:
        """Get cognitive block health status.
        
        Returns the health status of the CognitiveBlock based on initialization
        state, error rates, and PII detection rates. Health is unhealthy if error
        rate exceeds 20%, degraded if PII detection rate exceeds 10%.
        
        Returns:
            BlockHealth object containing:
            - status: HealthStatus (HEALTHY, DEGRADED, or UNHEALTHY)
            - message: Human-readable status message
            - details: Dictionary with operational metrics (operations, errors, PII detections, rates)
        """
        if not self._initialized:
            return BlockHealth(
                status=HealthStatus.UNHEALTHY,
                message="CognitiveBlock not initialized",
                details={}
            )
        
        error_rate = self._error_count / max(self._operation_count, 1)
        pii_rate = self._pii_detections / max(self._operation_count, 1)
        
        if error_rate > 0.2:  # More than 20% error rate
            return BlockHealth(
                status=HealthStatus.UNHEALTHY,
                message=f"High error rate: {error_rate:.2%}",
                details={"error_rate": error_rate, "operations": self._operation_count, "errors": self._error_count}
            )
        
        if pii_rate > 0.1:  # More than 10% PII detection rate
            return BlockHealth(
                status=HealthStatus.DEGRADED,
                message=f"High PII detection rate: {pii_rate:.2%}",
                details={"pii_rate": pii_rate, "pii_detections": self._pii_detections}
            )
        
        return BlockHealth(
            status=HealthStatus.HEALTHY,
            message="CognitiveBlock operating normally",
            details={
                "operations": self._operation_count,
                "errors": self._error_count,
                "error_rate": error_rate,
                "pii_detections": self._pii_detections,
                "pii_rate": pii_rate,
                "audit_log_entries": len(self._audit_log)
            }
        )
    
    def get_audit_log(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get audit log entries.
        
        Retrieves recent audit log entries for LLM operations. This is a Sentinel
        compliance check for audit logging access.
        
        Args:
            limit: Maximum number of entries to return (default: 100).
        
        Returns:
            List of audit log entry dictionaries, most recent first.
        """
        return self._audit_log[-limit:]

