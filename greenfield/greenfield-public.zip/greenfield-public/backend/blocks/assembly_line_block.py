# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""AssemblyLineBlock - Pipeline orchestration for agent crew.

The AssemblyLineBlock orchestrates the agent pipeline processing workflow,
coordinating the execution of multiple agents (Caretaker, Gardener, Mercury,
Sentinel, Conductor, Scribe) in sequence. It manages agent handoffs, PII
detection, error handling, and memory storage.

**Card**: CARD-V6B-P1-LEGO-ASSEMBLY_LINE  
**MC Target**: 8.60  
**Dependencies**: AgentBlock, MemoryBlock, CognitiveBlock (all required)

**Key Responsibilities**:
- Orchestrate agent pipeline execution in sequence
- Create and manage agent instances for each stage
- Validate input/output data at each stage
- Detect PII in pipeline content
- Handle errors and stop pipeline on failure
- Store pipeline results in memory
- Maintain audit logs and pipeline history

**Sentinel Compliance**:
- PII Detection: Scans input and output at each stage
- Data Validation: Validates input content and output results
- Agent Handoff Security: Creates secure agent instances for each stage
- Error Handling: Stops pipeline on errors and updates agent status
- Audit Logging: Logs all pipeline operations with context

**Pipeline Stages** (in order):
1. CARETAKER - Strategic intelligence and analysis
2. GARDENER - Structural intelligence and normalization
3. MERCURY - Discovery and extraction
4. SENTINEL - Security and compliance checks
5. CONDUCTOR - Workflow orchestration
6. SCRIBE - Documentation and reporting

**Example Usage**:
    ```python
    from blocks.assembly_line_block import AssemblyLineBlock, PipelineInput
    from blocks.agent_block import AgentBlock
    from blocks.memory_block import MemoryBlock
    from blocks.cognitive_block import CognitiveBlock
    
    # Initialize dependencies
    agent_block = AgentBlock()
    agent_block.initialize({})
    
    memory_block = MemoryBlock()
    memory_block.initialize({"vault_block": vault_block})
    
    cognitive_block = CognitiveBlock()
    cognitive_block.initialize({"api_keys": {...}})
    
    # Initialize assembly line
    assembly_line = AssemblyLineBlock()
    assembly_line.initialize({
        "agent_block": agent_block,
        "memory_block": memory_block,
        "cognitive_block": cognitive_block
    })
    
    # Process pipeline
    input_data = PipelineInput(
        content="Document to process...",
        context={"source": "user_input"},
        metadata={"priority": "high"}
    )
    
    output = await assembly_line.process_pipeline(input_data)
    print(f"Pipeline success: {output.success}")
    ```
"""

import logging
import re
import time
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

from .base_block import BlockHealth, HealthStatus, LEGOBlock
from .agent_block import AgentBlock, AgentInstance, AgentStatus
from .memory_block import MemoryBlock
from .cognitive_block import CognitiveBlock, LLMRequest, LLMResponse

# Import standardized exceptions
try:
    from utils.exceptions import ValidationError, ConfigurationError
except ImportError:
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from utils.exceptions import ValidationError, ConfigurationError

logger = logging.getLogger(__name__)


class PipelineStage(Enum):
    """Pipeline processing stage.
    
    Attributes:
        INPUT: Initial input stage (before processing).
        CARETAKER: Strategic intelligence and analysis stage.
        GARDENER: Structural intelligence and normalization stage.
        MERCURY: Discovery and extraction stage.
        SENTINEL: Security and compliance checks stage.
        CONDUCTOR: Workflow orchestration stage.
        SCRIBE: Documentation and reporting stage.
        OUTPUT: Final output stage (after all processing).
        ERROR: Error stage (when pipeline fails).
    """
    INPUT = "input"
    CARETAKER = "caretaker"
    GARDENER = "gardener"
    MERCURY = "mercury"
    SENTINEL = "sentinel"
    CONDUCTOR = "conductor"
    SCRIBE = "scribe"
    OUTPUT = "output"
    ERROR = "error"


@dataclass
class PipelineInput:
    """Pipeline input data.
    
    Attributes:
        content: Text content to process through the pipeline (required).
        context: Optional dictionary with processing context (source, user info, etc.).
        metadata: Optional dictionary with additional metadata (priority, tags, etc.).
    """
    content: str
    context: Optional[Dict[str, Any]] = None
    metadata: Optional[Dict[str, Any]] = None


@dataclass
class PipelineOutput:
    """Pipeline output data.
    
    Attributes:
        content: Processed content from the pipeline (empty if failed).
        stage: PipelineStage indicating the final stage reached.
        success: Boolean indicating if pipeline completed successfully.
        error: Error message if pipeline failed (None if successful).
        metadata: Optional dictionary with pipeline metadata (pipeline_id, stages, history).
    """
    content: str
    stage: PipelineStage
    success: bool
    error: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


class AssemblyLineBlock(LEGOBlock):
    """AssemblyLineBlock orchestrates agent pipeline processing.
    
    The AssemblyLineBlock coordinates the execution of the agent pipeline,
    managing sequential processing through multiple agent stages. It creates
    agent instances for each stage, validates data, detects PII, handles
    errors, and stores results in memory.
    
    Attributes:
        block_name: Block identifier ("assembly_line").
        version: Block version ("1.0.0").
        requires: Tuple containing ("agent", "memory", "cognitive") - requires
            AgentBlock, MemoryBlock, and CognitiveBlock.
        PII_PATTERNS: Dictionary of regex patterns for PII detection.
            Keys are PII types (email, phone, ssn), values are regex patterns.
        PIPELINE_STAGES: List of PipelineStage enums in execution order.
        agent_block: AgentBlock instance (set during initialization).
        memory_block: MemoryBlock instance (set during initialization).
        cognitive_block: CognitiveBlock instance (set during initialization).
    """
    
    block_name: str = "assembly_line"
    version: str = "1.0.0"
    requires: tuple = ("agent", "memory", "cognitive")  # Depends on AgentBlock, MemoryBlock, CognitiveBlock
    
    # PII patterns (SENTINEL: PII Detection)
    PII_PATTERNS: Dict[str, str] = {
        "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        "phone": r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
        "ssn": r'\b\d{3}-\d{2}-\d{4}\b',
    }
    
    # Pipeline stages in order
    PIPELINE_STAGES: List[PipelineStage] = [
        PipelineStage.CARETAKER,
        PipelineStage.GARDENER,
        PipelineStage.MERCURY,
        PipelineStage.SENTINEL,
        PipelineStage.CONDUCTOR,
        PipelineStage.SCRIBE,
    ]
    
    def __init__(self) -> None:
        """Initialize AssemblyLineBlock.
        
        Sets up internal state for dependency blocks, operation tracking, PII
        detection, audit logging, and pipeline history. Dependencies are set
        during initialization via initialize().
        """
        super().__init__()
        self.agent_block: Optional[AgentBlock] = None
        self.memory_block: Optional[MemoryBlock] = None
        self.cognitive_block: Optional[CognitiveBlock] = None
        self._operation_count: int = 0
        self._error_count: int = 0
        self._pii_detections: int = 0
        self._audit_log: List[Dict[str, Any]] = []
        self._pipeline_history: List[Dict[str, Any]] = []
    
    def get_schema(self) -> Dict[str, Any]:
        """Get configuration schema.
        
        Returns the JSON schema for AssemblyLineBlock configuration. Required
        fields are agent_block, memory_block, and cognitive_block (all must be
        initialized instances).
        
        Returns:
            Dictionary containing JSON schema for configuration validation.
        """
        return {
            "type": "object",
            "required": ["agent_block", "memory_block", "cognitive_block"],
            "properties": {
                "agent_block": {"type": "object", "description": "AgentBlock instance"},
                "memory_block": {"type": "object", "description": "MemoryBlock instance"},
                "cognitive_block": {"type": "object", "description": "CognitiveBlock instance"},
            },
        }
    
    def initialize(self, config: Dict[str, Any]) -> None:
        """Initialize assembly line block with dependencies.
        
        Initializes the AssemblyLineBlock with AgentBlock, MemoryBlock, and
        CognitiveBlock instances. Validates that all dependencies are correct
        types and are initialized. Must be called before processing pipelines.
        
        Args:
            config: Configuration dictionary containing:
                - agent_block: AgentBlock instance (required, must be initialized)
                - memory_block: MemoryBlock instance (required, must be initialized)
                - cognitive_block: CognitiveBlock instance (required, must be initialized)
        
        Raises:
            ConfigurationError: If any dependency is missing, wrong type, or not initialized.
            ValidationError: If configuration schema validation fails.
        
        Example:
            ```python
            assembly_line = AssemblyLineBlock()
            assembly_line.initialize({
                "agent_block": agent_block,
                "memory_block": memory_block,
                "cognitive_block": cognitive_block
            })
            ```
        """
        self.validate_config(config)
        
        # SENTINEL: Security - validate dependencies
        agent_block = config.get("agent_block")
        memory_block = config.get("memory_block")
        cognitive_block = config.get("cognitive_block")
        
        if not isinstance(agent_block, AgentBlock):
            raise ConfigurationError(
                "Assembly Line Block: Initialize - agent_block must be an AgentBlock instance",
                component="AssemblyLineBlock",
                context={"agent_block_type": type(agent_block).__name__ if agent_block else None}
            )
        if not isinstance(memory_block, MemoryBlock):
            raise ConfigurationError(
                "Assembly Line Block: Initialize - memory_block must be a MemoryBlock instance",
                component="AssemblyLineBlock",
                context={"memory_block_type": type(memory_block).__name__ if memory_block else None}
            )
        if not isinstance(cognitive_block, CognitiveBlock):
            raise ConfigurationError(
                "Assembly Line Block: Initialize - cognitive_block must be a CognitiveBlock instance",
                component="AssemblyLineBlock",
                context={"cognitive_block_type": type(cognitive_block).__name__ if cognitive_block else None}
            )
        
        if not agent_block._initialized:
            raise ConfigurationError(
                "Assembly Line Block: Initialize - AgentBlock must be initialized before AssemblyLineBlock",
                component="AssemblyLineBlock",
                context={}
            )
        if not memory_block._initialized:
            raise ConfigurationError(
                "Assembly Line Block: Initialize - MemoryBlock must be initialized before AssemblyLineBlock",
                component="AssemblyLineBlock",
                context={}
            )
        if not cognitive_block._initialized:
            raise ConfigurationError(
                "Assembly Line Block: Initialize - CognitiveBlock must be initialized before AssemblyLineBlock",
                component="AssemblyLineBlock",
                context={}
            )
        
        self.agent_block = agent_block
        self.memory_block = memory_block
        self.cognitive_block = cognitive_block
        self._initialized = True
        logger.info("AssemblyLineBlock initialized with all dependencies")
    
    def _detect_pii(self, text: str) -> Tuple[bool, List[str]]:
        """Detect PII in text.
        
        Scans text for PII patterns including email addresses, phone numbers,
        and SSNs. This is a Sentinel compliance check for PII detection.
        
        Args:
            text: Text string to scan for PII.
        
        Returns:
            Tuple containing:
            - Boolean indicating if any PII was detected
            - List of PII types detected (empty list if none)
        """
        detected_types = []
        for pii_type, pattern in self.PII_PATTERNS.items():
            if re.search(pattern, text, re.IGNORECASE):
                detected_types.append(pii_type)
        return len(detected_types) > 0, detected_types
    
    def _validate_input(self, input_data: PipelineInput) -> None:
        """Validate input.
        
        Validates pipeline input including content presence and length limits.
        This is a Sentinel compliance check for data validation.
        
        Args:
            input_data: PipelineInput object to validate.
        
        Raises:
            ValidationError: If content is empty or exceeds maximum length.
        """
        if not input_data.content or len(input_data.content.strip()) == 0:
            raise ValidationError(
                "Assembly Line Block: Validate Input - Input content cannot be empty",
                component="AssemblyLineBlock",
                context={}
            )
        
        if len(input_data.content) > 1000000:  # Reasonable limit
            raise ValidationError(
                "Assembly Line Block: Validate Input - Input content too long (max 1000000 characters)",
                component="AssemblyLineBlock",
                context={"content_length": len(input_data.content)}
            )
    
    def _validate_output(self, output: PipelineOutput) -> None:
        """Validate output.
        
        Validates pipeline output including content presence for successful
        outputs and error messages for failed outputs. This is a Sentinel
        compliance check for data validation.
        
        Args:
            output: PipelineOutput object to validate.
        
        Raises:
            ValidationError: If successful output lacks content or error output lacks message.
        """
        if output.success and not output.content:
            raise ValidationError(
                "Assembly Line Block: Validate Output - Successful output must have content",
                component="AssemblyLineBlock",
                context={"output_success": output.success}
            )
        
        if output.error and not output.error.strip():
            raise ValidationError(
                "Assembly Line Block: Validate Output - Error output must have error message",
                component="AssemblyLineBlock",
                context={"has_error": bool(output.error)}
            )
    
    def _log_audit(self, operation: str, pipeline_id: str, stage: PipelineStage, details: Optional[Dict[str, Any]] = None) -> None:
        """Log audit trail.
        
        Creates an audit log entry for pipeline operations. This is a Sentinel
        compliance check for audit logging.
        
        Args:
            operation: Name of the operation (e.g., "pipeline_start", "process_stage").
            pipeline_id: Unique identifier of the pipeline execution.
            stage: PipelineStage where the operation occurred.
            details: Optional dictionary with additional operation details.
        """
        audit_entry = {
            "timestamp": time.time(),
            "operation": operation,
            "pipeline_id": pipeline_id,
            "stage": stage.value,
            "details": details or {},
        }
        self._audit_log.append(audit_entry)
        logger.info(f"Audit: {operation} - Pipeline: {pipeline_id}, Stage: {stage.value}")
    
    def _create_agent_instance(self, agent_type: str, pipeline_id: str) -> AgentInstance:
        """Create agent instance for pipeline.
        
        Creates a new agent instance for a pipeline stage. This is a Sentinel
        compliance check for agent handoff security.
        
        Args:
            agent_type: Type of agent to create (e.g., "caretaker", "gardener").
            pipeline_id: Unique identifier of the pipeline execution.
        
        Returns:
            AgentInstance object for the created agent.
        
        Raises:
            Exception: If agent creation fails.
        """
        from .agent_block import AgentConfig
        agent_config = AgentConfig(
            agent_id=f"{agent_type}_{pipeline_id}",
            agent_type=agent_type,
            config={}
        )
        return self.agent_block.create_agent(agent_config)
    
    def _process_stage(self, stage: PipelineStage, content: str, context: Dict[str, Any], pipeline_id: str) -> PipelineOutput:
        """Process a single pipeline stage.
        
        Processes content through a single pipeline stage by creating an agent
        instance, updating its status, performing PII detection, and executing
        the agent's processing logic. This is a Sentinel compliance check for
        agent handoff security.
        
        Args:
            stage: PipelineStage to process.
            content: Content to process at this stage.
            context: Dictionary with processing context.
            pipeline_id: Unique identifier of the pipeline execution.
        
        Returns:
            PipelineOutput object with:
            - content: Processed content (empty if failed)
            - stage: PipelineStage processed
            - success: Boolean indicating success
            - error: Error message if failed
            - metadata: Dictionary with agent_id
        """
        try:
            # SENTINEL: Security - create agent instance for this stage
            agent_type = stage.value
            agent_instance = self._create_agent_instance(agent_type, pipeline_id)
            
            # Update agent status
            self.agent_block.update_agent_status(agent_instance.agent_id, AgentStatus.RUNNING)
            
            # SENTINEL: PII Detection - check input before processing
            pii_detected, pii_types = self._detect_pii(content)
            if pii_detected:
                self._pii_detections += 1
                logger.warning(f"PII detected in stage {stage.value}: {pii_types}")
            
            # Process stage (simplified - in production, each agent has specific logic)
            # For greenfield, simulate agent processing
            processed_content = self._simulate_agent_processing(stage, content, context)
            
            # SENTINEL: PII Detection - check output after processing
            output_pii_detected, output_pii_types = self._detect_pii(processed_content)
            if output_pii_detected:
                self._pii_detections += 1
                logger.warning(f"PII detected in stage {stage.value} output: {output_pii_types}")
            
            # Update agent status
            self.agent_block.update_agent_status(agent_instance.agent_id, AgentStatus.IDLE)
            
            # SENTINEL: Audit Logging
            self._log_audit("process_stage", pipeline_id, stage, {
                "agent_id": agent_instance.agent_id,
                "pii_detected": pii_detected or output_pii_detected
            })
            
            return PipelineOutput(
                content=processed_content,
                stage=stage,
                success=True,
                metadata={"agent_id": agent_instance.agent_id}
            )
            
        except Exception as e:
            self._error_count += 1
            error_msg = str(e)
            logger.error(f"Stage {stage.value} failed: {error_msg}")
            
            # SENTINEL: Error Handling
            # Update agent status to ERROR if agent exists
            try:
                agent_id = f"{stage.value}_{pipeline_id}"
                if agent_id in [a.agent_id for a in self.agent_block.list_agents()]:
                    self.agent_block.update_agent_status(agent_id, AgentStatus.ERROR)
            except Exception:
                pass
            
            # SENTINEL: Audit Logging
            self._log_audit("process_stage_error", pipeline_id, stage, {"error": error_msg})
            
            return PipelineOutput(
                content="",
                stage=stage,
                success=False,
                error=error_msg
            )
    
    def _simulate_agent_processing(self, stage: PipelineStage, content: str, context: Dict[str, Any]) -> str:
        """Simulate agent processing.
        
        Simulates agent processing for greenfield. In production, each agent
        has specific processing logic. This is a placeholder implementation.
        
        Args:
            stage: PipelineStage being processed.
            content: Content to process.
            context: Dictionary with processing context.
        
        Returns:
            Processed content string (simulated).
        """
        # Simplified simulation - in production, each agent has specific processing
        stage_prefix = {
            PipelineStage.CARETAKER: "[Caretaker]",
            PipelineStage.GARDENER: "[Gardener]",
            PipelineStage.MERCURY: "[Mercury]",
            PipelineStage.SENTINEL: "[Sentinel]",
            PipelineStage.CONDUCTOR: "[Conductor]",
            PipelineStage.SCRIBE: "[Scribe]",
        }
        return f"{stage_prefix.get(stage, '')} {content}"
    
    async def process_pipeline(self, input_data: PipelineInput) -> PipelineOutput:
        """Process input through the agent pipeline.
        
        Processes input data through the complete agent pipeline, executing
        all stages sequentially (Caretaker → Gardener → Mercury → Sentinel →
        Conductor → Scribe). Performs PII detection, validates data, handles
        errors, and stores results in memory. Stops pipeline on any stage failure.
        
        Args:
            input_data: PipelineInput object containing content, context, and metadata.
        
        Returns:
            PipelineOutput object with:
            - content: Final processed content (empty if failed)
            - stage: Final PipelineStage reached (OUTPUT if successful, ERROR if failed)
            - success: Boolean indicating if pipeline completed successfully
            - error: Error message if pipeline failed
            - metadata: Dictionary with pipeline_id, stages_processed, pipeline_history
        
        Raises:
            RuntimeError: If AssemblyLineBlock is not initialized.
            ValidationError: If input validation fails or output validation fails.
        
        Example:
            ```python
            input_data = PipelineInput(
                content="Document to analyze...",
                context={"source": "user"},
                metadata={"priority": "high"}
            )
            
            output = await assembly_line.process_pipeline(input_data)
            if output.success:
                print(f"Processed: {output.content}")
            else:
                print(f"Error: {output.error}")
            ```
        """
        if not self._initialized:
            raise RuntimeError("AssemblyLineBlock not initialized")
        
        # SENTINEL: Data Validation
        self._validate_input(input_data)
        
        pipeline_id = f"pipeline_{int(time.time() * 1000)}"
        self._operation_count += 1
        
        # SENTINEL: PII Detection - check input
        pii_detected, pii_types = self._detect_pii(input_data.content)
        if pii_detected:
            self._pii_detections += 1
            logger.warning(f"PII detected in pipeline input: {pii_types}")
        
        # SENTINEL: Audit Logging
        self._log_audit("pipeline_start", pipeline_id, PipelineStage.INPUT, {
            "content_length": len(input_data.content),
            "pii_detected": pii_detected
        })
        
        current_content = input_data.content
        context = input_data.context or {}
        pipeline_history = []
        
        # Process through pipeline stages
        for stage in self.PIPELINE_STAGES:
            stage_output = self._process_stage(stage, current_content, context, pipeline_id)
            
            pipeline_history.append({
                "stage": stage.value,
                "success": stage_output.success,
                "error": stage_output.error,
            })
            
            if not stage_output.success:
                # SENTINEL: Error Handling - stop pipeline on error
                error_output = PipelineOutput(
                    content="",
                    stage=PipelineStage.ERROR,
                    success=False,
                    error=f"Pipeline failed at {stage.value}: {stage_output.error}",
                    metadata={"pipeline_history": pipeline_history}
                )
                
                # SENTINEL: Audit Logging
                self._log_audit("pipeline_error", pipeline_id, PipelineStage.ERROR, {
                    "failed_stage": stage.value,
                    "error": stage_output.error
                })
                
                return error_output
            
            current_content = stage_output.content
        
        # Store in memory (SENTINEL: Memory integration)
        try:
            # Calculate MC score (simplified - in production, use MC Engine)
            mc_score = 8.5  # Default score
            self.memory_block.store_memory(
                content=current_content,
                mc_score=mc_score,
                metadata={"pipeline_id": pipeline_id, "stages": [s.value for s in self.PIPELINE_STAGES]}
            )
        except Exception as e:
            logger.warning(f"Failed to store pipeline result in memory: {e}")
            # Don't fail pipeline if memory storage fails
        
        # Final output
        output = PipelineOutput(
            content=current_content,
            stage=PipelineStage.OUTPUT,
            success=True,
            metadata={
                "pipeline_id": pipeline_id,
                "stages_processed": len(self.PIPELINE_STAGES),
                "pipeline_history": pipeline_history
            }
        )
        
        # SENTINEL: Data Validation
        self._validate_output(output)
        
        # SENTINEL: Audit Logging
        self._log_audit("pipeline_complete", pipeline_id, PipelineStage.OUTPUT, {
            "stages_processed": len(self.PIPELINE_STAGES),
            "success": True
        })
        
        self._pipeline_history.append({
            "pipeline_id": pipeline_id,
            "timestamp": time.time(),
            "success": True,
            "stages": len(self.PIPELINE_STAGES)
        })
        
        logger.info(f"Pipeline completed: {pipeline_id}")
        return output
    
    def get_health(self) -> BlockHealth:
        """Get assembly line block health status.
        
        Returns the health status of the AssemblyLineBlock based on initialization
        state, dependency health (AgentBlock, MemoryBlock, CognitiveBlock), error
        rates, and PII detection rates. Health is degraded if any dependency is
        unhealthy or error rate exceeds 10%.
        
        Returns:
            BlockHealth object containing:
            - status: HealthStatus (HEALTHY, DEGRADED, or UNHEALTHY)
            - message: Human-readable status message
            - details: Dictionary with operational metrics (operations, errors, PII
                detections, rates, pipelines_completed, audit_log_entries)
        """
        if not self._initialized:
            return BlockHealth(
                status=HealthStatus.UNHEALTHY,
                message="AssemblyLineBlock not initialized",
                details={}
            )
        
        # Check dependency health
        agent_health = self.agent_block.get_health()
        memory_health = self.memory_block.get_health()
        cognitive_health = self.cognitive_block.get_health()
        
        if agent_health.status != HealthStatus.HEALTHY:
            return BlockHealth(
                status=HealthStatus.DEGRADED,
                message=f"AgentBlock unhealthy: {agent_health.message}",
                details={"agent_health": agent_health.details}
            )
        
        if memory_health.status != HealthStatus.HEALTHY:
            return BlockHealth(
                status=HealthStatus.DEGRADED,
                message=f"MemoryBlock unhealthy: {memory_health.message}",
                details={"memory_health": memory_health.details}
            )
        
        if cognitive_health.status != HealthStatus.HEALTHY:
            return BlockHealth(
                status=HealthStatus.DEGRADED,
                message=f"CognitiveBlock unhealthy: {cognitive_health.message}",
                details={"cognitive_health": cognitive_health.details}
            )
        
        error_rate = self._error_count / max(self._operation_count, 1)
        pii_rate = self._pii_detections / max(self._operation_count, 1)
        
        if error_rate > 0.1:
            return BlockHealth(
                status=HealthStatus.DEGRADED,
                message=f"High error rate: {error_rate:.2%}",
                details={"error_rate": error_rate, "operations": self._operation_count, "errors": self._error_count}
            )
        
        return BlockHealth(
            status=HealthStatus.HEALTHY,
            message="AssemblyLineBlock operating normally",
            details={
                "operations": self._operation_count,
                "errors": self._error_count,
                "error_rate": error_rate,
                "pii_detections": self._pii_detections,
                "pii_rate": pii_rate,
                "pipelines_completed": len(self._pipeline_history),
                "audit_log_entries": len(self._audit_log)
            }
        )
    
    def get_audit_log(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get audit log entries.
        
        Retrieves recent audit log entries for pipeline operations. This is a
        Sentinel compliance check for audit logging access.
        
        Args:
            limit: Maximum number of entries to return (default: 100).
        
        Returns:
            List of audit log entry dictionaries, most recent first.
        """
        return self._audit_log[-limit:]
    
    def get_pipeline_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get pipeline execution history.
        
        Retrieves recent pipeline execution history including pipeline IDs,
        timestamps, success status, and number of stages processed.
        
        Args:
            limit: Maximum number of entries to return (default: 100).
        
        Returns:
            List of pipeline history dictionaries, most recent first.
        """
        return self._pipeline_history[-limit:]

