# Copyright 2025 Janus DTM Core Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""BatchBlock - Batch processing operations.

The BatchBlock provides batch processing capabilities for handling multiple
items efficiently. It manages batch jobs with queuing, processing, status
tracking, and PII detection. Supports configurable batch thresholds and
timeouts.

**Card**: CARD-V6B-P1-LEGO-BATCH  
**MC Target**: 8.55  
**Dependencies**: None (foundational block)

**Key Responsibilities**:
- Create and manage batch processing jobs
- Determine when items should be processed in batch mode
- Process batches with error handling
- Track job status (QUEUED, PROCESSING, COMPLETED, FAILED, CANCELLED)
- Detect PII in batch items
- Maintain audit logs of batch operations

**Sentinel Compliance**:
- PII Detection: Scans batch items for PII patterns
- Data Validation: Validates batch sizes, job IDs, and item counts
- Error Handling: Handles individual item failures gracefully
- Audit Logging: Logs all batch operations with context
- Security: Validates job status and authorization

**Example Usage**:
    ```python
    from blocks.batch_block import BatchBlock
    
    batch_block = BatchBlock()
    batch_block.initialize({
        "batch_threshold": 5,
        "max_batch_size": 100,
        "timeout_seconds": 300
    })
    
    # Create batch job
    items = [{"id": i, "data": f"item_{i}"} for i in range(10)]
    job_id = batch_block.create_batch_job(items, metadata={"source": "api"})
    
    # Process batch
    result = batch_block.process_batch(job_id)
    print(f"Processed {result['items_processed']} items")
    ```
"""

import logging
import re
import time
import uuid
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional

from .base_block import BlockHealth, HealthStatus, LEGOBlock

# Import standardized exceptions
try:
    from utils.exceptions import ValidationError, ConfigurationError
except ImportError:
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from utils.exceptions import ValidationError, ConfigurationError

logger = logging.getLogger(__name__)


class BatchStatus(Enum):
    """Batch processing status.
    
    Attributes:
        QUEUED: Job is queued and waiting to be processed.
        PROCESSING: Job is currently being processed.
        COMPLETED: Job completed successfully.
        FAILED: Job failed during processing.
        CANCELLED: Job was cancelled before completion.
    """
    QUEUED = "queued"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class BatchJob:
    """Batch processing job.
    
    Attributes:
        job_id: Unique identifier for the batch job.
        items: List of items to process in the batch.
        status: Current BatchStatus of the job.
        created_at: Timestamp when job was created.
        started_at: Optional timestamp when processing started.
        completed_at: Optional timestamp when processing completed.
        error: Optional error message if job failed.
        results: Optional list of processing results for each item.
        metadata: Optional dictionary with job metadata.
    """
    job_id: str
    items: List[Dict[str, Any]]
    status: BatchStatus
    created_at: float
    started_at: Optional[float] = None
    completed_at: Optional[float] = None
    error: Optional[str] = None
    results: Optional[List[Dict[str, Any]]] = None
    metadata: Optional[Dict[str, Any]] = None


class BatchBlock(LEGOBlock):
    """BatchBlock provides batch processing operations.
    
    The BatchBlock manages batch processing jobs with queuing, status tracking,
    and error handling. It supports configurable batch thresholds and maximum
    batch sizes, and performs PII detection on batch items.
    
    Attributes:
        block_name: Block identifier ("batch").
        version: Block version ("1.0.0").
        requires: Empty tuple (foundational block, no dependencies).
        DEFAULT_BATCH_THRESHOLD: Default threshold for auto-batching (5 items).
        DEFAULT_MAX_BATCH_SIZE: Default maximum batch size (100 items).
        DEFAULT_TIMEOUT_SECONDS: Default timeout in seconds (300 = 5 minutes).
        PII_PATTERNS: Dictionary of regex patterns for PII detection.
            Keys are PII types (email, phone, ssn, credit_card), values are regex patterns.
    """
    
    block_name: str = "batch"
    version: str = "1.0.0"
    requires: tuple = ()  # Foundational block
    
    # Batch configuration
    DEFAULT_BATCH_THRESHOLD: int = 5  # Auto-batch when >= 5 items
    DEFAULT_MAX_BATCH_SIZE: int = 100
    DEFAULT_TIMEOUT_SECONDS: int = 300  # 5 minutes
    
    # PII patterns (SENTINEL: PII Detection)
    PII_PATTERNS: Dict[str, str] = {
        "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        "phone": r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
        "ssn": r'\b\d{3}-\d{2}-\d{4}\b',
        "credit_card": r'\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b',
    }
    
    def __init__(self) -> None:
        """Initialize BatchBlock.
        
        Sets up internal state for batch jobs, operation tracking, and configuration.
        Configuration (thresholds, timeouts) is set during initialization via initialize().
        """
        super().__init__()
        self._batch_threshold: int = self.DEFAULT_BATCH_THRESHOLD
        self._max_batch_size: int = self.DEFAULT_MAX_BATCH_SIZE
        self._timeout_seconds: int = self.DEFAULT_TIMEOUT_SECONDS
        self._jobs: Dict[str, BatchJob] = {}
        self._processing_count: int = 0
        self._total_processed: int = 0
        self._total_failed: int = 0
    
    def get_schema(self) -> Dict[str, Any]:
        """Get block configuration schema.
        
        Returns the JSON schema for BatchBlock configuration. Optional fields
        are batch_threshold (default: 5), max_batch_size (default: 100), and
        timeout_seconds (default: 300).
        
        Returns:
            Dictionary containing JSON schema for configuration validation.
        """
        return {
            "type": "object",
            "properties": {
                "batch_threshold": {
                    "type": "integer",
                    "description": "Auto-batch threshold for items",
                    "default": self.DEFAULT_BATCH_THRESHOLD
                },
                "max_batch_size": {
                    "type": "integer",
                    "description": "Maximum batch size",
                    "default": self.DEFAULT_MAX_BATCH_SIZE
                },
                "timeout_seconds": {
                    "type": "integer",
                    "description": "Batch processing timeout in seconds",
                    "default": self.DEFAULT_TIMEOUT_SECONDS
                }
            }
        }
    
    def initialize(self, config: Dict[str, Any]) -> None:
        """Initialize the block with configuration.
        
        Initializes the BatchBlock with batch threshold, maximum batch size,
        and timeout settings. Validates all configuration values.
        
        Args:
            config: Configuration dictionary containing:
                - batch_threshold: Optional integer threshold for auto-batching (default: 5)
                - max_batch_size: Optional integer maximum batch size (default: 100)
                - timeout_seconds: Optional number timeout in seconds (default: 300)
        
        Raises:
            ConfigurationError: If any configuration value is invalid.
            ValidationError: If configuration schema validation fails.
        
        Example:
            ```python
            batch_block = BatchBlock()
            batch_block.initialize({
                "batch_threshold": 10,
                "max_batch_size": 200,
                "timeout_seconds": 600
            })
            ```
        """
        self.validate_config(config)
        
        # SENTINEL: Data Validation
        batch_threshold = config.get("batch_threshold", self.DEFAULT_BATCH_THRESHOLD)
        if not isinstance(batch_threshold, int) or batch_threshold < 1:
            raise ConfigurationError(
                "Batch Block: Initialize - batch_threshold must be a positive integer",
                component="BatchBlock",
                context={"batch_threshold": batch_threshold, "threshold_type": type(batch_threshold).__name__}
            )
        
        max_batch_size = config.get("max_batch_size", self.DEFAULT_MAX_BATCH_SIZE)
        if not isinstance(max_batch_size, int) or max_batch_size < 1:
            raise ConfigurationError(
                "Batch Block: Initialize - max_batch_size must be a positive integer",
                component="BatchBlock",
                context={"max_batch_size": max_batch_size, "size_type": type(max_batch_size).__name__}
            )
        
        timeout_seconds = config.get("timeout_seconds", self.DEFAULT_TIMEOUT_SECONDS)
        if not isinstance(timeout_seconds, (int, float)) or timeout_seconds < 1:
            raise ConfigurationError(
                "Batch Block: Initialize - timeout_seconds must be a positive number",
                component="BatchBlock",
                context={"timeout_seconds": timeout_seconds, "timeout_type": type(timeout_seconds).__name__}
            )
        
        self._batch_threshold = batch_threshold
        self._max_batch_size = max_batch_size
        self._timeout_seconds = timeout_seconds
        self._config = config
        self._initialized = True
        
        # SENTINEL: Audit Logging
        logger.info(
            f"BatchBlock initialized: threshold={batch_threshold}, "
            f"max_size={max_batch_size}, timeout={timeout_seconds}"
        )
    
    def should_batch(self, item_count: int) -> bool:
        """Determine if items should be processed in batch mode.
        
        Checks if the item count meets or exceeds the batch threshold.
        
        Args:
            item_count: Number of items to process.
        
        Returns:
            Boolean indicating if items should be batched (True if item_count >= threshold).
        
        Raises:
            ValidationError: If item_count is not a non-negative integer.
        """
        # SENTINEL: Data Validation
        if not isinstance(item_count, int) or item_count < 0:
            raise ValidationError(
                "Batch Block: Should Batch - item_count must be a non-negative integer",
                component="BatchBlock",
                context={"item_count": item_count, "item_count_type": type(item_count).__name__}
            )
        
        return item_count >= self._batch_threshold
    
    def create_batch_job(
        self,
        items: List[Dict[str, Any]],
        metadata: Optional[Dict[str, Any]] = None
    ) -> str:
        """Create a new batch processing job.
        
        Creates a new batch job with the specified items. Performs PII detection,
        validates batch size, and creates a job in QUEUED status.
        
        Args:
            items: List of items to process in the batch (must be non-empty).
            metadata: Optional dictionary with job metadata.
        
        Returns:
            String job ID for the created batch job.
        
        Raises:
            ValidationError: If items is not a list, is empty, or exceeds max_batch_size.
        
        Example:
            ```python
            items = [{"id": i, "data": f"item_{i}"} for i in range(10)]
            job_id = batch_block.create_batch_job(items, metadata={"source": "api"})
            ```
        """
        # SENTINEL: Data Validation
        if not isinstance(items, list):
            raise ValidationError(
                "Batch Block: Create Batch Job - items must be a list",
                component="BatchBlock",
                context={"items_type": type(items).__name__}
            )
        
        if len(items) == 0:
            raise ValidationError(
                "Batch Block: Create Batch Job - items list cannot be empty",
                component="BatchBlock",
                context={}
            )
        
        if len(items) > self._max_batch_size:
            raise ValidationError(
                f"Batch Block: Create Batch Job - items list exceeds max_batch_size ({self._max_batch_size})",
                component="BatchBlock",
                context={"items_count": len(items), "max_batch_size": self._max_batch_size}
            )
        
        # SENTINEL: PII Detection
        pii_detected = self._detect_pii(items)
        if pii_detected:
            logger.warning("PII detected in batch job items - proceeding with caution")
        
        # SENTINEL: Security - Authorization check (mock for greenfield)
        # In production, this would check user permissions
        self._audit_operation("create_batch_job", {"item_count": len(items)})
        
        job_id = str(uuid.uuid4())
        job = BatchJob(
            job_id=job_id,
            items=items,
            status=BatchStatus.QUEUED,
            created_at=time.time(),
            metadata=metadata or {}
        )
        
        self._jobs[job_id] = job
        
        # SENTINEL: Audit Logging
        logger.info(f"Batch job created: job_id={job_id}, items={len(items)}")
        
        return job_id
    
    def process_batch(self, job_id: str) -> Dict[str, Any]:
        """Process a batch job.
        
        Processes a batch job by updating its status to PROCESSING, processing
        each item, and updating status to COMPLETED or FAILED. Handles individual
        item failures gracefully.
        
        Args:
            job_id: Unique identifier of the batch job to process.
        
        Returns:
            Dictionary with:
            - job_id: Job identifier
            - status: "completed"
            - items_processed: Number of items processed
            - duration_seconds: Processing duration
        
        Raises:
            ValidationError: If job_id is invalid, job not found, or job not in QUEUED status.
            Exception: If batch processing fails (job status set to FAILED).
        
        Example:
            ```python
            result = batch_block.process_batch(job_id)
            print(f"Processed {result['items_processed']} items in {result['duration_seconds']:.2f}s")
            ```
        """
        # SENTINEL: Data Validation
        if not isinstance(job_id, str) or not job_id:
            raise ValidationError(
                "Batch Block: Process Batch Job - job_id must be a non-empty string",
                component="BatchBlock",
                context={"job_id_type": type(job_id).__name__}
            )
        
        if job_id not in self._jobs:
            raise ValidationError(
                f"Batch Block: Process Batch Job - Job not found: {job_id}",
                component="BatchBlock",
                context={"job_id": job_id, "available_jobs": list(self._jobs.keys())}
            )
        
        job = self._jobs[job_id]
        
        # SENTINEL: Security - Check job status
        if job.status != BatchStatus.QUEUED:
            raise ValidationError(
                f"Batch Block: Process Batch Job - Job {job_id} is not in QUEUED status (current: {job.status.value})",
                component="BatchBlock",
                context={"job_id": job_id, "current_status": job.status.value, "expected_status": BatchStatus.QUEUED.value}
            )
        
        # SENTINEL: Audit Logging
        self._audit_operation("process_batch", {"job_id": job_id, "item_count": len(job.items)})
        
        job.status = BatchStatus.PROCESSING
        job.started_at = time.time()
        self._processing_count += 1
        
        try:
            # Mock processing (in production, this would call actual processing logic)
            results = []
            for item in job.items:
                # SENTINEL: Error Handling - Validate each item
                try:
                    # Mock processing result
                    result = {
                        "item_id": item.get("id", str(uuid.uuid4())),
                        "status": "processed",
                        "processed_at": time.time()
                    }
                    results.append(result)
                except Exception as e:
                    # SENTINEL: Error Handling - Handle individual item failures
                    logger.error(f"Error processing item in batch {job_id}: {e}")
                    results.append({
                        "item_id": item.get("id", "unknown"),
                        "status": "failed",
                        "error": str(e)
                    })
            
            job.status = BatchStatus.COMPLETED
            job.completed_at = time.time()
            job.results = results
            self._total_processed += len(results)
            
            # SENTINEL: Audit Logging
            logger.info(
                f"Batch job completed: job_id={job_id}, "
                f"items={len(results)}, duration={job.completed_at - job.started_at:.2f}s"
            )
            
            return {
                "job_id": job_id,
                "status": "completed",
                "items_processed": len(results),
                "duration_seconds": job.completed_at - job.started_at
            }
            
        except Exception as e:
            # SENTINEL: Error Handling - Handle batch processing failures
            job.status = BatchStatus.FAILED
            job.completed_at = time.time()
            job.error = str(e)
            self._total_failed += 1
            
            logger.error(f"Batch job failed: job_id={job_id}, error={e}")
            
            raise
    
    def get_job_status(self, job_id: str) -> Dict[str, Any]:
        """Get batch job status.
        
        Retrieves the current status and metadata for a batch job.
        
        Args:
            job_id: Unique identifier of the batch job.
        
        Returns:
            Dictionary with:
            - job_id: Job identifier
            - status: Current BatchStatus value
            - items_count: Number of items in the batch
            - created_at: Creation timestamp
            - started_at: Processing start timestamp (None if not started)
            - completed_at: Completion timestamp (None if not completed)
            - error: Error message (None if no error)
            - results_count: Number of results (0 if not completed)
        
        Raises:
            ValidationError: If job_id is invalid or job not found.
        """
        # SENTINEL: Data Validation
        if not isinstance(job_id, str) or not job_id:
            raise ValidationError(
                "Batch Block: Get Job Status - job_id must be a non-empty string",
                component="BatchBlock",
                context={"job_id_type": type(job_id).__name__}
            )
        
        if job_id not in self._jobs:
            raise ValidationError(
                f"Batch Block: Get Job Status - Job not found: {job_id}",
                component="BatchBlock",
                context={"job_id": job_id, "available_jobs": list(self._jobs.keys())}
            )
        
        job = self._jobs[job_id]
        
        return {
            "job_id": job_id,
            "status": job.status.value,
            "items_count": len(job.items),
            "created_at": job.created_at,
            "started_at": job.started_at,
            "completed_at": job.completed_at,
            "error": job.error,
            "results_count": len(job.results) if job.results else 0
        }
    
    def get_health(self) -> BlockHealth:
        """Get block health status.
        
        Returns the health status of the BatchBlock based on initialization
        state, failure rates, and active job counts. Health is degraded if
        failure rate exceeds 10% or too many active jobs.
        
        Returns:
            BlockHealth object containing:
            - status: HealthStatus (HEALTHY, DEGRADED, or UNHEALTHY)
            - message: Human-readable status message
            - details: Dictionary with operational metrics (total_jobs, active_jobs,
                failed_jobs, total_processed, total_failed, batch_threshold, max_batch_size)
        """
        if not self._initialized:
            return BlockHealth(
                HealthStatus.UNHEALTHY,
                "Block not initialized",
                {}
            )
        
        # Calculate health metrics
        total_jobs = len(self._jobs)
        active_jobs = sum(1 for j in self._jobs.values() if j.status == BatchStatus.PROCESSING)
        failed_jobs = sum(1 for j in self._jobs.values() if j.status == BatchStatus.FAILED)
        
        # Health is degraded if failure rate is high
        failure_rate = failed_jobs / total_jobs if total_jobs > 0 else 0.0
        if failure_rate > 0.1:  # >10% failure rate
            status = HealthStatus.DEGRADED
            message = f"High failure rate: {failure_rate:.1%}"
        elif active_jobs > self._max_batch_size:
            status = HealthStatus.DEGRADED
            message = f"Too many active jobs: {active_jobs}"
        else:
            status = HealthStatus.HEALTHY
            message = "Batch processing operational"
        
        return BlockHealth(
            status,
            message,
            {
                "total_jobs": total_jobs,
                "active_jobs": active_jobs,
                "failed_jobs": failed_jobs,
                "total_processed": self._total_processed,
                "total_failed": self._total_failed,
                "batch_threshold": self._batch_threshold,
                "max_batch_size": self._max_batch_size
            }
        )
    
    def _detect_pii(self, items: List[Dict[str, Any]]) -> bool:
        """Detect PII in batch items.
        
        Scans batch items for PII patterns. This is a Sentinel compliance
        check for PII detection.
        
        Args:
            items: List of items to scan for PII.
        
        Returns:
            Boolean indicating if any PII was detected.
        """
        # SENTINEL: PII Detection
        items_str = str(items).lower()
        
        for pii_type, pattern in self.PII_PATTERNS.items():
            if re.search(pattern, items_str, re.IGNORECASE):
                logger.warning(f"PII detected in batch items: {pii_type}")
                return True
        
        return False
    
    def _audit_operation(self, operation: str, details: Dict[str, Any]) -> None:
        """Audit an operation for security and compliance.
        
        Creates an audit log entry for batch operations. This is a Sentinel
        compliance check for audit logging.
        
        Args:
            operation: Name of the operation (e.g., "create_batch_job", "process_batch").
            details: Dictionary with operation details.
        """
        # SENTINEL: Audit Logging
        logger.info(f"BatchBlock audit: operation={operation}, details={details}")

