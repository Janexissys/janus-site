# Proof Packet V2.1: MCCE Stability & Routing Validation

**Schema Version**: `2.1.0`  
**Purpose**: Forensic validation of "Gates are Prescriptive; Scores are Descriptive" doctrine  
**Test Type**: `[Smoke | Gold Standard]`  
**Timestamp**: `YYYY-MM-DDTHH:MM:SSZ`

---

## 1. Test Configuration

### 1.1 System Context
```yaml
system_prompt_hash: sha256:<hash>  # SHA-256 of the actual system prompt used
model_name: "gpt-4o"               # Or "claude-3-5-sonnet-20241022"
temperature: 0.0                   # Locked for determinism
n_runs: 50                         # Sample size
test_tier: "smoke"                 # "smoke" (quick) or "gold" (comprehensive)
```

### 1.2 Input Prompt
```
[Fixed input text that is used for all N runs]
```

### 1.3 Expected Behavior
- **Eligible**: `true` | `false`
- **MC Score Range**: `[min, max]`
- **Stop Gate (if ineligible)**: `"gate_name"` | `null`

---

## 2. Raw Results (N=50)

| Run | MC Score | Eligible | Stop Gate | Proximity Risk | Logic Error |
|-----|----------|----------|-----------|----------------|-------------|
| 1   | 8.45     | true     | null      | 0.05           | none        |
| 2   | 8.47     | true     | null      | 0.03           | none        |
| ... | ...      | ...      | ...       | ...            | ...         |
| 50  | 8.42     | true     | null      | 0.08           | none        |

**Proximity Risk**: Distance from nearest gate threshold (0.0 = at boundary, 1.0 = far from any gate).

---

## 3. Statistical Analysis

### 3.1 Score Stability
```yaml
mean_score: 8.45
std_dev: 0.12           # σ (Standard Deviation)
variance: 0.014         # σ²
min_score: 8.20
max_score: 8.65
range: 0.45
coefficient_of_variation: 1.42%  # (σ/μ) * 100
```

**Pass Criteria**: σ < 0.5 (Low variance = stable)

### 3.2 Eligibility Stability
```yaml
eligible_count: 48
ineligible_count: 2
flip_rate: 4.0%         # (flips / n_runs) * 100
flip_runs: [23, 47]     # Run numbers where eligibility flipped
```

**Pass Criteria**: Flip Rate < 5% (High consistency)

### 3.3 Proximity Risk Analysis
```yaml
mean_proximity: 0.05    # Average distance from nearest threshold
min_proximity: 0.01     # Closest to a boundary
risky_runs: 3           # Runs with proximity < 0.10
risky_run_ids: [5, 23, 47]
```

**Pass Criteria**: Mean Proximity > 0.10 (Safe margin from gates)

### 3.4 Gate Trace Consistency
```yaml
unique_traces: 1        # Number of distinct gate sequences
common_trace: "signal->execution_risk->education->knowledge->bias_bad->priority->ethos->drift->memory_short->memory_long->mental_state->bias_good"
trace_variance: 0       # Deviation from expected sequence
```

**Pass Criteria**: Unique Traces = 1 (Deterministic path)

---

## 4. Error Analysis

### 4.1 Logic Errors (Code-Level Failures)
```yaml
logic_error_count: 0
logic_error_runs: []
error_types: {}
```

**Logic Errors**: Code-level failures (e.g., missing bin, wrong threshold, NaN score).

### 4.2 Drift Errors (Score Stochasticity)
```yaml
drift_error_count: 2
drift_error_runs: [23, 47]
drift_details:
  - run: 23
    reason: "Eligibility flipped from true to false (score 8.08 vs mean 8.45)"
  - run: 47
    reason: "Eligibility flipped from true to false (score 8.09 vs mean 8.45)"
```

**Drift Errors**: Unexpected variance in LLM output despite fixed prompt/temp.

---

## 5. Doctrine Compliance

### 5.1 "Gates are Prescriptive"
```yaml
status: PASS | FAIL
evidence: "In 48/50 runs (96%), eligibility decision was deterministic based on gate passage."
violations: 2
violation_runs: [23, 47]
violation_reason: "Score variance near boundary (8.08, 8.09) caused flips."
```

### 5.2 "Scores are Descriptive"
```yaml
status: PASS | FAIL
evidence: "Raw MC scores preserved in all runs. No eligibility override corrupted the score."
score_preservation_rate: 100.0%
```

### 5.3 Routing Logic Integrity
```yaml
status: PASS | FAIL
expected_route: "ltm"  # Based on eligible=true, score >= 8.5
actual_route_consistency: 96.0%  # (48/50 routed to LTM)
misroutes: 2
misroute_runs: [23, 47]
misroute_reason: "Ineligible despite score >= 8.5 (gate failure)"
```

---

## 6. Test Tier: Smoke vs Gold

### 6.1 Smoke Test (Quick Validation)
- **N**: 10-20 runs
- **Purpose**: Catch gross failures (logic errors, crashes)
- **Pass Criteria**: Zero logic errors, σ < 1.0
- **Duration**: ~2 minutes

### 6.2 Gold Standard Test (Forensic Validation)
- **N**: 50-100 runs
- **Purpose**: Prove architectural stability
- **Pass Criteria**: σ < 0.5, Flip Rate < 5%, Mean Proximity > 0.10
- **Duration**: ~10 minutes

**This Report Type**: `[Smoke | Gold]`

---

## 7. Recommendations

### 7.1 If Test Passes (All Criteria Green)
- **Action**: Promote MCCE to LTMVault as "Validated Doctrine"
- **MC Score**: ≥ 9.0 (empirically proven)
- **Next Steps**: Deploy to production, monitor live metrics

### 7.2 If Test Fails (Any Criteria Red)
- **Root Cause Analysis Required**: See Section 4 for error breakdown
- **Potential Issues**:
  - **High σ**: LLM temperature not locked, prompt ambiguity
  - **High Flip Rate**: Threshold too close to score distribution
  - **Low Proximity**: Gates need tuning (widen safe zones)
  - **Logic Errors**: Code bugs in `ImprovementAnalyzer` or `MercuryAgent`

---

## 8. Audit Trail

```yaml
test_executed_by: "GitHub Copilot | Janus-AI | Human"
test_script: "greenfield/scripts/validate_mcce_stability.py"
git_commit: "<sha>"
system_prompt_hash_verified: true
temperature_locked: true
codebase_state: "V6.0 - Post MCCE Integration"
```

---

## 9. Sign-Off

**Pass/Fail**: `[PASS | FAIL]`  
**Confidence**: `[High | Medium | Low]`  
**Reviewer**: `_______________________`  
**Date**: `YYYY-MM-DD`

**Notes**: 
```
[Any additional context or caveats]
```

---

**End of Proof Packet V2.1**
