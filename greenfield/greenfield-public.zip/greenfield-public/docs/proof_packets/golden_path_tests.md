# Golden Path Tests - Proof Packet

**Type:** Acceptance Test Suite
**Status:** Active
**Last Verified:** 2026-01-03

## Invariant

The system MUST pass all 5 golden path tests before any release.

## Tests

### 1. Plan Phase
- **Input:** Raw task description
- **Expected:** Valid Plan Packet with MC-scored cards
- **Verify:** `make plan-test`

### 2. Apply Phase
- **Input:** Approved Plan Packet
- **Expected:** Executed cards with audit trail
- **Verify:** `make apply-test`

### 3. Idempotent Apply
- **Input:** Same Plan Packet applied twice
- **Expected:** No duplicate work, same final state
- **Verify:** `make idempotent-test`

### 4. Baseline Reject
- **Input:** Card below MC threshold (< 8.5)
- **Expected:** Rejected with improvement suggestions
- **Verify:** `make baseline-reject-test`

### 5. Fix Ritual
- **Input:** Failed apply with error trace
- **Expected:** Fix card generated, human approval required
- **Verify:** `make fix-test`

## Evidence

```bash
# Run all golden path tests
make golden-path

# Individual tests
make plan-test
make apply-test
make idempotent-test
make baseline-reject-test
make fix-test
```

## Boundary Conditions

- Plan with 0 cards → Error, not empty packet
- Apply without approval → Blocked
- MC score exactly 8.5 → Passes threshold
- Fix without human approval → Blocked indefinitely

## Failure Modes

1. **Silent pass on bad input:** Test framework masks failures
   - Mitigation: Assert explicit success conditions, not just "no errors"
2. **Flaky async timing:** Race conditions in apply
   - Mitigation: Deterministic test fixtures, no real LLM calls in tests

