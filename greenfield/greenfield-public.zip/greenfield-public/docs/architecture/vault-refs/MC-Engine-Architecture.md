# MC Engine Architecture - 12-Bin Framework with Score Separation

**Reference Card**: `CARD-V6B-P1-COMP-MC_ENGINE`  
**Created**: 2025-11-14  
**Status**: Active

---

## Overview

The MC Engine implements the complete 12-bin cognitive framework for Meta-Cognitive scoring. **CRITICAL ARCHITECTURE DECISION**: Must separate MC Gate Score (backend complexity/quality gate) from Confidence Score (user-facing alignment/certainty).

---

## Architecture

### 12-Bin Cognitive Framework

1. **Signal Processor** - Technical clarity assessment
2. **Short-term Memory Manager** - STM integration
3. **Mental State Tracker** - Team familiarity tracking
4. **Good Bias Detector** - Positive assumptions
5. **Bad Bias Detector** - Negative assumptions
6. **Long-term Memory Manager** - LTM integration
7. **Knowledge Applicator** - Existing patterns application
8. **Education Validator** - Documentation needs
9. **Priority Resolver** - Strategic alignment
10. **Ethos Aligner** - V6.0 vision alignment
11. **Drift Monitor** - Scope adherence
12. **Risk Assessor** - Rollback complexity

### Score Separation

**MC Gate Score** (Backend):
- Purpose: Complexity/quality gate for routing, memory promotion, quality gates
- Used by: Backend routing logic, memory promotion decisions, quality gate enforcement
- Scale: 0.0-10.0
- Thresholds: promote_threshold (0.85), tools_threshold (0.70), caretaker_threshold, quarantine_threshold

**Confidence Score** (User-Facing):
- Purpose: Alignment with goals, right answer, trust/transparency
- Used by: User display, frontend components, API responses
- Scale: 0.0-1.0 (normalized for display)
- Thresholds: high_confidence (0.85), medium_confidence (0.70), low_confidence (<0.70)

### Implementation Options

**Option 1**: Integrate DualCognitiveScoring features into MCEngine
- Pros: Leverages existing MCEngine infrastructure
- Cons: May introduce complexity

**Option 2**: Replace MCEngine with clean DualCognitiveScoring implementation
- Pros: Clean implementation, clear separation
- Cons: Requires migration

**Decision**: Single unified system - evaluate both options in greenfield, choose based on cleanest implementation.

---

## Data Flows

```
Content Input → MC Engine → 12-Bin Analysis
                ↓
         MC Gate Score (backend)
                ↓
    Backend Routing / Memory Promotion

         Confidence Score (user)
                ↓
         User Display / API
```

---

## Dependencies

- CognitiveBlock: LLM provider for cognitive analysis
- MemoryBlock: STM/LTM integration for memory bins
- North Star Integration: Alignment validation

---

## Sentinel Enforcement

- Score separation enforced 100% (zero misuse)
- Gate score never displayed to users
- Confidence score never used for backend routing
- Both scores validated independently

---

## Evidence

- `backend/janus/app/services/mc_engine.py` - Current MCEngine implementation
- `backend/janus/app/services/mc_system/core/mc_engine.py` - MC Engine core
- `backend/janus/vendor/core/cognitive_systems/dual_cognitive_scoring.py` - DualCognitiveScoring reference
- `backend/janus/app/core/quality_gates.py` - Quality gates integration

---

## Greenfield Considerations

- Must implement clean score separation
- No legacy/test repo imports
- Single unified system (integrate OR replace)
- Performance: 12-bin framework <100ms
- Accuracy: MC calculation ≥95%

---

**This document provides full context for MC Engine implementation. Cards reference this document via breadcrumb pointers.**

