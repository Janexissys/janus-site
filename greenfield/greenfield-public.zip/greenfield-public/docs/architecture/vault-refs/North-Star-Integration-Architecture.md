# North Star Integration Architecture - Soul and System Direction

**Reference Card**: `CARD-V6B-P1-COMP-NORTH_STAR`  
**Created**: 2025-11-14  
**Status**: Active

---

## Overview

North Star Integration provides the soul (non-negotiables) and system direction (Projects) for Janus OS. It enforces North Star Meta alignment and manages Projects (user goals) that provide practical expression of North Star alignment.

---

## Architecture

### North Star Meta (Soul/Non-Negotiables)
- **Purpose**: Blocking violations, hard rules, truth alignment
- **Components**:
  - Ingest policy specification
  - Hard rules enforcement
  - Truth alignment validation
- **Enforcement**: Caretaker Agent + IngestProcessingTask (canonical NS gate)

### Projects (User Goals) - CRITICAL SYSTEM DIRECTION COMPONENT
- **Purpose**: System direction, context enrichment, alignment scoring
- **Architecture**:
  - Max 3 active: 1 primary + 2 secondary
  - Alignment validation: alignment_score ≥ 0.7 required
  - Project context enrichment for all agents
  - Clarification triggers (MC < 7.0)
  - WIP limits: 5 cards primary, 3 cards secondary
- **Role**: Bridge between North Star soul and practical system direction

---

## Data Flows

```
North Star Meta → Policy Enforcement → Agents
Projects → Context Enrichment → Agents
Projects → Alignment Validation → North Star Meta
```

---

## Dependencies

- None (foundational system)
- All agents consume North Star + project metadata
- IngestBlock uses North Star ingest policy

---

## Sentinel Enforcement

- Policy enforcement security
- Project alignment validation (≥0.7 threshold)
- Ingest policy compliance
- Project switching security (primary changes require review)
- Access control on North Star meta

---

## Evidence

- `backend/janus/app/core/north_star_projects_service.py` - North Star and Projects service
- `backend/janus/app/core/north_star_meta.py` - North Star meta implementation
- `vaults/north_star/PROJECTS_CONTRACT.yaml` - Projects contract
- `config/north_star_meta.yaml` - North Star meta configuration

---

## Greenfield Considerations

- Clean North Star Meta implementation
- Robust Projects system
- Alignment validation (≥0.7)
- Project context enrichment
- Policy enforcement

---

**This document provides full context for North Star Integration implementation. Cards reference this document via breadcrumb pointers.**

