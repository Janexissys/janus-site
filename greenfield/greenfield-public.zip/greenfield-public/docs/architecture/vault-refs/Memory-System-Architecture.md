# Memory System Architecture - STM/LTM Coordination

**Reference Card**: `CARD-V6B-P1-LEGO-MEMORY`  
**Created**: 2025-11-14  
**Status**: Active

---

## Overview

MemoryBlock coordinates STM (Short-Term Memory) and LTM (Long-Term Memory) systems, providing unified memory services for the Janus OS. It manages memory promotion, retrieval, and coordination between STMVault and LTMVault.

---

## Architecture

### STM (Short-Term Memory)
- **Storage**: STMVault (curated design truth, card context, architecture notes)
- **Purpose**: Ephemeral memory for recent operations
- **Retention**: Temporary, promoted to LTM based on MC score
- **Access**: Fast access for recent context

### LTM (Long-Term Memory)
- **Storage**: LTMVault (runtime memory, historical logs, vector store)
- **Purpose**: Persistent memory for long-term knowledge
- **Retention**: Permanent storage, indexed in vector database
- **Access**: Vector search for semantic retrieval

### Memory Promotion
- **Criteria**: MC Gate Score ≥ threshold (typically 0.80)
- **Process**: STM → LTM promotion with vector indexing
- **Enforcement**: Caretaker Agent gate (single-writer enforcement)

---

## Data Flows

```
Ingest → MemoryBlock → STM (temporary)
                ↓
         MC Gate Score Check
                ↓
         Promotion Decision
                ↓
         LTM (persistent) → Vector Index
```

---

## Dependencies

- VaultBlock: Foundational storage for STMVault/LTMVault
- VectorDatabaseBlock: Vector indexing for LTM
- MC Engine: MC Gate Score for promotion decisions
- Caretaker Agent: Single-writer enforcement

---

## Sentinel Enforcement

**CRITICAL**: PII in memory storage

- PII detection before all memory writes
- Access control on all memory reads
- Data retention policies enforced
- Encryption at rest for sensitive data
- Audit logging for all memory access

---

## Evidence

- `backend/janus/app/lego_registry/blocks/memory.py` - MemoryBlock implementation
- `docs/Diagrams/Memory.mmd` - Memory architecture diagram
- `backend/janus/app/models/memory_database.py` - Memory database models

---

## Greenfield Considerations

- Clean STM/LTM separation
- Robust memory promotion logic
- Comprehensive PII detection
- Vector indexing integration
- Health monitoring

---

**This document provides full context for Memory System implementation. Cards reference this document via breadcrumb pointers.**

