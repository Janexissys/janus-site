<!-- b536b659-dcac-4bca-958d-1fab2e424be9 800e9154-9a2c-4ffb-83d1-c07b281fcbd9 -->
# Greenfield v6.0 – Complete Flight Plan with MC Separation

## Mission

**What:** Use these 29 cards as the *only* contract for a greenfield Janus v6.0 build.

**Why:** Test the principle that "good cards + MC + Sentinels + Vault" let an AI out-build you on implementation, while you keep trajectory.

**Confidence:** 0.95

**Core Principle:** You are not proving you can out-code a model. You are proving you can design a **game board** where any competent model is forced to play in human-quality structure and ethics.

---

## Prerequisites (Before Starting)

### Clear tasks.yaml for Clean Start

**What**: Archive/clear existing tasks from `tasks.yaml` to have a clean tasks field for the 29 greenfield cards.

**Action**:

- Archive current tasks.yaml to `tasks.yaml.archive.{timestamp}`
- Keep YAML structure (version, project, status_map, priority_label_map, fields)
- Clear the `tasks:` array to empty: `tasks: []`
- This ensures clean field for the 29 greenfield cards

**Why**: Prevents confusion and ensures only the 29 greenfield cards exist in tasks.yaml during the test.

**Confidence**: 0.95

---

## Memory Naming – v6.0 Standard

**STM = old QVault role**

- Name: STMVault / STM Memory System
- Function: curated design truth, card context, architecture notes, breadcrumbs
- Used by: LEGO cards, MC engine, North Star alignment

**LTM = old PVault role**

- Name: LTMVault / LTM Memory System
- Function: runtime memory, historical logs, vector store, long-tail recall
- Used by: Mercury, LearningBlock, VectorDatabaseBlock, telemetry history

**Banned Terms:**

- Do not use: QVault, PVault, Q, P in new docs, cards, or comments
- If found in legacy docs: treat as:
- QVault → STMVault
- PVault → LTMVault

---

## Critical Architecture Decision: MC Separation

### The Problem

MC is currently doing two jobs:

1. **MC Gate Score** = complexity/quality gate (backend routing, memory promotion)
2. **Confidence Score** = user-facing certainty (alignment with goals, right answer)

**Issue**: Lower MC (low complexity) = good for system, but appears as "not confident" to users.

### The Solution

**MC Engine (#21) must separate:**

- **MC Gate Score** (backend): Complexity/quality gate for routing, memory promotion, quality gates
- **Confidence Score** (user-facing): Alignment with goals, right answer, trust/transparency

**Architecture Decision**: Single unified system - either:

- Integrate DualCognitiveScoring features into MCEngine, OR
- Replace MCEngine with clean DualCognitiveScoring implementation

**No Legacy Mess**: Greenfield must be clean - no importing deprecated/test repo code. Either integrate features OR replace with clean implementation.

**Sentinel**: MC score misuse (gate score displayed as confidence, or vice versa)

---

## Directional Rules

### 1. Cards Are Law, Code Is Detail

**What:** For all 29 cards (LEGO, Agent, Core System):

- Card defines purpose, dependencies, Sentinel, MC target, and boundaries
- Implementation is free as long as it obeys the card

**Why:** You are testing cognitive architecture, not line-by-line style.

**Confidence:** 0.9

---

### 2. Vault Is Spine, Cards Are Nerves

**What:**

- STMVault holds **context documents**
- Cards hold **pointers and summaries**, never full duplication
- Each card must include breadcrumb links into STMVault for deeper context

**Why:** Proves the STMVault pattern and keeps the LEGO deck light but anchored.

**Confidence:** 0.9

---

### 3. MC and Sentinel Are Non-Negotiable

**What:** For each card:

- Provide simulated 12-bin MC snapshot
- Implement Sentinel rule in a way that is testable (PII, auth, policy, etc.)
- Aim to *match or exceed* the listed MC score

**Why:** This is not just a build test; it is a drift and safety test.

**Confidence:** 0.9

---

### 4. Dependency Ladder Is the Build Order

**What:** Phase 2 build must follow LEGO dependency order:

1. Foundation blocks (no dependencies)
2. Second layer (depends on foundation)
3. Third layer (depends on memory)
4. Top layer (multi-dependency components)

**Why:** If you cannot build in this order, the architecture is lying about modularity.

**Confidence:** 0.9

---

### 5. AI Builds, You Guard North Star

**What:**

- AI chooses patterns, libraries, and internal wiring per block
- You intervene only when a card, Sentinel, or North Star rule is violated

**Why:** The test is whether your **structures** can steer a stronger coder.

**Confidence:** 0.9

---

### 6. Comparison Focus = Behaviour, Not Style

**What:** In Phase 3 comparison, compare v6 vs greenfield on:

- Same inputs → same or better outputs
- Sentinel behaviour (PII, auth, ingest, handoff)
- MC scores and drift handling per block

**Why:** You care about cognitive and safety behaviour, not aesthetics.

**Confidence:** 0.9

---

### 7. Hardening Follows Risk, Not Ego

**What:** Phase 4 cleanup plan:

- Rank blocks by MC gap and Sentinel severity
- Fix Sentinel-critical blocks first (Vault, Memory, Ingest, Assembly Line, API)
- Apply North Star corrections before refactors or elegance

**Why:** This keeps you out of perfectionism loops and on risk reduction.

**Confidence:** 0.9

---

### 8. Behaviour Rules During Test

**What:**

- No new cards. Only these 29.
- No silent changes to a card. Any change must log a one-line "why".
- Every modification justified as: "This improves X by Y for the system."
- **No legacy/test repo imports**: Greenfield must be clean. Either integrate features into current system OR replace with clean implementation.

**Why:** You are testing whether Janus can *hold* a direction under pressure. Clean greenfield, not bringing mess from test repo.

**Confidence:** 0.9

---

### 9. Immediate High-Leverage Next Step

**What:** Create `CARD-V6B-P1-LEGO-INDEX` in STMVault with:

- List of all 29 card IDs and types
- This rule set summarised in one screen
- Note: "Greenfield Reference Implementation – v6.0 test of LEGO architecture."

**Why:** That card becomes the anchor you and any AI must obey during the entire greenfield experiment.

**Confidence:** 0.95

---

## The 29 Cards (Locked Scope)

### LEGO Blocks (13 cards)

1. MemoryBlock - `CARD-V6B-P1-LEGO-MEMORY` (MC: 8.70, Deps: VaultBlock)
2. VaultBlock - `CARD-V6B-P1-LEGO-VAULT` (MC: 8.65, Deps: None)
3. IngestBlock - `CARD-V6B-P1-LEGO-INGEST` (MC: 8.60, Deps: None)
4. BatchBlock - `CARD-V6B-P1-LEGO-BATCH` (MC: 8.55, Deps: None)
5. AssemblyLineBlock - `CARD-V6B-P1-LEGO-ASSEMBLY_LINE` (MC: 8.60, Deps: AgentBlock, MemoryBlock, CognitiveBlock)
6. AgentBlock - `CARD-V6B-P1-LEGO-AGENT` (MC: 8.55, Deps: None)
7. TelemetryBlockAdapter - `CARD-V6B-P1-LEGO-TELEMETRY` (MC: 8.50, Deps: None)
8. CognitiveBlockAdapter - `CARD-V6B-P1-LEGO-COGNITIVE` (MC: 8.65, Deps: None)
9. LearningBlockAdapter - `CARD-V6B-P1-LEGO-LEARNING` (MC: 8.55, Deps: MemoryBlock)
10. ActionsBlockAdapter - `CARD-V6B-P1-LEGO-ACTIONS` (MC: 8.50, Deps: None)
11. ActionWebhookBlockAdapter - `CARD-V6B-P1-LEGO-ACTION_WEBHOOK` (MC: 8.50, Deps: None)
12. RmdBlockAdapter - `CARD-V6B-P1-LEGO-RMD` (MC: 8.45, Deps: None)

  - **Purpose**: Markdown with YAML headers for AI speed of read (simple formatter)
  - **Note**: MC 8.45 is correct - low complexity formatter, not a gate

13. VectorDatabaseBlock - `CARD-V6B-P1-LEGO-VECTOR_DB` (MC: 8.60, Deps: None)

### Agent Crew (6 cards)

14. Caretaker Agent - `CARD-V6B-P1-AGENT-CARETAKER` (MC: 8.65)
15. Gardener Agent - `CARD-V6B-P1-AGENT-GARDENER` (MC: 8.60)
16. Mercury Agent - `CARD-V6B-P1-AGENT-MERCURY` (MC: 8.55)
17. Sentinel Agent - `CARD-V6B-P1-AGENT-SENTINEL` (MC: 8.70)
18. Conductor Agent - `CARD-V6B-P1-AGENT-CONDUCTOR` (MC: 8.50)
19. Scribe Agent - `CARD-V6B-P1-AGENT-SCRIBE` (MC: 8.55)

### Core Systems (10 cards)

20. Assembly Line Processor - `CARD-V6B-P1-COMP-ASSEMBLY_LINE` (MC: 8.60)
21. MC Engine & 12-Bin System - `CARD-V6B-P1-COMP-MC_ENGINE` (MC: 8.70)

  - **Critical Requirement**: Must separate MC Gate Score from Confidence Score
  - **MC Gate Score** = complexity/quality gate (backend routing, memory promotion, quality gates)
  - **Confidence Score** = user-facing certainty (alignment with goals, right answer, trust)
  - **Architecture Decision**: Single unified system - either:
  - Integrate DualCognitiveScoring features into MCEngine, OR
  - Replace MCEngine with clean DualCognitiveScoring implementation
  - **No Legacy Mess**: Greenfield must be clean - no importing deprecated/test repo code
  - **User Experience**: Lower MC (low complexity) should NOT appear as "not confident" to users
  - **Sentinel**: MC score misuse (gate score displayed as confidence, or vice versa)

22. Memory System (STM/LTM) - `CARD-V6B-P1-COMP-MEMORY_SYSTEM` (MC: 8.65)
23. Vault System - `CARD-V6B-P1-COMP-VAULT_SYSTEM` (MC: 8.60)
24. Telemetry & Metrics - `CARD-V6B-P1-COMP-TELEMETRY` (MC: 8.50)
25. North Star Integration - `CARD-V6B-P1-COMP-NORTH_STAR` (MC: 8.80)

  - **Components**: 
  - North Star Meta (soul/non-negotiables) - blocking violations, hard rules, truth alignment
  - **Projects** (user goals) - **CRITICAL SYSTEM DIRECTION COMPONENT**
  - **Projects Architecture**:
  - Projects = User Goals (System Tuning) - practical expression of North Star alignment
  - Max 3 active: 1 primary + 2 secondary
  - Alignment validation: alignment_score ≥ 0.7 required
  - Project context enrichment for all agents
  - Clarification triggers (MC < 7.0)
  - WIP limits: 5 cards primary, 3 cards secondary
  - **Purpose**: 
  - North Star = blocking violations, truth alignment enforcement
  - **Projects = system direction** - they provide the practical expression of user goals that align with North Star soul
  - Projects guide agent decisions, context enrichment, and priority allocation

26. Task & Card System - `CARD-V6B-P1-COMP-TASK_CARD_SYSTEM` (MC: 8.55)
27. Frontend Components - `CARD-V6B-P1-COMP-FRONTEND` (MC: 8.50)
28. API Layer - `CARD-V6B-P1-COMP-API` (MC: 8.55)
29. LEGO Registry - `CARD-V6B-P1-COMP-LEGO_REGISTRY` (MC: 8.70)

---

## Phase 1: Narrative Documentation (Weeks 1-2)

**Principle**: Narrative, not perfection. Define soul and edges.

**Per Card (29 total)**:

- 12-bin MC snapshot (simulated acceptable)
- Sentinel policy (explicit, testable)
- Boundaries and data flows
- North Star tie-in (and Project alignment if applicable)
- Dependencies (LEGO dependency graph)
- Evidence citations
- **STMVault context documents** (full context, breadcrumb pointers from cards)

**Card Structure**:

- Cards hold **pointers and summaries**, never full duplication
- Each card must include breadcrumb links into STMVault for deeper context
- STMVault holds **context documents**

**Non-Negotiables**:

- MC Target: Match or beat listed score
- Sentinel: Explicitly implemented and testable
- Isolation: Buildable/testable independently
- Dependencies: Only listed dependencies allowed

**Ethos Guardrails**:

- No new features
- No card definition changes mid-build without logging why
- Every change justified: "This change improves X by Y"
- **No legacy/test repo imports**: Clean greenfield only

**Critical Architecture Decisions**:

- **MC Engine (#21)**: Must separate MC Gate Score (backend complexity gate) from Confidence Score (user-facing alignment). Single unified system - integrate DualCognitiveScoring features OR replace with clean implementation. No legacy/test repo code.
- **Card #25**: Must explicitly document Projects as critical system direction component.

---

## Phase 2: Greenfield Build by Dependency Order (Weeks 3-6)

**Principle**: Build by dependency order ONLY. If you cannot build in this order, architecture is lying.

**Strategy**: **Blocker-First Approach** - Focus on critical path blockers first, then fill in remaining blocks. For large projects, better to plan the main spine then break each card into its own implementation session.

**Installation Location**: Create `greenfield/` directory at repo root, parallel to `backend/` and `frontend/`

**Directory Structure**:
```
greenfield/
├── backend/          # Greenfield backend implementation
├── frontend/        # Greenfield frontend implementation (if applicable)
├── tests/           # Greenfield-specific tests
└── README.md        # Greenfield build notes and metrics
```

**Critical Path Blockers** (Must build first):
1. ✅ VaultBlock - Foundation storage (COMPLETED)
2. ✅ CognitiveBlock - LLM provider (COMPLETED)
3. ✅ AgentBlock - Agent management (COMPLETED)
4. ✅ MemoryBlock - STM/LTM coordination (COMPLETED, depends on VaultBlock)
5. ✅ AssemblyLineBlock - Pipeline orchestration (COMPLETED, all dependencies ready ✅)

**Workflow Notes**: See `greenfield/WORKFLOW_NOTES.md` for implementation patterns and insights.

**Build Order** (LEGO dependency ladder):

1. Foundation: VaultBlock, CognitiveBlock, TelemetryBlock, AgentBlock, ActionsBlock, ActionWebhookBlock, RmdBlock, VectorDatabaseBlock, IngestBlock, BatchBlock
2. Second Layer: MemoryBlock (depends on VaultBlock)
3. Memory-Dependent: LearningBlock (depends on MemoryBlock)
4. Multi-Dependency: AssemblyLineBlock (depends on AgentBlock, MemoryBlock, CognitiveBlock)

**AI Implementation Rules**:

- AI chooses patterns, libraries, wiring inside each block
- AI honors card constraints
- Human guards North Star alignment only
- Human intervenes only when card, Sentinel, or North Star rule is violated

**Metrics per Block**:

- Build time
- Code complexity
- Test coverage
- MC score achievement
- Sentinel compliance

**MC Engine Implementation**:

- Must implement MC Gate Score and Confidence Score separation
- Single unified system (integrate OR replace, no legacy imports)
- Gate score for backend routing/memory promotion
- Confidence score for user-facing display

---

## Phase 3: Behavioral Comparison (Week 7)

**Principle**: Compare behavior, not line-by-line code. Validate cognitive architecture.

**Compare**:

- Same inputs → same or better outputs?
- Same Sentinel behavior? (PII, auth, ingest, handoff)
- Similar or better MC scores and drift behavior?
- Dependency graph sanity
- **MC separation**: Gate score used for backend, confidence score for user-facing

**Do NOT Compare**:

- Line-by-line code differences
- Implementation patterns (unless they affect behavior)
- Library choices (unless they affect outcomes)
- Code aesthetics or style

---

## Phase 4: Hardening Follows Risk, Not Ego (Week 8)

**Principle**: Fix highest-risk first. "Move the needle" not "make it pretty."

**Prioritization**:

1. Rank by MC gap and Sentinel severity
2. Fix Sentinel-critical blocks first: Vault, Memory, Ingest, Assembly Line, API
3. Apply North Star corrections before refactors or elegance
4. Then address elegance or tech-debt polish

**Success Metric**: Blocks move toward MC target and pass Sentinel checks, not code prettiness.

---

## Success Criteria

**You are not proving you can out-code a model. You are proving you can design a **game board** where any competent model is forced to play in human-quality structure and ethics.**

- Prerequisite: tasks.yaml cleared and archived
- All 29 cards created with MC scores ≥8.5
- Greenfield built following dependency order
- Behavioral equivalence validated
- Sentinel checks pass
- **MC separation validated**: Gate score for backend, confidence score for user-facing
- North Star alignment maintained throughout (including Projects as system direction)
- No scope creep, no feature additions
- Every change logged and justified
- STMVault context documents created (not QVault)
- Memory naming follows v6.0 standard (STM/LTM, not Q/P)
- **No legacy/test repo imports**: Clean greenfield implementation

