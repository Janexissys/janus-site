# Greenfield Traceability Matrix

Generated from `scripts/generate_traceability.py`. Maps the **29 locked-scope cards** from
`cards/p1/CARD-V6B-P1-LEGO-INDEX.md` to narrative, reference implementation, canonical live code, tests, and phase proof.

**Reference impl** = snapshot under `greenfield/backend/` (git restore c06c586).  
**Canonical impl** = live code under repo `backend/` (source of truth for runtime).

| Card ID | Narrative card | Reference impl | Canonical impl | Unit test | Phase proof |
|---------|----------------|----------------|----------------|-----------|-------------|
| CARD-V6B-P1-LEGO-MEMORY | `cards/p1/CARD-V6B-P1-LEGO-MEMORY.md` | `backend/blocks/memory_block.py` | `backend/blocks/memory_block.py` | `—` | `docs/status/PHASE2_COMPLETE.md; tests/results/phase3_comparison_report.json` |
| CARD-V6B-P1-LEGO-VAULT | `cards/p1/CARD-V6B-P1-LEGO-VAULT.md` | `backend/blocks/vault_block.py` | `backend/blocks/vault_block.py` | `tests/test_vault_block.py` | `docs/status/PHASE2_COMPLETE.md; tests/results/phase3_comparison_report.json` |
| CARD-V6B-P1-LEGO-INGEST | `cards/p1/CARD-V6B-P1-LEGO-INGEST.md` | `backend/blocks/ingest_block.py` | `backend/blocks/ingest_block.py` | `—` | `docs/status/PHASE2_COMPLETE.md; tests/results/phase3_comparison_report.json` |
| CARD-V6B-P1-LEGO-BATCH | `cards/p1/CARD-V6B-P1-LEGO-BATCH.md` | `backend/blocks/batch_block.py` | `backend/blocks/batch_block.py` | `tests/test_batch_block.py` | `docs/status/PHASE2_COMPLETE.md; tests/results/phase3_comparison_report.json` |
| CARD-V6B-P1-LEGO-ASSEMBLY_LINE | `cards/p1/CARD-V6B-P1-LEGO-ASSEMBLY_LINE.md` | `backend/blocks/assembly_line_block.py` | `backend/blocks/assembly_line_block.py` | `—` | `docs/status/PHASE2_COMPLETE.md; tests/results/phase3_comparison_report.json` |
| CARD-V6B-P1-LEGO-AGENT | `cards/p1/CARD-V6B-P1-LEGO-AGENT.md` | `backend/blocks/agent_block.py` | `backend/blocks/agent_block.py` | `—` | `docs/status/PHASE2_COMPLETE.md; tests/results/phase3_comparison_report.json` |
| CARD-V6B-P1-LEGO-TELEMETRY | `cards/p1/CARD-V6B-P1-LEGO-TELEMETRY.md` | `backend/blocks/telemetry_block.py` | `backend/blocks/telemetry_block.py` | `—` | `docs/status/PHASE2_COMPLETE.md; tests/results/phase3_comparison_report.json` |
| CARD-V6B-P1-LEGO-COGNITIVE | `cards/p1/CARD-V6B-P1-LEGO-COGNITIVE.md` | `backend/blocks/cognitive_block.py` | `backend/blocks/cognitive_block.py` | `—` | `docs/status/PHASE2_COMPLETE.md; tests/results/phase3_comparison_report.json` |
| CARD-V6B-P1-LEGO-LEARNING | `cards/p1/CARD-V6B-P1-LEGO-LEARNING.md` | `backend/blocks/learning_block.py` | `backend/blocks/learning_block.py` | `—` | `docs/status/PHASE2_COMPLETE.md; tests/results/phase3_comparison_report.json` |
| CARD-V6B-P1-LEGO-ACTIONS | `cards/p1/CARD-V6B-P1-LEGO-ACTIONS.md` | `backend/blocks/actions_block.py` | `backend/blocks/actions_block.py` | `tests/test_actions_block.py` | `docs/status/PHASE2_COMPLETE.md; tests/results/phase3_comparison_report.json` |
| CARD-V6B-P1-LEGO-ACTION_WEBHOOK | `cards/p1/CARD-V6B-P1-LEGO-ACTION_WEBHOOK.md` | `backend/blocks/action_webhook_block.py` | `backend/blocks/action_webhook_block.py` | `tests/test_action_webhook_block.py` | `docs/status/PHASE2_COMPLETE.md; tests/results/phase3_comparison_report.json` |
| CARD-V6B-P1-LEGO-RMD | `cards/p1/CARD-V6B-P1-LEGO-RMD.md` | `backend/blocks/rmd_block.py` | `backend/blocks/rmd_block.py` | `tests/test_rmd_block.py` | `docs/status/PHASE2_COMPLETE.md; tests/results/phase3_comparison_report.json` |
| CARD-V6B-P1-LEGO-VECTOR_DB | `cards/p1/CARD-V6B-P1-LEGO-VECTOR_DB.md` | `backend/blocks/vector_database_block.py` | `backend/blocks/vector_database_block.py` | `—` | `docs/status/PHASE2_COMPLETE.md; tests/results/phase3_comparison_report.json` |
| CARD-V6B-P1-AGENT-CARETAKER | `cards/p1/CARD-V6B-P1-AGENT-CARETAKER.md` | `backend/agents/caretaker_agent.py` | `backend/agents/caretaker_agent.py` | `—` | `docs/status/PHASE2_COMPLETE.md; tests/results/phase3_comparison_report.json` |
| CARD-V6B-P1-AGENT-GARDENER | `cards/p1/CARD-V6B-P1-AGENT-GARDENER.md` | `backend/agents/gardener_agent.py` | `backend/agents/gardener_agent.py` | `—` | `docs/status/PHASE2_COMPLETE.md; tests/results/phase3_comparison_report.json` |
| CARD-V6B-P1-AGENT-MERCURY | `cards/p1/CARD-V6B-P1-AGENT-MERCURY.md` | `backend/agents/mercury_agent.py` | `backend/agents/mercury_agent.py` | `—` | `docs/status/PHASE2_COMPLETE.md; tests/results/phase3_comparison_report.json` |
| CARD-V6B-P1-AGENT-SENTINEL | `cards/p1/CARD-V6B-P1-AGENT-SENTINEL.md` | `backend/agents/sentinel_agent.py` | `backend/agents/sentinel_agent.py` | `—` | `docs/status/PHASE2_COMPLETE.md; tests/results/phase3_comparison_report.json` |
| CARD-V6B-P1-AGENT-CONDUCTOR | `cards/p1/CARD-V6B-P1-AGENT-CONDUCTOR.md` | `backend/agents/conductor_agent.py` | `backend/agents/conductor_agent.py` | `—` | `docs/status/PHASE2_COMPLETE.md; tests/results/phase3_comparison_report.json` |
| CARD-V6B-P1-AGENT-SCRIBE | `cards/p1/CARD-V6B-P1-AGENT-SCRIBE.md` | `backend/agents/scribe_agent.py` | `backend/agents/scribe_agent.py` | `—` | `docs/status/PHASE2_COMPLETE.md; tests/results/phase3_comparison_report.json` |
| CARD-V6B-P1-COMP-ASSEMBLY_LINE | `cards/p1/CARD-V6B-P1-COMP-ASSEMBLY_LINE.md` | `backend/systems/assembly_line_processor.py` | `backend/systems/assembly_line_processor.py` | `—` | `docs/status/PHASE2_COMPLETE.md; tests/results/phase3_comparison_report.json` |
| CARD-V6B-P1-COMP-MC_ENGINE | `cards/p1/CARD-V6B-P1-COMP-MC_ENGINE.md` | `backend/systems/mc_engine.py` | `backend/systems/mc_engine.py` | `—` | `docs/status/PHASE2_COMPLETE.md; tests/results/phase3_comparison_report.json` |
| CARD-V6B-P1-COMP-MEMORY_SYSTEM | `cards/p1/CARD-V6B-P1-COMP-MEMORY_SYSTEM.md` | `backend/systems/memory_system.py` | `backend/systems/memory_system.py` | `—` | `docs/status/PHASE2_COMPLETE.md; tests/results/phase3_comparison_report.json` |
| CARD-V6B-P1-COMP-VAULT_SYSTEM | `cards/p1/CARD-V6B-P1-COMP-VAULT_SYSTEM.md` | `backend/systems/vault_system.py` | `backend/systems/vault_system.py` | `—` | `docs/status/PHASE2_COMPLETE.md; tests/results/phase3_comparison_report.json` |
| CARD-V6B-P1-COMP-TELEMETRY | `cards/p1/CARD-V6B-P1-COMP-TELEMETRY.md` | `backend/systems/telemetry_system.py` | `backend/systems/_archive/telemetry_system.py` | `tests/test_telemetry_system.py` | `docs/status/PHASE2_COMPLETE.md; tests/results/phase3_comparison_report.json` |
| CARD-V6B-P1-COMP-NORTH_STAR | `cards/p1/CARD-V6B-P1-COMP-NORTH_STAR.md` | `backend/systems/north_star.py` | `backend/systems/north_star.py` | `—` | `docs/status/PHASE2_COMPLETE.md; tests/results/phase3_comparison_report.json` |
| CARD-V6B-P1-COMP-TASK_CARD_SYSTEM | `cards/p1/CARD-V6B-P1-COMP-TASK_CARD_SYSTEM.md` | `backend/systems/task_card_system.py` | `backend/systems/task_card_system.py` | `tests/test_task_card_system.py` | `docs/status/PHASE2_COMPLETE.md; tests/results/phase3_comparison_report.json` |
| CARD-V6B-P1-COMP-FRONTEND | `cards/p1/CARD-V6B-P1-COMP-FRONTEND.md` | `backend/systems/frontend_components.py` | `backend/systems/_archive/frontend_components.py` | `tests/test_frontend_components.py` | `docs/status/PHASE2_COMPLETE.md; tests/results/phase3_comparison_report.json` |
| CARD-V6B-P1-COMP-API | `cards/p1/CARD-V6B-P1-COMP-API.md` | `backend/systems/api_layer.py` | `backend/systems/_archive/api_layer.py` | `tests/test_api_layer.py` | `docs/status/PHASE2_COMPLETE.md; tests/results/phase3_comparison_report.json` |
| CARD-V6B-P1-COMP-LEGO_REGISTRY | `cards/p1/CARD-V6B-P1-COMP-LEGO_REGISTRY.md` | `—` | `—` | `tests/test_lego_registry.py` | `docs/status/PHASE2_COMPLETE.md; tests/results/phase3_comparison_report.json` |
