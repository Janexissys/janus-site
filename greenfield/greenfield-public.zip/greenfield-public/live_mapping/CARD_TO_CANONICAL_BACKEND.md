# Card ID → Canonical Backend Path

Live runtime code lives outside `greenfield/`. This map is for thesis metrics only.

| Card ID | Canonical path |
|---------|----------------|
| `CARD-V6B-P1-LEGO-MEMORY` | `backend/blocks/memory_block.py` |
| `CARD-V6B-P1-LEGO-VAULT` | `backend/blocks/vault_block.py` |
| `CARD-V6B-P1-LEGO-INGEST` | `backend/blocks/ingest_block.py` |
| `CARD-V6B-P1-LEGO-BATCH` | `backend/blocks/batch_block.py` |
| `CARD-V6B-P1-LEGO-ASSEMBLY_LINE` | `backend/blocks/assembly_line_block.py` |
| `CARD-V6B-P1-LEGO-AGENT` | `backend/blocks/agent_block.py` |
| `CARD-V6B-P1-LEGO-TELEMETRY` | `backend/blocks/telemetry_block.py` |
| `CARD-V6B-P1-LEGO-COGNITIVE` | `backend/blocks/cognitive_block.py` |
| `CARD-V6B-P1-LEGO-LEARNING` | `backend/blocks/learning_block.py` |
| `CARD-V6B-P1-LEGO-ACTIONS` | `backend/blocks/actions_block.py` |
| `CARD-V6B-P1-LEGO-ACTION_WEBHOOK` | `backend/blocks/action_webhook_block.py` |
| `CARD-V6B-P1-LEGO-RMD` | `backend/blocks/rmd_block.py` |
| `CARD-V6B-P1-LEGO-VECTOR_DB` | `backend/blocks/vector_database_block.py` |
| `CARD-V6B-P1-AGENT-CARETAKER` | `backend/agents/caretaker_agent.py` |
| `CARD-V6B-P1-AGENT-GARDENER` | `backend/agents/gardener_agent.py` |
| `CARD-V6B-P1-AGENT-MERCURY` | `backend/agents/mercury_agent.py` |
| `CARD-V6B-P1-AGENT-SENTINEL` | `backend/agents/sentinel_agent.py` |
| `CARD-V6B-P1-AGENT-CONDUCTOR` | `backend/agents/conductor_agent.py` |
| `CARD-V6B-P1-AGENT-SCRIBE` | `backend/agents/scribe_agent.py` |
| `CARD-V6B-P1-COMP-ASSEMBLY_LINE` | `backend/systems/assembly_line_processor.py` |
| `CARD-V6B-P1-COMP-MC_ENGINE` | `backend/systems/mc_engine.py` |
| `CARD-V6B-P1-COMP-MEMORY_SYSTEM` | `backend/systems/memory_system.py` |
| `CARD-V6B-P1-COMP-VAULT_SYSTEM` | `backend/systems/vault_system.py` |
| `CARD-V6B-P1-COMP-TELEMETRY` | `backend/systems/_archive/telemetry_system.py` |
| `CARD-V6B-P1-COMP-NORTH_STAR` | `backend/systems/north_star.py` |
| `CARD-V6B-P1-COMP-TASK_CARD_SYSTEM` | `backend/systems/task_card_system.py` |
| `CARD-V6B-P1-COMP-FRONTEND` | `backend/systems/_archive/frontend_components.py` |
| `CARD-V6B-P1-COMP-API` | `backend/systems/_archive/api_layer.py` |
| `CARD-V6B-P1-COMP-LEGO_REGISTRY` | `—` |
