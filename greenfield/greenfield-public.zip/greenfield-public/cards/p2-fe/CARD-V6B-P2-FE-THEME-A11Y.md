# CARD-V6B-P2-FE-THEME-A11Y

**Card ID**: `CARD-V6B-P2-FE-THEME-A11Y`  
**Type**: System  
**MC Score**: 8.30  
**MC Target**: 8.30  
**Status**: Active  
**Created**: 2025-01-27  
**North Star Link**: `NORTH-STAR-V6`

---

## Summary

Applies the agreed visual theme (grayscale baseline, severity as only colour) and basic accessibility requirements (contrast, keyboard focus, ARIA where needed). Ensures the Greenfield dashboard is usable and legible for real operators.

---

## North Star

Ensure the Greenfield dashboard is usable and legible for real operators. The dashboard must be usable at 23:00 by a tired operator with mediocre lighting. No cleverness that hurts legibility.

---

## Main Question

**What question does this view answer?**  
"Is this dashboard usable in real-world conditions?"

---

## What

Implement theming and accessibility:
- Visual theme: grayscale baseline, severity as only colour
- Contrast: minimum contrast guidelines met
- Keyboard navigation: major interactions keyboard-accessible
- ARIA labels: where needed for screen readers
- Typography: readable at 3m, sufficient contrast

---

## Why

This is a proof-of-concept for production-grade operators, not a one-off demo. Real operators need usable interfaces in various lighting conditions.

---

## Guarantees

**What must be visible:**
- Clear visual hierarchy
- Sufficient contrast for readability
- Keyboard focus indicators

**What cannot be hidden:**
- Focus states
- Accessibility features

**What must never happen:**
- Random accent colours (violates severity-only rule)
- Insufficient contrast (violates accessibility)
- Keyboard traps (violates accessibility)
- Missing focus indicators (violates accessibility)

---

## Constraints

- Colours follow the severity palette; no random accent colours
- Key screens meet minimum contrast guidelines
- Keyboard navigation works for major interactions (tabbing through cards and views)
- Keep styling lightweight to avoid blocking core behavior

---

## MC Scoring (12-Bin Cognitive Framework)

**Composite MC Score**: 8.30

| Bin | Score | Rationale |
|-----|-------|-----------|
| signal | 8.4 | Clear theming and accessibility requirements |
| memory_short | 8.3 | References FE-DOCTRINE |
| mental_state | 8.2 | Aligned with operator needs (usability) |
| bias_good | 8.3 | Positive assumptions about accessibility |
| bias_bad | 8.1 | Awareness of accessibility complexity |
| memory_long | 8.3 | Links to existing accessibility patterns |
| knowledge | 8.4 | Leverages existing accessibility standards |
| education | 8.2 | Well-documented accessibility guidelines |
| priority | 8.3 | Strategic alignment (user experience) |
| ethos | 8.4 | Strong v6.0 vision alignment (calm until critical) |
| drift | 8.2 | Scope adherence (baseline only) |
| execution_risk | 8.1 | Medium risk (accessibility edge cases) |

**MC Validation Note**: Score reflects theming and accessibility baseline. Primary focus: execution_risk, secondary: drift.

---

## Sentinel Policy

**CRITICAL**: Accessibility compliance

**Sentinel Checks**:
1. **Contrast**: Minimum contrast guidelines met
2. **Keyboard Navigation**: Major interactions keyboard-accessible
3. **Focus Indicators**: Visible focus states
4. **Colour Discipline**: Only severity colours used
5. **ARIA Labels**: Where needed for screen readers

**Testability**:
- Contrast tests: verify WCAG AA compliance
- Keyboard tests: verify all major interactions keyboard-accessible
- Screen reader tests: verify ARIA labels work
- Visual tests: verify focus indicators visible

---

## Architecture Boundaries

**In Scope**:
- Visual theme (grayscale + severity colours)
- Contrast compliance
- Keyboard navigation
- ARIA labels
- Focus indicators

**Out of Scope**:
- Full WCAG AAA compliance (Phase 2)
- Complex animations
- Custom font loading

**Data Flows**:
```
Theme Config → Visual Styles → All Views
Accessibility Config → ARIA Labels → Screen Readers
Keyboard Events → Focus Management → Navigation
```

---

## Dependencies

**Required Cards**: 
- `CARD-V6B-P2-FE-DOCTRINE` (doctrine reference)

**Dependent Cards**: 
- All view cards (use theme and accessibility features)

**Build Order**: Foundation layer (after doctrine, before views)

---

## North Star Alignment

**Truth**: Provides accurate, reliable theming  
**Clarity**: Clear visual hierarchy  
**Progress**: Enables accessibility  
**Precision**: Precise contrast and keyboard navigation

**Project Alignment**: Critical for Greenfield frontend usability.

---

## Evidence Citations

- FE-DOCTRINE: "calm until critical", severity colours
- User requirement: "usable at 23:00 by tired operator"
- WCAG AA guidelines

---

## Contrarian Analysis

**Failure Modes**:
1. Insufficient contrast → unreadable text
2. Missing keyboard navigation → accessibility failure
3. Random colours → violates severity-only rule
4. Missing focus indicators → keyboard navigation confusion

**Alternatives Considered**:
- Full WCAG AAA (rejected: too complex for Phase 1)
- No accessibility (rejected: violates usability)

**Hidden Assumptions**:
- Operators can use keyboards
- Screen readers available (for ARIA)

---

## Steel-Man Mitigation

**Strengthened Arguments**:
- Theming ensures visual consistency
- Accessibility enables broader user base
- Contrast compliance improves readability

**Risk Mitigation**:
1. Comprehensive contrast testing
2. Keyboard navigation testing
3. Screen reader testing
4. User testing in various lighting conditions

**Enhanced Criteria**:
- WCAG AA contrast compliance
- 100% keyboard navigation for major interactions
- Visible focus indicators
- Only severity colours used

---

## STMVault Context

**Pointer**:
- Type: `system`
- Path: `vaults/stmvault/cards/greenfield/frontend/CARD-V6B-P2-FE-THEME-A11Y.md`
- Title: "Theming & Accessibility Baseline"

---

## Acceptance Criteria

- [ ] Colours follow the severity palette; no random accent colours
- [ ] Key screens meet minimum contrast guidelines
- [ ] Keyboard navigation works for major interactions (tabbing through cards and views)
- [ ] Focus indicators visible
- [ ] ARIA labels where needed for screen readers
- [ ] Typography readable at 3m
- [ ] Grayscale baseline with severity colours only

---

**Blocking Dependencies**: `CARD-V6B-P2-FE-DOCTRINE`  
**Blocks Tasks**: All frontend view cards

