# CARD-V6B-P2-FE-STATE-MANAGEMENT

**Card ID**: `CARD-V6B-P2-FE-STATE-MANAGEMENT`  
**Type**: System  
**MC Score**: 8.55  
**MC Target**: 8.55  
**Status**: Active  
**Created**: 2025-01-27  
**North Star Link**: `NORTH-STAR-V6`

---

## Summary

Implements frontend state for filters (by type, status, MC range), selected card, and current view, scoped to the Greenfield project. Allows the pilot to filter, sort, and select cards and agents without desync or confusion.

---

## North Star

Allow the pilot to filter, sort, and select cards and agents without desync or confusion. Filters and selections feel stable and predictable. When you change tabs, your mental context comes with you.

---

## Main Question

**What question does this view answer?**  
"How do filters, selections, and view state persist across navigation?"

---

## What

Implement frontend state management for:
- Filters: by type (LEGO/Agent/Core/Doctrine), status, MC range
- Selected card: current card being viewed/edited
- Current view: active tab/view
- Scoped to Greenfield project

---

## Why

Without clean state, the pilot cannot reason about the 29-card board or compare Greenfield vs test builds. State must be predictable and restorable.

---

## Guarantees

**What must be visible:**
- Current filter settings
- Currently selected card
- Current view/tab

**What cannot be hidden:**
- State changes (filters applied, card selected)
- State restoration failures

**What must never happen:**
- Hidden global state causing desyncs
- Filters not applying consistently across views
- State loss on navigation
- Multiple sources of truth for same state

---

## Constraints

- Filters apply consistently across views that share card lists
- State can be restored from URL or session (basic deep-linking)
- No hidden global state; single predictable source for UI filters/selection
- Keep to minimal state solution (context/store); avoid premature complexity

---

## MC Scoring (12-Bin Cognitive Framework)

**Composite MC Score**: 8.55

| Bin | Score | Rationale |
|-----|-------|-----------|
| signal | 8.6 | Clear state management requirements |
| memory_short | 8.5 | References FE-DOCTRINE and FE-DATA-ADAPTERS |
| mental_state | 8.5 | Aligned with operator mental model |
| bias_good | 8.6 | Positive assumptions about state consistency |
| bias_bad | 8.4 | Awareness of state management complexity |
| memory_long | 8.5 | Links to existing state patterns |
| knowledge | 8.6 | Leverages existing state management patterns |
| education | 8.4 | Well-documented state structure |
| priority | 8.6 | Strategic alignment (enables filtering) |
| ethos | 8.6 | Strong v6.0 vision alignment |
| drift | 8.4 | Scope adherence (minimal state) |
| execution_risk | 8.3 | Medium-high risk (state management complexity) |

**MC Validation Note**: Score reflects state management system with filter/selection persistence. Primary focus: execution_risk, secondary: drift.

---

## Sentinel Policy

**CRITICAL**: State consistency

**Sentinel Checks**:
1. **Single Source**: No multiple sources of truth
2. **Consistency**: Filters apply across views
3. **Persistence**: State survives navigation
4. **Restoration**: URL/session restore works
5. **No Hidden State**: All state visible and debuggable

**Testability**:
- Unit tests: verify state updates correctly
- Integration tests: verify filters persist across views
- Navigation tests: verify state survives tab switches
- Restoration tests: verify URL/session restore

---

## Architecture Boundaries

**In Scope**:
- Filter state (type, status, MC range)
- Selection state (selected card)
- View state (current tab)
- State persistence (URL/session)

**Out of Scope**:
- Backend state synchronization (Phase 2)
- Complex state machines
- Optimistic updates

**Data Flows**:
```
User Action → State Update → View Refresh
Navigation → State Preservation → View Restoration
Filter Change → State Update → All Views Update
```

---

## Dependencies

**Required Cards**: 
- `CARD-V6B-P2-FE-DOCTRINE` (doctrine reference)
- `CARD-V6B-P2-FE-DATA-ADAPTERS` (data types)

**Dependent Cards**: 
- All view cards (use state for filters/selection)

**Build Order**: Foundation layer (after adapters, before views)

---

## North Star Alignment

**Truth**: Provides accurate, reliable state management  
**Clarity**: Clear state structure  
**Progress**: Enables filtering and selection  
**Precision**: Precise state contracts

**Project Alignment**: Critical for Greenfield frontend usability.

---

## Evidence Citations

- FE-DOCTRINE: state management principles
- User requirement: "filters stable across tab switches"

---

## Contrarian Analysis

**Failure Modes**:
1. State desync → user confusion
2. State loss → user frustration
3. Multiple sources → inconsistent UI
4. Hidden state → debugging nightmare

**Alternatives Considered**:
- No state management (rejected: violates usability)
- Complex state machine (rejected: violates minimal complexity)

**Hidden Assumptions**:
- URL/session storage available
- State management library available

---

## Steel-Man Mitigation

**Strengthened Arguments**:
- State management enables filtering and selection
- Persistence improves user experience
- Single source prevents desyncs

**Risk Mitigation**:
1. Comprehensive state testing
2. Navigation state preservation tests
3. Restoration testing
4. User testing for state consistency

**Enhanced Criteria**:
- State persistence 100% reliable
- Filters apply consistently across views
- URL/session restore works
- Zero state desyncs

---

## STMVault Context

**Pointer**:
- Type: `system`
- Path: `vaults/stmvault/cards/greenfield/frontend/CARD-V6B-P2-FE-STATE-MANAGEMENT.md`
- Title: "Frontend State Management for Greenfield"

---

## Acceptance Criteria

- [ ] Filters apply consistently across views that share card lists
- [ ] State can be restored from URL or session (basic deep-linking)
- [ ] No hidden global state; single predictable source for UI filters/selection
- [ ] Filter state: by type, status, MC range
- [ ] Selection state: currently selected card
- [ ] View state: current tab/view
- [ ] State survives navigation

---

**Blocking Dependencies**: `CARD-V6B-P2-FE-DOCTRINE`, `CARD-V6B-P2-FE-DATA-ADAPTERS`  
**Blocks Tasks**: All frontend view cards

