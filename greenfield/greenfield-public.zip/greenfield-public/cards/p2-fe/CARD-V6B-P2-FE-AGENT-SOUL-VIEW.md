# CARD-V6B-P2-FE-AGENT-SOUL-VIEW

**Card ID**: `CARD-V6B-P2-FE-AGENT-SOUL-VIEW`  
**Type**: View  
**MC Score**: 8.65  
**MC Target**: 8.65  
**Status**: Active  
**Created**: 2025-01-27  
**North Star Link**: `NORTH-STAR-V6`

---

## Summary

Implements a dedicated view rendering the Agent Soul Pack doctrine and summarizing each agent's obsession, stays_out_of, and soul_ref link to implementation cards. Makes each agent's vows, obsessions, and boundaries visible and stable over refactors.

---

## North Star

Make each agent's vows, obsessions, and boundaries visible and stable over refactors. This is the primary proof that the identity layer is separate from implementation.

---

## Main Question

**What question does this view answer?**  
"Who are these agents, and what are their vows?"

---

## What

Implement dedicated view that:
- Renders Agent Soul Pack doctrine (`CARD-V6B-P0-AGENT-SOUL`) in full or summarized
- Shows six agent tiles/columns, one per agent:
  - Name and title (e.g., "Caretaker — Guardian of Stewardship")
  - `obsession` (one sentence)
  - `stays_out_of` (one sentence)
  - `soul_ref` badge
  - Link to implementation card (e.g., `CARD-V6B-P1-AGENT-CARETAKER`)

---

## Why

This preserves the "implementation-agnostic identity layer." You can swap all code and keep this view stable. This is where you prove that you can "rip out every line of code and still keep the same system."

---

## Guarantees

**What must be visible:**
- Agent Soul Pack doctrine (full or summarized)
- Six agent identities: name, title, obsession, stays_out_of
- soul_ref badge for each agent
- Link to implementation card

**What cannot be hidden:**
- Agent identities
- Doctrine text

**What must never happen:**
- Showing implementation details (violates identity layer)
- Missing agent identities
- Broken links to implementation cards

---

## Constraints

- Layout should work on both single-monitor and wall-display use
- Doctrine card rendered in full or summarized clearly
- Six agent tiles show identity, not implementation
- Each tile links to implementation card drawer in Cards Board view

---

## MC Scoring (12-Bin Cognitive Framework)

**Composite MC Score**: 8.65

| Bin | Score | Rationale |
|-----|-------|-----------|
| signal | 8.7 | Clear identity view requirements |
| memory_short | 8.6 | References FE-DOCTRINE and Agent Soul Pack |
| mental_state | 8.6 | Aligned with pilot mental model |
| bias_good | 8.7 | Positive assumptions about identity clarity |
| bias_bad | 8.5 | Awareness of layout complexity |
| memory_long | 8.7 | Links to Agent Soul Pack doctrine |
| knowledge | 8.7 | Leverages existing identity patterns |
| education | 8.6 | Well-documented agent identities |
| priority | 8.7 | Strategic alignment (identity proof) |
| ethos | 8.8 | Strong v6.0 vision alignment |
| drift | 8.5 | Scope adherence (identity only) |
| execution_risk | 8.4 | Medium risk (layout complexity) |

**MC Validation Note**: Score reflects identity view showing agent souls separate from implementation. Primary focus: ethos, secondary: signal.

---

## Sentinel Policy

**CRITICAL**: Identity layer integrity

**Sentinel Checks**:
1. **No Implementation Details**: Only identity shown, not code
2. **Complete Identities**: All six agents shown
3. **Doctrine Present**: Agent Soul Pack doctrine visible
4. **Links Work**: Implementation card links functional
5. **Layout Responsive**: Works on single-monitor and wall-display

**Testability**:
- Unit tests: verify agent identities displayed
- Integration tests: verify doctrine rendered
- Visual tests: verify layout works on different screen sizes
- Link tests: verify implementation card links work

---

## Architecture Boundaries

**In Scope**:
- Agent Soul Pack doctrine rendering
- Six agent identity tiles
- Implementation card links
- Responsive layout

**Out of Scope**:
- Implementation details (delegated to Cards Board view)
- Agent metrics (delegated to Assembly Line view)
- Agent editing (read-only in Greenfield)

**Data Flows**:
```
Agent Soul Pack → Agent Soul View → Doctrine + Identity Display
Agent Identities → Agent Tiles → Identity Display
Implementation Card Link → Cards Board View → Card Details
```

---

## Dependencies

**Required Cards**: 
- `CARD-V6B-P2-FE-DOCTRINE` (doctrine reference)
- `CARD-V6B-P2-FE-DATA-ADAPTERS` (agent data)
- `CARD-V6B-P0-AGENT-SOUL` (Agent Soul Pack doctrine)

**Dependent Cards**: None (leaf view)

**Build Order**: View layer (after infrastructure)

---

## North Star Alignment

**Truth**: Provides accurate, reliable agent identities  
**Clarity**: Clear identity vs implementation separation  
**Progress**: Enables identity layer proof  
**Precision**: Precise identity display

**Project Alignment**: Critical for Greenfield identity layer demonstration.

---

## Evidence Citations

- Agent Soul Pack (`CARD-V6B-P0-AGENT-SOUL`)
- Six agent implementation cards
- FE-DOCTRINE: "identity, not implementation"

---

## Contrarian Analysis

**Failure Modes**:
1. Showing implementation details → violates identity layer
2. Missing agent identities → incomplete view
3. Broken links → poor user experience
4. Poor layout → unreadable on different screens

**Alternatives Considered**:
- Combined with implementation (rejected: violates identity separation)
- No doctrine display (rejected: violates completeness)

**Hidden Assumptions**:
- Agent Soul Pack doctrine available
- Agent identities available

---

## Steel-Man Mitigation

**Strengthened Arguments**:
- Identity view proves identity layer separate from implementation
- Agent tiles provide clear identity overview
- Doctrine display provides context

**Risk Mitigation**:
1. Comprehensive identity display testing
2. Layout responsive testing
3. Link functionality testing
4. User testing for clarity

**Enhanced Criteria**:
- All six agents displayed
- Doctrine rendered correctly
- Implementation card links work
- Layout responsive

---

## STMVault Context

**Pointer**:
- Type: `view`
- Path: `vaults/stmvault/cards/greenfield/frontend/CARD-V6B-P2-FE-AGENT-SOUL-VIEW.md`
- Title: "Agent Soul Pack Identity View"

---

## Acceptance Criteria

- [ ] The doctrine card (Agent Soul Pack) is rendered in full or summarized clearly
- [ ] Six agent tiles/columns show: name, title, obsession, stays_out_of, soul_ref badge
- [ ] Each tile links to its implementation card drawer in the Cards Board view
- [ ] Layout should work on both single-monitor and wall-display use
- [ ] No implementation details shown (identity only)
- [ ] All six agents displayed

---

**Blocking Dependencies**: `CARD-V6B-P2-FE-DOCTRINE`, `CARD-V6B-P2-FE-DATA-ADAPTERS`, `CARD-V6B-P0-AGENT-SOUL`  
**Blocks Tasks**: None

