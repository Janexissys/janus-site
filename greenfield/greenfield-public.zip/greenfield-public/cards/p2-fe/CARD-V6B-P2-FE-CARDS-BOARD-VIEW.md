# CARD-V6B-P2-FE-CARDS-BOARD-VIEW

**Card ID**: `CARD-V6B-P2-FE-CARDS-BOARD-VIEW`  
**Type**: View  
**MC Score**: 8.60  
**MC Target**: 8.60  
**Status**: Active  
**Created**: 2025-01-27  
**North Star Link**: `NORTH-STAR-V6`

---

## Summary

Implements a board/table that groups the 29 cards (plus Soul Pack) by type and shows their MC, status, and dependencies in a compact layout. Lets the pilot see and manipulate the 29 cards as a single structured game board.

---

## North Star

Let the pilot see and manipulate the 29 cards as a single structured game board. The Greenfield experiment lives or dies on the clarity of these 29 cards.

---

## Main Question

**What question does this view answer?**  
"What exactly is in scope?"

---

## What

Implement board/table that:
- Groups 29 cards by type (LEGO/Agent/Core/Doctrine)
- Shows for each card: id, title, type, status, MC score vs gate, dependency indicator
- Allows grouping by type or status (switchable)
- Side drawer for richer detail (read-only)
- Sorting by dependency order within groups

---

## Why

The Greenfield spec is literally "use the 29 cards as the contract." The UI must show those cards first and everything else second.

---

## Guarantees

**What must be visible:**
- All 29 cards (plus Soul Pack)
- Card type, status, MC score, dependencies
- Grouping by type or status
- Dependency indicators

**What cannot be hidden:**
- Cards that exist in backend
- MC scores below threshold
- Dependency relationships

**What must never happen:**
- Cards appear that have no backend card backing them
- MC scores recomputed in frontend
- Missing cards from the 29

---

## Constraints

- Grouping by type (LEGO/Agent/Core/Doctrine) is visible and switchable to status
- Each card shows: id, title, type, status, MC score vs gate, dependency indicator
- Selecting a card opens a side drawer with richer detail (not a new page)
- No inline editing in Greenfield mode; read-only for now
- Cards sorted by dependency order within groups

---

## MC Scoring (12-Bin Cognitive Framework)

**Composite MC Score**: 8.60

| Bin | Score | Rationale |
|-----|-------|-----------|
| signal | 8.7 | Clear board requirements |
| memory_short | 8.6 | References FE-DOCTRINE and backend cards |
| mental_state | 8.6 | Aligned with pilot mental model |
| bias_good | 8.7 | Positive assumptions about clarity |
| bias_bad | 8.5 | Awareness of data complexity |
| memory_long | 8.6 | Links to v6.0 board patterns |
| knowledge | 8.7 | Leverages existing board/table patterns |
| education | 8.5 | Well-documented card structure |
| priority | 8.7 | Strategic alignment (primary view) |
| ethos | 8.7 | Strong v6.0 vision alignment |
| drift | 8.5 | Scope adherence (read-only board) |
| execution_risk | 8.4 | Medium risk (data complexity) |

**MC Validation Note**: Score reflects board view showing all 29 cards. Primary focus: execution_risk, secondary: drift.

---

## Sentinel Policy

**CRITICAL**: Card accuracy

**Sentinel Checks**:
1. **Card Backing**: All displayed cards exist in backend
2. **MC Source**: MC scores from backend, not recomputed
3. **No Extras**: Only 29 cards + Soul Pack displayed
4. **Dependency Accuracy**: Dependency indicators match backend
5. **Read-Only**: No editing in Greenfield mode

**Testability**:
- Unit tests: verify card grouping correct
- Integration tests: verify all 29 cards displayed
- Visual tests: verify MC scores match backend
- Dependency tests: verify dependency indicators correct

---

## Architecture Boundaries

**In Scope**:
- Card board/table display
- Grouping by type or status
- Side drawer for card details
- Dependency indicators
- MC score vs gate display

**Out of Scope**:
- Card editing (read-only in Greenfield)
- Card creation (backend concern)
- Complex filtering (delegated to state management)

**Data Flows**:
```
Backend Cards → Cards Board View → Grouped Display
Card Selection → Side Drawer → Card Details
Filter State → Cards Board View → Filtered Display
```

---

## Dependencies

**Required Cards**: 
- `CARD-V6B-P2-FE-DOCTRINE` (doctrine reference)
- `CARD-V6B-P2-FE-DATA-ADAPTERS` (card data)
- `CARD-V6B-P2-FE-STATE-MANAGEMENT` (filter state, selection)

**Dependent Cards**: None (leaf view)

**Build Order**: View layer (after infrastructure)

---

## North Star Alignment

**Truth**: Provides accurate, reliable card display  
**Clarity**: Clear card grouping and details  
**Progress**: Enables card exploration  
**Precision**: Precise MC and dependency display

**Project Alignment**: Critical for Greenfield card visibility.

---

## Evidence Citations

- Backend 29 cards
- Agent Soul Pack (`CARD-V6B-P0-AGENT-SOUL`)
- FE-DOCTRINE: "cards are reality, UI is window"

---

## Contrarian Analysis

**Failure Modes**:
1. Missing cards → incomplete view
2. Extra cards → violates contract
3. MC recomputation → drift from backend truth
4. Poor grouping → user confusion

**Alternatives Considered**:
- No grouping (rejected: violates clarity)
- Editable cards (rejected: violates read-only constraint)

**Hidden Assumptions**:
- Backend cards available
- MC scores available from backend

---

## Steel-Man Mitigation

**Strengthened Arguments**:
- Board view is primary interface for 29 cards
- Grouping improves clarity
- Side drawer provides detail without navigation

**Risk Mitigation**:
1. Comprehensive card display testing
2. Grouping logic testing
3. MC score accuracy testing
4. User testing for clarity

**Enhanced Criteria**:
- All 29 cards displayed
- Grouping works correctly
- MC scores from backend only
- Side drawer shows correct details

---

## STMVault Context

**Pointer**:
- Type: `view`
- Path: `vaults/stmvault/cards/greenfield/frontend/CARD-V6B-P2-FE-CARDS-BOARD-VIEW.md`
- Title: "29-Card Board View"

---

## Acceptance Criteria

- [ ] Grouping by type (LEGO/Agent/Core/Doctrine) is visible and switchable to status
- [ ] Each card shows: id, title, type, status, MC score vs gate, dependency indicator
- [ ] Selecting a card opens a side drawer with richer detail (not a new page)
- [ ] No inline editing in Greenfield mode; read-only for now
- [ ] Cards sorted by dependency order within groups
- [ ] All 29 cards + Soul Pack displayed
- [ ] MC scores from backend, not recomputed

---

**Blocking Dependencies**: `CARD-V6B-P2-FE-DOCTRINE`, `CARD-V6B-P2-FE-DATA-ADAPTERS`, `CARD-V6B-P2-FE-STATE-MANAGEMENT`  
**Blocks Tasks**: None

