# CARD-V6B-P2-FE-TELEMETRY-HOOKS

**Card ID**: `CARD-V6B-P2-FE-TELEMETRY-HOOKS`  
**Type**: System  
**MC Score**: 8.45  
**MC Target**: 8.45  
**Status**: Active  
**Created**: 2025-01-27  
**North Star Link**: `NORTH-STAR-V6`

---

## Summary

Adds non-invasive telemetry hooks for view usage, filter patterns, and card drill-downs, with tags indicating "greenfield" vs "legacy/testing" context. Captures enough frontend telemetry to compare Greenfield vs test-built systems.

---

## North Star

Capture enough frontend telemetry to compare Greenfield vs test-built systems. Quietly record how humans actually move around this machine, so later you can prove Greenfield is better than the "scrappy beta."

---

## Main Question

**What question does this view answer?**  
"How do users actually interact with the Greenfield dashboard?"

---

## What

Implement telemetry hooks for:
- View switches: when user changes tabs/views
- Card selections: when user selects a card
- Filter changes: when user applies filters
- Tags: project id, mode (greenfield/testing), card id (if any)

---

## Why

You want real evidence that the Greenfield-structured dashboard behaves better than the ad hoc version built during testing. Telemetry provides quantitative comparison data.

---

## Guarantees

**What must be visible:**
- Telemetry events firing (for debugging)
- Telemetry toggle (on/off)

**What cannot be hidden:**
- Telemetry collection (user should know)

**What must never happen:**
- Telemetry blocking UI interactions
- Telemetry collecting PII without consent
- Telemetry without toggle option

---

## Constraints

- Telemetry events fire for view switches, card selections, and filter changes
- Each event includes: project id, mode (greenfield/testing), card id (if any)
- Telemetry can be turned off or pointed at a test endpoint during development
- Keep schema minimal and versioned; this will feed later analytics

---

## MC Scoring (12-Bin Cognitive Framework)

**Composite MC Score**: 8.45

| Bin | Score | Rationale |
|-----|-------|-----------|
| signal | 8.5 | Clear telemetry requirements |
| memory_short | 8.4 | References FE-DOCTRINE and FE-STATE-MANAGEMENT |
| mental_state | 8.4 | Aligned with analytics needs |
| bias_good | 8.5 | Positive assumptions about telemetry value |
| bias_bad | 8.3 | Awareness of privacy concerns |
| memory_long | 8.4 | Links to existing telemetry patterns |
| knowledge | 8.6 | Leverages existing telemetry patterns |
| education | 8.3 | Well-documented telemetry schema |
| priority | 8.5 | Strategic alignment (comparison data) |
| ethos | 8.5 | Strong v6.0 vision alignment (evidence-based) |
| drift | 8.3 | Scope adherence (minimal telemetry) |
| execution_risk | 8.2 | Medium risk (privacy concerns) |

**MC Validation Note**: Score reflects telemetry system with privacy considerations. Primary focus: execution_risk, secondary: drift.

---

## Sentinel Policy

**CRITICAL**: Privacy and performance

**Sentinel Checks**:
1. **No PII**: Telemetry does not collect PII
2. **Non-Blocking**: Telemetry does not block UI interactions
3. **Toggle**: Telemetry can be disabled
4. **Minimal Schema**: Only necessary data collected
5. **Versioned**: Schema versioned for future changes

**Testability**:
- Unit tests: verify telemetry events fire correctly
- Integration tests: verify telemetry does not block UI
- Privacy tests: verify no PII collected
- Performance tests: verify telemetry overhead minimal

---

## Architecture Boundaries

**In Scope**:
- Telemetry event hooks
- Event schema (project id, mode, card id)
- Telemetry toggle
- Test endpoint support

**Out of Scope**:
- Telemetry analytics (backend concern)
- Complex event processing (Phase 2)
- User identification (privacy concern)

**Data Flows**:
```
User Action → Telemetry Hook → Event → Backend/Test Endpoint
Telemetry Toggle → Hook Enable/Disable → Event Collection
```

---

## Dependencies

**Required Cards**: 
- `CARD-V6B-P2-FE-DOCTRINE` (doctrine reference)
- `CARD-V6B-P2-FE-NAV-SHELL` (view switches)
- `CARD-V6B-P2-FE-STATE-MANAGEMENT` (filter changes, card selections)

**Dependent Cards**: 
- All view cards (emit telemetry events)

**Build Order**: Foundation layer (after state management, before views)

---

## North Star Alignment

**Truth**: Provides accurate, reliable telemetry  
**Clarity**: Clear telemetry schema  
**Progress**: Enables comparison analysis  
**Precision**: Precise event tagging

**Project Alignment**: Critical for Greenfield vs test-build comparison.

---

## Evidence Citations

- FE-DOCTRINE: telemetry principles
- User requirement: "prove Greenfield is better than scrappy beta"

---

## Contrarian Analysis

**Failure Modes**:
1. PII collection → privacy violation
2. Blocking telemetry → poor performance
3. No toggle → user frustration
4. Complex schema → maintenance burden

**Alternatives Considered**:
- No telemetry (rejected: no comparison data)
- Full analytics (rejected: violates minimal schema)

**Hidden Assumptions**:
- Backend endpoint available
- Users consent to telemetry

---

## Steel-Man Mitigation

**Strengthened Arguments**:
- Telemetry enables evidence-based comparison
- Minimal schema reduces privacy risk
- Toggle provides user control

**Risk Mitigation**:
1. Privacy review of telemetry schema
2. Performance testing
3. User consent for telemetry
4. Schema versioning

**Enhanced Criteria**:
- Zero PII in telemetry
- Telemetry overhead <1% of UI time
- Toggle works correctly
- Schema versioned

---

## STMVault Context

**Pointer**:
- Type: `system`
- Path: `vaults/stmvault/cards/greenfield/frontend/CARD-V6B-P2-FE-TELEMETRY-HOOKS.md`
- Title: "Frontend Telemetry & Comparison Hooks"

---

## Acceptance Criteria

- [ ] Telemetry events fire for view switches, card selections, and filter changes
- [ ] Each event includes: project id, mode (greenfield/testing), card id (if any)
- [ ] Telemetry can be turned off or pointed at a test endpoint during development
- [ ] Schema minimal and versioned
- [ ] No PII collected
- [ ] Telemetry does not block UI interactions
- [ ] Telemetry toggle works

---

**Blocking Dependencies**: `CARD-V6B-P2-FE-DOCTRINE`, `CARD-V6B-P2-FE-NAV-SHELL`, `CARD-V6B-P2-FE-STATE-MANAGEMENT`  
**Blocks Tasks**: All frontend view cards

