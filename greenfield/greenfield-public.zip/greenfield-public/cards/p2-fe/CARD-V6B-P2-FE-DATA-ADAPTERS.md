# CARD-V6B-P2-FE-DATA-ADAPTERS

**Card ID**: `CARD-V6B-P2-FE-DATA-ADAPTERS`  
**Type**: LEGO Block  
**MC Score**: 8.65  
**MC Target**: 8.65  
**Status**: Active  
**Created**: 2025-01-27  
**North Star Link**: `NORTH-STAR-V6`

---

## Summary

Implements a small adapter layer that converts backend payloads (`/api/v1/cards`, `/crew/status`, `/logs`) into normalized frontend types for Greenfield cards and agents. Every view reads the same normalized card and agent model derived from backend APIs.

---

## North Star

Every view reads the same normalized card and agent model derived from backend APIs. The 29 cards are the game board. The frontend must treat them as structured data with explicit types, not ad hoc fields per view.

---

## Main Question

**What question does this view answer?**  
"What is the canonical shape of a card and an agent in the frontend?"

---

## What

Implement adapter layer that:
- Defines `GreenfieldCard` TypeScript interface (or equivalent)
- Defines `AgentIdentity` TypeScript interface (or equivalent)
- Converts backend API responses to normalized frontend types
- Provides adapter functions for `/api/v1/cards`, `/api/v1/crew`, `/api/v1/logs`
- Makes MC scores and soul_ref available in normalized shape

---

## Why

The 29 cards are the game board. The frontend must treat them as structured data with explicit types, not ad hoc fields per view. This adapter ensures all views share the same mental model.

---

## Guarantees

**What must be visible:**
- Normalized card type with all required fields
- Normalized agent type with identity fields
- MC scores accessible in consistent format
- soul_ref available for agent cards

**What cannot be hidden:**
- Backend API contract differences
- Type mismatches between backend and frontend

**What must never happen:**
- Views calling backend responses directly (bypass adapter)
- Different views using different card shapes
- MC scores recomputed in frontend (must come from backend)

---

## Constraints

- All views import from single adapter module
- Adapter handles API contract differences transparently
- Types are explicit and documented
- No view-specific data transformations (normalize once, use everywhere)

---

## MC Scoring (12-Bin Cognitive Framework)

**Composite MC Score**: 8.65

| Bin | Score | Rationale |
|-----|-------|-----------|
| signal | 8.7 | Clear adapter requirements |
| memory_short | 8.6 | References FE-DOCTRINE and backend cards |
| mental_state | 8.6 | Aligned with developer mental model |
| bias_good | 8.7 | Positive assumptions about normalization |
| bias_bad | 8.5 | Awareness of API contract risks |
| memory_long | 8.7 | Links to backend card structure |
| knowledge | 8.8 | Leverages existing adapter patterns |
| education | 8.6 | Well-documented type definitions |
| priority | 8.7 | Strategic alignment (foundation for views) |
| ethos | 8.7 | Strong v6.0 vision alignment |
| drift | 8.5 | Scope adherence (adapter only, no view logic) |
| execution_risk | 8.4 | Medium risk (API contract changes) |

**MC Validation Note**: Score reflects adapter layer that normalizes backend data for frontend consumption. Primary focus: execution_risk, secondary: drift.

---

## Sentinel Policy

**CRITICAL**: Data integrity

**Sentinel Checks**:
1. **Type Safety**: All adapters use explicit types
2. **No Direct API Calls**: Views must use adapter, not call backend directly
3. **MC Source**: MC scores come from backend, not recomputed
4. **Consistency**: Same card shape used across all views
5. **Error Handling**: API failures handled gracefully

**Testability**:
- Unit tests: verify adapter transforms backend → frontend correctly
- Type tests: verify TypeScript types match runtime data
- Integration tests: verify views use adapter, not direct API calls

---

## Architecture Boundaries

**In Scope**:
- Type definitions (`GreenfieldCard`, `AgentIdentity`)
- Adapter functions for API endpoints
- Data transformation logic
- Error handling for API failures

**Out of Scope**:
- View-specific rendering logic
- State management (delegated to FE-STATE-MANAGEMENT)
- Caching strategies (Phase 2)

**Data Flows**:
```
Backend API → Adapter → Normalized Types → Views
Backend Cards → GreenfieldCard → All Views
Backend Agents → AgentIdentity → Agent Views
```

---

## Dependencies

**Required Cards**: 
- `CARD-V6B-P2-FE-DOCTRINE` (doctrine reference)

**Dependent Cards**: 
- All view cards (require normalized data)

**Build Order**: Foundation layer (after doctrine, before views)

---

## North Star Alignment

**Truth**: Provides accurate, reliable data normalization  
**Clarity**: Clear type definitions  
**Progress**: Enables view development  
**Precision**: Precise type contracts

**Project Alignment**: Critical for Greenfield frontend data consistency.

---

## Evidence Citations

- Backend card structure (29 cards)
- Agent Soul Pack (`CARD-V6B-P0-AGENT-SOUL`)
- Backend API endpoints: `/api/v1/cards`, `/api/v1/crew`, `/api/v1/logs`

---

## Contrarian Analysis

**Failure Modes**:
1. Type mismatches → runtime errors
2. Direct API calls → inconsistent data shapes
3. MC recomputation → drift from backend truth
4. Missing fields → views break

**Alternatives Considered**:
- Per-view adapters (rejected: violates consistency)
- No adapter (rejected: violates type safety)

**Hidden Assumptions**:
- Backend API contracts are stable
- TypeScript (or equivalent) available

---

## Steel-Man Mitigation

**Strengthened Arguments**:
- Adapter ensures consistency across views
- Type safety prevents runtime errors
- Normalization simplifies view logic

**Risk Mitigation**:
1. Comprehensive type testing
2. API contract versioning
3. Adapter unit tests
4. Integration tests with real backend

**Enhanced Criteria**:
- 100% type coverage
- All views use adapter (no direct API calls)
- MC scores from backend only
- Zero type-related runtime errors

---

## STMVault Context

**Pointer**:
- Type: `lego_block`
- Path: `vaults/stmvault/cards/greenfield/frontend/CARD-V6B-P2-FE-DATA-ADAPTERS.md`
- Title: "Card & Agent Data Adapters"

---

## Acceptance Criteria

- [ ] Define `GreenfieldCard` TypeScript type (or equivalent)
- [ ] Define `AgentIdentity` TypeScript type (or equivalent)
- [ ] All views import from single adapter module, not call backend responses directly
- [ ] MC scores and soul_ref available in normalized shape
- [ ] Adapter handles `/api/v1/cards`, `/api/v1/crew`, `/api/v1/logs`
- [ ] Error handling for API failures
- [ ] Types documented and tested

---

**Blocking Dependencies**: `CARD-V6B-P2-FE-DOCTRINE`  
**Blocks Tasks**: All frontend view cards

