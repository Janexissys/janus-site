# CARD-V6B-P2-FE-DOCTRINE

**Card ID**: `CARD-V6B-P2-FE-DOCTRINE`  
**Type**: Doctrine  
**MC Score**: 8.70  
**MC Target**: 8.70  
**Status**: Active  
**Created**: 2025-01-27  
**North Star Link**: `NORTH-STAR-V6`

---

## Summary

Defines the UX/visual doctrine for the Greenfield dashboard: views, severity language, layout principles, and disclosure levels (Overview → Hover → Drawer). This is the UX equivalent of `CARD-V6B-P0-AGENT-SOUL` - a stable identity layer that keeps the frontend recognizable as Janus regardless of implementation changes.

---

## North Star

**Frontend North Star**: "Extend the human mind without overruling it, with a dashboard that is readable at 3m, calm until critical, and driven entirely by the 29 Greenfield cards + Agent Soul Pack."

---

## Core Principles

### 1. Cards are reality. UI is a window.
- If there is no card, it does not exist on screen.
- If the card changes, the UI must follow, not vice versa.

### 2. Read-only first. Control later.
- Greenfield frontend is an instrument panel, not a cockpit.
- First proof: "we can see the whole system clearly and honestly."

### 3. Calm until critical.
- Default is grey, flat, low drama.
- Colour and motion are reserved for real problems: Sentinel blocks, missing cards, broken contract.

### 4. 3-step disclosure.
- **Overview**: "What is happening?"
- **Hover**: "What is this?"
- **Drawer**: "Show me the full story."
- Nothing deeper than a drawer in v6.0 Greenfield.

### 5. One concept, one place.
- Each idea (MC gate, Soul Pack, assembly line) has one primary home view.
- Other views may *reference*, but never reinvent or re-explain.

---

## Design Practice

### Start from doctrine, not layout.
- First question: "What does this view *prove* about the system?"
- Only then: "How do we lay it out so a tired human sees that in 3 seconds?"

### Every view answers a single main question.
- Flight Plan: "Are we still flying the Greenfield contract?"
- Cards Board: "What exactly is in scope?"
- Agent Soul: "Who are these agents, and what are their vows?"
- Assembly Line: "How do cards move through the crew?"
- MC & Sentinels: "What is being held back, and why?"
- Run Log: "What actually happened?"

### No hidden logic in the frontend.
- The UI may *group, sort, filter,* but never *re-interpret* meaning.
- Interpretation belongs to cards + backend MC/Sentinel logic.

### Narrative before decoration.
- For each view, you can speak one clear sentence:
  "This screen exists to show X so the human can decide Y."
- If you cannot say that, the view is not ready.

### Comparison is a first-class citizen.
- Always ask: "What about this view will make Greenfield vs test-build differences obvious?"
- Greenfield must feel tighter, clearer, less surprising.

---

## Visual Language

### Layout Grid
- Designed for 3m readability on large screens
- Primary information density: low to medium
- Secondary information: drawers and tooltips

### Severity Colours
- **Grey**: Default, neutral, calm
- **Red**: Critical problems (Sentinel blocks, contract failures)
- **Yellow/Orange**: Warnings (MC gate near threshold, pending reviews)
- **Green**: Success indicators (all criteria met, healthy status)
- No random accent colours

### Typography
- Clear hierarchy: title → subtitle → body → metadata
- Sufficient contrast for 23:00 operator with mediocre lighting
- Readable at 3m distance

### Motion
- Minimal animation
- Reserved for critical state changes
- No decorative motion

---

## Anti-Patterns (Forbidden)

- Do **not** add UI elements that have no card backing them.
- Do **not** let the frontend guess at MC or Sentinel reasoning.
- Do **not** introduce new colours, icons, or metaphors per view.
- Do **not** optimise for "cool factor" over "three-second understanding."
- Do **not** hide contract failures; surface them plainly.

---

## MC Scoring (12-Bin Cognitive Framework)

**Composite MC Score**: 8.70

| Bin | Score | Rationale |
|-----|-------|-----------|
| signal | 8.8 | Clear UX doctrine specification |
| memory_short | 8.7 | References Agent Soul Pack and backend cards |
| mental_state | 8.7 | Aligned with human operator needs |
| bias_good | 8.8 | Positive assumptions about clarity |
| bias_bad | 8.6 | Awareness of UI complexity risks |
| memory_long | 8.7 | Links to v6.0 Basic principles |
| knowledge | 8.8 | Leverages existing design patterns |
| education | 8.6 | Well-documented principles |
| priority | 8.7 | Strategic alignment with Greenfield goals |
| ethos | 8.9 | Strong v6.0 vision alignment |
| drift | 8.6 | Scope adherence (no blueprint details) |
| execution_risk | 8.5 | Low risk (doctrine, not implementation) |

**MC Validation Note**: Score reflects comprehensive UX doctrine that guides all frontend views without prescribing implementation. Primary focus: ethos, secondary: signal.

---

## Sentinel Policy

**CRITICAL**: Doctrine compliance

**Sentinel Checks**:
1. **Card Backing**: All UI elements must reference a card
2. **No Hidden Logic**: Frontend never re-interprets backend meaning
3. **Disclosure Levels**: No deeper than drawer (3-step max)
4. **Colour Discipline**: Only severity colours used
5. **One Concept, One Place**: No duplicate explanations

**Testability**:
- Manual review: verify each view answers its main question
- Visual audit: check colour usage matches severity only
- Navigation test: verify disclosure levels (overview → hover → drawer)

---

## Architecture Boundaries

**In Scope**:
- UX principles and visual language
- View definitions and their main questions
- Disclosure level rules
- Anti-patterns and constraints

**Out of Scope**:
- Specific component implementations
- Layout algorithms
- Widget libraries
- Animation details
- Exact copy or microcopy

**Data Flows**:
```
Backend Cards → Frontend Doctrine → View Implementation
User Question → View Selection → Answer Display
```

---

## Dependencies

**Required Cards**: None (foundational doctrine)

**Dependent Cards**: All frontend cards (FE-NAV-SHELL, FE-DATA-ADAPTERS, FE-STATE-MANAGEMENT, FE-ERROR-EMPTY-STATES, FE-THEME-A11Y, FE-TELEMETRY-HOOKS, FE-FLIGHT-PLAN-VIEW, FE-CARDS-BOARD-VIEW, FE-AGENT-SOUL-VIEW, FE-ASSEMBLY-LINE-VIEW, FE-MC-SENTINELS-VIEW, FE-RUN-LOG-VIEW)

**Build Order**: Must be created first, referenced by all other frontend cards

---

## North Star Alignment

**Truth**: Provides accurate, reliable UX doctrine  
**Clarity**: Clear visual and interaction principles  
**Progress**: Enables consistent frontend development  
**Precision**: Precise constraints without blueprint details

**Project Alignment**: Critical for Greenfield frontend identity and consistency.

---

## Evidence Citations

- Agent Soul Pack (`CARD-V6B-P0-AGENT-SOUL`) - identity layer precedent
- v6.0 Basic principles: "Invisible enforcement, visible speed"
- User requirements: 3m readability, calm until critical

---

## Contrarian Analysis

**Failure Modes**:
1. Doctrine too vague → inconsistent implementations
2. Doctrine too prescriptive → becomes blueprint, limits AI exploration
3. Missing anti-patterns → UI drift from Greenfield contract
4. Colour misuse → visual noise, confusion

**Alternatives Considered**:
- No doctrine (rejected: leads to inconsistent UI)
- Detailed blueprint (rejected: limits AI path-finding)
- Per-view doctrine (rejected: violates "one concept, one place")

**Hidden Assumptions**:
- Operators have large screens (3m readability)
- Operators work in various lighting conditions
- Greenfield vs test-build comparison is valuable

---

## Steel-Man Mitigation

**Strengthened Arguments**:
- Doctrine provides stable identity layer for frontend
- Constraints guide without limiting exploration
- Anti-patterns prevent common UI mistakes

**Risk Mitigation**:
1. Regular doctrine review against implementations
2. User testing for 3m readability and contrast
3. Visual audit for colour discipline
4. Navigation testing for disclosure levels

**Enhanced Criteria**:
- All views reference this doctrine
- No UI element without card backing
- Colour usage matches severity palette only
- Disclosure levels respected (overview → hover → drawer)

---

## STMVault Context

**Pointer**:
- Type: `doctrine`
- Path: `vaults/stmvault/cards/greenfield/frontend/CARD-V6B-P2-FE-DOCTRINE.md`
- Title: "Frontend Doctrine – Greenfield v6.0 Dashboard"

---

## Acceptance Criteria

- [ ] Document includes: views list, layout grid, severity colours, typography rules
- [ ] All other FE cards reference this doctrine in their notes
- [ ] No view introduces concepts not present in the 29 cards or Agent Soul Pack
- [ ] Visual language defined: grey default, colour for severity only
- [ ] 3-step disclosure documented: Overview → Hover → Drawer
- [ ] Anti-patterns clearly stated

---

**Blocking Dependencies**: None  
**Blocks Tasks**: All frontend implementation cards

