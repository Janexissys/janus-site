# CARD-V6B-P2-FE-RUN-LOG-VIEW

**Card ID**: `CARD-V6B-P2-FE-RUN-LOG-VIEW`  
**Type**: View  
**MC Score**: 8.50  
**MC Target**: 8.50  
**Status**: Active  
**Created**: 2025-01-27  
**North Star Link**: `NORTH-STAR-V6`

---

## Summary

Builds a chronological feed of Greenfield-relevant actions: card creation, MC changes, Sentinel blocks, assembly line runs, and doctrine updates. Provides a human-readable timeline of all significant Greenfield events.

---

## North Star

Provide a human-readable timeline of all significant Greenfield events. You need a place to show "what actually happened" during tests and demos, without digging through infra logs.

---

## Main Question

**What question does this view answer?**  
"What actually happened?"

---

## What

Implement chronological event feed that displays:
- Greenfield-relevant events:
  - Card creation or updated
  - MC threshold crossed
  - Sentinel block
  - Agent Soul Pack modified
  - Assembly Line test run
- Filters: by event type (card, MC, Sentinel, assembly, doctrine)
- Time range controls: "Last hour", "Today", "All Greenfield"
- Links: events link back to their card or agent where applicable

---

## Why

You need a single place where you can say "show me everything Greenfield did in the last 24 hours." This provides accountability and transparency.

---

## Guarantees

**What must be visible:**
- Chronological event feed
- Event type (card, MC, Sentinel, assembly, doctrine)
- Timestamp for each event
- Links to source cards/agents

**What cannot be hidden:**
- Significant Greenfield events
- Event timestamps

**What must never happen:**
- Showing non-Greenfield events
- Missing significant events
- Broken links to cards/agents

---

## Constraints

- Events can be filtered by type (card, MC, Sentinel, assembly, doctrine)
- Each event links back to its card or agent where applicable
- Time range controls exist for at least "Last hour", "Today", "All Greenfield"
- Start simple: table or list with light grouping by day
- Human-readable format, not raw logs

---

## MC Scoring (12-Bin Cognitive Framework)

**Composite MC Score**: 8.50

| Bin | Score | Rationale |
|-----|-------|-----------|
| signal | 8.6 | Clear log view requirements |
| memory_short | 8.5 | References FE-DOCTRINE |
| mental_state | 8.4 | Aligned with operator needs |
| bias_good | 8.5 | Positive assumptions about readability |
| bias_bad | 8.3 | Awareness of log volume complexity |
| memory_long | 8.5 | Links to existing log patterns |
| knowledge | 8.6 | Leverages existing log/feed patterns |
| education | 8.4 | Well-documented event types |
| priority | 8.5 | Strategic alignment (accountability) |
| ethos | 8.6 | Strong v6.0 vision alignment (legibility) |
| drift | 8.4 | Scope adherence (simple feed) |
| execution_risk | 8.2 | Medium risk (log volume, filtering) |

**MC Validation Note**: Score reflects log view showing Greenfield events in human-readable format. Primary focus: execution_risk, secondary: drift.

---

## Sentinel Policy

**CRITICAL**: Event accuracy

**Sentinel Checks**:
1. **Event Accuracy**: Only real events shown
2. **Greenfield Scope**: Only Greenfield events, not other projects
3. **Link Integrity**: Links to cards/agents work
4. **No Missing Events**: Significant events not hidden
5. **Human Readable**: Events in plain language, not raw logs

**Testability**:
- Unit tests: verify events displayed correctly
- Integration tests: verify event filtering works
- Link tests: verify card/agent links work
- Readability tests: verify events human-readable

---

## Architecture Boundaries

**In Scope**:
- Chronological event feed
- Event filtering (by type, time range)
- Event links to cards/agents
- Human-readable formatting

**Out of Scope**:
- Raw log display (backend concern)
- Complex log analysis (Phase 2)
- Event editing (read-only in Greenfield)

**Data Flows**:
```
Backend Logs → Run Log View → Filtered Event Feed
Event Selection → Card/Agent Link → Detail View
Time Range → Filter → Filtered Events
```

---

## Dependencies

**Required Cards**: 
- `CARD-V6B-P2-FE-DOCTRINE` (doctrine reference)
- `CARD-V6B-P2-FE-DATA-ADAPTERS` (log data)
- `CARD-V6B-P2-FE-STATE-MANAGEMENT` (filter state)

**Dependent Cards**: None (leaf view)

**Build Order**: View layer (after infrastructure)

---

## North Star Alignment

**Truth**: Provides accurate, reliable event feed  
**Clarity**: Clear chronological display  
**Progress**: Enables accountability  
**Precision**: Precise event filtering

**Project Alignment**: Critical for Greenfield transparency.

---

## Evidence Citations

- Backend log system
- Greenfield event types
- FE-DOCTRINE: "human-readable, not raw logs"

---

## Contrarian Analysis

**Failure Modes**:
1. Missing events → incomplete history
2. Non-Greenfield events → scope violation
3. Broken links → poor user experience
4. Raw logs → unreadable

**Alternatives Considered**:
- Raw log display (rejected: violates human-readable requirement)
- No filtering (rejected: violates usability)

**Hidden Assumptions**:
- Backend logs available
- Event types stable

---

## Steel-Man Mitigation

**Strengthened Arguments**:
- Log view provides accountability
- Human-readable format improves usability
- Filtering enables focused review

**Risk Mitigation**:
1. Comprehensive event accuracy testing
2. Filter functionality testing
3. Link integrity testing
4. User testing for readability

**Enhanced Criteria**:
- All significant events displayed
- Filtering works correctly
- Links to cards/agents work
- Events human-readable

---

## STMVault Context

**Pointer**:
- Type: `view`
- Path: `vaults/stmvault/cards/greenfield/frontend/CARD-V6B-P2-FE-RUN-LOG-VIEW.md`
- Title: "Greenfield Run Log View"

---

## Acceptance Criteria

- [ ] Events can be filtered by type (card, MC, Sentinel, assembly, doctrine)
- [ ] Each event links back to its card or agent where applicable
- [ ] Time range controls exist for at least "Last hour", "Today", "All Greenfield"
- [ ] Start simple: table or list with light grouping by day
- [ ] Human-readable format, not raw logs
- [ ] Only Greenfield events shown
- [ ] Chronological order maintained

---

**Blocking Dependencies**: `CARD-V6B-P2-FE-DOCTRINE`, `CARD-V6B-P2-FE-DATA-ADAPTERS`, `CARD-V6B-P2-FE-STATE-MANAGEMENT`  
**Blocks Tasks**: None

