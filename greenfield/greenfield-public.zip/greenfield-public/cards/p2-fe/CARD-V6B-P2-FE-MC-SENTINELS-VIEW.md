# CARD-V6B-P2-FE-MC-SENTINELS-VIEW

**Card ID**: `CARD-V6B-P2-FE-MC-SENTINELS-VIEW`  
**Type**: View  
**MC Score**: 8.70  
**MC Target**: 8.70  
**Status**: Active  
**Created**: 2025-01-27  
**North Star Link**: `NORTH-STAR-V6`

---

## Summary

Implements a view that lists cards with their MC score, gate threshold, and Sentinel status so the pilot can see which outputs are held back vs safe to expose. Makes MC as backend gate vs user confidence visible and auditable per card.

---

## North Star

Make MC as backend gate vs user confidence visible and auditable per card. Greenfield explicitly requires MC separation validation. This is the visual proof.

---

## Main Question

**What question does this view answer?**  
"What is being held back, and why?"

---

## What

Implement view that displays:
- Table per card type (LEGO, Agent, Core, Doctrine)
- For each card:
  - Card name and id
  - MC score bar (0–10 scale)
  - MC gate line (8.50 threshold)
  - Gate result (pass/hold)
  - Sentinel status (clear, warning, blocked)
  - Last drift check timestamp
- Filters: "held by MC" and "blocked by Sentinel"

---

## Why

Greenfield explicitly requires MC separation validation: Gate score for backend, confidence score for user-facing. This view is the proof that MC and Sentinel can say "no" even when everything else says "yes."

---

## Guarantees

**What must be visible:**
- MC score for each card (0–10)
- MC gate threshold (8.50)
- Gate result (pass/hold)
- Sentinel status (clear/warning/blocked)
- Cards below gate visually flagged

**What cannot be hidden:**
- Cards held by MC gate
- Cards blocked by Sentinel
- MC scores below threshold

**What must never happen:**
- MC scores recomputed in frontend (must come from backend)
- Cards below gate misread as "safe"
- Hidden Sentinel blocks

---

## Constraints

- Each card row shows: MC score (0–10), MC gate, gate result (pass/hold), Sentinel status
- Cards below gate are visually flagged and cannot be misread as "safe"
- View supports filtering by "held by MC" and "blocked by Sentinel"
- Use compact visual language (e.g., bar + line) rather than dense text
- MC comes from MC engine, not recomputed in UI

---

## MC Scoring (12-Bin Cognitive Framework)

**Composite MC Score**: 8.70

| Bin | Score | Rationale |
|-----|-------|-----------|
| signal | 8.8 | Clear MC separation requirements |
| memory_short | 8.7 | References FE-DOCTRINE and MC engine |
| mental_state | 8.7 | Aligned with pilot mental model |
| bias_good | 8.8 | Positive assumptions about clarity |
| bias_bad | 8.6 | Awareness of MC complexity |
| memory_long | 8.7 | Links to MC engine and Sentinel |
| knowledge | 8.8 | Leverages existing MC patterns |
| education | 8.6 | Well-documented MC separation |
| priority | 8.8 | Strategic alignment (MC validation proof) |
| ethos | 8.9 | Strong v6.0 vision alignment |
| drift | 8.6 | Scope adherence (MC display only) |
| execution_risk | 8.5 | Medium risk (MC data complexity) |

**MC Validation Note**: Score reflects MC separation view showing gate vs confidence. Primary focus: ethos, secondary: signal.

---

## Sentinel Policy

**CRITICAL**: MC separation integrity

**Sentinel Checks**:
1. **MC Source**: MC scores from backend, not recomputed
2. **Gate Accuracy**: Gate threshold (8.50) correct
3. **Sentinel Visibility**: Blocks visible, not hidden
4. **Visual Clarity**: Cards below gate clearly flagged
5. **No Misrepresentation**: Gate results accurate

**Testability**:
- Unit tests: verify MC scores displayed correctly
- Integration tests: verify gate results match backend
- Visual tests: verify cards below gate flagged
- Sentinel tests: verify blocks visible

---

## Architecture Boundaries

**In Scope**:
- MC score display (0–10 scale)
- MC gate line (8.50 threshold)
- Gate result (pass/hold)
- Sentinel status display
- Filters (held by MC, blocked by Sentinel)

**Out of Scope**:
- MC score computation (backend concern)
- Sentinel policy editing (backend concern)
- Historical MC trends (Phase 2)

**Data Flows**:
```
Backend MC Engine → MC & Sentinels View → MC Display
Backend Sentinel → Sentinel Status → Status Display
MC Gate → Gate Result → Pass/Hold Display
```

---

## Dependencies

**Required Cards**: 
- `CARD-V6B-P2-FE-DOCTRINE` (doctrine reference)
- `CARD-V6B-P2-FE-DATA-ADAPTERS` (MC and Sentinel data)
- `CARD-V6B-P2-FE-STATE-MANAGEMENT` (filter state)

**Dependent Cards**: None (leaf view)

**Build Order**: View layer (after infrastructure)

---

## North Star Alignment

**Truth**: Provides accurate, reliable MC and Sentinel status  
**Clarity**: Clear gate vs confidence separation  
**Progress**: Enables MC validation  
**Precision**: Precise gate and Sentinel display

**Project Alignment**: Critical for Greenfield MC separation validation.

---

## Evidence Citations

- Backend MC engine
- Backend Sentinel system
- MC gate threshold: 8.50
- FE-DOCTRINE: "MC comes from MC engine, not recomputed"

---

## Contrarian Analysis

**Failure Modes**:
1. MC recomputation → drift from backend truth
2. Hidden Sentinel blocks → false sense of security
3. Cards below gate misread as safe → user confusion
4. Incorrect gate results → misrepresentation

**Alternatives Considered**:
- No MC display (rejected: violates MC separation requirement)
- Dense text (rejected: violates compact visual language)

**Hidden Assumptions**:
- Backend MC scores available
- Backend Sentinel status available

---

## Steel-Man Mitigation

**Strengthened Arguments**:
- MC separation view proves gate vs confidence
- Visual clarity prevents misreading
- Sentinel visibility ensures safety

**Risk Mitigation**:
1. Comprehensive MC accuracy testing
2. Gate result validation
3. Visual clarity testing
4. User testing for understanding

**Enhanced Criteria**:
- MC scores from backend only
- Gate results 100% accurate
- Cards below gate clearly flagged
- Sentinel blocks visible

---

## STMVault Context

**Pointer**:
- Type: `view`
- Path: `vaults/stmvault/cards/greenfield/frontend/CARD-V6B-P2-FE-MC-SENTINELS-VIEW.md`
- Title: "MC & Sentinel Separation View"

---

## Acceptance Criteria

- [ ] Each card row shows: MC score (0–10), MC gate, gate result (pass/hold), Sentinel status
- [ ] Cards below gate are visually flagged and cannot be misread as "safe"
- [ ] View supports filtering by "held by MC" and "blocked by Sentinel"
- [ ] Use compact visual language (e.g., bar + line) rather than dense text
- [ ] MC comes from MC engine, not recomputed in UI
- [ ] Table per card type (LEGO, Agent, Core, Doctrine)
- [ ] Last drift check timestamp displayed

---

**Blocking Dependencies**: `CARD-V6B-P2-FE-DOCTRINE`, `CARD-V6B-P2-FE-DATA-ADAPTERS`, `CARD-V6B-P2-FE-STATE-MANAGEMENT`  
**Blocks Tasks**: None

