# CARD-V6B-P2-FE-ERROR-EMPTY-STATES

**Card ID**: `CARD-V6B-P2-FE-ERROR-EMPTY-STATES`  
**Type**: System  
**MC Score**: 8.40  
**MC Target**: 8.40  
**Status**: Active  
**Created**: 2025-01-27  
**North Star Link**: `NORTH-STAR-V6`

---

## Summary

Implements error boundaries, retry prompts, and explicit Greenfield empty states when cards or doctrine are missing or misconfigured. Fail safely and legibly when backend data or Greenfield scope is not available.

---

## North Star

Fail safely and legibly when backend data or Greenfield scope is not available. When Greenfield assumptions are broken, the UI tells you *which contract failed*, in human language, not technical jargon.

---

## Main Question

**What question does this view answer?**  
"What went wrong, and which contract failed?"

---

## What

Implement error handling for:
- Error boundaries: catch and display errors gracefully
- Empty states: when 29 cards not found, Agent Soul Pack missing, etc.
- Retry prompts: for transient failures
- Contract failure messages: plain language explanations

---

## Why

The proof of workflow includes how the system behaves when the contract is broken. Users need clear, actionable error messages, not stack traces.

---

## Guarantees

**What must be visible:**
- Which contract failed (29 cards missing, Soul Pack missing, etc.)
- Plain language explanation
- Actionable next steps (if any)

**What cannot be hidden:**
- Error details (in human-readable form)
- Contract failures

**What must never happen:**
- Blank screens on errors
- Technical jargon in error messages
- Silent failures
- Crashes without error boundaries

---

## Constraints

- If the 29 cards are not found, a clear "Greenfield configuration incomplete" banner appears
- If Agent Soul Pack is missing, Agent Soul view explains the missing doctrine instead of crashing
- All views show friendly empty states rather than blank screens
- Error messages use plain language, not technical jargon

---

## MC Scoring (12-Bin Cognitive Framework)

**Composite MC Score**: 8.40

| Bin | Score | Rationale |
|-----|-------|-----------|
| signal | 8.5 | Clear error handling requirements |
| memory_short | 8.4 | References FE-DOCTRINE |
| mental_state | 8.3 | Aligned with operator needs (clear errors) |
| bias_good | 8.4 | Positive assumptions about error clarity |
| bias_bad | 8.2 | Awareness of error handling complexity |
| memory_long | 8.4 | Links to existing error patterns |
| knowledge | 8.5 | Leverages existing error boundary patterns |
| education | 8.3 | Well-documented error states |
| priority | 8.4 | Strategic alignment (user experience) |
| ethos | 8.5 | Strong v6.0 vision alignment (calm until critical) |
| drift | 8.3 | Scope adherence (error handling only) |
| execution_risk | 8.2 | Medium risk (error handling edge cases) |

**MC Validation Note**: Score reflects error handling system with plain language messages. Primary focus: execution_risk, secondary: drift.

---

## Sentinel Policy

**CRITICAL**: Error clarity

**Sentinel Checks**:
1. **No Blank Screens**: All errors show messages
2. **Plain Language**: No technical jargon
3. **Contract Identification**: Which contract failed is clear
4. **Error Boundaries**: Crashes caught and displayed
5. **Empty States**: Missing data shows friendly messages

**Testability**:
- Unit tests: verify error boundaries catch errors
- Integration tests: verify empty states display correctly
- User tests: verify error messages are understandable

---

## Architecture Boundaries

**In Scope**:
- Error boundary implementation
- Empty state components
- Error message formatting (plain language)
- Retry logic for transient failures

**Out of Scope**:
- Backend error handling (backend concern)
- Complex error recovery (Phase 2)
- Error analytics (Phase 2)

**Data Flows**:
```
Error → Error Boundary → Plain Language Message → User
Missing Data → Empty State → Friendly Message → User
Transient Failure → Retry Prompt → Retry Action → User
```

---

## Dependencies

**Required Cards**: 
- `CARD-V6B-P2-FE-DOCTRINE` (doctrine reference)
- `CARD-V6B-P2-FE-NAV-SHELL` (navigation context)

**Dependent Cards**: 
- All view cards (use error boundaries and empty states)

**Build Order**: Foundation layer (after navigation, before views)

---

## North Star Alignment

**Truth**: Provides accurate, reliable error information  
**Clarity**: Clear error messages  
**Progress**: Enables error recovery  
**Precision**: Precise contract failure identification

**Project Alignment**: Critical for Greenfield frontend user experience.

---

## Evidence Citations

- FE-DOCTRINE: "calm until critical" principle
- User requirement: "which contract failed, in human language"

---

## Contrarian Analysis

**Failure Modes**:
1. Blank screens → user confusion
2. Technical jargon → user frustration
3. Silent failures → undetected problems
4. Missing error boundaries → crashes

**Alternatives Considered**:
- No error handling (rejected: violates user experience)
- Technical error messages (rejected: violates plain language)

**Hidden Assumptions**:
- Users can read English
- Error boundaries technically feasible

---

## Steel-Man Mitigation

**Strengthened Arguments**:
- Error handling improves user experience
- Plain language messages reduce confusion
- Contract identification helps debugging

**Risk Mitigation**:
1. Comprehensive error testing
2. User testing for message clarity
3. Error boundary testing
4. Empty state testing

**Enhanced Criteria**:
- Zero blank screens on errors
- 100% plain language error messages
- All contract failures identified
- Error boundaries catch all crashes

---

## STMVault Context

**Pointer**:
- Type: `system`
- Path: `vaults/stmvault/cards/greenfield/frontend/CARD-V6B-P2-FE-ERROR-EMPTY-STATES.md`
- Title: "Error Boundaries & Empty States"

---

## Acceptance Criteria

- [ ] If the 29 cards are not found, a clear "Greenfield configuration incomplete" banner appears
- [ ] If Agent Soul Pack is missing, Agent Soul view explains the missing doctrine instead of crashing
- [ ] All views show friendly empty states rather than blank screens
- [ ] Error boundaries catch and display errors gracefully
- [ ] Error messages use plain language, not technical jargon
- [ ] Retry prompts for transient failures
- [ ] Contract failures clearly identified

---

**Blocking Dependencies**: `CARD-V6B-P2-FE-DOCTRINE`, `CARD-V6B-P2-FE-NAV-SHELL`  
**Blocks Tasks**: All frontend view cards

