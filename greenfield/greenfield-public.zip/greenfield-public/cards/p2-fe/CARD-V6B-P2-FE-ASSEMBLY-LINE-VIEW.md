# CARD-V6B-P2-FE-ASSEMBLY-LINE-VIEW

**Card ID**: `CARD-V6B-P2-FE-ASSEMBLY-LINE-VIEW`  
**Type**: View  
**MC Score**: 8.55  
**MC Target**: 8.55  
**Status**: Active  
**Created**: 2025-01-27  
**North Star Link**: `NORTH-STAR-V6`

---

## Summary

Builds a visual representation of how cards move through the six agents, including which agents have processed which cards and where items are currently paused. Shows Caretaker → Gardener → Mercury → Sentinel → Conductor → Scribe as a real assembly line.

---

## North Star

Show Caretaker → Gardener → Mercury → Sentinel → Conductor → Scribe as a real assembly line. The Greenfield test must demonstrate that the assembly line respects agent lanes, not just that code runs.

---

## Main Question

**What question does this view answer?**  
"How do cards move through the crew?"

---

## What

Implement visual representation that:
- Shows six agents in canonical order on one axis (Caretaker → Gardener → Mercury → Sentinel → Conductor → Scribe)
- Shows recent card runs with which stages are complete for each card
- Visually distinguishes Sentinel blocks and defers from "not yet processed"
- Shows current stage for each card
- Displays agent availability/status

---

## Why

The Greenfield test must demonstrate that the assembly line respects agent lanes, not just that code runs. This view shows that the six souls are actually doing their jobs in the correct order.

---

## Guarantees

**What must be visible:**
- Six agents in canonical order
- Card processing history (which agents processed which cards)
- Current stage for each card
- Sentinel blocks and defers (visually distinct)
- Agent availability/status

**What cannot be hidden:**
- Agent order violations
- Cards stuck in processing
- Sentinel blocks

**What must never happen:**
- Showing agents out of canonical order
- Hiding Sentinel blocks
- Showing cards that don't exist

---

## Constraints

- The six agents appear in canonical order on one axis
- Recent card runs show which stages are complete for each card
- Sentinel blocks and defers are visually distinct from "not yet processed"
- Initial implementation can be a simple table or swimlane; full graph view is optional

---

## MC Scoring (12-Bin Cognitive Framework)

**Composite MC Score**: 8.55

| Bin | Score | Rationale |
|-----|-------|-----------|
| signal | 8.6 | Clear assembly line requirements |
| memory_short | 8.5 | References FE-DOCTRINE and agent order |
| mental_state | 8.5 | Aligned with pilot mental model |
| bias_good | 8.6 | Positive assumptions about clarity |
| bias_bad | 8.4 | Awareness of visualization complexity |
| memory_long | 8.5 | Links to Agent Soul Pack and assembly line |
| knowledge | 8.6 | Leverages existing visualization patterns |
| education | 8.4 | Well-documented agent order |
| priority | 8.6 | Strategic alignment (assembly line proof) |
| ethos | 8.6 | Strong v6.0 vision alignment |
| drift | 8.4 | Scope adherence (simple visualization) |
| execution_risk | 8.3 | Medium risk (visualization complexity) |

**MC Validation Note**: Score reflects assembly line visualization showing agent order and card flow. Primary focus: execution_risk, secondary: drift.

---

## Sentinel Policy

**CRITICAL**: Agent order integrity

**Sentinel Checks**:
1. **Canonical Order**: Agents displayed in correct order
2. **Card Accuracy**: Only real cards shown
3. **Sentinel Visibility**: Blocks and defers visible
4. **Stage Accuracy**: Current stages match backend
5. **No Order Violations**: Agents never shown out of order

**Testability**:
- Unit tests: verify agent order correct
- Integration tests: verify card stages match backend
- Visual tests: verify Sentinel blocks visible
- Order tests: verify no order violations

---

## Architecture Boundaries

**In Scope**:
- Agent order visualization
- Card processing history
- Current stage display
- Sentinel block indicators
- Agent availability/status

**Out of Scope**:
- Complex graph visualization (Phase 2)
- Historical trends (Phase 2)
- Agent editing (read-only in Greenfield)

**Data Flows**:
```
Backend Assembly Line → Assembly Line View → Visualization
Card Processing History → Stage Display → Agent Progress
Sentinel Blocks → Visual Indicators → Block Display
```

---

## Dependencies

**Required Cards**: 
- `CARD-V6B-P2-FE-DOCTRINE` (doctrine reference)
- `CARD-V6B-P2-FE-DATA-ADAPTERS` (assembly line data)
- `CARD-V6B-P2-FE-STATE-MANAGEMENT` (filter state)

**Dependent Cards**: None (leaf view)

**Build Order**: View layer (after infrastructure)

---

## North Star Alignment

**Truth**: Provides accurate, reliable assembly line visualization  
**Clarity**: Clear agent order and card flow  
**Progress**: Enables assembly line monitoring  
**Precision**: Precise stage and block display

**Project Alignment**: Critical for Greenfield assembly line demonstration.

---

## Evidence Citations

- Agent Soul Pack (`CARD-V6B-P0-AGENT-SOUL`): canonical agent order
- Backend assembly line processor
- FE-DOCTRINE: "one concept, one place"

---

## Contrarian Analysis

**Failure Modes**:
1. Agents out of order → violates canonical order
2. Missing Sentinel blocks → hides critical information
3. Incorrect stages → misrepresents card status
4. Poor visualization → user confusion

**Alternatives Considered**:
- Complex graph (rejected: violates simple visualization)
- No visualization (rejected: violates clarity requirement)

**Hidden Assumptions**:
- Backend assembly line data available
- Agent order stable

---

## Steel-Man Mitigation

**Strengthened Arguments**:
- Assembly line view proves agent order respected
- Visualization improves clarity
- Sentinel blocks provide critical information

**Risk Mitigation**:
1. Comprehensive order testing
2. Stage accuracy testing
3. Visualization testing
4. User testing for clarity

**Enhanced Criteria**:
- Agents always in canonical order
- Card stages match backend
- Sentinel blocks visible
- Visualization clear and readable

---

## STMVault Context

**Pointer**:
- Type: `view`
- Path: `vaults/stmvault/cards/greenfield/frontend/CARD-V6B-P2-FE-ASSEMBLY-LINE-VIEW.md`
- Title: "Assembly Line Flow View"

---

## Acceptance Criteria

- [ ] The six agents appear in canonical order on one axis
- [ ] Recent card runs show which stages are complete for each card
- [ ] Sentinel blocks and defers are visually distinct from "not yet processed"
- [ ] Current stage for each card displayed
- [ ] Agent availability/status shown
- [ ] Simple table or swimlane visualization (full graph optional)

---

**Blocking Dependencies**: `CARD-V6B-P2-FE-DOCTRINE`, `CARD-V6B-P2-FE-DATA-ADAPTERS`, `CARD-V6B-P2-FE-STATE-MANAGEMENT`  
**Blocks Tasks**: None

