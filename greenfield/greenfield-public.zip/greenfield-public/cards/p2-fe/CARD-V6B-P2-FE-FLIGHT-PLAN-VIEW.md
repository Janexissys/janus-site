# CARD-V6B-P2-FE-FLIGHT-PLAN-VIEW

**Card ID**: `CARD-V6B-P2-FE-FLIGHT-PLAN-VIEW`  
**Type**: View  
**MC Score**: 8.70  
**MC Target**: 8.70  
**Status**: Active  
**Created**: 2025-01-27  
**North Star Link**: `NORTH-STAR-V6`

---

## Summary

Builds a summary view that displays overall progress on the 29 cards + Soul Pack, MC averages, and pass/fail on explicit Greenfield success criteria. Shows in one glance whether the Greenfield contract is being honoured.

---

## North Star

Show in one glance whether the Greenfield contract is being honoured. This is the "are we still flying the plan" screen for the pilot and for demos.

---

## Main Question

**What question does this view answer?**  
"Are we still flying the Greenfield contract?"

---

## What

Build overview view that displays:
- Card counts by type (LEGO: 13, Agent: 6, Core: 10, Doctrine: 1)
- Pass/fail indicators for success criteria:
  - All 29 cards exist
  - All agent cards have `soul_ref`
  - All MC ≥ 8.50
  - No extra cards outside the 29
- MC averages per card type
- Overall health status

---

## Why

This is the "are we still flying the plan" screen for the pilot and for demos. Answers whether Greenfield contract is intact or drifted.

---

## Guarantees

**What must be visible:**
- Card counts by type
- Pass/fail indicators for all success criteria
- MC averages per type
- Overall health status

**What cannot be hidden:**
- Contract failures (if any)
- Missing cards
- MC scores below threshold

**What must never happen:**
- Showing cards that don't exist in backend
- Hiding contract failures
- Recomputing MC scores (must come from backend)

---

## Constraints

- Shows at most three primary KPIs; detail moves to drawers or tooltips
- Designed to be readable at 3m on a large screen
- Data comes from backend cards, not recomputed
- Pass/fail indicators use severity colours (green/red)

---

## MC Scoring (12-Bin Cognitive Framework)

**Composite MC Score**: 8.70

| Bin | Score | Rationale |
|-----|-------|-----------|
| signal | 8.8 | Clear overview requirements |
| memory_short | 8.7 | References FE-DOCTRINE and backend cards |
| mental_state | 8.7 | Aligned with pilot mental model |
| bias_good | 8.8 | Positive assumptions about clarity |
| bias_bad | 8.6 | Awareness of data accuracy risks |
| memory_long | 8.7 | Links to v6.0 overview patterns |
| knowledge | 8.8 | Leverages existing dashboard patterns |
| education | 8.6 | Well-documented success criteria |
| priority | 8.8 | Strategic alignment (contract validation) |
| ethos | 8.9 | Strong v6.0 vision alignment |
| drift | 8.6 | Scope adherence (overview only) |
| execution_risk | 8.5 | Medium risk (data aggregation) |

**MC Validation Note**: Score reflects overview view that validates Greenfield contract. Primary focus: ethos, secondary: signal.

---

## Sentinel Policy

**CRITICAL**: Contract validation

**Sentinel Checks**:
1. **Data Accuracy**: Card counts match backend
2. **MC Source**: MC scores from backend, not recomputed
3. **Contract Validation**: All success criteria checked
4. **No Hidden Failures**: Contract failures visible
5. **Readability**: Readable at 3m

**Testability**:
- Unit tests: verify card counts correct
- Integration tests: verify MC averages correct
- Visual tests: verify readable at 3m
- Contract tests: verify all success criteria checked

---

## Architecture Boundaries

**In Scope**:
- Card count display
- Pass/fail indicators
- MC averages
- Overall health status

**Out of Scope**:
- Individual card details (delegated to Cards Board view)
- Historical trends (Phase 2)
- Drill-down to specific cards (delegated to Cards Board view)

**Data Flows**:
```
Backend Cards → Flight Plan View → Aggregated Display
Success Criteria → Validation → Pass/Fail Indicators
MC Scores → Aggregation → MC Averages
```

---

## Dependencies

**Required Cards**: 
- `CARD-V6B-P2-FE-DOCTRINE` (doctrine reference)
- `CARD-V6B-P2-FE-DATA-ADAPTERS` (card data)
- `CARD-V6B-P2-FE-STATE-MANAGEMENT` (filter state)

**Dependent Cards**: None (leaf view)

**Build Order**: View layer (after infrastructure)

---

## North Star Alignment

**Truth**: Provides accurate, reliable contract validation  
**Clarity**: Clear pass/fail indicators  
**Progress**: Enables contract monitoring  
**Precision**: Precise success criteria checking

**Project Alignment**: Critical for Greenfield contract validation.

---

## Evidence Citations

- Backend 29 cards
- Agent Soul Pack (`CARD-V6B-P0-AGENT-SOUL`)
- Success criteria: all 29 present, MC ≥ 8.5, soul_ref present, no extras

---

## Contrarian Analysis

**Failure Modes**:
1. Incorrect card counts → false contract status
2. Hidden contract failures → false sense of security
3. MC recomputation → drift from backend truth
4. Unreadable at 3m → fails usability requirement

**Alternatives Considered**:
- Detailed card list (rejected: violates "at most three KPIs")
- No pass/fail indicators (rejected: violates clarity requirement)

**Hidden Assumptions**:
- Backend cards available
- MC scores available from backend

---

## Steel-Man Mitigation

**Strengthened Arguments**:
- Overview enables quick contract validation
- Pass/fail indicators provide clear status
- MC averages show overall health

**Risk Mitigation**:
1. Comprehensive data accuracy testing
2. Contract validation testing
3. Readability testing at 3m
4. User testing for clarity

**Enhanced Criteria**:
- Card counts 100% accurate
- All success criteria checked
- MC averages from backend only
- Readable at 3m

---

## STMVault Context

**Pointer**:
- Type: `view`
- Path: `vaults/stmvault/cards/greenfield/frontend/CARD-V6B-P2-FE-FLIGHT-PLAN-VIEW.md`
- Title: "Flight Plan Overview View"

---

## Acceptance Criteria

- [ ] Shows count of cards by type (LEGO, Agent, Core System, Doctrine)
- [ ] Shows pass/fail flags for: all 29 present, all MC ≥ 8.5, all agents have soul_ref, no extra cards
- [ ] Displays at most three primary KPIs; detail moves to drawers or tooltips
- [ ] Designed to be readable at 3m on a large screen
- [ ] MC averages per card type
- [ ] Overall health status
- [ ] Data comes from backend, not recomputed

---

**Blocking Dependencies**: `CARD-V6B-P2-FE-DOCTRINE`, `CARD-V6B-P2-FE-DATA-ADAPTERS`, `CARD-V6B-P2-FE-STATE-MANAGEMENT`  
**Blocks Tasks**: None

