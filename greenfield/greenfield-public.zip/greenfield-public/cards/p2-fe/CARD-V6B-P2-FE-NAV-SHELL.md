# CARD-V6B-P2-FE-NAV-SHELL

**Card ID**: `CARD-V6B-P2-FE-NAV-SHELL`  
**Type**: System  
**MC Score**: 8.60  
**MC Target**: 8.60  
**Status**: Active  
**Created**: 2025-01-27  
**North Star Link**: `NORTH-STAR-V6`

---

## Summary

Implements the top-level navigation for the Greenfield dashboard, including the tab bar, project selector (Greenfield vs other projects), and mode indicator (v6_basic vs v6_greenfield). Makes "I am in Greenfield mode" obvious and frictionless.

---

## North Star

Make Greenfield v6.0 a first-class mode, with clear tabbing between core views. Switching views must feel like walking around one machine, not entering new apps.

---

## Main Question

**What question does this view answer?**  
"Where am I? What mode am I in?"

---

## What

Implement the top-level navigation for the Greenfield dashboard:
- Tab bar with 6 core views: Flight Plan, Cards Board, Agent Soul Pack, Assembly Line, MC & Sentinels, Run Log
- Project selector: Greenfield vs other projects
- Mode indicator: v6_basic vs v6_greenfield badge/label
- State preservation: filters and selection persist across tab switches

---

## Why

The system must visibly switch into "Greenfield contract" mode so that the pilot knows they are looking at the 29-card game board, not legacy structures. Navigation should feel unified, not fragmented.

---

## Guarantees

**What must be visible:**
- Current active tab clearly indicated
- Greenfield mode badge/label visible when active
- Project selector accessible
- All 6 core views accessible from navigation

**What cannot be hidden:**
- Current mode (v6_greenfield vs v6_basic)
- Current project context
- Available views

**What must never happen:**
- Losing filter/selection state when switching tabs unexpectedly
- Hidden navigation requiring multiple clicks
- Mode switching without clear visual feedback

---

## Constraints

- Keep navigation minimal; avoid nested menus for this phase
- Navigation must work with keyboard (tab navigation)
- Mode indicator must be readable at 3m
- State preservation must be predictable and reliable

---

## MC Scoring (12-Bin Cognitive Framework)

**Composite MC Score**: 8.60

| Bin | Score | Rationale |
|-----|-------|-----------|
| signal | 8.7 | Clear navigation requirements |
| memory_short | 8.6 | References FE-DOCTRINE |
| mental_state | 8.5 | Aligned with operator mental model |
| bias_good | 8.6 | Positive assumptions about clarity |
| bias_bad | 8.4 | Awareness of state management risks |
| memory_long | 8.6 | Links to v6.0 navigation patterns |
| knowledge | 8.7 | Leverages existing navigation patterns |
| education | 8.5 | Well-documented navigation structure |
| priority | 8.6 | Strategic alignment (foundation for views) |
| ethos | 8.7 | Strong v6.0 vision alignment |
| drift | 8.5 | Scope adherence (minimal navigation) |
| execution_risk | 8.4 | Medium risk (state management complexity) |

**MC Validation Note**: Score reflects foundational navigation system with state preservation. Primary focus: execution_risk, secondary: drift.

---

## Sentinel Policy

**CRITICAL**: Navigation integrity

**Sentinel Checks**:
1. **Mode Clarity**: Current mode always visible
2. **State Preservation**: Filters/selection persist across tabs
3. **Accessibility**: Keyboard navigation works
4. **No Hidden Views**: All 6 views accessible
5. **Visual Feedback**: Mode changes provide clear feedback

**Testability**:
- Manual test: switch tabs, verify state preserved
- Keyboard test: tab through navigation
- Visual test: mode indicator visible at 3m
- State test: verify filters persist across tab switches

---

## Architecture Boundaries

**In Scope**:
- Tab bar implementation
- Mode indicator
- Project selector
- State preservation logic

**Out of Scope**:
- View content (delegated to view cards)
- Deep linking implementation (Phase 2)
- Nested navigation menus

**Data Flows**:
```
User Action → Navigation Shell → View Selection → State Update
Mode Change → Visual Feedback → View Refresh
```

---

## Dependencies

**Required Cards**: 
- `CARD-V6B-P2-FE-DOCTRINE` (doctrine reference)

**Dependent Cards**: 
- All view cards (FE-FLIGHT-PLAN-VIEW, FE-CARDS-BOARD-VIEW, etc.)

**Build Order**: Foundation layer (after doctrine, before views)

---

## North Star Alignment

**Truth**: Provides accurate, reliable navigation  
**Clarity**: Clear mode and view indication  
**Progress**: Enables view access  
**Precision**: Precise state preservation

**Project Alignment**: Critical for Greenfield frontend foundation.

---

## Evidence Citations

- FE-DOCTRINE: navigation principles
- User requirement: "obvious and frictionless" mode switching

---

## Contrarian Analysis

**Failure Modes**:
1. State loss → user frustration
2. Hidden navigation → poor discoverability
3. Mode confusion → wrong context displayed
4. Keyboard inaccessibility → accessibility failure

**Alternatives Considered**:
- Nested menus (rejected: violates minimal navigation)
- No mode indicator (rejected: violates clarity requirement)

**Hidden Assumptions**:
- Users understand tab-based navigation
- State preservation is technically feasible

---

## Steel-Man Mitigation

**Strengthened Arguments**:
- Navigation is foundation for all views
- State preservation improves user experience
- Mode clarity prevents context confusion

**Risk Mitigation**:
1. Comprehensive state management testing
2. Keyboard navigation testing
3. Visual feedback validation
4. User testing for mode clarity

**Enhanced Criteria**:
- State preservation 100% reliable
- Keyboard navigation fully functional
- Mode indicator visible at 3m
- All 6 views accessible in ≤2 clicks

---

## STMVault Context

**Pointer**:
- Type: `system`
- Path: `vaults/stmvault/cards/greenfield/frontend/CARD-V6B-P2-FE-NAV-SHELL.md`
- Title: "Navigation Shell & Mode Switch"

---

## Acceptance Criteria

- [ ] Tabs exist for: Flight Plan, Cards Board, Agent Soul Pack, Assembly Line, MC & Sentinels, Run Log
- [ ] Clear badge or label shows "Greenfield v6.0" when that mode is active
- [ ] Switching project/mode does not lose current filters or selection state unexpectedly
- [ ] Keyboard navigation works for tab switching
- [ ] Mode indicator readable at 3m
- [ ] All 6 views accessible from navigation

---

**Blocking Dependencies**: `CARD-V6B-P2-FE-DOCTRINE`  
**Blocks Tasks**: All frontend view cards

