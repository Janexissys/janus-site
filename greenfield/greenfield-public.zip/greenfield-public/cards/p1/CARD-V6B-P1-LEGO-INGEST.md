# CARD-V6B-P1-LEGO-INGEST

**Card ID**: `CARD-V6B-P1-LEGO-INGEST`  
**Type**: LEGO Block  
**MC Score**: 8.60  
**MC Target**: 8.60  
**Status**: Active  
**Created**: 2025-11-14

---

## Purpose

IngestBlock provides the canonical ingest access point for all content ingestion into Janus OS. It processes files, validates ingest policy, and routes content to appropriate memory systems.

---

## MC Scoring (12-Bin Cognitive Framework)

**Composite MC Score**: 8.60

| Bin | Score | Rationale |
|-----|-------|-----------|
| signal | 8.7 | Clear ingest pipeline specification |
| memory_short | 8.5 | STM ingestion coordination |
| mental_state | 8.5 | Team familiarity with ingest systems |
| bias_good | 8.4 | Positive assumptions about ingest reliability |
| bias_bad | 8.3 | Awareness of ingest policy validation risks |
| memory_long | 8.5 | LTM ingestion coordination |
| knowledge | 8.6 | Leverages existing ingest patterns |
| education | 8.5 | Well-documented ingest architecture |
| priority | 8.7 | Critical for content ingestion |
| ethos | 8.6 | Aligned with v6.0 ingest architecture |
| drift | 8.4 | Stable ingest interface contracts |
| execution_risk | 8.3 | Moderate risk due to policy validation complexity |

**MC Validation Note**: Score reflects critical ingest functionality with awareness of policy validation risks. Primary focus: execution_risk (policy validation), secondary: bias_bad (ingest failures).

---

## Sentinel Policy

**CRITICAL**: Ingest policy validation

**Sentinel Checks**:
1. **Policy Validation**: All ingested content must pass North Star ingest policy
2. **File Type Validation**: Only allowed file types can be ingested
3. **Size Limits**: File size limits enforced to prevent DoS
4. **Malware Scanning**: Ingested files scanned for malware
5. **PII Detection**: Ingested content scanned for PII before storage

**Testability**:
- Unit tests verify policy validation on all ingest operations
- Integration tests validate file type and size enforcement
- Security tests confirm malware scanning
- E2E tests verify PII detection before storage

---

## Architecture Boundaries

**In Scope**:
- Canonical ingest access point
- Ingest policy validation
- File processing and parsing
- Batch processing coordination

**Out of Scope**:
- Storage implementation (delegated to MemoryBlock/VaultBlock)
- PII detection algorithms (delegated to Sentinel Agent)
- Memory promotion logic (delegated to MemoryBlock)

**Data Flows**:
```
Files → IngestBlock → Policy Validation → MemoryBlock → STM/LTM
IngestBlock → BatchBlock (batch processing)
IngestBlock → Sentinel Agent (PII detection)
```

---

## Dependencies

**Required Blocks**: None (foundational block)

**Dependent Blocks**:
- Uses VaultBlock for file access
- Uses MemoryBlock for storage
- Uses BatchBlock for batch processing

**Build Order**: Foundation layer (no dependencies, but uses other foundation blocks)

---

## North Star Alignment

**Truth**: Ingest system validates all content against North Star ingest policy  
**Clarity**: Clear ingest pipeline with policy enforcement  
**Progress**: Enables reliable content ingestion  
**Precision**: Precise policy validation and file processing

**Project Alignment**: Critical for content ingestion - ensures all ingested content aligns with North Star.

---

## Evidence Citations

- `backend/janus/app/lego_registry/blocks/ingest.py:L1-57` - IngestBlock implementation
- `backend/janus/app/services/ingest_jobs.py` - IngestJobManager implementation
- `backend/janus/app/core/vault_adapter.py:L1-57` - Vault adapter integration
- `config/north_star_meta.yaml` - Ingest policy specification

---

## Contrarian Analysis

**Failure Modes**:
1. Policy validation bypass → non-compliant content ingested
2. File parsing errors → content loss or corruption
3. Batch processing failures → ingestion backlog
4. PII leaks through ingest → security breach

**Alternatives Considered**:
- Multiple ingest points (rejected: need single canonical point)
- No policy validation (rejected: violates North Star)

**Hidden Assumptions**:
- Policy validation is comprehensive
- File parsing is reliable
- Batch processing can handle load

---

## Steel-Man Mitigation

**Strengthened Arguments**:
- Canonical ingest point ensures consistent policy enforcement
- Policy validation prevents non-compliant content ingestion
- Batch processing enables efficient bulk ingestion

**Risk Mitigation**:
1. Comprehensive policy validation testing
2. Robust file parsing with error handling
3. Batch processing with retry mechanisms
4. PII detection before all storage operations

**Enhanced Criteria**:
- Policy validation enforcement 100% (zero bypasses)
- File parsing success rate ≥99%
- Batch processing handles 1000+ files without errors
- Zero PII leaks through ingest pipeline

---

## STMVault Context

**Pointer**:
- Type: `task_spec`
- Path: `vaults/stmvault/01-Architecture/Core-System/Ingest-System-Architecture.md`
- Title: "Ingest System Architecture - Canonical Access Point"

---

## Acceptance Criteria

- [ ] IngestBlock provides canonical ingest access point
- [ ] Ingest policy validation enforced on all content
- [ ] File type and size limits enforced
- [ ] Malware scanning works correctly
- [ ] PII detection prevents sensitive data ingestion
- [ ] Batch processing coordination works correctly
- [ ] Health monitoring reports ingest system status
- [ ] All Sentinel checks pass (policy, file type, size, malware, PII)

---

**Blocking Dependencies**: None (foundational block)  
**Blocks Tasks**: None (enables other systems but doesn't block)

