# CARD-V6B-P1-COMP-MC_ENGINE

**Card ID**: `CARD-V6B-P1-COMP-MC_ENGINE`  
**Type**: Core System  
**MC Score**: 8.70  
**MC Target**: 8.70  
**Status**: Active  
**Created**: 2025-11-14

---

## Purpose

MC Engine & 12-Bin System implements the complete 12-bin cognitive framework for Meta-Cognitive scoring. **CRITICAL REQUIREMENT**: Must separate MC Gate Score (backend complexity/quality gate) from Confidence Score (user-facing alignment/certainty).

---

## MC Scoring (12-Bin Cognitive Framework)

**Composite MC Score**: 8.70

| Bin | Score | Rationale |
|-----|-------|-----------|
| signal | 8.8 | Clear 12-bin cognitive framework specification |
| memory_short | 8.7 | STM integration for MC scoring |
| mental_state | 8.6 | Mental state tracking in MC bins |
| bias_good | 8.7 | Good bias detection in MC bins |
| bias_bad | 8.7 | Bad bias detection in MC bins |
| memory_long | 8.7 | LTM integration for MC scoring |
| knowledge | 8.8 | Knowledge application in MC bins |
| education | 8.6 | Education validation in MC bins |
| priority | 8.9 | Critical for cognitive OS operation |
| ethos | 8.8 | Aligned with v6.0 cognitive architecture |
| drift | 8.6 | Drift monitoring in MC bins |
| execution_risk | 8.5 | Moderate risk due to separation complexity |

**MC Validation Note**: Score reflects comprehensive cognitive framework with awareness of separation complexity. Primary focus: execution_risk (MC/Confidence separation), secondary: drift (MC score consistency).

---

## Sentinel Policy

**CRITICAL**: MC score misuse (gate score displayed as confidence, or vice versa)

**Sentinel Checks**:
1. **Score Separation**: MC Gate Score and Confidence Score must be clearly separated
2. **Gate Score Usage**: Gate score only used for backend routing/memory promotion
3. **Confidence Score Usage**: Confidence score only used for user-facing display
4. **Score Validation**: Both scores validated independently
5. **Display Validation**: Frontend must display confidence score, not gate score

**Testability**:
- Unit tests verify score separation in MC engine
- Integration tests validate gate score used for backend routing
- E2E tests confirm confidence score displayed to users
- Sentinel tests verify no score misuse

---

## Architecture Boundaries

**In Scope**:
- 12-bin cognitive framework implementation
- MC Gate Score calculation (backend complexity/quality)
- Confidence Score calculation (user-facing alignment/certainty)
- Score separation and validation
- MC bin orchestration

**Out of Scope**:
- LLM provider (delegated to CognitiveBlock)
- Memory storage (delegated to MemoryBlock)
- User display (delegated to Frontend)

**Data Flows**:
```
Content → MC Engine → 12-Bin Analysis → MC Gate Score (backend) + Confidence Score (user)
MC Gate Score → Backend Routing/Memory Promotion
Confidence Score → User Display
```

---

## Dependencies

**Required Blocks**:
- `CARD-V6B-P1-LEGO-COGNITIVE` (CognitiveBlock) - LLM provider
- `CARD-V6B-P1-LEGO-MEMORY` (MemoryBlock) - Memory integration

**Dependent Blocks**:
- All agents use MC scores for decision-making
- Assembly Line uses MC scores for routing

**Build Order**: Can build after CognitiveBlock and MemoryBlock

---

## North Star Alignment

**Truth**: MC system provides accurate cognitive assessment  
**Clarity**: Clear separation between gate score and confidence score  
**Progress**: Enables cognitive OS operation  
**Precision**: Precise 12-bin cognitive framework

**Project Alignment**: Critical for cognitive OS - enables self-reflective AI operation.

---

## Critical Architecture Decision: MC Separation

**Problem**: MC currently doing two jobs:
1. MC Gate Score = complexity/quality gate (backend routing, memory promotion)
2. Confidence Score = user-facing certainty (alignment with goals, right answer)

**Issue**: Lower MC (low complexity) = good for system, but appears as "not confident" to users.

**Solution**: Must separate:
- **MC Gate Score** (backend): Complexity/quality gate for routing, memory promotion, quality gates
- **Confidence Score** (user-facing): Alignment with goals, right answer, trust/transparency

**Architecture Decision**: Single unified system - either:
- Integrate DualCognitiveScoring features into MCEngine, OR
- Replace MCEngine with clean DualCognitiveScoring implementation

**No Legacy Mess**: Greenfield must be clean - no importing deprecated/test repo code. Either integrate features OR replace with clean implementation.

---

## Evidence Citations

- `backend/janus/app/services/mc_engine.py:L128-413` - MCEngine implementation
- `backend/janus/app/services/mc_system/core/mc_engine.py:L56-372` - MC Engine core
- `backend/janus/vendor/core/cognitive_systems/dual_cognitive_scoring.py:L1-523` - DualCognitiveScoring reference
- `backend/janus/app/core/quality_gates.py:L1-44` - Quality gates integration

---

## Contrarian Analysis

**Failure Modes**:
1. Score separation fails → gate score displayed as confidence (user confusion)
2. MC calculation errors → incorrect routing/promotion decisions
3. 12-bin framework complexity → performance issues
4. Legacy code import → technical debt

**Alternatives Considered**:
- Keep unified MC score (rejected: causes user confusion)
- Separate systems (rejected: violates single unified system requirement)

**Hidden Assumptions**:
- Score separation is feasible
- DualCognitiveScoring can be integrated cleanly
- Performance impact is acceptable

---

## Steel-Man Mitigation

**Strengthened Arguments**:
- MC separation is essential for user trust and system operation
- 12-bin framework provides comprehensive cognitive assessment
- Single unified system prevents architectural drift

**Risk Mitigation**:
1. Comprehensive score separation testing
2. Clear API boundaries between gate and confidence scores
3. Performance optimization for 12-bin framework
4. Clean implementation (no legacy imports)

**Enhanced Criteria**:
- Score separation enforced 100% (zero misuse)
- MC calculation accuracy ≥95%
- 12-bin framework performance <100ms
- Zero legacy code imports

---

## STMVault Context

**Pointer**:
- Type: `task_spec`
- Path: `vaults/stmvault/01-Architecture/Core-System/MC-Engine-Architecture.md`
- Title: "MC Engine Architecture - 12-Bin Framework with Score Separation"

---

## Acceptance Criteria

- [ ] MC Engine implements 12-bin cognitive framework
- [ ] MC Gate Score and Confidence Score clearly separated
- [ ] Gate score used only for backend routing/memory promotion
- [ ] Confidence score used only for user-facing display
- [ ] Score separation validated in all tests
- [ ] No score misuse (gate score displayed as confidence)
- [ ] Single unified system (integrated OR replaced, no legacy imports)
- [ ] All Sentinel checks pass (separation, usage, validation, display)

---

**Blocking Dependencies**: CognitiveBlock, MemoryBlock  
**Blocks Tasks**: All agents (MC-dependent), Assembly Line (MC routing)

