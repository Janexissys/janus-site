# CARD-V6B-P1-LEGO-MEMORY

**Card ID**: `CARD-V6B-P1-LEGO-MEMORY`  
**Type**: LEGO Block  
**MC Score**: 8.70  
**MC Target**: 8.70  
**Status**: Active  
**Created**: 2025-11-14

---

## Purpose

MemoryBlock coordinates STM (Short-Term Memory) and LTM (Long-Term Memory) systems, providing unified memory services for the Janus OS. It manages memory promotion, retrieval, and coordination between STMVault and LTMVault.

---

## MC Scoring (12-Bin Cognitive Framework)

**Composite MC Score**: 8.70

| Bin | Score | Rationale |
|-----|-------|-----------|
| signal | 8.8 | Clear technical specification, well-defined interfaces |
| memory_short | 8.9 | Direct STM coordination responsibility |
| mental_state | 8.5 | Team familiarity with memory systems |
| bias_good | 8.6 | Positive assumptions about memory reliability |
| bias_bad | 8.4 | Awareness of PII risks in memory storage |
| memory_long | 8.9 | Direct LTM coordination responsibility |
| knowledge | 8.7 | Leverages existing memory patterns |
| education | 8.5 | Well-documented memory architecture |
| priority | 8.6 | High priority for system operation |
| ethos | 8.7 | Aligned with v6.0 memory architecture |
| drift | 8.5 | Stable memory interface contracts |
| execution_risk | 8.4 | Moderate risk due to PII handling |

**MC Validation Note**: Score reflects strong memory coordination capabilities with awareness of PII risks. Primary focus: drift (memory consistency), secondary: execution_risk (PII handling).

---

## Sentinel Policy

**CRITICAL**: PII in memory storage

**Sentinel Checks**:
1. **PII Detection**: All memory writes must be scanned for PII before storage
2. **Access Control**: Memory reads require proper authorization checks
3. **Data Retention**: STM data must be purged according to retention policies
4. **Encryption**: Sensitive memory data must be encrypted at rest
5. **Audit Logging**: All memory access must be logged for security audits

**Testability**:
- Unit tests verify PII detection before memory writes
- Integration tests validate access control on memory reads
- E2E tests confirm data retention policies are enforced

---

## Architecture Boundaries

**In Scope**:
- STM/LTM coordination and promotion logic
- Memory retrieval and search interfaces
- Vector store integration for LTM
- Memory health monitoring

**Out of Scope**:
- Actual storage implementation (delegated to VaultBlock)
- Vector database implementation (delegated to VectorDatabaseBlock)
- PII detection algorithms (delegated to Sentinel Agent)

**Data Flows**:
```
Ingest → MemoryBlock → STM (temporary) → LTM (promoted)
MemoryBlock → VectorDatabaseBlock (indexing)
MemoryBlock → Agents (retrieval)
```

---

## Dependencies

**Required Blocks**:
- `CARD-V6B-P1-LEGO-VAULT` (VaultBlock) - foundational storage

**Dependent Blocks**:
- `CARD-V6B-P1-LEGO-LEARNING` (LearningBlock) - depends on MemoryBlock
- `CARD-V6B-P1-LEGO-ASSEMBLY_LINE` (AssemblyLineBlock) - uses memory

**Build Order**: Second layer (depends on VaultBlock foundation)

---

## North Star Alignment

**Truth**: Memory system provides accurate, reliable access to system knowledge  
**Clarity**: Clear separation between STM (ephemeral) and LTM (persistent)  
**Progress**: Enables learning and knowledge accumulation  
**Precision**: Precise memory retrieval and promotion criteria

**Project Alignment**: Critical for cognitive OS operation - enables agent memory and learning capabilities.

---

## Evidence Citations

- `backend/janus/app/lego_registry/blocks/memory.py:L1-54` - MemoryBlock implementation
- `docs/Diagrams/Memory.mmd:L1-60` - Memory architecture diagram
- `docs/architecture/lego-dependency-graph.mmd:L14-15` - Dependency relationship
- `backend/janus/app/models/memory_database.py:L147-170` - Memory database models

---

## Contrarian Analysis

**Failure Modes**:
1. Memory promotion logic fails → data stuck in STM, lost on restart
2. PII leaks through memory → security breach, compliance violation
3. Vector indexing fails → LTM search becomes unreliable
4. Memory corruption → system loses critical knowledge

**Alternatives Considered**:
- Single-tier memory (rejected: need STM/LTM separation)
- External memory service (rejected: violates LEGO isolation)

**Hidden Assumptions**:
- VaultBlock provides reliable storage
- Vector database is always available
- Memory access patterns are predictable

---

## Steel-Man Mitigation

**Strengthened Arguments**:
- Memory coordination is essential for cognitive OS operation
- STM/LTM separation enables efficient memory management
- Clear boundaries prevent memory system bloat

**Risk Mitigation**:
1. Implement robust error handling for memory promotion failures
2. Comprehensive PII scanning before all memory writes
3. Fallback mechanisms for vector indexing failures
4. Regular memory integrity checks and corruption detection

**Enhanced Criteria**:
- Memory promotion success rate ≥99%
- PII detection accuracy ≥95%
- Memory retrieval latency <100ms for STM, <500ms for LTM
- Zero unencrypted PII in memory storage

---

## STMVault Context

**Pointer**:
- Type: `task_spec`
- Path: `vaults/stmvault/01-Architecture/Core-System/Memory-System-Architecture.md`
- Title: "Memory System Architecture - STM/LTM Coordination"

---

## Acceptance Criteria

- [ ] MemoryBlock coordinates STM and LTM systems
- [ ] Memory promotion logic works correctly (STM → LTM)
- [ ] PII detection prevents sensitive data storage
- [ ] Memory retrieval interfaces function correctly
- [ ] Vector store integration works for LTM indexing
- [ ] Health monitoring reports memory system status
- [ ] All Sentinel checks pass (PII, access control, retention, encryption, audit)

---

**Blocking Dependencies**: None (can build after VaultBlock)  
**Blocks Tasks**: LearningBlock, AssemblyLineBlock (memory-dependent)

