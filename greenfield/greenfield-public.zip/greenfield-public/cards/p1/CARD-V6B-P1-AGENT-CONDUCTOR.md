# CARD-V6B-P1-AGENT-CONDUCTOR

**Card ID**: `CARD-V6B-P1-AGENT-CONDUCTOR`  
**Type**: Agent  
**MC Score**: 8.5  
**MC Target**: 8.5  
**Status**: Active  
**Created**: 2025-11-14

---

## Purpose

Conductor Agent: Workflow orchestration

---

## Agent Identity

**Soul Reference**: `CARD-V6B-P0-AGENT-SOUL`

**Obsession**: Rhythm, load, and protecting focus from runaway automation.

**Stays Out Of**: Deciding what matters, judging content, or redefining the North Star.

---

## MC Scoring (12-Bin Cognitive Framework)

**Composite MC Score**: 8.5

| Bin | Score | Rationale |
|-----|-------|-----------|
| signal | 8.6 | Clear technical specification |
| memory_short | 8.5 | Memory integration |
| mental_state | 8.4 | Team familiarity |
| bias_good | 8.5 | Positive assumptions |
| bias_bad | 8.3 | Awareness of risks |
| memory_long | 8.5 | LTM integration |
| knowledge | 8.6 | Leverages existing patterns |
| education | 8.4 | Well-documented |
| priority | 8.5 | Strategic alignment |
| ethos | 8.6 | V6.0 vision alignment |
| drift | 8.4 | Scope adherence |
| execution_risk | 8.3 | Rollback complexity |

**MC Validation Note**: Score reflects workflow orchestration with awareness of workflow state session data leakage. Primary focus: execution_risk, secondary: drift.

---

## Sentinel Policy

**CRITICAL**: Workflow state session data leakage

**Sentinel Checks**:
1. **Security**: All operations require proper authorization
2. **PII Detection**: PII detection and prevention
3. **Data Validation**: Input/output validation
4. **Error Handling**: Robust error handling
5. **Audit Logging**: All operations logged

**Testability**:
- Unit tests verify security controls
- Integration tests validate PII detection
- E2E tests confirm data validation
- Security tests verify audit logging

---

## Architecture Boundaries

**In Scope**:
- Workflow orchestration
- Workflow state session data leakage enforcement
- Health monitoring

**Out of Scope**:
- Implementation details delegated to other blocks
- Storage delegated to MemoryBlock/VaultBlock

**Data Flows**:
```
Input → Conductor Agent → Processing → Output
Conductor Agent → Monitoring → Health Status
```

---

## Dependencies

**Required Blocks**: None

**Dependent Blocks**: Various (depends on usage)

**Build Order**: Foundation layer

---

## North Star Alignment

**Truth**: Provides accurate, reliable workflow orchestration  
**Clarity**: Clear workflow orchestration specification  
**Progress**: Enables system operation  
**Precision**: Precise workflow orchestration guarantees

**Project Alignment**: Critical for system operation.

---

## Evidence Citations

- Implementation files (to be specified in greenfield)
- Architecture diagrams (to be created)
- Test files (to be created)

---

## Contrarian Analysis

**Failure Modes**:
1. Security bypass → unauthorized access
2. PII leaks → security breach
3. Processing errors → system failures
4. Performance issues → system degradation

**Alternatives Considered**:
- Alternative implementations (evaluated in greenfield)

**Hidden Assumptions**:
- Dependencies are reliable
- Security mechanisms are effective

---

## Steel-Man Mitigation

**Strengthened Arguments**:
- Workflow orchestration is essential for system operation
- Clear boundaries prevent system bloat
- Sentinel checks ensure security

**Risk Mitigation**:
1. Comprehensive security testing
2. Robust error handling
3. Performance optimization
4. Regular security audits

**Enhanced Criteria**:
- Security enforcement 100%
- PII detection accuracy ≥95%
- Processing success rate ≥99%
- Zero security vulnerabilities

---

## STMVault Context

**Pointer**:
- Type: `task_spec`
- Path: `vaults/stmvault/01-Architecture/Core-System/Conductor-Agent-Architecture.md`
- Title: "Conductor Agent Architecture - Workflow orchestration"

---

## Acceptance Criteria

- [ ] Conductor Agent implements Workflow orchestration
- [ ] Workflow state session data leakage enforced
- [ ] Health monitoring works
- [ ] All Sentinel checks pass
- [ ] Dependencies properly integrated

---

**Blocking Dependencies**: None  
**Blocks Tasks**: Various (depends on usage)
