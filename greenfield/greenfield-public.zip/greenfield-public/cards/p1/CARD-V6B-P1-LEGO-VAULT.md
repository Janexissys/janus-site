# CARD-V6B-P1-LEGO-VAULT

**Card ID**: `CARD-V6B-P1-LEGO-VAULT`  
**Type**: LEGO Block  
**MC Score**: 8.65  
**MC Target**: 8.65  
**Status**: Active  
**Created**: 2025-11-14

---

## Purpose

VaultBlock provides foundational storage for STMVault (curated design truth, card context) and LTMVault (runtime memory, historical logs). It manages vault synchronization, access control, and file operations.

---

## MC Scoring (12-Bin Cognitive Framework)

**Composite MC Score**: 8.65

| Bin | Score | Rationale |
|-----|-------|-----------|
| signal | 8.7 | Clear vault architecture specification |
| memory_short | 8.6 | STMVault coordination |
| mental_state | 8.5 | Team familiarity with vault systems |
| bias_good | 8.5 | Positive assumptions about vault reliability |
| bias_bad | 8.4 | Awareness of access control risks |
| memory_long | 8.6 | LTMVault coordination |
| knowledge | 8.7 | Leverages existing vault patterns |
| education | 8.5 | Well-documented vault architecture |
| priority | 8.8 | Critical foundational block |
| ethos | 8.7 | Aligned with v6.0 vault architecture |
| drift | 8.4 | Stable vault interface contracts |
| execution_risk | 8.5 | Moderate risk due to access control complexity |

**MC Validation Note**: Score reflects foundational importance with awareness of access control risks. Primary focus: execution_risk (access control), secondary: drift (vault consistency).

---

## Sentinel Policy

**CRITICAL**: Vault access controls

**Sentinel Checks**:
1. **Access Control**: All vault operations require proper authorization
2. **File Permissions**: Vault files must have correct permissions (read/write restrictions)
3. **Path Traversal**: Prevent directory traversal attacks in vault paths
4. **Concurrent Access**: Prevent race conditions in vault file operations
5. **Backup Integrity**: Vault backups must be verified for integrity

**Testability**:
- Unit tests verify access control on all vault operations
- Integration tests validate file permission enforcement
- Security tests confirm path traversal prevention
- Concurrency tests verify race condition handling

---

## Architecture Boundaries

**In Scope**:
- STMVault/LTMVault file operations
- Vault synchronization logic
- Access control enforcement
- Vault health monitoring

**Out of Scope**:
- File content parsing (delegated to IngestBlock)
- Memory promotion logic (delegated to MemoryBlock)
- Vector indexing (delegated to VectorDatabaseBlock)

**Data Flows**:
```
VaultBlock → STMVault (design truth, cards)
VaultBlock → LTMVault (runtime memory, logs)
VaultBlock → MemoryBlock (storage backend)
```

---

## Dependencies

**Required Blocks**: None (foundational block)

**Dependent Blocks**:
- `CARD-V6B-P1-LEGO-MEMORY` (MemoryBlock) - depends on VaultBlock
- `CARD-V6B-P1-LEGO-INGEST` (IngestBlock) - uses vault for file access

**Build Order**: Foundation layer (no dependencies)

---

## North Star Alignment

**Truth**: Vault system provides reliable, secure storage for system knowledge  
**Clarity**: Clear separation between STMVault (design) and LTMVault (runtime)  
**Progress**: Enables persistent knowledge storage and retrieval  
**Precision**: Precise access control and file operation guarantees

**Project Alignment**: Foundational for all memory and knowledge operations.

---

## Evidence Citations

- `backend/janus/app/core/vault_indexer.py` - Vault indexing implementation
- `config/policies/access/vault_access_policy.yaml:L1-83` - Vault access policy
- `docs/architecture/lego-dependency-graph.mmd:L6` - Vault dependency relationship
- `vaults/stmvault/VAULT_PATH_CONTRACT.md` - Vault path contract specification

---

## Contrarian Analysis

**Failure Modes**:
1. Access control bypass → unauthorized vault access
2. File corruption → loss of critical system knowledge
3. Concurrent write conflicts → data inconsistency
4. Path traversal attack → unauthorized file access

**Alternatives Considered**:
- Database-only storage (rejected: need file-based vaults for human readability)
- Single vault (rejected: need STM/LTM separation)

**Hidden Assumptions**:
- File system is reliable
- Access control mechanisms are secure
- Concurrent access is manageable

---

## Steel-Man Mitigation

**Strengthened Arguments**:
- Vault system is foundational for all knowledge operations
- STM/LTM separation enables efficient knowledge management
- File-based storage enables human readability and version control

**Risk Mitigation**:
1. Comprehensive access control testing and validation
2. File integrity checks and corruption detection
3. Lock mechanisms for concurrent access
4. Regular vault backups and recovery procedures

**Enhanced Criteria**:
- Access control enforcement 100% (zero bypasses)
- File operation success rate ≥99.9%
- Zero path traversal vulnerabilities
- Vault backup integrity verified daily

---

## STMVault Context

**Pointer**:
- Type: `task_spec`
- Path: `vaults/stmvault/01-Architecture/Core-System/Vault-System-Architecture.md`
- Title: "Vault System Architecture - STMVault/LTMVault Management"

---

## Acceptance Criteria

- [ ] VaultBlock manages STMVault and LTMVault operations
- [ ] Access control enforced on all vault operations
- [ ] File permissions correctly set and enforced
- [ ] Path traversal attacks prevented
- [ ] Concurrent access handled safely (no race conditions)
- [ ] Vault synchronization works correctly
- [ ] Health monitoring reports vault system status
- [ ] All Sentinel checks pass (access control, permissions, path traversal, concurrency, backup)

---

**Blocking Dependencies**: None (foundational block)  
**Blocks Tasks**: MemoryBlock, IngestBlock (vault-dependent)

