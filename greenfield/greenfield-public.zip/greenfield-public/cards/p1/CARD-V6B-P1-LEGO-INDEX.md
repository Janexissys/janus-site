# CARD-V6B-P1-LEGO-INDEX

**Card ID**: `CARD-V6B-P1-LEGO-INDEX`  
**Type**: Index Card  
**MC Score**: 9.00  
**Status**: Active  
**Created**: 2025-11-14

---

## Purpose

Master index card for Greenfield Reference Implementation – v6.0 test of LEGO architecture. This card serves as the anchor that all AI agents and human operators must obey during the entire greenfield experiment.

---

## The 29 Cards (Locked Scope)

### LEGO Blocks (13 cards)

1. **MemoryBlock** - `CARD-V6B-P1-LEGO-MEMORY` (MC: 8.70, Deps: VaultBlock)
2. **VaultBlock** - `CARD-V6B-P1-LEGO-VAULT` (MC: 8.65, Deps: None)
3. **IngestBlock** - `CARD-V6B-P1-LEGO-INGEST` (MC: 8.60, Deps: None)
4. **BatchBlock** - `CARD-V6B-P1-LEGO-BATCH` (MC: 8.55, Deps: None)
5. **AssemblyLineBlock** - `CARD-V6B-P1-LEGO-ASSEMBLY_LINE` (MC: 8.60, Deps: AgentBlock, MemoryBlock, CognitiveBlock)
6. **AgentBlock** - `CARD-V6B-P1-LEGO-AGENT` (MC: 8.55, Deps: None)
7. **TelemetryBlockAdapter** - `CARD-V6B-P1-LEGO-TELEMETRY` (MC: 8.50, Deps: None)
8. **CognitiveBlockAdapter** - `CARD-V6B-P1-LEGO-COGNITIVE` (MC: 8.65, Deps: None)
9. **LearningBlockAdapter** - `CARD-V6B-P1-LEGO-LEARNING` (MC: 8.55, Deps: MemoryBlock)
10. **ActionsBlockAdapter** - `CARD-V6B-P1-LEGO-ACTIONS` (MC: 8.50, Deps: None)
11. **ActionWebhookBlockAdapter** - `CARD-V6B-P1-LEGO-ACTION_WEBHOOK` (MC: 8.50, Deps: None)
12. **RmdBlockAdapter** - `CARD-V6B-P1-LEGO-RMD` (MC: 8.45, Deps: None)
    - Purpose: Markdown with YAML headers for AI speed of read (simple formatter)
    - Note: MC 8.45 is correct - low complexity formatter, not a gate
13. **VectorDatabaseBlock** - `CARD-V6B-P1-LEGO-VECTOR_DB` (MC: 8.60, Deps: None)

### Agent Crew (6 cards)

14. **Caretaker Agent** - `CARD-V6B-P1-AGENT-CARETAKER` (MC: 8.65)
15. **Gardener Agent** - `CARD-V6B-P1-AGENT-GARDENER` (MC: 8.60)
16. **Mercury Agent** - `CARD-V6B-P1-AGENT-MERCURY` (MC: 8.55)
17. **Sentinel Agent** - `CARD-V6B-P1-AGENT-SENTINEL` (MC: 8.70)
18. **Conductor Agent** - `CARD-V6B-P1-AGENT-CONDUCTOR` (MC: 8.50)
19. **Scribe Agent** - `CARD-V6B-P1-AGENT-SCRIBE` (MC: 8.55)

### Core Systems (10 cards)

20. **Assembly Line Processor** - `CARD-V6B-P1-COMP-ASSEMBLY_LINE` (MC: 8.60)
21. **MC Engine & 12-Bin System** - `CARD-V6B-P1-COMP-MC_ENGINE` (MC: 8.70)
    - **Critical Requirement**: Must separate MC Gate Score from Confidence Score
    - MC Gate Score = complexity/quality gate (backend routing, memory promotion, quality gates)
    - Confidence Score = user-facing certainty (alignment with goals, right answer, trust)
    - Architecture Decision: Single unified system - either integrate DualCognitiveScoring features into MCEngine OR replace with clean implementation
    - No Legacy Mess: Greenfield must be clean - no importing deprecated/test repo code
22. **Memory System (STM/LTM)** - `CARD-V6B-P1-COMP-MEMORY_SYSTEM` (MC: 8.65)
23. **Vault System** - `CARD-V6B-P1-COMP-VAULT_SYSTEM` (MC: 8.60)
24. **Telemetry & Metrics** - `CARD-V6B-P1-COMP-TELEMETRY` (MC: 8.50)
25. **North Star Integration** - `CARD-V6B-P1-COMP-NORTH_STAR` (MC: 8.80)
    - Components: North Star Meta (soul/non-negotiables) + Projects (user goals - critical system direction)
26. **Task & Card System** - `CARD-V6B-P1-COMP-TASK_CARD_SYSTEM` (MC: 8.55)
27. **Frontend Components** - `CARD-V6B-P1-COMP-FRONTEND` (MC: 8.50)
28. **API Layer** - `CARD-V6B-P1-COMP-API` (MC: 8.55)
29. **LEGO Registry** - `CARD-V6B-P1-COMP-LEGO_REGISTRY` (MC: 8.70)

---

## Core Principles (Summary)

### 1. Cards Are Law, Code Is Detail
- Card defines purpose, dependencies, Sentinel, MC target, and boundaries
- Implementation is free as long as it obeys the card

### 2. Vault Is Spine, Cards Are Nerves
- STMVault holds context documents
- Cards hold pointers and summaries, never full duplication
- Each card must include breadcrumb links into STMVault

### 3. MC and Sentinel Are Non-Negotiable
- Provide simulated 12-bin MC snapshot
- Implement Sentinel rule in a way that is testable
- Aim to match or exceed the listed MC score

### 4. Dependency Ladder Is the Build Order
- Foundation blocks (no dependencies)
- Second layer (depends on foundation)
- Third layer (depends on memory)
- Top layer (multi-dependency components)

### 5. AI Builds, You Guard North Star
- AI chooses patterns, libraries, and internal wiring per block
- Human intervenes only when card, Sentinel, or North Star rule is violated

### 6. Comparison Focus = Behaviour, Not Style
- Compare: Same inputs → same or better outputs, Sentinel behaviour, MC scores
- Do NOT compare: Line-by-line code differences, implementation patterns, library choices

### 7. Hardening Follows Risk, Not Ego
- Rank blocks by MC gap and Sentinel severity
- Fix Sentinel-critical blocks first
- Apply North Star corrections before refactors

### 8. Behaviour Rules During Test
- No new cards. Only these 29.
- No silent changes to a card. Any change must log a one-line "why".
- Every modification justified as: "This improves X by Y for the system."
- **No legacy/test repo imports**: Greenfield must be clean

### 9. Memory Naming – v6.0 Standard
- STM = STMVault (curated design truth, card context, architecture notes)
- LTM = LTMVault (runtime memory, historical logs, vector store)
- Banned: QVault, PVault, Q, P

---

## Critical Architecture Decisions

### MC Separation (Card #21)
- **Problem**: MC currently doing two jobs (gate + confidence)
- **Solution**: Must separate MC Gate Score (backend) from Confidence Score (user-facing)
- **Architecture**: Single unified system - integrate OR replace, no legacy imports

### Projects Integration (Card #25)
- Projects = critical system direction component
- Max 3 active: 1 primary + 2 secondary
- Alignment validation: alignment_score ≥ 0.7 required

---

## Success Criteria

- All 29 cards created with MC scores ≥8.5
- Greenfield built following dependency order
- Behavioral equivalence validated
- Sentinel checks pass
- MC separation validated: Gate score for backend, confidence score for user-facing
- North Star alignment maintained throughout
- No scope creep, no feature additions
- Every change logged and justified
- STMVault context documents created (not QVault)
- Memory naming follows v6.0 standard (STM/LTM, not Q/P)
- No legacy/test repo imports: Clean greenfield implementation

---

## Reference

- Plan: `greenfield-reference-implementation-plan.plan.md`
- STMVault: `vaults/stmvault/`
- Template: `templates/janus_card_template_v6.yaml`

---

**This card is the anchor. All agents and operators must reference this card during the greenfield experiment.**

