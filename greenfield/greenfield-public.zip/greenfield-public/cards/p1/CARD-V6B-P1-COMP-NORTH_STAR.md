# CARD-V6B-P1-COMP-NORTH_STAR

**Card ID**: `CARD-V6B-P1-COMP-NORTH_STAR`  
**Type**: Core System  
**MC Score**: 8.80  
**MC Target**: 8.80  
**Status**: Active  
**Created**: 2025-11-14

---

## Purpose

North Star Integration provides the soul (non-negotiables) and system direction (Projects) for Janus OS. It enforces North Star Meta alignment and manages Projects (user goals) that provide practical expression of North Star alignment.

---

## MC Scoring (12-Bin Cognitive Framework)

**Composite MC Score**: 8.80

| Bin | Score | Rationale |
|-----|-------|-----------|
| signal | 8.9 | Clear North Star specification |
| memory_short | 8.7 | STM integration for North Star context |
| mental_state | 8.8 | High team familiarity with North Star |
| bias_good | 8.8 | Strong positive assumptions about alignment |
| bias_bad | 8.6 | Awareness of alignment validation risks |
| memory_long | 8.7 | LTM integration for North Star context |
| knowledge | 8.9 | Leverages existing North Star patterns |
| education | 8.8 | Well-documented North Star architecture |
| priority | 9.0 | Highest priority - system soul |
| ethos | 9.0 | Perfect alignment with v6.0 vision |
| drift | 8.7 | Stable North Star contracts |
| execution_risk | 8.5 | Moderate risk due to alignment complexity |

**MC Validation Note**: Score reflects critical system soul with awareness of alignment validation risks. Primary focus: ethos (vision alignment), secondary: execution_risk (alignment validation).

---

## Sentinel Policy

**CRITICAL**: Policy enforcement security, project alignment validation

**Sentinel Checks**:
1. **Policy Enforcement**: North Star policies enforced on all operations
2. **Project Alignment**: Projects must have alignment_score ≥ 0.7
3. **Ingest Policy**: Ingest policy compliance validated
4. **Project Switching**: Primary project changes require review
5. **Access Control**: North Star meta access properly controlled

**Testability**:
- Unit tests verify policy enforcement
- Integration tests validate project alignment
- E2E tests confirm ingest policy compliance
- Security tests verify access control

---

## Architecture Boundaries

**In Scope**:
- North Star Meta (soul/non-negotiables) - blocking violations, hard rules
- Projects (user goals) - system direction, context enrichment
- Alignment validation (alignment_score ≥ 0.7)
- Project context enrichment for agents

**Out of Scope**:
- Actual policy implementation (delegated to agents)
- Project task management (delegated to Task & Card System)

**Data Flows**:
```
North Star Meta → Policy Enforcement → Agents
Projects → Context Enrichment → Agents
Projects → Alignment Validation → North Star Meta
```

---

## Dependencies

**Required Blocks**: None (foundational system)

**Dependent Blocks**:
- All agents consume North Star + project metadata
- IngestBlock uses North Star ingest policy
- CaretakerAgent enforces North Star policies

**Build Order**: Foundation layer (no dependencies)

---

## North Star Alignment

**Truth**: North Star provides truth alignment enforcement  
**Clarity**: Clear North Star principles and project alignment  
**Progress**: Enables system direction through Projects  
**Precision**: Precise alignment validation (≥0.7 threshold)

**Project Alignment**: This IS the North Star - perfect alignment.

---

## Components

### North Star Meta (Soul/Non-Negotiables)
- Blocking violations, hard rules, truth alignment
- Ingest policy specification
- Hard rules enforcement

### Projects (User Goals) - CRITICAL SYSTEM DIRECTION COMPONENT
- Projects = User Goals (System Tuning) - practical expression of North Star alignment
- Max 3 active: 1 primary + 2 secondary
- Alignment validation: alignment_score ≥ 0.7 required
- Project context enrichment for all agents
- Clarification triggers (MC < 7.0)
- WIP limits: 5 cards primary, 3 cards secondary

**Purpose**: 
- North Star = blocking violations, truth alignment enforcement
- **Projects = system direction** - they provide the practical expression of user goals that align with North Star soul
- Projects guide agent decisions, context enrichment, and priority allocation

---

## Evidence Citations

- `backend/janus/app/core/north_star_projects_service.py:L1-413` - North Star and Projects service
- `backend/janus/app/core/north_star_meta.py` - North Star meta implementation
- `vaults/north_star/PROJECTS_CONTRACT.yaml` - Projects contract specification
- `vaults/north_star/projects/` - Project card examples
- `config/north_star_meta.yaml` - North Star meta configuration

---

## Contrarian Analysis

**Failure Modes**:
1. Policy enforcement bypass → non-compliant operations
2. Project misalignment → system works against goals
3. Alignment validation fails → invalid projects activated
4. Project switching without review → direction chaos

**Alternatives Considered**:
- No Projects (rejected: system lacks direction)
- No alignment validation (rejected: violates North Star)

**Hidden Assumptions**:
- Alignment scoring is accurate
- Project switching review is effective
- Agents consume project context correctly

---

## Steel-Man Mitigation

**Strengthened Arguments**:
- North Star provides system soul and direction
- Projects bridge soul and practical goals
- Alignment validation ensures consistency

**Risk Mitigation**:
1. Comprehensive policy enforcement testing
2. Robust alignment validation (≥0.7 threshold)
3. Project switching review process
4. Agent context enrichment validation

**Enhanced Criteria**:
- Policy enforcement 100% (zero bypasses)
- Project alignment validation 100% (all projects ≥0.7)
- Project switching review 100% (zero unauthorized switches)
- Agent context enrichment verified

---

## STMVault Context

**Pointer**:
- Type: `task_spec`
- Path: `vaults/stmvault/01-Architecture/Strategic-Vision/North-Star-Integration-Architecture.md`
- Title: "North Star Integration Architecture - Soul and System Direction"

---

## Acceptance Criteria

- [ ] North Star Meta provides soul/non-negotiables
- [ ] Projects provide system direction (user goals)
- [ ] Alignment validation enforced (≥0.7 threshold)
- [ ] Project context enrichment works for agents
- [ ] Project switching requires review
- [ ] Ingest policy compliance validated
- [ ] All Sentinel checks pass (policy, alignment, ingest, switching, access)

---

**Blocking Dependencies**: None (foundational system)  
**Blocks Tasks**: All agents (North Star-dependent), IngestBlock (policy-dependent)

