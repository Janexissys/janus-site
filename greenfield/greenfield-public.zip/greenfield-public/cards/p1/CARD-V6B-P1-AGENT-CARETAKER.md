# CARD-V6B-P1-AGENT-CARETAKER

**Card ID**: `CARD-V6B-P1-AGENT-CARETAKER`  
**Type**: Agent  
**MC Score**: 8.65  
**MC Target**: 8.65  
**Status**: Active  
**Created**: 2025-11-14

---

## Purpose

Caretaker Agent: Strategic decision-making (approve/reject/defer)

---

## Agent Identity

**Soul Reference**: `CARD-V6B-P0-AGENT-SOUL`

**Obsession**: Stewardship and safety, even if that slows things down.

**Stays Out Of**: Truth judgments and prioritizing what the human should work on.

---

## MC Scoring (12-Bin Cognitive Framework)

**Composite MC Score**: 8.65

| Bin | Score | Rationale |
|-----|-------|-----------|
| signal | 8.8 | Clear technical specification |
| memory_short | 8.7 | Memory integration |
| mental_state | 8.6 | Team familiarity |
| bias_good | 8.7 | Positive assumptions |
| bias_bad | 8.5 | Awareness of risks |
| memory_long | 8.7 | LTM integration |
| knowledge | 8.8 | Leverages existing patterns |
| education | 8.6 | Well-documented |
| priority | 8.7 | Strategic alignment |
| ethos | 8.8 | V6.0 vision alignment |
| drift | 8.6 | Scope adherence |
| execution_risk | 8.5 | Rollback complexity |

**MC Validation Note**: Score reflects strategic decision-making (approve/reject/defer) with awareness of north star policy evaluation for pii. Primary focus: execution_risk, secondary: drift.

---

## Sentinel Policy

**CRITICAL**: North Star policy evaluation for PII

**Sentinel Checks**:
1. **Security**: All operations require proper authorization
2. **PII Detection**: PII detection and prevention
3. **Data Validation**: Input/output validation
4. **Error Handling**: Robust error handling
5. **Audit Logging**: All operations logged

**Testability**:
- Unit tests verify security controls
- Integration tests validate PII detection
- E2E tests confirm data validation
- Security tests verify audit logging

---

## Architecture Boundaries

**In Scope**:
- Strategic decision-making (approve/reject/defer)
- North Star policy evaluation for PII enforcement
- Health monitoring

**Out of Scope**:
- Implementation details delegated to other blocks
- Storage delegated to MemoryBlock/VaultBlock

**Data Flows**:
```
Input → Caretaker Agent → Processing → Output
Caretaker Agent → Monitoring → Health Status
```

---

## Dependencies

**Required Blocks**: None

**Dependent Blocks**: Various (depends on usage)

**Build Order**: Foundation layer

---

## North Star Alignment

**Truth**: Provides accurate, reliable strategic decision-making (approve/reject/defer)  
**Clarity**: Clear strategic decision-making (approve/reject/defer) specification  
**Progress**: Enables system operation  
**Precision**: Precise strategic decision-making (approve/reject/defer) guarantees

**Project Alignment**: Critical for system operation.

---

## Evidence Citations

- Implementation files (to be specified in greenfield)
- Architecture diagrams (to be created)
- Test files (to be created)

---

## Contrarian Analysis

**Failure Modes**:
1. Security bypass → unauthorized access
2. PII leaks → security breach
3. Processing errors → system failures
4. Performance issues → system degradation

**Alternatives Considered**:
- Alternative implementations (evaluated in greenfield)

**Hidden Assumptions**:
- Dependencies are reliable
- Security mechanisms are effective

---

## Steel-Man Mitigation

**Strengthened Arguments**:
- Strategic decision-making (approve/reject/defer) is essential for system operation
- Clear boundaries prevent system bloat
- Sentinel checks ensure security

**Risk Mitigation**:
1. Comprehensive security testing
2. Robust error handling
3. Performance optimization
4. Regular security audits

**Enhanced Criteria**:
- Security enforcement 100%
- PII detection accuracy ≥95%
- Processing success rate ≥99%
- Zero security vulnerabilities

---

## STMVault Context

**Pointer**:
- Type: `task_spec`
- Path: `vaults/stmvault/01-Architecture/Core-System/Caretaker-Agent-Architecture.md`
- Title: "Caretaker Agent Architecture - Strategic decision-making (approve/reject/defer)"

---

## Acceptance Criteria

- [ ] Caretaker Agent implements Strategic decision-making (approve/reject/defer)
- [ ] North Star policy evaluation for PII enforced
- [ ] Health monitoring works
- [ ] All Sentinel checks pass
- [ ] Dependencies properly integrated

---

**Blocking Dependencies**: None  
**Blocks Tasks**: Various (depends on usage)
