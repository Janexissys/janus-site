# CARD-V6B-P1-LEGO-VECTOR-DB-PERSISTENCE

**Card ID:** `CARD-V6B-P1-LEGO-VECTOR-DB-PERSISTENCE`
**Priority:** P1
**Phase:** V6.1 Polish
**Status:** Completed
**Date:** 2026-01-23

---

## Completion Notes (2026-01-23)
- **Governance Alignment**: Changed storage path from `data/chromadb` to `vaults/ltmvault/vector_db` to comply with LTM Space governance (Memory owns Memory).
- **Implementation**: Updated `vector_database_block.py` to use `chromadb.PersistentClient`.
- **Sanitization**: Added metadata sanitization to handle complex types (lists/dicts) which ChromaDB strictly rejects.
- **Validation**: Verified indexing and search persistence with `test_vector_db_simple.py`.

## North Star

> "Long-term memory must be persistent, semantic, and searchable across session boundaries."

**Why**: Currently, the V6.0 `VectorDatabaseBlock` operates in "Mock Mode" with in-memory storage that wipes on restart. This breaks the promise of "Long Term Memory". We must bridge the gap by integrating the robust `chromadb` persistence logic from V5.5 into the new Greenfield architecture.

---

## Risk Assessment & Mitigation

| Risk | Mitigation strategy |
|---|---|
| **Data Loss** | Use `chromadb.PersistentClient` pointing to `data/chromadb`. |
| **Dependency Bloat** | Isolate `chromadb` to the vector block; use standard version. |
| **Migration Friction** | Ensure V5.5 data schema is compatible or clearly versioned. |
| **Performance** | Use `embedded` mode by default to avoid managing extra services. |

---

## Scope

### 1. Dependencies
- Add `chromadb` to `backend/requirements.txt`.
- (Optional) Add `sentence-transformers` for better-than-default embeddings if needed later.

### 2. Block Implementation (`backend/blocks/vector_database_block.py`)
- **Initialize**: Replace dictionary storage with `chromadb.PersistentClient`.
- **Persist**: Ensure `data/chromadb` directory is created.
- **Embed**: Switch from MD5 mock embeddings to Chroma's default embedding function (ONNX/all-MiniLM-L6-v2) or maintain mock if dependencies are too heavy, but *persist* the vectors.
- **Port Legacy Logic**: Adapt `backend/janus/app/services/vector_db.py` initialization patterns.

### 3. Verification
- **persistence_test**: data survives process restart.
- **search_test**: query string returns relevant document.

## Legacy Reference (V5.5)
- **Source**: `backend/janus/app/services/vector_db.py`
- **Key Pattern**: `chromadb.PersistentClient(path="./data/chromadb")`
- **Collection**: `janus_memories`

## Outcome
A vector database that remembers what it learned yesterday.
