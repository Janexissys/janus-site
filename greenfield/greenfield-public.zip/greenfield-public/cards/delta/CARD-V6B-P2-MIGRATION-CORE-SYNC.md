# CARD-V6B-P2-MIGRATION-CORE-SYNC

**Card ID**: CARD-V6B-P2-MIGRATION-CORE-SYNC
**Title**: Core Component Synchronization (Greenfield → Main)
**Type**: migration
**Phase**: P2
**Status**: new
**Created**: 2025-12-17
**MC Score**: 8.50

---

## Summary

Promote the validated, Sentinel-compliant core components from Greenfield (the "Golden Source") to Main V6.0. This establishes the functional baseline for Main V6.0, replacing legacy/divergent code with the proven Greenfield implementation.

---

## MC Scoring

**MC Score**: 8.50 (Target: 8.50)

### MC Bins (12-bin breakdown)
- **signal**: 9.0 - Explicit directive to "copy and improve".
- **memory_short**: 8.5 - Greenfield just validated as 100% complete.
- **mental_state**: 8.5 - Clear separation of "Golden Source" vs "Target".
- **bias_good**: 9.0 - Greenfield code is proven working.
- **bias_bad**: 8.0 - Risk of import path errors during copy.
- **memory_long**: 9.0 - Unifies the codebase under V6.0 architecture.
- **knowledge**: 8.5 - Pattern is standard file synchronization.
- **education**: 8.0 - Requires careful import rewriting.
- **priority**: 9.5 - Blocker for making Main V6 functional.
- **ethos**: 9.0 - "Build Intelligent Systems" requires a working core.
- **drift**: 8.5 - Strictly scoped to core components.
- **execution_risk**: 8.0 - Low risk if Greenfield is preserved.

---

## Acceptance Criteria

- [ ] **Blocks Synced**: All 13 LEGO blocks copied from `greenfield/backend/blocks/` to `backend/blocks/`.
- [ ] **Agents Synced**: All 6 Nano Agents copied from `greenfield/backend/agents/` to `backend/agents/`.
- [ ] **Systems Synced**: All 10 Core Systems copied from `greenfield/backend/systems/` to `backend/systems/`.
- [ ] **Utils Synced**: Shared utilities (PII detector) copied to `backend/utils/`.
- [ ] **Import Paths Fixed**: All imports in destination files updated to reference `backend.*` instead of `greenfield.backend.*`.
- [ ] **Greenfield Preserved**: No changes to source `greenfield/` directory.
- [ ] **Smoke Test**: Verify Main V6 can import the new components without error.

---

## Implementation Details

1. **Source of Truth**: `greenfield/backend/` is the read-only source.
2. **Destination**: `backend/` is the write target.
3. **Transformation**:
   - Read file from Source.
   - Rewrite imports (regex replace `from greenfield.backend` -> `from backend`).
   - Write to Destination.
4. **Verification**:
   - Create `scripts/verify_core_imports.py` in Main to check for broken imports.

---

## Dependencies
- Greenfield Phase 4 Complete (Done).
- MCCE Validation (Done).

---
