# CARD-V6B-P1-DELTA-BACKEND-HARDENING

**Card ID**: CARD-V6B-P1-DELTA-BACKEND-HARDENING
**Title**: Backend Hardening & Dependency Management
**Type**: delta
**Phase**: P1
**Status**: review
**Created**: 2025-12-15
**MC Score**: 8.00

---

## Summary

Formalize the Greenfield backend environment by establishing a canonical `requirements.txt`, auditing dependencies, and verifying the execution environment for LAN testing and production readiness.

---

## MC Scoring

**MC Score**: 8.00 (Target: 8.50)

### MC Bins (12-bin breakdown)
- **signal**: 8.0 - Clear need for dependency management.
- **memory_short**: 8.0 - Context fresh from LAN setup.
- **mental_state**: 8.5 - Team aligned on hardening.
- **bias_good**: 8.5 - Standard practice.
- **bias_bad**: 8.0 - Risk of missing obscure imports.
- **memory_long**: 8.0 - Essential for long-term maintenance.
- **knowledge**: 9.0 - Standard Python ecosystem task.
- **education**: 7.5 - Need to document specific versions.
- **priority**: 9.0 - Critical for stable deployment.
- **ethos**: 8.5 - Professional engineering standard.
- **drift**: 8.0 - Focused scope.
- **execution_risk**: 8.0 - Low risk, high value.

---

## Acceptance Criteria

- [x] Create `greenfield/requirements.txt` containing all used packages.
- [x] Audit imports in `greenfield/backend/` to ensure coverage.
- [x] Verify `start_server.sh` uses or references the requirements.
- [x] Document dependency installation in `greenfield/README.md` or `LAN_TESTING_READY.md`.
- [x] Update `setup-venv.sh` for Greenfield v6.0 compatibility.
- [x] Integrate venv detection into `start_server.sh`.
- [x] Create `setup-frontend.sh` for frontend dependency management.
- [x] Update `start_frontend.sh` with dependency checks and LAN configuration.

---

## Implementation Details

1. **Scan Imports**: Analyzed codebase for external libraries (FastAPI, Uvicorn, OpenAI, Anthropic, etc.).
2. **Generate Requirements**: Created `greenfield/requirements.txt` with pinned or minimum versions.
3. **Virtual Environment**: Updated `setup-venv.sh` for Greenfield v6.0 to use `requirements.txt`.
4. **Server Integration**: Updated `start_server.sh` to automatically detect and use venv if present.
5. **Frontend Setup**: Created `setup-frontend.sh` for npm/node dependency management.
6. **Frontend Integration**: Updated `start_frontend.sh` with dependency checks and LAN IP detection.
7. **Documentation**: Updated `LAN_TESTING_READY.md` with both backend and frontend setup instructions.

---

## Dependencies
- None.

---

