# OSS Production Release - Card Plan

**Date**: 2025-12-16  
**North Star**: Field-agnostic testbed for heuristic critical-thinking network (CTN)  
**Goal**: Prove workflow repeatability with deterministic MC scoring  
**Release Target**: OSS Production v1.0

---

## North Star Definition

> "Same inputs → Same MC scores. We are solving the black box of AI thought process with a CTN overlay."

**Repeatability Contract**:
- Card request "make me a window card" → deterministic MC score
- Same workflow steps → same outputs every run
- Full audit trail for reproducibility

---

## System Architecture (Production)

```
┌─────────────────────────────────────────────────────────────────────┐
│                        GREENFIELD OSS v1.0                         │
├─────────────────────────────────────────────────────────────────────┤
│  FRONTEND (5 Tabs)                                                  │
│  ├── Cards Board    - Card lifecycle visualization                  │
│  ├── Insights       - System analytics & MC trends                  │
│  ├── Chat           - Command interface & card creation             │
│  ├── Systems        - LEGO blocks, agents, MC engine status         │
│  └── Workflow Test  - Repeatability validation harness              │
├─────────────────────────────────────────────────────────────────────┤
│  BACKEND (Nano Agents + Orchestration)                              │
│  ├── 6 Nano Agents  - Caretaker, Gardener, Mercury, Scribe,        │
│  │                    Conductor, Sentinel                           │
│  ├── 13 LEGO Blocks - Vault, Cognitive, Agent, Memory, etc.        │
│  ├── MC Engine      - 12-bin deterministic scoring                  │
│  └── Assembly Line  - Orchestrated processing pipeline              │
├─────────────────────────────────────────────────────────────────────┤
│  VAULTS                                                             │
│  ├── STMVault       - Active work (MC < 8.5)                       │
│  └── LTMVault       - Promoted knowledge (MC ≥ 8.5)                │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Cards Overview

| Phase | Card ID | Title | MCCE | Priority |
|-------|---------|-------|------|----------|
| **P0** | CARD-OSS-P0-001 | MC Engine Determinism Hardening | 5d | CRITICAL |
| **P0** | CARD-OSS-P0-002 | Repeatability Test Harness | 4d | CRITICAL |
| **P0** | CARD-OSS-P0-003 | Agent Orchestration Import | 3d | CRITICAL |
| **P0** | CARD-OSS-P0-004 | LLM Response Caching for Repeatability | 4d | CRITICAL |
| **P1** | CARD-OSS-P1-001 | Cards Board Production UI | 5d | HIGH |
| **P1** | CARD-OSS-P1-002 | Insights Dashboard | 4d | HIGH |
| **P1** | CARD-OSS-P1-003 | Chat Interface Production | 5d | HIGH |
| **P1** | CARD-OSS-P1-004 | Systems Status Page | 3d | HIGH |
| **P1** | CARD-OSS-P1-005 | Workflow Test Page | 4d | HIGH |
| **P2** | CARD-OSS-P2-001 | API Documentation & OpenAPI | 3d | MEDIUM |
| **P2** | CARD-OSS-P2-002 | OSS Packaging & Distribution | 3d | MEDIUM |
| **P2** | CARD-OSS-P2-003 | E2E Test Suite | 4d | MEDIUM |
| **P2** | CARD-OSS-P2-004 | Docker Containerization | 2d | MEDIUM |
| **P3** | CARD-OSS-P3-001 | README & Quickstart Guide | 2d | LOW |
| **P3** | CARD-OSS-P3-002 | License & Contributing Docs | 1d | LOW |

**Total MCCE**: 52 dev-days

---

## Phase 0: Critical Infrastructure (MCCE: 16d)

### CARD-OSS-P0-001: MC Engine Determinism Hardening

```yaml
card_id: CARD-OSS-P0-001
title: MC Engine Determinism Hardening
phase: P0
lane: New

mc_score: 7.50
mc_target: 8.50
mc_bins:
  signal: 8.0          # Technical clarity high
  memory_short: 7.5    # Recent context good
  mental_state: 7.0    # Team familiar with MC
  bias_good: 7.5       # Optimistic about determinism
  bias_bad: 8.0        # Aware of floating-point risks
  memory_long: 7.0     # Historical patterns available
  knowledge: 8.5       # 12-bin well documented
  education: 7.0       # Needs determinism docs
  priority: 9.0        # Critical for OSS
  ethos: 8.5           # Core to CTN vision
  drift: 7.5           # Scope well defined
  execution_risk: 7.0  # Medium complexity

mc_validation_note: "MC engine exists but lacks guaranteed determinism. Need to lock random seeds, normalize floating-point, cache bin weights."
bin_focus: "execution_risk (primary), education (secondary)"
blocking_dependencies: []

evidence:
  - "greenfield/backend/systems/mc_engine.py:L1-L200"
  - "greenfield/docs/architecture/mc-system.mmd"

contrarian: |
  - Floating-point arithmetic varies across platforms
  - LLM responses inherently non-deterministic
  - Time-based components may affect scores
  
steelman: |
  - Use fixed random seeds for all stochastic components
  - Normalize floats to fixed precision (4 decimal places)
  - Mock/stub external LLM calls for testing
  - Cache computed weights for reproducibility

owner: Systems Engineering
reviewer: Architecture Team
telemetry_steward: DevOps
status: pending
estimated_duration: 5d

acceptance:
  - "Same card input produces identical MC score across 100 runs"
  - "MC calculation is platform-independent (Windows/Linux/Mac)"
  - "Random seed configuration exposed via environment variable"
  - "Floating-point normalized to 4 decimal places"
  - "Unit tests cover all 12 bins with determinism checks"

dependencies: []
blocks_tasks:
  - CARD-OSS-P0-002
  - CARD-OSS-P1-005

system: mc_engine
pillar: core_infrastructure
labels:
  - P0
  - critical
  - determinism
```

---

### CARD-OSS-P0-002: Repeatability Test Harness

```yaml
card_id: CARD-OSS-P0-002
title: Repeatability Test Harness
phase: P0
lane: New

mc_score: 7.20
mc_target: 8.50
mc_bins:
  signal: 7.5          # Clear requirements
  memory_short: 7.0    # Test patterns known
  mental_state: 7.0    # Team understands goal
  bias_good: 7.5       # Confident in approach
  bias_bad: 7.0        # Aware of edge cases
  memory_long: 7.0     # Testing history available
  knowledge: 7.5       # Test frameworks known
  education: 6.5       # Needs documentation
  priority: 9.0        # Critical for validation
  ethos: 8.5           # Core to CTN proof
  drift: 7.5           # Scope bounded
  execution_risk: 7.5  # Moderate complexity

mc_validation_note: "Need automated harness to run N iterations and compare MC outputs. Must support golden dataset of test cards."
bin_focus: "education (primary), signal (secondary)"
blocking_dependencies:
  - "CARD-OSS-P0-001 (MC determinism)"

evidence:
  - "greenfield/tests/test_improvement_analyzer_regression.py"
  - "greenfield/docs/workflows/MC_GATE_VECTOR_MCCE_IMPLEMENTATION.md"

contrarian: |
  - Test data may be biased toward passing cases
  - Environment differences may cause false failures
  - Golden dataset needs maintenance
  
steelman: |
  - Include adversarial test cases
  - Document environment requirements precisely
  - Version golden dataset with semantic versioning
  - CI/CD integration for automated regression

owner: QA Engineering
reviewer: Systems Engineering
telemetry_steward: DevOps
status: pending
estimated_duration: 4d

acceptance:
  - "CLI command: `pytest tests/repeatability/ -v` passes"
  - "Golden dataset of 20 test cards with expected MC scores"
  - "Tolerance threshold configurable (default: 0.0 for exact match)"
  - "CI integration with GitHub Actions"
  - "Failure report shows bin-by-bin diff"

dependencies:
  - CARD-OSS-P0-001
blocks_tasks:
  - CARD-OSS-P1-005

system: testing
pillar: quality_assurance
labels:
  - P0
  - critical
  - testing
```

---

### CARD-OSS-P0-003: Agent Orchestration Import

```yaml
card_id: CARD-OSS-P0-003
title: Agent Orchestration Import
phase: P0
lane: New

mc_score: 7.80
mc_target: 8.50
mc_bins:
  signal: 8.0          # Requirements clear
  memory_short: 8.0    # Orchestration patterns known
  mental_state: 7.5    # Team familiar with agents
  bias_good: 7.5       # Confident in existing code
  bias_bad: 7.5        # Aware of integration risks
  memory_long: 8.0     # Historical patterns available
  knowledge: 8.5       # Agents well documented
  education: 7.5       # Needs integration guide
  priority: 8.5        # Required for workflow
  ethos: 8.0           # Aligns with nano-agent vision
  drift: 8.0           # Scope locked per user
  execution_risk: 7.5  # Import complexity

mc_validation_note: "6 nano agents exist. Orchestration layer may need import from external repo. Scope is LOCKED - do not expand agent capabilities."
bin_focus: "execution_risk (primary), education (secondary)"
blocking_dependencies: []

evidence:
  - "greenfield/backend/agents/*.py"
  - "greenfield/backend/systems/assembly_line_processor.py"

contrarian: |
  - External repo may have breaking changes
  - Import may introduce unwanted dependencies
  - Agent scope creep risk
  
steelman: |
  - Pin external repo to specific commit/tag
  - Audit imported code for scope compliance
  - Integration tests validate agent behavior unchanged
  - Document agent scope boundaries in README

owner: Systems Engineering
reviewer: Architecture Team
telemetry_steward: DevOps
status: pending
estimated_duration: 3d

acceptance:
  - "All 6 nano agents operational: Caretaker, Gardener, Mercury, Scribe, Conductor, Sentinel"
  - "Assembly line processor orchestrates full pipeline"
  - "Agent scope unchanged from Greenfield spec"
  - "Integration tests pass for agent workflow"
  - "No new external dependencies beyond existing requirements.txt"

dependencies: []
blocks_tasks:
  - CARD-OSS-P1-003
  - CARD-OSS-P1-005

system: agents
pillar: core_infrastructure
labels:
  - P0
  - critical
  - agents
```

---

## 🎯 CARD-OSS-P0-004: LLM Response Caching for MC Repeatability

### Goal
Make MC scoring and gate decisions **repeatable** by freezing the LLM boundary during tests.

### Problem
LLM calls are not guaranteed deterministic across:
- retries / network timing
- backend changes / model revisions
- tokenization and minor infra variance

Even at temperature 0, you can get drift. That makes MC tests flaky and undermines the "gated pipeline" proof.

### What is "MC repeatability"?

**Repeatability = same repo + same inputs + same config ⇒ identical MC outputs every run.**

The catch: you are using a **stochastic component (LLM)** inside a **deterministic framework (MC gates)**. 

**The framework can be repeatable**, but only if you **freeze the LLM boundary during tests**.

Caching is not "cheating." It is **how you isolate variables**. You are proving: *given a fixed model-output stream, the MC engine is deterministic and gate-enforced.*

### Scope (P0)
This is **NOT** a production performance cache. This is a **repeatability harness**.

Repeatability mode:
- fingerprints the full LLM request payload
- returns a cached response on fingerprint match
- records cache hits/misses in logs
- hard-fails if repeatability mode is enabled and a fingerprint is missing (optional strict mode)

### Design

**Fingerprint key** = SHA256 of canonical JSON containing:
- model id
- endpoint type (responses/chat)
- system prompt + user prompt (or full message list)
- response_format / schema_version (if any)
- temperature, top_p, max_tokens
- seed (if supported by endpoint)
- tool definitions (names + JSON schema) when tools are enabled
- Janus prompt-pack version (critical)

**Storage**
- SQLite file: `data/llm_cache.sqlite3` (portable, diffable, easy to inspect)
- Table: `llm_cache(key TEXT PRIMARY KEY, request_json TEXT, response_json TEXT, created_at TEXT, meta_json TEXT)`

### Why this is the right kind of proof

* You are not proving "LLMs are deterministic." They are not.
* You are proving: **Janus is a governed, testable pipeline** where:
  * stochastic steps are isolated
  * deterministic steps are enforced (MC gates)
  * regressions are catchable (CI fixtures)

That is exactly the story the "kanban cannot advance until gate passes" demo tells.

### Acceptance Criteria

```yaml
card_id: CARD-OSS-P0-004
title: LLM Response Caching for MC Repeatability
phase: P0
lane: New

mc_score: 7.80
mc_target: 8.50
mc_bins:
  signal: 8.0          # Clear technical spec
  memory_short: 7.5    # Caching patterns known
  mental_state: 7.5    # Team understands isolation
  bias_good: 8.0       # Confident in approach
  bias_bad: 8.0        # Aware of LLM non-determinism
  memory_long: 7.5     # Historical patterns available
  knowledge: 8.0       # Caching + fingerprinting well understood
  education: 7.5       # Clear documentation provided
  priority: 9.0        # Critical for repeatability proof
  ethos: 9.0           # Core to CTN black-box solution
  drift: 8.0           # Scope tightly defined
  execution_risk: 7.5  # Moderate implementation complexity

mc_validation_note: |
  LLM caching isolates stochastic boundary. Proves MC framework determinism.
  SQLite cache with SHA256 fingerprints of canonical request JSON.
  Strict mode fails on cache miss. Production mode bypasses cache.

bin_focus: "execution_risk (primary), education (secondary)"
blocking_dependencies:
  - "CARD-OSS-P0-001 (MC determinism - need stable inputs first)"

evidence:
  - "greenfield/backend/blocks/cognitive_block.py"
  - "greenfield/backend/services/chat_command_gateway.py"
  - "greenfield/vaults/stmvault/ingest/OSS_RELEASE_CARDS.md:L289-L380"

contrarian: |
  - Caching could mask real LLM drift issues in production
  - Cache invalidation complexity (when to refresh golden dataset?)
  - Storage overhead if cache grows unbounded
  - False confidence if users misunderstand "repeatability" as "correctness"
  
steelman: |
  - Repeatability mode is TEST ONLY - never runs in production
  - Clear UX messaging: "Repeatability mode tests workflow consistency, not correctness"
  - Cache keys include prompt-pack version to prevent false reuse
  - Golden dataset is version-controlled and manually curated
  - Production mode bypasses cache entirely (default)
  - SQLite makes cache portable and inspectable

owner: Systems Engineering
reviewer: Architecture Team
telemetry_steward: DevOps
status: pending
estimated_duration: 4d

acceptance:
  - "With REPEATABILITY_MODE=true, identical inputs produce byte-identical MC bin scores, gate_trace, stop_gate/eligible_for_action"
  - "Cache hit rate visible in logs"
  - "Cache keys include prompt-pack version"
  - "CI test demonstrates: same fixture run twice → identical output JSON"
  - "Fingerprint includes: model, endpoint, prompts, temperature, top_p, max_tokens, seed, tools, response_format, prompt-pack version"
  - "SQLite storage at data/llm_cache.sqlite3"
  - "Strict mode (REPEATABILITY_STRICT=true) fails on cache miss"
  - "Production mode (default) bypasses cache"

dependencies:
  - CARD-OSS-P0-001
blocks_tasks:
  - CARD-OSS-P0-002
  - CARD-OSS-P1-005

system: cognitive
pillar: core_infrastructure
labels:
  - P0
  - critical
  - repeatability
  - caching

pointer:
  type: "task_spec"
  path: "vaults/stmvault/ingest/OSS_RELEASE_CARDS.md"
  title: "OSS Production Release - Card Plan"
```

### UX / Messaging
Repeatability means **workflow consistency**, not truth or correctness.

**Implementation reference**: See `backend/services/llm_cache.py` for minimal SQLite cache with fingerprinting.

---

## Phase 1: Frontend Production (MCCE: 21d)

### CARD-OSS-P1-001: Cards Board Production UI

```yaml
card_id: CARD-OSS-P1-001
title: Cards Board Production UI
phase: P1
lane: New

mc_score: 7.40
mc_target: 8.50
mc_bins:
  signal: 7.5          # UI requirements clear
  memory_short: 7.5    # V5.5 patterns available
  mental_state: 7.0    # Team familiar with React
  bias_good: 7.5       # Confident in v5.5 base
  bias_bad: 7.0        # Aware of polish gaps
  memory_long: 7.5     # V5.5 code available
  knowledge: 8.0       # React/TypeScript known
  education: 7.0       # Needs component docs
  priority: 8.0        # Core user interface
  ethos: 7.5           # Supports workflow visibility
  drift: 7.5           # Scope well defined
  execution_risk: 7.0  # UI complexity moderate

mc_validation_note: "Cards Board exists in both frontends. Need to consolidate using v5.5 patterns, add MC visualization, lifecycle colors."
bin_focus: "execution_risk (primary), education (secondary)"
blocking_dependencies: []

evidence:
  - "greenfield/frontend/src/components/views/CardsBoardView.tsx"
  - "greenfield/frontend-v5.5/src/components/KanbanBoard.tsx"
  - "greenfield/DELTA_CARDS_V5.5_DESIGN_RESOURCES.md:L30-L70"

contrarian: |
  - Two frontend codebases may cause confusion
  - V5.5 patterns may not fit v6 data models
  - UI polish may delay core functionality
  
steelman: |
  - Use v5.5 as reference, implement in greenfield/frontend
  - Adapter layer (transformers.ts) handles data model differences
  - Prioritize function over form - polish in P3

owner: Frontend Engineering
reviewer: UX Team
telemetry_steward: DevOps
status: pending
estimated_duration: 5d

acceptance:
  - "Cards Board displays all card lifecycle states"
  - "MC score visible per card (gauge or badge)"
  - "Lifecycle colors match v5.5 patterns"
  - "Drag-and-drop between columns (optional)"
  - "Card click opens detail drawer"
  - "Responsive layout (desktop/tablet)"

dependencies: []
blocks_tasks: []

system: frontend
pillar: user_interface
labels:
  - P1
  - high
  - frontend
```

---

### CARD-OSS-P1-002: Insights Dashboard

```yaml
card_id: CARD-OSS-P1-002
title: Insights Dashboard
phase: P1
lane: New

mc_score: 7.30
mc_target: 8.50
mc_bins:
  signal: 7.5          # Requirements clear
  memory_short: 7.0    # Analytics patterns known
  mental_state: 7.0    # Team understands metrics
  bias_good: 7.5       # Confident in approach
  bias_bad: 7.0        # Aware of data gaps
  memory_long: 7.0     # Historical patterns available
  knowledge: 7.5       # Charting libs known
  education: 7.0       # Needs metrics docs
  priority: 8.0        # Key for system visibility
  ethos: 8.0           # Supports CTN transparency
  drift: 7.5           # Scope bounded
  execution_risk: 7.0  # Moderate complexity

mc_validation_note: "Insights page needed for MC trends, agent activity, workflow metrics. Must support repeatability validation visibility."
bin_focus: "knowledge (primary), education (secondary)"
blocking_dependencies: []

evidence:
  - "greenfield/frontend-v5.5/src/components/insights/"
  - "greenfield/backend/systems/telemetry_system.py"

contrarian: |
  - Metrics may be noisy without proper aggregation
  - Real-time updates may impact performance
  - Chart library choice affects bundle size
  
steelman: |
  - Aggregate metrics server-side
  - Poll-based updates (not websocket) for simplicity
  - Use lightweight charting (no D3 overhead)
  - Focus on MC trend over time as primary metric

owner: Frontend Engineering
reviewer: Systems Engineering
telemetry_steward: DevOps
status: pending
estimated_duration: 4d

acceptance:
  - "MC score trend chart (line graph over time)"
  - "Agent activity summary (cards processed per agent)"
  - "Workflow completion rate metric"
  - "Repeatability score display (% exact matches)"
  - "Data refresh every 30 seconds"

dependencies: []
blocks_tasks: []

system: frontend
pillar: user_interface
labels:
  - P1
  - high
  - frontend
```

---

### CARD-OSS-P1-003: Chat Interface Production

```yaml
card_id: CARD-OSS-P1-003
title: Chat Interface Production
phase: P1
lane: New

mc_score: 7.50
mc_target: 8.50
mc_bins:
  signal: 7.5          # Chat requirements clear
  memory_short: 8.0    # Chat patterns well known
  mental_state: 7.5    # Team familiar with chat UX
  bias_good: 7.5       # Confident in gateway
  bias_bad: 7.0        # Aware of command edge cases
  memory_long: 7.5     # V5.5 chat available
  knowledge: 8.0       # Chat patterns known
  education: 7.0       # Needs command docs
  priority: 8.5        # Primary user interface
  ethos: 8.0           # Core interaction model
  drift: 7.5           # Scope well defined
  execution_risk: 7.5  # Integration complexity

mc_validation_note: "Chat is primary card creation interface. Must integrate with chat_command_gateway, support command prefill, show MC scores in responses."
bin_focus: "execution_risk (primary), education (secondary)"
blocking_dependencies:
  - "CARD-OSS-P0-003 (Agent orchestration)"

evidence:
  - "greenfield/frontend-v5.5/src/components/chat/"
  - "greenfield/backend/services/chat_command_gateway.py"
  - "greenfield/backend/routers/chat.py"

contrarian: |
  - Command parsing may have edge cases
  - Agent routing complexity
  - Response formatting inconsistencies
  
steelman: |
  - Use existing chat_command_registry patterns
  - Validate commands before execution
  - Standardized response format with MC score
  - Error messages include recovery suggestions

owner: Frontend Engineering
reviewer: Systems Engineering
telemetry_steward: DevOps
status: pending
estimated_duration: 5d

acceptance:
  - "Chat input with command suggestions"
  - "Card creation via 'create card \"title\"' command"
  - "MC score displayed in card creation response"
  - "Command history (up arrow recall)"
  - "Agent routing visible in response metadata"
  - "Error handling with user-friendly messages"

dependencies:
  - CARD-OSS-P0-003
blocks_tasks: []

system: frontend
pillar: user_interface
labels:
  - P1
  - high
  - frontend
```

---

### CARD-OSS-P1-004: Systems Status Page

```yaml
card_id: CARD-OSS-P1-004
title: Systems Status Page
phase: P1
lane: New

mc_score: 7.60
mc_target: 8.50
mc_bins:
  signal: 8.0          # Requirements clear
  memory_short: 7.5    # Status patterns known
  mental_state: 7.5    # Team understands systems
  bias_good: 7.5       # Confident in approach
  bias_bad: 7.0        # Aware of complexity
  memory_long: 7.5     # System docs available
  knowledge: 8.0       # Patterns well known
  education: 7.5       # Needs system docs
  priority: 7.5        # Useful for debugging
  ethos: 8.0           # Supports transparency
  drift: 8.0           # Scope bounded
  execution_risk: 7.0  # Low-moderate complexity

mc_validation_note: "Systems page shows LEGO blocks, agents, MC engine status. Essential for debugging and transparency."
bin_focus: "education (primary), execution_risk (secondary)"
blocking_dependencies: []

evidence:
  - "greenfield/backend/systems/lego_registry.py"
  - "greenfield/backend/agents/*.py"
  - "greenfield/backend/systems/mc_engine.py"

contrarian: |
  - Too much detail may overwhelm users
  - Real-time status may be expensive
  - Block dependencies may be complex to visualize
  
steelman: |
  - Collapsible sections for detail levels
  - Status polling (not real-time streaming)
  - Simple list view, not graph visualization
  - Health indicators (green/yellow/red)

owner: Frontend Engineering
reviewer: Systems Engineering
telemetry_steward: DevOps
status: pending
estimated_duration: 3d

acceptance:
  - "LEGO blocks list with status indicators"
  - "Agent crew status (active/idle/error)"
  - "MC engine status (operational/degraded)"
  - "Vault status (STM/LTM counts)"
  - "API health endpoint integration"

dependencies: []
blocks_tasks: []

system: frontend
pillar: user_interface
labels:
  - P1
  - high
  - frontend
```

---

### CARD-OSS-P1-005: Workflow Test Page

```yaml
card_id: CARD-OSS-P1-005
title: Workflow Test Page
phase: P1
lane: New

mc_score: 7.20
mc_target: 8.50
mc_bins:
  signal: 7.5          # Requirements clear
  memory_short: 7.0    # Test UI patterns known
  mental_state: 7.0    # Team understands goal
  bias_good: 7.5       # Confident in approach
  bias_bad: 7.0        # Aware of edge cases
  memory_long: 7.0     # Testing history available
  knowledge: 7.5       # Test patterns known
  education: 6.5       # Needs user guide
  priority: 9.0        # Critical for repeatability proof
  ethos: 9.0           # Core to CTN mission
  drift: 7.5           # Scope bounded
  execution_risk: 7.5  # Integration complexity

mc_validation_note: "This is THE page that proves repeatability. User enters card request, runs N times, sees MC score consistency."
bin_focus: "education (primary), execution_risk (secondary)"
blocking_dependencies:
  - "CARD-OSS-P0-001 (MC determinism)"
  - "CARD-OSS-P0-002 (Test harness)"
  - "CARD-OSS-P0-003 (Agent orchestration)"

evidence:
  - "greenfield/tests/test_e2e_workflows.py"
  - "greenfield/docs/workflows/MC_GATE_VECTOR_MCCE_IMPLEMENTATION.md"

contrarian: |
  - Users may misunderstand what "repeatability" means
  - Large N runs may be slow
  - UI may be too technical for non-developers
  
steelman: |
  - Clear explanation of repeatability on page
  - Default N=5, configurable up to 100
  - Progress indicator during runs
  - Simple pass/fail with optional detail view

owner: Frontend Engineering
reviewer: QA Engineering
telemetry_steward: DevOps
status: pending
estimated_duration: 4d

acceptance:
  - "Input field for card request (e.g., 'make me a window card')"
  - "Run count selector (5, 10, 25, 50, 100)"
  - "Execute button triggers backend test harness"
  - "Results show: runs completed, MC scores per run, variance"
  - "Pass/Fail indicator (pass = 0 variance)"
  - "Export results as JSON"

dependencies:
  - CARD-OSS-P0-001
  - CARD-OSS-P0-002
  - CARD-OSS-P0-003
blocks_tasks: []

system: frontend
pillar: user_interface
labels:
  - P1
  - high
  - frontend
  - repeatability
```

---

## Phase 2: OSS Production (MCCE: 12d)

### CARD-OSS-P2-001: API Documentation & OpenAPI

```yaml
card_id: CARD-OSS-P2-001
title: API Documentation & OpenAPI
phase: P2
lane: New

mc_score: 7.50
mc_target: 8.50
mc_bins:
  signal: 8.0
  memory_short: 7.5
  mental_state: 7.5
  bias_good: 7.5
  bias_bad: 7.0
  memory_long: 7.5
  knowledge: 8.0
  education: 7.0
  priority: 7.5
  ethos: 7.5
  drift: 8.0
  execution_risk: 7.0

mc_validation_note: "FastAPI auto-generates OpenAPI. Need to enhance descriptions, add examples, publish to docs site."
bin_focus: "education (primary)"
blocking_dependencies: []

owner: Technical Writing
reviewer: Systems Engineering
status: pending
estimated_duration: 3d

acceptance:
  - "OpenAPI spec at /docs with all endpoints documented"
  - "Each endpoint has description, request/response examples"
  - "Authentication requirements documented"
  - "Error codes documented with recovery steps"

system: documentation
pillar: oss_release
labels:
  - P2
  - medium
```

---

### CARD-OSS-P2-002: OSS Packaging & Distribution

```yaml
card_id: CARD-OSS-P2-002
title: OSS Packaging & Distribution
phase: P2
lane: New

mc_score: 7.40
mc_target: 8.50
mc_bins:
  signal: 7.5
  memory_short: 7.0
  mental_state: 7.0
  bias_good: 7.5
  bias_bad: 7.0
  memory_long: 7.0
  knowledge: 7.5
  education: 7.0
  priority: 8.0
  ethos: 8.0
  drift: 7.5
  execution_risk: 7.5

mc_validation_note: "Package for PyPI (backend) and npm (frontend). Ensure clean dependency list, version tagging."
bin_focus: "execution_risk (primary)"
blocking_dependencies: []

owner: DevOps
reviewer: Systems Engineering
status: pending
estimated_duration: 3d

acceptance:
  - "Backend installable via `pip install janus-ctn`"
  - "Frontend buildable via `npm run build`"
  - "Version tagged (semver)"
  - "Changelog generated"
  - "GitHub release created"

system: devops
pillar: oss_release
labels:
  - P2
  - medium
```

---

### CARD-OSS-P2-003: E2E Test Suite

```yaml
card_id: CARD-OSS-P2-003
title: E2E Test Suite
phase: P2
lane: New

mc_score: 7.30
mc_target: 8.50
mc_bins:
  signal: 7.5
  memory_short: 7.5
  mental_state: 7.0
  bias_good: 7.5
  bias_bad: 7.0
  memory_long: 7.0
  knowledge: 7.5
  education: 7.0
  priority: 8.0
  ethos: 8.0
  drift: 7.5
  execution_risk: 7.5

mc_validation_note: "Full E2E tests covering card creation, MC scoring, workflow completion. Uses Playwright or Cypress."
bin_focus: "execution_risk (primary)"
blocking_dependencies:
  - "CARD-OSS-P1-001"
  - "CARD-OSS-P1-003"

owner: QA Engineering
reviewer: Frontend Engineering
status: pending
estimated_duration: 4d

acceptance:
  - "E2E test: Create card via chat → verify MC score"
  - "E2E test: View card in board → verify lifecycle"
  - "E2E test: Run workflow test → verify repeatability"
  - "CI integration with test results"
  - "Test coverage report"

system: testing
pillar: quality_assurance
labels:
  - P2
  - medium
```

---

### CARD-OSS-P2-004: Docker Containerization

```yaml
card_id: CARD-OSS-P2-004
title: Docker Containerization
phase: P2
lane: New

mc_score: 7.60
mc_target: 8.50
mc_bins:
  signal: 8.0
  memory_short: 7.5
  mental_state: 7.5
  bias_good: 7.5
  bias_bad: 7.0
  memory_long: 7.5
  knowledge: 8.0
  education: 7.5
  priority: 7.5
  ethos: 7.5
  drift: 8.0
  execution_risk: 7.0

mc_validation_note: "Dockerfile for backend, frontend, and docker-compose for full stack. Enables one-command deployment."
bin_focus: "education (primary)"
blocking_dependencies: []

owner: DevOps
reviewer: Systems Engineering
status: pending
estimated_duration: 2d

acceptance:
  - "Dockerfile.backend builds and runs"
  - "Dockerfile.frontend builds and serves"
  - "docker-compose.yml starts full stack"
  - "`docker-compose up` works on fresh machine"
  - "Environment variables documented"

system: devops
pillar: oss_release
labels:
  - P2
  - medium
```

---

## Phase 3: Documentation (MCCE: 3d)

### CARD-OSS-P3-001: README & Quickstart Guide

```yaml
card_id: CARD-OSS-P3-001
title: README & Quickstart Guide
phase: P3
lane: New

mc_score: 7.50
mc_target: 8.50
mc_bins:
  signal: 8.0
  memory_short: 7.5
  mental_state: 7.5
  bias_good: 7.5
  bias_bad: 7.0
  memory_long: 7.5
  knowledge: 8.0
  education: 7.0
  priority: 7.0
  ethos: 8.0
  drift: 8.0
  execution_risk: 6.5

mc_validation_note: "OSS README with project overview, quickstart (5 minute setup), architecture overview."
bin_focus: "education (primary)"
blocking_dependencies:
  - "CARD-OSS-P2-004"

owner: Technical Writing
reviewer: Systems Engineering
status: pending
estimated_duration: 2d

acceptance:
  - "README.md with project description"
  - "5-minute quickstart section"
  - "Architecture diagram"
  - "Link to full documentation"
  - "Badges (build status, license, version)"

system: documentation
pillar: oss_release
labels:
  - P3
  - low
```

---

### CARD-OSS-P3-002: License & Contributing Docs

```yaml
card_id: CARD-OSS-P3-002
title: License & Contributing Docs
phase: P3
lane: New

mc_score: 7.80
mc_target: 8.50
mc_bins:
  signal: 8.5
  memory_short: 7.5
  mental_state: 8.0
  bias_good: 7.5
  bias_bad: 7.0
  memory_long: 8.0
  knowledge: 8.0
  education: 7.5
  priority: 7.0
  ethos: 8.0
  drift: 8.0
  execution_risk: 6.0

mc_validation_note: "Standard OSS files: LICENSE, CONTRIBUTING.md, CODE_OF_CONDUCT.md."
bin_focus: "education (primary)"
blocking_dependencies: []

owner: Legal/Technical Writing
reviewer: Project Lead
status: pending
estimated_duration: 1d

acceptance:
  - "LICENSE file (MIT or Apache 2.0)"
  - "CONTRIBUTING.md with PR guidelines"
  - "CODE_OF_CONDUCT.md"
  - "SECURITY.md with disclosure policy"

system: documentation
pillar: oss_release
labels:
  - P3
  - low
```

---

## MCCE Summary

| Phase | Cards | Total MCCE | Cumulative |
|-------|-------|------------|------------|
| P0 - Critical | 4 | 16d | 16d |
| P1 - Frontend | 5 | 21d | 37d |
| P2 - OSS Prod | 4 | 12d | 49d |
| P3 - Docs | 2 | 3d | **52d** |

**Parallelization Opportunities**:
- P0-003 and P0-004 can run in parallel after P0-001
- P1 cards can run in parallel after P0 completes
- P2-001, P2-002, P2-004 can run in parallel
- P3 can run in parallel with P2

**Realistic Timeline**: 
- Sequential: ~11 weeks
- With parallelization: ~7 weeks (2 frontend devs, 1 backend dev)

---

## Dependency Graph

```
P0-001 (MC Determinism)
    ├─> P0-004 (LLM Caching) ──> P0-002 (Test Harness)
    │                                   └─> P1-005 (Workflow Test Page)
    └─> P0-002 (Test Harness)
    
P0-003 (Agent Orchestration)
    └─> P1-003 (Chat Interface)
    └─> P1-005 (Workflow Test Page)

P0-004 (LLM Caching)
    └─> P0-002 (Test Harness)
    └─> P1-005 (Workflow Test Page)

P1-001 (Cards Board) ─────┐
P1-002 (Insights) ────────┼─> P2-003 (E2E Tests)
P1-003 (Chat Interface) ──┘

P2-004 (Docker) ──> P3-001 (README)
```

---

## Next Steps

1. **Validate**: Review this card plan against North Star
2. **Prioritize**: Confirm P0 cards are correctly identified as blockers
3. **Assign**: Allocate owners to cards
4. **Execute**: Begin P0-001 (MC Determinism) immediately
5. **Track**: Use Cards Board to track progress

---

**Document Status**: Draft for Review  
**Created By**: AI Agent  
**Review Required**: Project Lead
