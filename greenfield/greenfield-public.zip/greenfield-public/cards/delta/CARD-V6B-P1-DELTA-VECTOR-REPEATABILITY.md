# CARD-V6B-P1-DELTA-VECTOR-REPEATABILITY

**Card ID**: CARD-V6B-P1-DELTA-VECTOR-REPEATABILITY
**Title**: Vector-Based Repeatability (Not 1:1 Exact Match)
**Type**: delta
**Phase**: P1
**Status**: in_progress
**Created**: 2025-12-15
**MC Score**: 8.60

---

## Summary

Shift repeatability system from impossible "1:1 exact match" to achievable "guaranteed vector" approach. AI systems cannot guarantee byte-for-byte identical outputs, but we can guarantee consistent outcomes, gate decisions, and workflow directions.

---

## MC Scoring

**MC Score**: 8.60 (Target: 8.50)

### MC Bins (12-bin breakdown)
- **signal**: 8.7 - Clear signal: 1:1 impossible with AI
- **memory_short**: 8.6 - Recent work on repeatability harness
- **mental_state**: 8.5 - Team aligned on vector approach
- **bias_good**: 8.8 - Realistic approach enables actual repeatability
- **bias_bad**: 8.4 - Risk: May need tolerance thresholds
- **memory_long**: 8.6 - Aligns with long-term AI system design
- **knowledge**: 9.0 - Standard AI system design pattern
- **education**: 8.5 - Need to document vector concept
- **priority**: 9.0 - Critical for realistic repeatability
- **ethos**: 8.7 - Honest about AI limitations
- **drift**: 8.5 - Focused scope change
- **execution_risk**: 8.3 - Low risk, conceptual shift

---

## Problem

Current repeatability system (CARD-OSS-P0-004) attempts to achieve **1:1 exact match**:
- Same input → byte-for-byte identical output
- Requires LLM response caching to freeze stochastic boundary
- **This is impossible with AI** - LLMs are inherently non-deterministic

**Reality**: Even with caching, you cannot guarantee:
- Exact same token sequences
- Exact same reasoning paths
- Exact same intermediate outputs

**What we CAN guarantee**:
- **Gate decisions** (pass/hold) are consistent
- **Workflow direction** (promote LTM, route to Caretaker) is consistent
- **MC score ranges** are within tolerance
- **System behavior** follows predictable vectors

---

## Solution: Guaranteed Vector Approach

### Core Principle

**Vector Repeatability** = Same input → Same **direction/outcome**, not same exact output.

### What Gets Guaranteed

1. **Gate Decisions** (Deterministic)
   - `gate_result: "pass" | "hold"` - Always consistent for same MC score
   - `promote_ltm: bool` - Always same for score >= 8.5
   - `route_caretaker: bool` - Always same for score < 7.0

2. **MC Score Ranges** (Within Tolerance)
   - MC score within ±0.1 tolerance
   - Gate decision stable across runs
   - Bin scores within ±0.2 tolerance

3. **Workflow Direction** (Consistent)
   - Same card → same lifecycle path
   - Same MC score → same routing decision
   - Same context → same agent assignment

4. **System Behavior** (Predictable)
   - Assembly line order is deterministic
   - Sentinel blocks are consistent
   - Memory promotion rules are deterministic

### What Does NOT Get Guaranteed

- Exact LLM response text
- Exact reasoning chain
- Exact intermediate outputs
- Exact token sequences

---

## Implementation Changes

### 1. Update Repeatability Contract

**Before** (Impossible):
```
Same input → Exact same output (byte-for-byte)
```

**After** (Achievable):
```
Same input → Same gate decision + MC score within tolerance + Same workflow direction
```

### 2. Vector Validation Function

Add `validate_vector_repeatability()` that checks:
- Gate decision consistency
- MC score within tolerance (±0.1)
- Workflow direction consistency
- System behavior alignment

### 3. Tolerance Configuration

Add configurable tolerances:
```python
VECTOR_REPEATABILITY_TOLERANCE = {
    "mc_score": 0.1,      # MC score can vary ±0.1
    "bin_score": 0.2,     # Bin scores can vary ±0.2
    "gate_decision": 0.0,  # Gate decision must be exact
    "workflow_direction": 0.0  # Workflow must be exact
}
```

### 4. Update Tests

Change from:
```python
assert output1 == output2  # Exact match (fails with AI)
```

To:
```python
assert validate_vector_repeatability(output1, output2)  # Vector match
```

---

## Acceptance Criteria

- [ ] Update repeatability contract documentation
- [ ] Add `validate_vector_repeatability()` function
- [ ] Add tolerance configuration
- [ ] Update repeatability tests to use vector validation
- [ ] Update CARD-OSS-P0-004 documentation
- [ ] Add vector repeatability examples

---

## Evidence

**Current System**:
- `greenfield/backend/services/llm_cache.py` - Attempts exact match caching
- `greenfield/tests/test_repeatability_cache.py` - Tests for exact matches
- `greenfield/vaults/stmvault/ingest/OSS_RELEASE_CARDS.md` - Defines 1:1 contract

**MC Engine Already Supports Vectors**:
- `greenfield/backend/systems/mc_engine.py` - Gate decisions are deterministic
- Gate thresholds are fixed (8.5, 7.0, 7.5, 5.0)
- Workflow routing is deterministic based on gate scores

---

## Contrarian Analysis

**Potential Issues**:
1. **Tolerance Too Loose**: ±0.1 might allow different gate decisions
2. **Tolerance Too Tight**: ±0.1 might be too strict for AI variance
3. **User Confusion**: Users might expect exact matches

**Alternatives Considered**:
- Keep exact match for non-LLM components (MC engine, gates)
- Use statistical validation (mean, std dev)
- Use semantic similarity instead of exact match

**Hidden Assumptions**:
- MC score variance is normally distributed
- Gate decisions are stable at boundaries
- Workflow direction is more important than exact outputs

---

## Steel-Man Approach

**Strengthened Arguments**:
1. **Realistic**: Acknowledges AI limitations honestly
2. **Achievable**: Vector repeatability is actually possible
3. **Useful**: Gate decisions and workflow direction are what matter
4. **Testable**: Can validate vectors with tolerance checks

**Risk Mitigation**:
- Gate decision tolerance is 0.0 (must be exact)
- MC score tolerance is small (±0.1)
- Workflow direction is deterministic
- Clear documentation of what's guaranteed vs. not

**Enhanced Criteria**:
- Vector validation function implemented
- Tolerance configuration documented
- Tests updated to use vector validation
- Documentation updated to reflect vector approach

---

## Dependencies

**Blocks**: None  
**Blocked By**: None  
**Related Cards**:
- CARD-OSS-P0-004 (LLM Response Caching) - Update to vector approach
- CARD-OSS-P0-002 (Repeatability Test Harness) - Update tests
- CARD-V6B-P1-COMP-MC_ENGINE (MC Engine) - Gate decisions are deterministic

---

## Metadata

**Owner**: Systems Engineering  
**Reviewer**: Architecture Team  
**Telemetry Steward**: DevOps  
**System**: v6_greenfield  
**Pillar**: repeatability  
**Labels**: 
  - P1
  - delta
  - repeatability
  - high_priority
  - v6_greenfield
  - ai_systems

---

## Breadcrumb Pointer

**Type**: task_spec  
**Path**: `vaults/stmvault/cards/CARD-V6B-P1-DELTA-VECTOR-REPEATABILITY.md`  
**Title**: Vector-Based Repeatability - Full Context

---

## Next Steps

1. **Implement Vector Validation**: ✅ Complete
   - Created `validate_vector_repeatability()` function
   - Added tolerance configuration with guard bands
   - Updated validation to check gate decision consistency

2. **Prove Decision Corridor (Finite, Auditable)**: ✅ Complete
   - Created `ACTION_PERMISSION_MATRIX.md` defining allowed actions per lane
   - Mapped deterministic routing logic (Score -> Gate -> Lane)

3. **Prove Statistical Stability**: ✅ Complete
   - Created `scripts/measure_mc_stability.py` harness
   - Validated lane stability and score variance

4. **Generate Proof Packet**: ✅ Complete
   - Created `scripts/generate_proof_packet.py`
   - Generated `docs/proof_packets/latest_proof.md` (investor-grade report)

5. **Update Documentation**:
   - ✅ Created `VECTOR_SPACE_NARROWING_ANALYSIS.md`
   - Update CARD-OSS-P0-004
   - Update repeatability contract
   - Add vector repeatability examples

## Related Analysis

See `docs/workflows/VECTOR_SPACE_NARROWING_ANALYSIS.md` for detailed analysis of:
- How Doctrine + MC Template + Gates + Lanes narrow vector space by 99.64%
- How MC heuristic variance is bounded by deterministic gate decisions
- How human oversight + reasoning surfacing keeps system on vector

See `docs/workflows/ACTION_PERMISSION_MATRIX.md` for:
- Finite list of permitted actions per agent
- Deterministic routing tables

See `docs/proof_packets/latest_proof.md` for:
- Empirical proof of 100% lane stability
- Statistical variance measurements for MC scores

---

**Status**: ⚠️ **IN PROGRESS**  
**MC Validation**: ✅ PASS (8.60 ≥ 8.50)

